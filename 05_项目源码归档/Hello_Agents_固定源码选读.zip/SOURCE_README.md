# Hello-Agents 固定源码选读

来源：Datawhale / datawhalechina/hello-agents
固定提交：36f583c233ea5cee4537ef93455702b55053af18
原始入口：https://github.com/datawhalechina/hello-agents/tree/36f583c233ea5cee4537ef93455702b55053af18

本包只包含顶层LICENSE.txt、第十二章README和三个评测/数据生成示例、第十四章研究助手pyproject.toml，共6个原始路径文件；它是通用教材和评测方法参考，不是已核成功候选人的本人求职项目，不证明任何SSP录用。原始及归档SHA256、获取状态和修改清单见SOURCE_MANIFEST.json。

顶层许可证为CC BY-NC-SA 4.0，原LICENSE.txt保留；所选第十四章研究助手pyproject.toml自行声明MIT。不同范围分别记录，不以一个章节的声明概括全部软件许可，也不以顶层CC概括每个子项目许可。来源及署名保留，仅用于当前本地研究，未对外发布。

本包不是完整或可构建仓库。没有归档整仓图片、共创项目、配置、模型、数据集和依赖；也没有安装依赖、构建、运行测试、调用BFCL命令、模型、搜索或裁判服务。README中的预期输出和示例样本不代表本次运行成绩。

邮箱、电话和常见凭据模式只在内存筛查；命中时先脱敏再写文件，只记录类型和数量，不保存原始命中值。该模式筛查可能覆盖示例字符串，也不构成全仓隐私审计。
