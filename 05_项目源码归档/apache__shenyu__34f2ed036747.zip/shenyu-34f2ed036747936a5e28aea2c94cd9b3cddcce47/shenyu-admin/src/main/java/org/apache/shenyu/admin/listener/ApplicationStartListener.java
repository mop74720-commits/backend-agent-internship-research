/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.shenyu.admin.listener;

import jakarta.annotation.Resource;
import org.apache.shenyu.admin.mode.ShenyuRunningModeService;
import org.apache.shenyu.common.utils.IpUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.context.WebServerInitializedEvent;
import org.springframework.boot.web.servlet.context.ServletWebServerInitializedEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;


/**
 * ApplicationStartListener.
 */
@Component
public class ApplicationStartListener implements ApplicationListener<WebServerInitializedEvent> {
    
    @Value("${server.servlet.context-path:}")
    private String contextPath;
    
    @Resource
    private ShenyuRunningModeService shenyuRunningModeService;
    
    @Override
    public void onApplicationEvent(final WebServerInitializedEvent event) {
        if (event instanceof ServletWebServerInitializedEvent servletEvent
                && "management".equals(servletEvent.getApplicationContext().getServerNamespace())) {
            // the management server is a side-channel, not another Admin instance:
            // starting the running mode again would re-run checker setup and schedule
            // an extra election task with the management port
            return;
        }
        int port = event.getWebServer().getPort();
        final String host = IpUtils.getHost();
        
        shenyuRunningModeService.start(host, port, contextPath);
    }
}
