# -*- coding: utf-8 -*-
"""Example of Moonshot model calls with MoonshotMultiAgentFormatter and
image input."""
import asyncio
import os

from _utils import stream_and_collect
from agentscope.formatter import MoonshotMultiAgentFormatter
from agentscope.message import Msg, TextBlock, DataBlock, URLSource
from agentscope.model import MoonshotChatModel
from agentscope.credential import MoonshotCredential

TEST_IMAGE_URL = (
    "https://help-static-aliyun-doc.aliyuncs.com/file-manage"
    "-files/zh-CN/20241022/emyrja/dog_and_girl.jpeg"
)


async def example_multiagent_image_url() -> None:
    """Multi-agent conversation where Alice shares an image for the group."""
    formatter = MoonshotMultiAgentFormatter()

    model = MoonshotChatModel(
        credential=MoonshotCredential(
            api_key=os.environ["MOONSHOT_API_KEY"],
        ),
        model="kimi-k2.6",
        stream=True,
        context_size=262_144,
        parameters=MoonshotChatModel.Parameters(thinking_enable=True),
        formatter=formatter,
    )

    image_block = DataBlock(
        source=URLSource(url=TEST_IMAGE_URL, media_type="image/jpeg"),
    )

    msgs = [
        Msg(
            name="system",
            content=[
                TextBlock(
                    text=(
                        "You are a helpful moderator in a group chat. "
                        "Summarize what the image shows and what the "
                        "participants said."
                    ),
                ),
            ],
            role="system",
        ),
        Msg(
            name="alice",
            content=[
                TextBlock(
                    text="Hey everyone, look at this cute photo I took!",
                ),
                image_block,
            ],
            role="user",
        ),
        Msg(
            name="bob",
            content=[
                TextBlock(text="Aww, that's adorable! Where was this taken?"),
            ],
            role="assistant",
        ),
        Msg(
            name="alice",
            content=[TextBlock(text="At the local park yesterday.")],
            role="user",
        ),
        Msg(
            name="moderator",
            content=[
                TextBlock(
                    text="Please summarize the image content and the "
                    "conversation in one paragraph.",
                ),
            ],
            role="user",
        ),
    ]

    print("=== Multi-Agent + Multimodal Call ===")
    await stream_and_collect(await model(msgs))


if __name__ == "__main__":
    asyncio.run(example_multiagent_image_url())
