//
//  Copyright 2026 The InfiniFlow Authors. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

// Package component contains e2e fixture stubs used directly by tests.
//
// The test fixtures under internal/agent/dsl/testdata reference
// fixture-backed component names that are registered here: Generate,
// Iteration, and IterationItem. The fixture stub bodies are deliberately trivial — they
// echo a stable, template-friendly output shape and never call
// the network or DB. The contract is "registered, non-panicking,
// and produces outputs downstream templates can resolve", not
// "do something useful".
//
// The fixture names were chosen by enumerating the component_name
// values in the testdata fixtures (see the `examples` var in
// internal/agent/canvas/dsl_examples_test.go). Keeping the list
// in sync with the fixture set is a single-source-of-truth
// discipline: if a new fixture references a name not in this file,
// the e2e test's compile+invoke loop will surface the gap with a
// clear factory error.
package component

import (
	"context"
	"fmt"

	"gorm.io/gorm"
)

// ----- Generate -----

const componentNameGenerate = "Generate"

// GenerateStub is a fixture stub for the legacy "Generate"
// component name. The Python DSL used "Generate" for a
// non-tool-using chat call; the Go port renamed the canonical
// name to "LLM" (see llm.go) and registers "Generate" here as a
// thin alias that routes to the LLM factory. Test fixtures that
// still reference the old name compile and run identically to
// LLM-backed flows.
type GenerateStub struct {
	inner *LLMComponent
}

// NewGenerateStub constructs a Generate stub. params is forwarded to
// the LLM factory so Generate and LLM share the same param surface
// (llm_id, prompt, temperature, message_history_window_size, cite).
func NewGenerateStub(params map[string]any) (Component, error) {
	llmParams, err := buildLLMParamFromV1Params(params)
	if err != nil {
		return nil, fmt.Errorf("Generate: %w", err)
	}
	return &GenerateStub{inner: NewLLMComponent(llmParams)}, nil
}

// Name returns the registered component name.
func (g *GenerateStub) Name() string { return componentNameGenerate }

// Invoke delegates to the LLM component.
func (g *GenerateStub) Invoke(ctx context.Context, db *gorm.DB, inputs map[string]any) (map[string]any, error) {
	return g.inner.Invoke(ctx, db, inputs)
}

// Stream delegates to the LLM component.
func (g *GenerateStub) Stream(ctx context.Context, db *gorm.DB, inputs map[string]any) (<-chan map[string]any, error) {
	return g.inner.Stream(ctx, db, inputs)
}

// Inputs returns the DSL param surface. Matches LLM's surface
// plus the v1-only message_history_window_size and cite.
func (g *GenerateStub) Inputs() map[string]string {
	return map[string]string{
		"llm_id":                      "LLM model identifier.",
		"prompt":                      "System / user prompt template.",
		"temperature":                 "Sampling temperature (0 = greedy).",
		"message_history_window_size": "How many prior turns to include.",
		"cite":                        "Whether to include source citations in the output.",
	}
}

// Outputs returns the public output surface.
func (g *GenerateStub) Outputs() map[string]string {
	return map[string]string{
		"content": "Assistant text response.",
		"model":   "Resolved model identifier.",
		"tokens":  "Token count for the call.",
	}
}

// buildLLMParamFromV1Params converts the test-fixture Generate params shape
// into the LLMParam shape. legacy fixtures store the user prompt under "prompt"
// (not "user_prompt") and the system prompt is sometimes empty (the
// system role is often folded into "prompt"). We map: prompt →
// UserPrompt, llm_id → ModelID, temperature → Temperature,
// base_url → BaseURL, api_key → APIKey.
func buildLLMParamFromV1Params(p map[string]any) (LLMParam, error) {
	out := LLMParam{}
	if v, ok := p["llm_id"].(string); ok {
		out.ModelID = v
	}
	if v, ok := p["prompt"].(string); ok {
		out.UserPrompt = v
	}
	if v, ok := p["temperature"].(float64); ok {
		out.Temperature = &v
	}
	if v, ok := p["max_tokens"].(float64); ok {
		i := int(v)
		out.MaxTokens = &i
	}
	if v, ok := p["api_key"].(string); ok {
		out.APIKey = v
	}
	if v, ok := p["base_url"].(string); ok {
		out.BaseURL = v
	}
	return out, nil
}

// ----- Iteration / IterationItem (alias to Parallel) -----

// componentNameIteration / componentNameIterationItem are the legacy
// v1 names that the front-end may still emit. The Go port's runtime
// uses "Parallel" for the same concept; the two stubs registered
// below therefore alias through to the real Parallel factory. Any
// caller that bypasses dsl.NormalizeForCanvas (and so still sees the
// legacy names) gets Parallel behaviour for free; the canonical
// path through the decoder boundary uses dsl.NormalizeForCanvas's
// fold step (see internal/agent/dsl/normalize.go) to rewrite
// "Iteration" -> "Parallel" and drop LoopItem/IterationItem nodes
// before they reach the registry.
const (
	componentNameIteration     = "Iteration"
	componentNameIterationItem = "IterationItem"
)

// IterationStub delegates every call to the real Parallel
// component. Existence of this type is purely for registry
// compatibility (the v1 "Iteration" name must resolve) and for
// test introspection (RegisteredNames() still returns "Iteration"
// so parallel_test.go assertions do not churn).
type IterationStub struct {
	inner Component
}

// NewIterationStub constructs an Iteration alias by routing to the
// Parallel factory. Any error from the inner factory is surfaced
// unchanged.
func NewIterationStub(params map[string]any) (Component, error) {
	inner, err := New(componentNameParallel, params)
	if err != nil {
		return nil, err
	}
	return &IterationStub{inner: inner}, nil
}

// Name returns the registered (legacy) component name.
func (i *IterationStub) Name() string { return componentNameIteration }

// Invoke delegates to the inner Parallel component.
func (i *IterationStub) Invoke(ctx context.Context, db *gorm.DB, inputs map[string]any) (map[string]any, error) {
	return i.inner.Invoke(ctx, db, inputs)
}

// Stream delegates to the inner Parallel component.
func (i *IterationStub) Stream(ctx context.Context, db *gorm.DB, inputs map[string]any) (<-chan map[string]any, error) {
	return i.inner.Stream(ctx, db, inputs)
}

// Inputs mirrors Parallel's surface for introspection.
func (i *IterationStub) Inputs() map[string]string {
	return i.inner.Inputs()
}

// Outputs mirrors Parallel's surface for introspection.
func (i *IterationStub) Outputs() map[string]string {
	return i.inner.Outputs()
}

// IterationItemStub is a fixture stub for the body node of an
// Iteration. The real wiring (parent_id → child routing) is
// engine-side; the stub itself is a passthrough.
type IterationItemStub struct{}

// NewIterationItemStub constructs an IterationItem stub.
func NewIterationItemStub(_ map[string]any) (Component, error) {
	return &IterationItemStub{}, nil
}

// Name returns the registered component name.
func (it *IterationItemStub) Name() string { return componentNameIterationItem }

// Invoke returns a passthrough empty map.
func (it *IterationItemStub) Invoke(_ context.Context, _ *gorm.DB, _ map[string]any) (map[string]any, error) {
	return map[string]any{"result": ""}, nil
}

// Stream mirrors Invoke.
func (it *IterationItemStub) Stream(ctx context.Context, db *gorm.DB, inputs map[string]any) (<-chan map[string]any, error) {
	out, err := it.Invoke(ctx, db, inputs)
	if err != nil {
		return nil, err
	}
	ch := make(chan map[string]any, 1)
	ch <- out
	close(ch)
	return ch, nil
}

// Inputs returns the DSL param surface.
func (it *IterationItemStub) Inputs() map[string]string {
	return map[string]string{
		"item": "The current iteration item, injected by the Iteration parent.",
	}
}

// Outputs returns the public output surface.
func (it *IterationItemStub) Outputs() map[string]string {
	return map[string]string{
		"result": "Body result for the current item.",
	}
}

// ----- registrations -----

// One init per file keeps the registrations grouped and visible.
// Each Register call panics on a duplicate (the registry enforces
// uniqueness), so accidental double-registration in a later refactor
// surfaces as a panic at init time, not as a silent override.
func init() {
	// Retrieval still requires its specialized adapter.
	Register(componentNameRetrieval, newRetrievalComponent)
	// The agent canvas uses both a PascalCase "SearchMyDataset"
	// and the original snake_case typo "search_my_dateset"; an
	// intermediate "search_my_dataset" form also exists in some
	// legacy DSLs. The Universe B tool registry accepts all
	// three (see internal/agent/tool/registry.go); Universe A
	// must mirror that surface or older DSLs fall back to
	// "unknown component" at buildNodeBody time. All four
	// registrations resolve to the same wrapper, so swapping
	// the factory in the future only needs to happen once.
	Register("SearchMyDataset", newRetrievalComponent)
	Register("search_my_dataset", newRetrievalComponent)
	Register("search_my_dateset", newRetrievalComponent)
	Register(componentNameCodeExec, newCodeExecComponent)
	Register(componentNameGenerate, NewGenerateStub)
	Register(componentNameIteration, NewIterationStub)
	Register(componentNameIterationItem, NewIterationItemStub)
}
