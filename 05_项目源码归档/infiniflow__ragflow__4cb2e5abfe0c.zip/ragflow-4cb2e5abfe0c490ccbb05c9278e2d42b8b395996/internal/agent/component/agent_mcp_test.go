package component

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"ragflow/internal/agent/runtime"
	"ragflow/internal/common"
	"ragflow/internal/entity"
	"ragflow/internal/entity/models"
	mcpclient "ragflow/internal/mcp/client"
	"ragflow/internal/utility"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"gorm.io/gorm"

	"github.com/cloudwego/eino/compose"
	"github.com/cloudwego/eino/flow/agent/react"
	"github.com/cloudwego/eino/schema"
)

func TestAgentMCPRequiresRuntimeServer(t *testing.T) {
	p := mergeAgentParam(AgentParam{}, map[string]any{"mcp": []any{map[string]any{"mcp_id": "missing", "tools": map[string]any{"route": map[string]any{"name": "route"}}}}})
	if _, err := buildAgentTools(t.Context(), p); err == nil {
		t.Fatal("configured MCP tools silently discarded")
	}
}

func TestAgentMCPModelDispatch(t *testing.T) {
	// Keep this test non-parallel: it swaps the global MCP network hooks.
	db := setupComponentTestDB(t)
	if err := db.AutoMigrate(&entity.MCPServer{}); err != nil {
		t.Fatal(err)
	}
	pushComponentDB(t, db)
	lookup := common.LookupHost
	common.LookupHost = func(string) ([]string, error) { return []string{"8.8.8.8"}, nil }
	t.Cleanup(func() { common.LookupHost = lookup })
	var dispatched atomic.Bool
	const authToken = "ragflow-secret"
	mcp := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.RawQuery != "" {
			t.Error("MCP authentication unexpectedly appeared in the URL")
		}
		if got := r.Header.Get("Authorization"); got != "Bearer "+authToken {
			t.Errorf("Authorization = %q, want MCP bearer token", got)
		}
		if r.Method == "DELETE" {
			w.WriteHeader(204)
			return
		}
		var req struct {
			ID     int    `json:"id"`
			Method string `json:"method"`
			Params struct {
				Name      string            `json:"name"`
				Arguments map[string]string `json:"arguments"`
			} `json:"params"`
		}
		json.NewDecoder(r.Body).Decode(&req)
		w.Header().Set("Content-Type", "application/json")
		switch req.Method {
		case "initialize":
			fmt.Fprintf(w, `{"jsonrpc":"2.0","id":%d,"result":{"protocolVersion":"2025-03-26","capabilities":{}}}`, req.ID)
		case "notifications/initialized":
			w.WriteHeader(202)
		case "tools/call":
			dispatched.Store(true)
			if req.Params.Name != "route" || req.Params.Arguments["origin"] != "大连路站" {
				t.Errorf("unexpected dispatch: %+v", req)
			}
			fmt.Fprintf(w, `{"jsonrpc":"2.0","id":%d,"result":{"content":[{"type":"text","text":"metro route"}]}}`, req.ID)
		}
	}))
	defer mcp.Close()
	pinned := utility.PinnedHTTPClient
	utility.PinnedHTTPClient = func(string, string, time.Duration) *http.Client { return mcp.Client() }
	t.Cleanup(func() { utility.PinnedHTTPClient = pinned })
	if err := db.Create(&entity.MCPServer{ID: "mcp", TenantID: "tenant", Name: "route server", URL: mcp.URL, ServerType: mcpclient.TransportStreamableHTTP, Headers: entity.JSONMap{"Authorization": "Bearer ${authorization_token}"}, Variables: entity.JSONMap{"authorization_token": authToken}}).Error; err != nil {
		t.Fatal(err)
	}
	addAgentMCPPermissionFixtures(t, db)
	state := runtime.NewCanvasState("run", "task")
	state.Sys["tenant_id"] = "tenant"
	state.Sys["user_id"] = "tenant"
	state.Sys["canvas_id"] = "canvas"
	ctx := withStateForTest(t.Context(), state)
	p := mergeAgentParam(AgentParam{}, map[string]any{"mcp": []any{map[string]any{"mcp_id": "mcp", "tools": map[string]any{"route": map[string]any{"name": "route", "inputSchema": map[string]any{"type": "object", "properties": map[string]any{"origin": map[string]any{"type": "string"}}, "required": []string{"origin"}}}}}}})
	tools, err := buildAgentTools(ctx, p)
	if err != nil {
		t.Fatal(err)
	}
	var requests atomic.Int32
	llm := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		body, err := io.ReadAll(r.Body)
		if err != nil {
			t.Error(err)
			return
		}
		if strings.Contains(string(body), authToken) || strings.Contains(string(body), mcp.URL) {
			t.Error("MCP connection credentials leaked into the model request")
		}
		var req struct {
			Tools []struct {
				Function struct {
					Name       string         `json:"name"`
					Parameters map[string]any `json:"parameters"`
				} `json:"function"`
			} `json:"tools"`
			ToolChoice string           `json:"tool_choice"`
			Messages   []models.Message `json:"messages"`
		}
		json.Unmarshal(body, &req)
		if len(req.Tools) != 1 || req.Tools[0].Function.Name != "route_0" || req.ToolChoice != "auto" {
			t.Errorf("tools missing from model request: %+v", req)
		}
		if len(req.Tools) == 1 {
			properties, _ := req.Tools[0].Function.Parameters["properties"].(map[string]any)
			if _, ok := properties["origin"]; !ok {
				t.Error("MCP argument schema missing from model request")
			}
		}
		if requests.Add(1) == 1 {
			w.Header().Set("Content-Type", "application/json")
			io.WriteString(w, `{"choices":[{"index":0,"finish_reason":"tool_calls","message":{"role":"assistant","tool_calls":[{"id":"call1","type":"function","function":{"name":"route_0","arguments":"{\"origin\":\"大连路站\"}"}}]}}]}`)
		} else {
			raw, _ := json.Marshal(req.Messages)
			if !strings.Contains(string(raw), "metro route") {
				t.Error("MCP result missing from follow-up model request")
			}
			w.Header().Set("Content-Type", "text/event-stream")
			io.WriteString(w, "data: {\"choices\":[{\"index\":0,\"delta\":{\"content\":\"metro answer\"},\"finish_reason\":\"stop\"}]}\n\ndata: [DONE]\n\n")
		}
	}))
	defer llm.Close()
	driver := models.NewOpenAIModel(map[string]string{"default": llm.URL}, models.URLSuffix{Chat: "chat/completions"})
	modelName, key := "test", "test"
	chat := models.NewEinoChatModel(models.NewChatModel(driver, &modelName, &models.APIConfig{ApiKey: &key}), nil)
	a, err := react.NewAgent(ctx, &react.AgentConfig{ToolCallingModel: chat, ToolsConfig: compose.ToolsNodeConfig{Tools: tools}, StreamToolCallChecker: scanAllStreamForToolCall, MaxStep: 3})
	if err != nil {
		t.Fatal(err)
	}
	stream, err := a.Stream(ctx, []*schema.Message{schema.UserMessage("how to go from 大连路站 to 水清三村公寓 by metro")})
	if err != nil {
		t.Fatal(err)
	}
	defer stream.Close()
	var content string
	for {
		msg, err := stream.Recv()
		if err == io.EOF {
			break
		}
		if err != nil {
			t.Fatal(err)
		}
		content += msg.Content
	}
	if !dispatched.Load() || content != "metro answer" {
		t.Fatalf("dispatch=%v content=%q", dispatched.Load(), content)
	}
	state.Sys["user_id"] = "outsider"
	state.Sys["tenant_id"] = "other-tenant"
	if _, err := buildAgentTools(ctx, p); err == nil {
		t.Fatal("MCP dependency access without canvas permission was allowed")
	}
}

func TestAgentMCPToolNamesDoNotCollide(t *testing.T) {
	db := setupComponentTestDB(t)
	if err := db.AutoMigrate(&entity.MCPServer{}); err != nil {
		t.Fatal(err)
	}
	pushComponentDB(t, db)
	for _, id := range []string{"first", "second"} {
		if err := db.Create(&entity.MCPServer{ID: id, TenantID: "tenant", Name: id, URL: "https://example.com/mcp", ServerType: mcpclient.TransportStreamableHTTP}).Error; err != nil {
			t.Fatal(err)
		}
	}
	addAgentMCPPermissionFixtures(t, db)
	state := runtime.NewCanvasState("run", "task")
	state.Sys["tenant_id"] = "tenant"
	state.Sys["user_id"] = "tenant"
	state.Sys["canvas_id"] = "canvas"
	ctx := withStateForTest(t.Context(), state)
	p := AgentParam{Tools: nil, MCP: []any{
		map[string]any{"mcp_id": "first", "tools": map[string]any{"search": map[string]any{"name": "web_search"}}},
		map[string]any{"mcp_id": "second", "tools": map[string]any{"search": map[string]any{"name": "web_search"}}},
	}}
	tools, err := buildAgentTools(ctx, p)
	if err != nil {
		t.Fatal(err)
	}
	want := []string{"search_0", "search_1"}
	if len(tools) != len(want) {
		t.Fatalf("got %d tools, want %d", len(tools), len(want))
	}
	for i, tool := range tools {
		info, err := tool.Info(ctx)
		if err != nil {
			t.Fatal(err)
		}
		if info.Name != want[i] {
			t.Errorf("tool %d name = %q, want %q", i, info.Name, want[i])
		}
	}
}

func addAgentMCPPermissionFixtures(t *testing.T, db *gorm.DB) {
	t.Helper()
	active := string(entity.StatusValid)
	if err := db.Create(&entity.UserTenant{
		ID: "mcp-owner-membership", UserID: "tenant", TenantID: "tenant",
		Role: "owner", InvitedBy: "tenant", Status: &active,
	}).Error; err != nil {
		t.Fatalf("create MCP owner membership: %v", err)
	}
	if err := db.Create(&entity.UserCanvas{
		ID: "canvas", UserID: "tenant", Permission: string(entity.TenantPermissionMe),
	}).Error; err != nil {
		t.Fatalf("create canvas permission fixture: %v", err)
	}
}
