//
//  Copyright 2026 The InfiniFlow Authors. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

// Package component contains the remaining specialized Canvas adapters for
// Retrieval and CodeExec. Tools with a standard Canvas surface are registered
// through ToolBackedComponent instead.
package component

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"

	"ragflow/internal/agent/runtime"
	agenttool "ragflow/internal/agent/tool"
	"ragflow/internal/common"
	"ragflow/internal/dao"
	"ragflow/internal/permission"
	"ragflow/internal/storage"

	"github.com/google/uuid"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

func stringParam(v any) string {
	if s, ok := v.(string); ok {
		return s
	}
	return ""
}

func anySlice(v any) []any {
	switch x := v.(type) {
	case []any:
		return x
	case []map[string]any:
		out := make([]any, 0, len(x))
		for _, item := range x {
			out = append(out, item)
		}
		return out
	default:
		return []any{}
	}
}

// retrievalParams mirrors the Python RetrievalParam shape: the
// values the canvas node declares at build time, applied as
// defaults to the per-invocation RetrievalRequest. The fields are
// the same the Python agent/component/retrieval.py exposes.
type retrievalParams struct {
	Query                    string
	KbIDs                    []string
	MemoryIDs                []string
	UserID                   string
	TopN                     int
	TopK                     int
	SimilarityThreshold      *float64
	KeywordsSimilarityWeight *float64
	RerankID                 string
	EmptyResponse            string
	CrossLanguages           []string
	UseKG                    bool
	MetaDataFilter           map[string]any
	RetrievalFrom            string
}

// parseRetrievalParams reads the v1 DSL node params for Retrieval.
// Unknown keys are ignored; nil/empty/missing-key inputs yield a
// zero-value retrievalParams which the tool layer treats as
// "default everything". This matches Python's
// component.retrieval.RetrievalParam.__init__ tolerance.
func parseRetrievalParams(params map[string]any) retrievalParams {
	out := retrievalParams{}
	if params == nil {
		return out
	}
	if ids, ok := params["dataset_ids"]; ok {
		params["kb_ids"] = ids
	}
	if v, ok := params["query"].(string); ok {
		out.Query = v
	}
	if v, ok := params["kb_ids"].([]any); ok {
		for _, x := range v {
			if s, ok := x.(string); ok {
				out.KbIDs = append(out.KbIDs, s)
			}
		}
	}
	if v, ok := params["kb_ids"].([]string); ok {
		out.KbIDs = append(out.KbIDs, v...)
	}
	out.MemoryIDs = toStringSlice(params["memory_ids"])
	if v, ok := params["user_id"].(string); ok {
		out.UserID = v
	}
	if v, ok := params["top_n"]; ok {
		out.TopN, _ = common.ToInt(v)
	}
	if v, ok := params["top_k"]; ok {
		out.TopK, _ = common.ToInt(v)
	}
	if v, ok := params["similarity_threshold"]; ok {
		value := toFloatParam(v)
		out.SimilarityThreshold = &value
	}
	if v, ok := params["keywords_similarity_weight"]; ok {
		value := toFloatParam(v)
		out.KeywordsSimilarityWeight = &value
	}
	if v, ok := params["rerank_id"].(string); ok {
		out.RerankID = v
	}
	if v, ok := params["empty_response"].(string); ok {
		out.EmptyResponse = v
	}
	out.CrossLanguages = toStringSlice(params["cross_languages"])
	if v, ok := params["use_kg"].(bool); ok {
		out.UseKG = v
	}
	if v, ok := params["meta_data_filter"].(map[string]any); ok {
		out.MetaDataFilter = cloneAnyMap(v)
	}
	if v, ok := params["retrieval_from"].(string); ok {
		out.RetrievalFrom = v
	}
	return out
}

// retrievalComponent delegates to internal/agent/tool/RetrievalTool.
// The wrapper captures the Retrieval node's DSL params at build time and
// applies them as defaults to each invocation. Per-call inputs override the
// defaults.
type retrievalComponent struct {
	inner  *agenttool.RetrievalTool
	params retrievalParams
}

const componentNameRetrieval = "Retrieval"

var legacyRetrievalQueryPattern = regexp.MustCompile(`(?s)^\s*UserFillUp:\s*(.*?)\s+Input\s+(.*?)\s*$`)

func newRetrievalComponent(params map[string]any) (Component, error) {
	return &retrievalComponent{
		inner:  agenttool.NewRetrievalTool(),
		params: parseRetrievalParams(params),
	}, nil
}

func (c *retrievalComponent) Name() string { return "Retrieval" }

func (c *retrievalComponent) Inputs() map[string]string {
	return map[string]string{
		"query":       "Natural-language search query.",
		"dataset_ids": "Optional list of dataset IDs to restrict the search to (overrides node-level kb_ids).",
		"top_n":       "Maximum chunks to return (default 8, overrides node-level top_n).",
		"use_kg":      "GraphRAG toggle (returns ErrKGRetrievalServiceMissing until a kg adapter is registered).",
	}
}

func (c *retrievalComponent) GetInputForm() map[string]any {
	return map[string]any{
		"query": map[string]any{
			"name": "Query",
			"type": "line",
		},
	}
}

func (c *retrievalComponent) Outputs() map[string]string {
	return map[string]string{
		"formalized_content": "Rendered chunks for downstream LLM prompts.",
		"json":               "Chunk payloads under the DSL-declared output name (Array<Object>).",
		"chunks":             "Raw chunk payloads (id, document_id, content, score).",
	}
}

func (c *retrievalComponent) Invoke(ctx context.Context, db *gorm.DB, inputs map[string]any) (map[string]any, error) {
	merged := c.applyDefaults(inputs)
	normalizeLegacyRetrievalInputs(ctx, db, merged)
	if err := checkCanvasRetrievalDependencies(ctx, db, merged); err != nil {
		return nil, fmt.Errorf("agent Retrieval dependency permission: %w", err)
	}
	query, _ := merged["query"].(string)
	if state, err := runtime.GetStateFromContext(ctx); err == nil && state != nil {
		if resolved, err := runtime.ResolveTemplateAuto(query, state); err == nil {
			query = resolved
		}
	}
	if query != "" && merged["retrieval_from"] == "dataset" {
		rawIDs, present := merged["dataset_ids"]
		emptySelection := !present || rawIDs == nil
		switch ids := rawIDs.(type) {
		case []string:
			emptySelection = len(ids) == 0
		case []any:
			emptySelection = len(ids) == 0
		}
		if emptySelection {
			return normalizeRetrievalOutputs(map[string]any{
				"_ERROR":             "No dataset is selected.",
				"formalized_content": "",
			}), nil
		}
	}
	common.Debug("agent retrieval component: invoke",
		zap.Any("inputs", inputs),
		zap.Any("merged", merged),
	)
	argsJSON, _ := json.Marshal(merged)
	out, err := c.inner.InvokableRun(ctx, string(argsJSON))
	if err != nil {
		return nil, fmt.Errorf("agent: Retrieval: %w", err)
	}
	common.Debug("agent retrieval component: output",
		zap.String("tool_output", out),
	)

	return normalizeRetrievalOutputs(parseToolEnvelope(out)), nil

}

func checkCanvasRetrievalDependencies(ctx context.Context, db *gorm.DB, inputs map[string]any) error {
	if state, err := runtime.GetStateFromContext(ctx); err == nil && state != nil {
		canvasID, _ := state.Sys["canvas_id"].(string)
		userID, _ := state.Sys["user_id"].(string)
		if strings.TrimSpace(canvasID) == "" && strings.TrimSpace(userID) != "" {
			return fmt.Errorf("%w: canvas id missing from runtime state", permission.ErrInvalidPermission)
		}
		if strings.TrimSpace(canvasID) != "" && strings.TrimSpace(userID) == "" {
			return permission.ErrUnauthenticated
		}
	}
	datasetIDs := toStringSlice(inputs["dataset_ids"])
	memoryIDs := toStringSlice(inputs["memory_ids"])
	retrievalFrom, _ := inputs["retrieval_from"].(string)
	switch {
	case strings.EqualFold(strings.TrimSpace(retrievalFrom), "memory"):
		return agenttool.CheckCanvasDependencies(ctx, db, permission.ResourceKindMemory, memoryIDs)
	case strings.TrimSpace(retrievalFrom) == "" && len(datasetIDs) == 0 && len(memoryIDs) > 0:
		return agenttool.CheckCanvasDependencies(ctx, db, permission.ResourceKindMemory, memoryIDs)
	default:
		return agenttool.CheckCanvasDependencies(ctx, db, permission.ResourceKindDataset, datasetIDs)
	}
}

func (c *retrievalComponent) Stream(_ context.Context, _ *gorm.DB, _ map[string]any) (<-chan map[string]any, error) {
	// V1: retrieval is a non-streaming node (the Python
	// Retrieval component also blocks on Dealer.search). A
	// streaming retrieval lands with the streaming-dealer
	// follow-up phase. The single-chunk fallback convention
	// (one {"_raw": "..."} frame) is intentionally NOT
	// emitted here because the canvas scheduler treats
	// nil-stream as "non-streaming node, read Invoke() output"
	// — a fallback frame would confuse downstream cpn wiring.
	return nil, nil
}

// normalizeRetrievalOutputs pins the Retrieval node's chunk array under both
// output names the canvas resolves: `json` (the DSL-declared output, typed
// Array<Object> by the frontend) and `chunks` (the tool envelope's name).
//
// The tool marshals its envelope with `chunks` tagged omitempty, so a
// zero-hit search drops the key outright, as does every early-return
// envelope (empty query, search error, GraphRAG opt-in) and
// parseToolEnvelope's `_raw` fallback. Without this, a downstream
// {{<id>@json}} reference dies in ResolveTemplate with "Can't find variable"
// instead of seeing the empty result set. Emptying the array — rather than
// leaving the key absent or nil — is what every other tool-backed search
// component emits unconditionally, and it is the shape callers iterate over.
func normalizeRetrievalOutputs(decoded map[string]any) map[string]any {
	if decoded == nil {
		decoded = make(map[string]any, 3)
	}
	chunks, ok := decoded["chunks"]
	if !ok || chunks == nil {
		chunks = []any{}
	}
	decoded["chunks"] = chunks
	if existing, has := decoded["json"]; !has || existing == nil {
		decoded["json"] = chunks
	}
	return decoded
}

// applyDefaults folds the node-level params into the per-call
// input map. Per-call values always win; node-level values fill
// the gaps. This mirrors Python's RetrievalParam semantics where
// the canvas DSL declares the defaults and the runtime input
// overrides them.
//
// v1 → tool field name: the wrapper writes node-level kb_ids
// (the v1 DSL / Python surface) but the tool's retrievalArgs
// JSON struct only declares `dataset_ids`. Passing kb_ids
// through unchanged would silently drop the filter (the tool's
// json.Unmarshal would never see the key). To avoid that
// regression, we normalise the merged map here: any `kb_ids`
// present (whether from defaults or inputs) is copied into
// `dataset_ids` (unless dataset_ids is already set), and the
// stale `kb_ids` key is removed so the marshalled payload to
// the tool carries exactly one canonical name.
func (c *retrievalComponent) applyDefaults(inputs map[string]any) map[string]any {
	out := make(map[string]any, len(inputs)+8)
	for k, v := range inputs {
		out[k] = v
	}
	if _, ok := out["query"]; !ok && c.params.Query != "" {
		out["query"] = c.params.Query
	}
	if _, ok := out["kb_ids"]; !ok && len(c.params.KbIDs) > 0 {
		ids := make([]any, len(c.params.KbIDs))
		for i, s := range c.params.KbIDs {
			ids[i] = s
		}
		out["kb_ids"] = ids
	}
	if _, ok := out["top_n"]; !ok && c.params.TopN > 0 {
		out["top_n"] = c.params.TopN
	}
	if _, ok := out["top_k"]; !ok && c.params.TopK > 0 {
		out["top_k"] = c.params.TopK
	}
	if _, ok := out["similarity_threshold"]; !ok && c.params.SimilarityThreshold != nil {
		out["similarity_threshold"] = *c.params.SimilarityThreshold
	}
	if _, ok := out["keywords_similarity_weight"]; !ok && c.params.KeywordsSimilarityWeight != nil {
		out["keywords_similarity_weight"] = *c.params.KeywordsSimilarityWeight
	}
	if _, ok := out["rerank_id"]; !ok && c.params.RerankID != "" {
		out["rerank_id"] = c.params.RerankID
	}
	if _, ok := out["empty_response"]; !ok && c.params.EmptyResponse != "" {
		out["empty_response"] = c.params.EmptyResponse
	}
	if _, ok := out["memory_ids"]; !ok && len(c.params.MemoryIDs) > 0 {
		out["memory_ids"] = append([]string(nil), c.params.MemoryIDs...)
	}
	if _, ok := out["user_id"]; !ok && c.params.UserID != "" {
		out["user_id"] = c.params.UserID
	}
	if _, ok := out["cross_languages"]; !ok && len(c.params.CrossLanguages) > 0 {
		out["cross_languages"] = append([]string(nil), c.params.CrossLanguages...)
	}
	if _, ok := out["use_kg"]; !ok && c.params.UseKG {
		out["use_kg"] = true
	}
	if _, ok := out["meta_data_filter"]; !ok && c.params.MetaDataFilter != nil {
		out["meta_data_filter"] = cloneAnyMap(c.params.MetaDataFilter)
	}
	if _, ok := out["retrieval_from"]; !ok && c.params.RetrievalFrom != "" {
		out["retrieval_from"] = c.params.RetrievalFrom
	}
	// Translate v1 DSL name `kb_ids` to the tool's expected
	// name `dataset_ids`. dataset_ids already-set wins; kb_ids
	// is consumed and removed so the marshalled JSON carries a
	// single canonical key. Without this step, the tool's
	// retrievalArgs.DatasetIDs would be empty even when the
	// caller supplied kb_ids at build or call time.
	if kbIDs, ok := out["kb_ids"]; ok {
		if _, hasDatasetIDs := out["dataset_ids"]; !hasDatasetIDs {
			out["dataset_ids"] = kbIDs
		}
		delete(out, "kb_ids")
	}
	return out
}

func normalizeLegacyRetrievalInputs(ctx context.Context, db *gorm.DB, out map[string]any) {
	if normalizeStructuredRetrievalInputs(ctx, db, out) {
		return
	}
	rawQuery, _ := out["query"].(string)
	rawQuery = strings.TrimSpace(rawQuery)
	if rawQuery == "" {
		return
	}
	matches := legacyRetrievalQueryPattern.FindStringSubmatch(rawQuery)
	if len(matches) != 3 {
		return
	}
	kbName := strings.TrimSpace(matches[1])
	queryText := strings.TrimSpace(matches[2])
	if queryText != "" {
		out["query"] = queryText
	}
	if _, hasDatasetIDs := out["dataset_ids"]; hasDatasetIDs {
		return
	}
	if kbName == "" {
		return
	}
	if datasetID := resolveRetrievalDatasetID(ctx, db, kbName); datasetID != "" {
		out["dataset_ids"] = []string{datasetID}
	}
}

func normalizeStructuredRetrievalInputs(ctx context.Context, db *gorm.DB, out map[string]any) bool {
	_, hasDatasetIDs := out["dataset_ids"]
	candidateMaps := []map[string]any{}
	if stateMap, ok := out["state"].(map[string]any); ok {
		if raw, ok := stateMap["UserFillUp:KBInput"].(map[string]any); ok {
			candidateMaps = append(candidateMaps, raw)
		}
	}
	candidateMaps = append(candidateMaps, out)

	consumed := false
	for _, candidate := range candidateMaps {
		kbName, _ := candidate["kb"].(string)
		queryText, _ := candidate["query"].(string)
		if kbName == "" && legacyRetrievalQueryPattern.MatchString(strings.TrimSpace(queryText)) {
			continue
		}
		if kbName == "" && queryText == "" {
			continue
		}
		consumed = true
		if queryText != "" {
			out["query"] = queryText
		}
		if kbName != "" && !hasDatasetIDs {
			if datasetID := resolveRetrievalDatasetID(ctx, db, strings.TrimSpace(kbName)); datasetID != "" {
				out["dataset_ids"] = []string{datasetID}
				common.Debug("agent retrieval component: resolved dataset id")
			}
		}
		if queryText != "" {
			return true
		}
		if kbName != "" && out["dataset_ids"] != nil {
			return true
		}
	}
	return consumed
}

func resolveRetrievalDatasetID(ctx context.Context, db *gorm.DB, kbName string) string {
	if kbName == "" {
		return ""
	}
	if kb, err := dao.NewKnowledgebaseDAO().GetByID(ctx, db, kbName); err == nil && kb != nil {
		common.Debug("agent retrieval component: resolved dataset id by direct id")
		return kb.ID
	} else if err != nil && !errors.Is(err, gorm.ErrRecordNotFound) {
		common.Warn("agent retrieval component: resolve dataset id by id failed",
			zap.Error(err))
	}
	if state, err := runtime.GetStateFromContext(ctx); err == nil && state != nil {
		common.Debug("agent retrieval component: resolve dataset id context")
		if tenantID, _ := state.Sys["tenant_id"].(string); tenantID != "" {
			if kb, lookupErr := dao.NewKnowledgebaseDAO().GetByName(ctx, db, kbName, tenantID); lookupErr == nil && kb != nil {
				common.Debug("agent retrieval component: resolved dataset id by tenant")
				return kb.ID
			} else if lookupErr != nil && !errors.Is(lookupErr, gorm.ErrRecordNotFound) {
				common.Warn("agent retrieval component: resolve dataset id by tenant failed",
					zap.Error(lookupErr))
			} else {
				common.Debug("agent retrieval component: tenant lookup missed")
			}
		}
		if userID, _ := state.Sys["user_id"].(string); userID != "" {
			kbs, lookupErr := dao.NewKnowledgebaseDAO().GetByNameInUserTenants(ctx, db, kbName, userID)
			if lookupErr != nil {
				common.Warn("agent retrieval component: resolve dataset id by tenant membership failed",
					zap.Error(lookupErr))
			} else {
				refs := make([]permission.ResourceRef, 0, len(kbs))
				for _, kb := range kbs {
					if kb != nil {
						refs = append(refs, permission.ResourceRef{Kind: permission.ResourceKindDataset, ID: kb.ID})
					}
				}
				accessible, accessErr := permission.NewDatabaseChecker(db).FilterResources(
					ctx,
					permission.Subject{UserID: userID},
					refs,
					permission.OperationUse,
				)
				if accessErr != nil {
					common.Warn("agent retrieval component: check dataset use permission failed",
						zap.Error(accessErr))
				} else if len(accessible) > 0 {
					common.Debug("agent retrieval component: resolved dataset id by permission")
					return accessible[0].ID
				}
			}
		}
	} else {
		common.Debug("agent retrieval component: resolve dataset id missing canvas state",
			zap.Error(err))
	}
	common.Debug("agent retrieval component: dataset id unresolved")
	return ""
}

// codeExecComponent delegates to internal/agent/tool/CodeExecTool.
// The node-level params map carries the legacy v1 DSL surface
// (`lang`, `script`, `arguments`, optional `timeout`). Per-call inputs
// override those defaults so resolved canvas refs win at invocation
// time, while static DSL-provided literals still flow through.
type codeExecComponent struct {
	inner   *agenttool.CodeExecTool
	params  map[string]any
	outputs map[string]any
}

const componentNameCodeExec = "CodeExec"

func newCodeExecComponent(params map[string]any) (Component, error) {
	cloned := make(map[string]any, len(params))
	for k, v := range params {
		cloned[k] = v
	}
	return &codeExecComponent{
		inner:   agenttool.NewCodeExecTool(),
		params:  cloned,
		outputs: cloneAnyMap(asAnyMap(params["outputs"])),
	}, nil
}

func (c *codeExecComponent) Name() string { return "CodeExec" }

func (c *codeExecComponent) Inputs() map[string]string {
	return map[string]string{
		"lang":      "Programming language: python/python3/javascript/nodejs.",
		"script":    "Code to execute. Should define main(...).",
		"arguments": "Arguments passed to main(...) as keyword args / object fields.",
		"timeout":   "Optional per-execution timeout in seconds.",
	}
}

func (c *codeExecComponent) GetInputForm() map[string]any {
	arguments := asAnyMap(c.params["arguments"])
	res := make(map[string]any, len(arguments))
	for k := range arguments {
		res[k] = map[string]any{
			"type": "line",
			"name": k,
		}
	}
	return res
}

func (c *codeExecComponent) Outputs() map[string]string {
	return map[string]string{
		"result":      "The main(...) return value rendered as the legacy CodeExec result field.",
		"content":     "Raw CodeExec tool content field.",
		"_ERROR":      "Execution or sandbox error message.",
		"actual_type": "Runtime type inferred by the sandbox bridge.",
		"stdout":      "Captured stdout.",
		"stderr":      "Captured stderr.",
		"exit_code":   "Process exit code.",
	}
}

func (c *codeExecComponent) Invoke(ctx context.Context, db *gorm.DB, inputs map[string]any) (map[string]any, error) {
	merged := make(map[string]any, len(c.params)+len(inputs))
	for k, v := range c.params {
		merged[k] = v
	}
	arguments := asAnyMap(c.params["arguments"])
	for k, v := range inputs {
		if _, ok := arguments[k]; !ok {
			merged[k] = v
		}
	}
	if rawArgs, ok := merged["arguments"].(map[string]any); ok {
		state, _ := runtime.GetStateFromContext(ctx)
		resolvedArgs := resolveCodeExecArguments(rawArgs, merged, state)
		for k := range rawArgs {
			if v, ok := inputs[k]; ok {
				resolvedArgs[k] = v
			}
		}
		merged["arguments"] = resolvedArgs
	}
	common.Debug("CodeExec wrapper invoke",
		zap.Int("params_keys", len(c.params)),
		zap.Int("inputs_keys", len(inputs)),
		zap.Int("merged_keys", len(merged)),
		zap.Bool("has_arguments", merged["arguments"] != nil))
	argsJSON, _ := json.Marshal(merged)
	out, err := c.inner.InvokableRun(ctx, string(argsJSON))
	decoded := parseToolEnvelope(out)
	if c.outputs != nil {
		applyCodeExecBusinessOutputs(decoded, c.outputs)
	} else if rawResult, ok := decoded["raw_result"]; ok {
		decoded["result"] = rawResult
		if _, ok := decoded["_ERROR"]; !ok {
			decoded["_ERROR"] = ""
		}
	} else if content, ok := decoded["content"]; ok {
		decoded["result"] = content
		if _, ok := decoded["_ERROR"]; !ok {
			decoded["_ERROR"] = ""
		}
	}
	// Upload sandbox-returned artifacts to object storage and surface
	// them as message attachments. Without this the tool's base64
	// `_ARTIFACTS` payload never reaches the UI: the canvas message
	// shows an empty `attachments` list even though the sandbox
	// collected files. Mirrors the Python code_exec tool
	// (_upload_artifacts / _build_attachment_markdown_list).
	attachCodeExecArtifacts(ctx, decoded)

	if err != nil {
		return decoded, fmt.Errorf("agent: CodeExec: %w", err)
	}
	return decoded, nil
}

func (c *codeExecComponent) Stream(_ context.Context, _ *gorm.DB, _ map[string]any) (<-chan map[string]any, error) {
	return nil, nil
}

// parseToolEnvelope decodes the JSON envelope returned by eino tool
// InvokableRun into a map[string]any. The result has whatever keys
// the tool's result type carries (rows/columns/chunks/etc.).
func parseToolEnvelope(jsonStr string) map[string]any {
	var out map[string]any
	if err := json.Unmarshal([]byte(jsonStr), &out); err != nil {
		// Tool returned non-JSON; surface the raw string under a
		// known key so the caller can still see something.
		return map[string]any{"_raw": jsonStr}
	}
	return out
}

func applyCodeExecBusinessOutputs(decoded map[string]any, outputs map[string]any) {
	if decoded == nil {
		return
	}
	rawResult := resolveCodeExecBusinessResult(decoded)
	common.Debug("CodeExec wrapper",
		zap.Int("decoded_keys", len(decoded)),
		zap.Bool("has_raw_result", rawResult != nil),
		zap.Bool("has_content", decoded["content"] != nil),
		zap.Int("outputs_keys", len(outputs)))
	if existingErr, _ := decoded["_ERROR"].(string); strings.TrimSpace(existingErr) != "" {
		for name := range outputs {
			if isCodeExecSystemOutput(name) {
				continue
			}
			decoded[name] = nil
		}
		if _, ok := decoded["actual_type"]; !ok {
			decoded["actual_type"] = agenttool.InferCodeExecActualType(rawResult)
		}
		if _, ok := decoded["content"]; !ok {
			decoded["content"] = agenttool.RenderCodeExecCanonicalContent(rawResult)
		}
		return
	}
	contract, err := agenttool.BuildCodeExecContract(outputs, rawResult)
	if err != nil {
		for name := range outputs {
			if isCodeExecSystemOutput(name) {
				continue
			}
			decoded[name] = nil
		}
		decoded["actual_type"] = agenttool.InferCodeExecActualType(rawResult)
		decoded["_ERROR"] = err.Error()
		if _, ok := decoded["content"]; !ok {
			decoded["content"] = agenttool.RenderCodeExecCanonicalContent(rawResult)
		}
		return
	}

	decoded["_ERROR"] = ""
	decoded["actual_type"] = contract.ActualType
	decoded["content"] = contract.Content
	decoded[contract.BusinessOutput] = contract.Value
}

func resolveCodeExecBusinessResult(decoded map[string]any) any {
	if decoded == nil {
		return nil
	}
	if rawResult, ok := decoded["raw_result"]; ok {
		return rawResult
	}
	content, _ := decoded["content"].(string)
	content = strings.TrimSpace(content)
	if content == "" {
		return nil
	}
	var parsed any
	if err := json.Unmarshal([]byte(content), &parsed); err == nil {
		return parsed
	}
	return content
}

func isCodeExecSystemOutput(name string) bool {
	switch name {
	case "content", "actual_type", "attachments", "_ERROR", "_ARTIFACTS", "_ATTACHMENT_CONTENT", "raw_result", "_created_time", "_elapsed_time":
		return true
	default:
		return false
	}
}

func asAnyMap(v any) map[string]any {
	if m, ok := v.(map[string]any); ok {
		return m
	}
	return nil
}

func cloneAnyMap(in map[string]any) map[string]any {
	if in == nil {
		return nil
	}
	out := make(map[string]any, len(in))
	for k, v := range in {
		out[k] = v
	}
	return out
}

func resolveCodeExecArguments(args map[string]any, merged map[string]any, state *runtime.CanvasState) map[string]any {
	if args == nil {
		return nil
	}
	out := make(map[string]any, len(args))
	for k, v := range args {
		out[k] = resolveCodeExecArgumentValue(v, merged, state)
	}
	return out
}

func resolveCodeExecArgumentValue(v any, merged map[string]any, state *runtime.CanvasState) any {
	switch x := v.(type) {
	case map[string]any:
		return resolveCodeExecArguments(x, merged, state)
	case []any:
		out := make([]any, 0, len(x))
		for _, item := range x {
			out = append(out, resolveCodeExecArgumentValue(item, merged, state))
		}
		return out
	case string:
		if resolved, ok := lookupCodeExecArgumentRef(x, merged, state); ok {
			return resolved
		}
		return x
	default:
		return v
	}
}

func lookupCodeExecArgumentRef(ref string, merged map[string]any, state *runtime.CanvasState) (any, bool) {
	ref = strings.TrimSpace(ref)
	if ref == "" {
		return nil, false
	}
	if state != nil {
		if v, err := state.GetVar(ref); err == nil && v != nil {
			return v, true
		}
	}
	at := strings.Index(ref, "@")
	if at <= 0 || at >= len(ref)-1 {
		return nil, false
	}
	cpnID := ref[:at]
	param := ref[at+1:]

	stateByNode, _ := merged["state"].(map[string]map[string]any)
	if bucket, ok := stateByNode[cpnID]; ok {
		if v, ok := bucket[param]; ok {
			return v, true
		}
	}
	return nil, false
}

// toFloatParam coerces a node-param float value to float64. Same
// JSON-float64 / numeric-string tolerance as toIntParam.
func toFloatParam(v any) float64 {
	switch x := v.(type) {
	case float64:
		return x
	case int:
		return float64(x)
	case int64:
		return float64(x)
	case string:
		f, _ := strconv.ParseFloat(x, 64)
		return f
	}
	return 0
}

// Compile-time interface checks.
var (
	_ Component = (*retrievalComponent)(nil)
	_ Component = (*codeExecComponent)(nil)
)

// Compile-time check that the eino InvokableTool methods we call
// are reachable (catches a future refactor that renames them).

// attachCodeExecArtifacts uploads the `_ARTIFACTS` produced by the
// CodeExec tool to object storage and populates the message-facing
// `attachments` / `_ATTACHMENT_CONTENT` outputs plus a content
// appendix. The attachments output remains an empty list when no files exist.
func attachCodeExecArtifacts(ctx context.Context, decoded map[string]any) {
	if _, ok := decoded["attachments"]; !ok {
		decoded["attachments"] = []string{}
	}
	raw, ok := decoded["_ARTIFACTS"].([]any)
	if !ok || len(raw) == 0 {
		return
	}
	sessionID := ""
	if state, err := runtime.GetStateFromContext(ctx); err == nil && state != nil {
		sessionID = state.SessionID
	}
	// The CodeExec tool already hosts sandbox artifacts and surfaces
	// them as `_ARTIFACTS` entries carrying a `url`; storage is only
	// needed for the legacy content_b64 fallback below.
	uploaded, markdown, attachmentContent := uploadCodeExecArtifacts(ctx, raw, sessionID, storage.GetStorageFactory().GetStorage())
	if len(uploaded) == 0 {
		return
	}
	decoded["_ARTIFACTS"] = uploaded
	decoded["attachments"] = markdown
	decoded["_ATTACHMENT_CONTENT"] = attachmentContent
	// Append the attachment sections to content, mirroring the Python
	// code_exec tool (content = "\"\n\n\"".join(content_parts)); when the
	// tool produced no base content the attachment text becomes the
	// content itself.
	if content, ok := decoded["content"].(string); ok && strings.TrimSpace(content) != "" {
		decoded["content"] = strings.TrimSpace(content + "\n\n" + attachmentContent)
	} else {
		decoded["content"] = strings.TrimSpace(attachmentContent)
	}
}

// codeExecArtifactBucket returns the object-storage bucket used for
// CodeExec sandbox artifacts. Mirrors the Python
// `SANDBOX_ARTIFACT_BUCKET` setting and the document service's
// default ("sandbox-artifacts").
func codeExecArtifactBucket() string {
	if bucket := common.GetEnv(common.EnvSandboxArtifactBucket); bucket != "" {
		return bucket
	}
	return "sandbox-artifacts"
}

// uploadCodeExecArtifacts uploads sandbox-returned artifacts to object
// storage and returns the attachment-facing payloads, mirroring the
// Python code_exec tool (_upload_artifacts / _build_attachment_markdown_list
// / _build_attachment_content):
//
//   - uploaded: `_ARTIFACTS` entries with a downloadable url
//   - markdown: `attachments` list (image preview / download links)
//   - attachmentContent: `_ATTACHMENT_CONTENT` text (attachment_count + sections)
//
// Entries that cannot be decoded or stored are skipped with a warning,
// matching the Python "skip on failure" semantics.
func uploadCodeExecArtifacts(ctx context.Context, artifacts []any, sessionID string, st storage.Storage) (uploaded []map[string]any, markdown []string, attachmentContent string) {
	bucket := codeExecArtifactBucket()
	sections := make([]string, 0, len(artifacts))
	for _, raw := range artifacts {
		m, ok := raw.(map[string]any)
		if !ok {
			continue
		}
		name := codeExecArtifactString(m["name"])
		if name == "" {
			continue
		}
		mimeType := codeExecArtifactString(m["mime_type"])
		size := codeExecArtifactInt64(m["size"])
		url := codeExecArtifactString(m["url"])
		if url == "" {
			// Legacy / direct-producer envelopes still carry the
			// base64 blob (content_b64) instead of a hosted url.
			contentB64 := codeExecArtifactString(m["content_b64"])
			if contentB64 == "" {
				continue
			}
			binary, err := base64.StdEncoding.DecodeString(contentB64)
			if err != nil || len(binary) == 0 {
				common.Warn("CodeExec: skip artifact with undecodable content_b64", zap.String("name", name))
				continue
			}
			if st == nil {
				common.Warn("CodeExec: storage not initialized; cannot upload artifact", zap.String("name", name))
				continue
			}
			storageName := uuid.NewString() + strings.ToLower(filepath.Ext(name))
			if err := st.Put(ctx, bucket, storageName, binary); err != nil {
				common.Warn("CodeExec: failed to upload artifact", zap.String("name", name), zap.String("storage", storageName), zap.Error(err))
				continue
			}
			url = fmt.Sprintf("/api/v1/documents/artifact/%s?session_id=%s", storageName, sessionID)
		}
		uploaded = append(uploaded, map[string]any{
			"name":      name,
			"url":       url,
			"mime_type": mimeType,
			"size":      size,
		})
		markdown = append(markdown, codeExecArtifactMarkdown(name, mimeType, url))
		sections = append(sections, codeExecAttachmentSection(len(sections)+1, name, mimeType, url))
	}
	if len(sections) > 0 {
		attachmentContent = fmt.Sprintf("attachment_count: %d\n\n%s", len(sections), strings.Join(sections, "\n\n"))
	} else {
		attachmentContent = "attachment_count: 0"
	}
	return uploaded, markdown, attachmentContent
}

// codeExecArtifactMarkdown renders one uploaded artifact as a Markdown
// link: image artifacts become inline images, everything else becomes a
// download link.
func codeExecArtifactMarkdown(name, mimeType, url string) string {
	if strings.HasPrefix(strings.ToLower(mimeType), "image/") && url != "" {
		return fmt.Sprintf("![%s](%s)", name, url)
	}
	if url != "" {
		return fmt.Sprintf("[Download %s](%s)", name, url)
	}
	return name
}

// codeExecAttachmentSection renders the `attachmentN (type): name`
// section used by _ATTACHMENT_CONTENT.
func codeExecAttachmentSection(idx int, name, mimeType, url string) string {
	title := fmt.Sprintf("attachment%d (%s): %s", idx, codeExecAttachmentType(name, mimeType), name)
	return title + "\n" + codeExecArtifactMarkdown(name, mimeType, url)
}

// codeExecAttachmentType mirrors Python's _normalize_attachment_type.
func codeExecAttachmentType(name, mimeType string) string {
	mimeType = strings.ToLower(strings.TrimSpace(mimeType))
	switch {
	case strings.HasPrefix(mimeType, "image/"):
		return "image"
	case mimeType == "application/pdf":
		return "pdf"
	case mimeType == "text/csv":
		return "csv"
	case mimeType == "application/json":
		return "json"
	case mimeType == "text/html":
		return "html"
	}
	if ext := strings.TrimPrefix(strings.ToLower(filepath.Ext(name)), "."); ext != "" {
		return ext
	}
	return "file"
}

func codeExecArtifactString(v any) string {
	if s, ok := v.(string); ok {
		return s
	}
	return ""
}

func codeExecArtifactInt64(v any) int64 {
	switch x := v.(type) {
	case int64:
		return x
	case int:
		return int64(x)
	case float64:
		return int64(x)
	case json.Number:
		if n, err := x.Int64(); err == nil {
			return n
		}
	}
	return 0
}
