//
//  Copyright 2026 The InfiniFlow Authors. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package component

import (
	"encoding/json"
	"strings"
	"testing"
	"unicode/utf8"

	"ragflow/internal/agent/canvas"
	"ragflow/internal/storage"
)

// TestDocsGenerator_Registered: the component is registered under
// its canonical name. The param check requires output_format and
// content; we provide a minimal valid params map.
func TestDocsGenerator_Registered(t *testing.T) {
	c, err := New("DocsGenerator", map[string]any{
		"output_format": "pdf",
		"content":       "Hello world",
	})
	if err != nil {
		t.Fatalf("New(DocsGenerator): %v", err)
	}
	if c.Name() != "DocsGenerator" {
		t.Errorf("Name=%q, want DocsGenerator", c.Name())
	}
	if c.Inputs() == nil {
		t.Error("Inputs() should be non-nil")
	}
	if c.Outputs() == nil {
		t.Error("Outputs() should be non-nil")
	}
}

func TestDocGeneratorAlias_Registered(t *testing.T) {
	c, err := New("DocGenerator", map[string]any{
		"output_format": "pdf",
		"content":       "Hello world",
	})
	if err != nil {
		t.Fatalf("New(DocGenerator): %v", err)
	}
	if c.Name() != "DocsGenerator" {
		t.Errorf("Name=%q, want DocsGenerator", c.Name())
	}
}

func TestDocGeneratorAlias_InputForm(t *testing.T) {
	c, err := New("DocGenerator", map[string]any{
		"output_format": "pdf",
		"content":       "Hello world",
	})
	if err != nil {
		t.Fatalf("New(DocGenerator): %v", err)
	}
	formGetter, ok := c.(interface{ GetInputForm() map[string]any })
	if !ok {
		t.Fatal("DocGenerator component does not expose GetInputForm")
	}
	content, ok := formGetter.GetInputForm()["content"].(map[string]any)
	if !ok {
		t.Fatalf("GetInputForm()[content] has type %T, want map", formGetter.GetInputForm()["content"])
	}
	if content["type"] != "line" {
		t.Fatalf("GetInputForm()[content][type] = %v, want line", content["type"])
	}
}

// TestDocsGenerator_Invoke_HappyPath: with valid params, the
// component runs without error and produces a non-nil output map.
// Real PDF/DOCX generation needs an actual font file on disk
// (see docs_generator.go's font initialization); when that's
// missing the generator returns a soft error.
func TestDocsGenerator_Invoke_HappyPath(t *testing.T) {
	c, err := New("DocsGenerator", map[string]any{
		"output_format": "txt",
		"content":       "Hello world",
		"filename":      "test",
	})
	if err != nil {
		t.Fatalf("New(DocsGenerator): %v", err)
	}
	_, _ = c.Invoke(t.Context(), nil, map[string]any{})
	// We do not assert err == nil here because txt output requires
	// the internal writer (which may not be available in this
	// checkout). The test pins that the call doesn't panic.
}

func TestDocsGenerator_Invoke_UsesQueryWhenContentEmpty(t *testing.T) {
	c, err := New("DocsGenerator", map[string]any{
		"output_format": "txt",
		"filename":      "query-body",
	})
	if err != nil {
		t.Fatalf("New(DocsGenerator): %v", err)
	}
	out, err := c.Invoke(t.Context(), nil, map[string]any{
		"query": "Hello from begin query",
	})
	if err != nil {
		t.Fatalf("Invoke: %v", err)
	}
	payload, ok := out["bytes"].([]byte)
	if !ok {
		t.Fatalf("bytes has type %T, want []byte", out["bytes"])
	}
	if !strings.Contains(string(payload), "Hello from begin query") {
		t.Fatalf("payload = %q, want query content", string(payload))
	}
}

func TestDocsGenerator_Invoke_AcceptsDecorationParamNames(t *testing.T) {
	c, err := New("DocsGenerator", map[string]any{
		"output_format":  "txt",
		"content":        "body",
		"filename":       "decorated",
		"header_text":    "Canonical Header",
		"footer_text":    "Canonical Footer",
		"watermark_text": "Canonical Watermark",
	})
	ctx := t.Context()
	if err != nil {
		t.Fatalf("New(DocsGenerator): %v", err)
	}
	out, err := c.Invoke(ctx, nil, map[string]any{})
	if err != nil {
		t.Fatalf("Invoke canonical params: %v", err)
	}
	payload, ok := out["bytes"].([]byte)
	if !ok {
		t.Fatalf("bytes has type %T, want []byte", out["bytes"])
	}
	text := string(payload)
	if !strings.Contains(text, "Canonical Header") || !strings.Contains(text, "Canonical Footer") {
		t.Fatalf("payload = %q, want canonical header and footer", text)
	}

	c, err = New("DocsGenerator", map[string]any{
		"output_format": "txt",
		"content":       "body",
		"filename":      "decorated-alias",
		"header":        "Alias Header",
		"footer":        "Alias Footer",
		"watermark":     "Alias Watermark",
	})
	if err != nil {
		t.Fatalf("New(DocsGenerator alias params): %v", err)
	}
	out, err = c.Invoke(ctx, nil, map[string]any{})
	if err != nil {
		t.Fatalf("Invoke alias params: %v", err)
	}
	payload, ok = out["bytes"].([]byte)
	if !ok {
		t.Fatalf("bytes has type %T, want []byte", out["bytes"])
	}
	text = string(payload)
	if !strings.Contains(text, "Alias Header") || !strings.Contains(text, "Alias Footer") {
		t.Fatalf("payload = %q, want alias header and footer", text)
	}
}

func TestDocsGenerator_Invoke_StoresAgentAttachment(t *testing.T) {
	storageFactory := storage.GetStorageFactory()
	prevStorage := storageFactory.GetStorage()
	memStorage := storage.NewMemoryStorage()
	storageFactory.SetStorage(memStorage)
	t.Cleanup(func() { storageFactory.SetStorage(prevStorage) })

	c, err := New("DocGenerator", map[string]any{
		"output_format": "txt",
		"content":       "Hello storage",
		"filename":      "stored",
	})
	if err != nil {
		t.Fatalf("New(DocGenerator): %v", err)
	}
	state := canvas.NewCanvasState("run-1", "task-1")
	state.Sys["tenant_id"] = "tenant-1"
	ctx := canvas.WithState(t.Context(), state)

	out, err := c.Invoke(ctx, nil, map[string]any{})
	if err != nil {
		t.Fatalf("Invoke: %v", err)
	}
	if out["stored"] != true {
		t.Fatalf("stored = %v, want true", out["stored"])
	}
	docID, ok := out["doc_id"].(string)
	if !ok || docID == "" {
		t.Fatalf("doc_id = %v, want non-empty string", out["doc_id"])
	}
	blob, err := memStorage.Get(ctx, "tenant-1-downloads", docID)
	if err != nil {
		t.Fatalf("stored blob missing: %v", err)
	}
	if string(blob) == "" || !strings.Contains(string(blob), "Hello storage") {
		t.Fatalf("stored blob = %q, want generated content", string(blob))
	}
	download, _ := out["download"].(string)
	var info map[string]any
	if err := json.Unmarshal([]byte(download), &info); err != nil {
		t.Fatalf("download is not JSON: %v", err)
	}
	if info["doc_id"] != docID {
		t.Fatalf("download doc_id = %v, want %s", info["doc_id"], docID)
	}
	if path, _ := info["url"].(string); !strings.HasPrefix(path, "/api/v1/agents/attachments/"+docID+"/download") {
		t.Fatalf("download url = %q, want attachment download path", path)
	}
	if _, ok := out["download_info"].(map[string]any); !ok {
		t.Fatalf("download_info has type %T, want map", out["download_info"])
	}
}

// TestResolveDocsGeneratorContent_ThinkAndTrim pins the static-content path:
// a think preamble is stripped, and outer whitespace is trimmed even when no
// think block is present — matching Python _strip_thinking's final .strip().
func TestResolveDocsGeneratorContent_ThinkAndTrim(t *testing.T) {
	got, err := resolveDocsGeneratorContent(t.Context(), "<think>reasoning</think>\n# Title\n", nil)
	if err != nil {
		t.Fatalf("resolveDocsGeneratorContent: %v", err)
	}
	if got != "# Title" {
		t.Errorf("content = %q, want %q", got, "# Title")
	}

	got, err = resolveDocsGeneratorContent(t.Context(), "  plain  \n", nil)
	if err != nil {
		t.Fatalf("resolveDocsGeneratorContent: %v", err)
	}
	if got != "plain" {
		t.Errorf("content = %q, want %q", got, "plain")
	}
}

// TestSanitizeFilename_CapsLength pins the two caps on generated names: 180
// characters for the base, then 255 bytes for the whole name. Both cuts land
// on a rune boundary and keep the extension; cutting bytes mid-rune left
// invalid UTF-8 in the filename and download URL.
func TestSanitizeFilename_CapsLength(t *testing.T) {
	cases := []struct {
		name string
		raw  string
		ext  string
		want string
	}{
		{"ascii over 180 chars", strings.Repeat("x", 200), ".pdf", strings.Repeat("x", 180) + ".pdf"},
		{"cjk at 255 bytes", strings.Repeat("报", 83), ".pdf", strings.Repeat("报", 83) + ".pdf"},
		{"cjk over 255 bytes", strings.Repeat("报", 84), ".pdf", strings.Repeat("报", 83) + ".pdf"},
		{"cjk over both caps", strings.Repeat("报", 200), ".pdf", strings.Repeat("报", 83) + ".pdf"},
		// The leading "a" puts the 255-byte boundary inside a 3-byte character.
		{"mixed cut on a character", "a" + strings.Repeat("报", 200), ".pdf", "a" + strings.Repeat("报", 83) + ".pdf"},
		{"longer extension", strings.Repeat("报", 100), ".docx", strings.Repeat("报", 83) + ".docx"},
		{"extension already present", strings.Repeat("报", 100) + ".PDF", ".pdf", strings.Repeat("报", 83) + ".PDF"},
	}
	for _, c := range cases {
		got := sanitizeFilename(c.raw, c.ext)
		if got != c.want {
			t.Errorf("%s: sanitizeFilename = %q (%d bytes), want %q (%d bytes)", c.name, got, len(got), c.want, len(c.want))
		}
		if len(got) > 255 || !utf8.ValidString(got) || !strings.HasSuffix(strings.ToLower(got), c.ext) {
			t.Errorf("%s: %q is longer than 255 bytes, not valid UTF-8 or lacks %s", c.name, got, c.ext)
		}
	}
}
