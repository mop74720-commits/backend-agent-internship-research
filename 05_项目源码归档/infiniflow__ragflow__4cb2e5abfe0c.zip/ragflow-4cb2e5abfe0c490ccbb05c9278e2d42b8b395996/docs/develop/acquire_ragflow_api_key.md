---
sidebar_position: 4
title: Acquire RAGFlow API Key
sidebar_label: Acquire RAGFlow API Key
slug: /acquire_ragflow_api_key
sidebar_custom_props: {
  categoryIcon: LucideKey
}
---
# Acquire RAGFlow API Key

An API key is required for the RAGFlow server to authenticate HTTP or MCP requests. This document provides instructions on obtaining a RAGFlow API key.

1. Click your avatar in the top right corner of the RAGFlow UI to access the configuration page.
2. Click **API** to switch to the **API** page.
3. Obtain a RAGFlow API key:

![ragflow_api_key](https://raw.githubusercontent.com/infiniflow/ragflow-docs/main/images/ragflow_api_key.jpg)

:::tip NOTE
See the [RAGFlow HTTP API reference](../references/http_api_reference.md) for the complete HTTP API reference.
:::
