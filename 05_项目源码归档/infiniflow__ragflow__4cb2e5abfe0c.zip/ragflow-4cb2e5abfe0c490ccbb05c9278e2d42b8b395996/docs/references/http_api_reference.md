---
sidebar_position: 4
slug: /http_api_reference
sidebar_custom_props: {
  categoryIcon: LucideGlobe
}
---
# HTTP API

A complete reference for RAGFlow's RESTful API, including migration notes for the 1.0 Go backend. Before proceeding, please ensure you [have your RAGFlow API key ready for authentication](https://ragflow.io/docs/dev/acquire_ragflow_api_key).

In the standard response envelope, `message` is always a non-empty string. Successful responses default to `"success"`; error responses contain a description of the error.

---

## ERROR CODES

RAGFlow responses may contain both an HTTP status code and a business code in the JSON response body. These codes should be checked separately.

### HTTP status codes

| Code | Meaning |
|------|---------|
| 200 | The HTTP request was processed successfully. Check the response body `code` for the business result. |
| 400 | Bad request |
| 401 | Unauthorized |
| 403 | Forbidden |
| 404 | Not found |
| 409 | Conflict |
| 500 | Internal server error |

### Response body codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 10 | Not effective |
| 100 | Exception error |
| 101 | Invalid request argument |
| 102 | Invalid or missing data |
| 103 | Operation error |
| 105 | Connection error |
| 106 | Operation still running |
| 108 | Permission error |
| 109 | Authentication error |
| 400 | Bad request |
| 401 | Unauthorized |
| 403 | Forbidden |
| 404 | Not found |
| 409 | Conflict |
| 500 | Server error |
---

## Migrate to 1.0

RAGFlow 1.0 moves the public REST API from the Python backend to Go. The canonical endpoints documented below remain available.

The following changes require client updates:

| Area | RAGFlow 1.0 Go change | Client action |
|------|------------------------|---------------|
| Dataset parser selection | Dataset create and update use `parse_type` with `parser_id` (BuiltIn) or `pipeline_id` (Pipeline); responses use the canonical value `general` instead of the legacy `chunk_method: "naive"`. | Replace `chunk_method` with `"parse_type": 1` and `"parser_id": "<builtin parser>"`. For the general parser, send `"parser_id": "general"`. |
| Dataset parser configuration | Go stores and returns component-scoped parser settings. Most legacy top-level `parser_config` fields are not mapped into that component structure. | Read the returned component map and send component-scoped keys when changing parser settings. |
| Errors and authentication | Some validation business codes, messages, and authentication HTTP statuses differ from Python. | Branch on documented codes rather than exact message text. |

:::note
Go responses include `X-API-Source: go`, which can be used to verify the serving backend during rollout.
:::

### Removed API aliases

The following paths remain available only on the Python backend. They are not registered by the RAGFlow 1.0 Go backend.

| Removed endpoint                                                                  | Replacement endpoint                                                                |
|-----------------------------------------------------------------------------------|-------------------------------------------------------------------------------------|
| **POST** `/api/v1/chats_openai/{chat_id}/chat/completions`                        | **POST** `/api/v1/openai/{chat_id}/chat/completions`                                |
| **PUT** `/api/v1/chats/{chat_id}/sessions/{session_id}`                           | **PATCH** `/api/v1/chats/{chat_id}/sessions/{session_id}`                           |
| **POST** `/api/v1/chats/{chat_id}/completions`                                    | **POST** `/api/v1/chat/completions`                                                 |
| **POST** `/api/v1/sessions/related_questions`                                     | **POST** `/api/v1/chat/recommendation`                                              |
| **PUT** `/api/v1/datasets/{dataset_id}/documents/{document_id}/chunks/{chunk_id}` | **PATCH** `/api/v1/datasets/{dataset_id}/documents/{document_id}/chunks/{chunk_id}` |
| **GET** `/v1/system/healthz`                                                      | **GET** `/api/v1/system/healthz`                                                    |
| **POST** `/v1/document/upload_info`                                               | **POST** `/api/v1/documents/upload`                                                 |
| **POST** `/api/v1/file/upload`                                                    | **POST** `/api/v1/files`                                                            |
| **POST** `/api/v1/file/create`                                                    | **POST** `/api/v1/files`                                                            |
| **GET** `/api/v1/file/list`                                                       | **GET** `/api/v1/files`                                                             |
| **GET** `/api/v1/file/root_folder`                                                | **GET** `/api/v1/files`                                                             |
| **GET** `/api/v1/file/parent_folder`                                              | **GET** `/api/v1/files/{file_id}/parent`                                            |
| **GET** `/api/v1/file/all_parent_folder`                                          | **GET** `/api/v1/files/{file_id}/ancestors`                                         |
| **POST** `/api/v1/file/rm`                                                        | **DELETE** `/api/v1/files`                                                          |
| **POST** `/api/v1/file/rename`                                                    | **POST** `/api/v1/files/move`                                                       |
| **GET** `/api/v1/file/get/{file_id}`                                              | **GET** `/api/v1/files/{file_id}`                                                   |
| **POST** `/api/v1/file/mv`                                                        | **POST** `/api/v1/files/move`                                                       |
| **POST** `/api/v1/file/convert`                                                   | **POST** `/api/v1/files/link-to-datasets`                                           |
| **POST** `/api/v1/agents_openai/{agent_id}/chat/completions`                      | **POST** `/api/v1/agents/chat/completions` with `"openai-compatible": true`         |

---

## OpenAI-Compatible API

---

### Create chat completion

**POST** `/api/v1/openai/{chat_id}/chat/completions`

Creates a model response for a given chat conversation.

:::caution REMOVED ALIAS
`POST /api/v1/chats_openai/{chat_id}/chat/completions` is not available in 1.0. Use this endpoint instead.
:::

This API follows the same request and response format as OpenAI's API. It allows you to interact with the model in a manner similar to how you would with [OpenAI's API](https://platform.openai.com/docs/api-reference/chat/create).

#### Request

- Method: POST
- URL: `/api/v1/openai/{chat_id}/chat/completions`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"model"`: `string` (optional)
  - `"messages"`: `object list`
  - `"stream"`: `boolean`
  - `"extra_body"`: `object` (optional)

##### Request example

```bash
curl --request POST \
     --url http://{address}/api/v1/openai/{chat_id}/chat/completions \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{
        "model": "glm-4-flash@ZHIPU-AI",
        "messages": [{"role": "user", "content": "Say this is a test!"}],
        "stream": true,
        "extra_body": {
          "reference": true,
          "reference_metadata": {
            "include": true,
            "fields": ["author", "year", "source"]
          },
          "metadata_condition": {
            "logic": "and",
            "conditions": [
              {
                "name": "author",
                "comparison_operator": "is",
                "value": "bob"
              }
            ]
          }
        }
      }'
```

##### Request parameters

- `chat_id` (*Path parameter*) `string`, *Required*
  Existing chat assistant ID. The request will use that chat assistant's knowledge and settings.

- `model` (*Body parameter*) `string`
  The model used to generate the response. When `chat_id` is provided, you may also use the legacy placeholder value `"model"` to keep using the chat assistant's configured model.

- `messages` (*Body parameter*) `list[object]`, *Required*
  A list of historical chat messages used to generate the response. This must contain at least one message with the `user` role.

- `stream` (*Body parameter*) `boolean`
  Whether to receive the response as a stream. Set this to `false` explicitly if you prefer to receive the entire response in one go instead of as a stream.

- `extra_body` (*Body parameter*) `object`
  Extra request parameters:
  - `reference`: `boolean` - include reference in the final chunk (stream) or in the final message (non-stream).
  - `reference_metadata`: `object` - include document metadata in each reference chunk.
    - `include`: `boolean` - enable document metadata in reference chunks.
    - `fields`: `list[string]` - optional allowlist of metadata keys. Omit to include all. Use an empty list to include none.
  - `metadata_condition`: `object` - metadata filter conditions applied to retrieval results.

#### Response

Stream:

```json
data:{
    "id": "chatcmpl-3b0397f277f511f0b47f729e3aa55728",
    "choices": [
        {
            "delta": {
                "content": "Hello! It seems like you're just greeting me. If you have a specific",
                "role": "assistant",
                "function_call": null,
                "tool_calls": null,
                "reasoning_content": null
            },
            "finish_reason": null,
            "index": 0,
            "logprobs": null
        }
    ],
    "created": 1755084508,
    "model": "model",
    "object": "chat.completion.chunk",
    "system_fingerprint": "",
    "usage": null
}

data:{"id": "chatcmpl-3b0397f277f511f0b47f729e3aa55728", "choices": [{"delta": {"content": " question or need information, feel free to ask, and I'll do my best", "role": "assistant", "function_call": null, "tool_calls": null, "reasoning_content": null}, "finish_reason": null, "index": 0, "logprobs": null}], "created": 1755084508, "model": "model", "object": "chat.completion.chunk", "system_fingerprint": "", "usage": null}

data:{"id": "chatcmpl-3b0397f277f511f0b47f729e3aa55728", "choices": [{"delta": {"content": " to assist you based on the knowledge base provided.", "role": "assistant", "function_call": null, "tool_calls": null, "reasoning_content": null}, "finish_reason": null, "index": 0, "logprobs": null}], "created": 1755084508, "model": "model", "object": "chat.completion.chunk", "system_fingerprint": "", "usage": null}

data:{"id": "chatcmpl-3b0397f277f511f0b47f729e3aa55728", "choices": [{"delta": {"content": null, "role": "assistant", "function_call": null, "tool_calls": null, "reasoning_content": null}, "finish_reason": "stop", "index": 0, "logprobs": null}], "created": 1755084508, "model": "model", "object": "chat.completion.chunk", "system_fingerprint": "", "usage": {"prompt_tokens": 5, "completion_tokens": 188, "total_tokens": 193}}

data:[DONE]
```

Non-stream:

```json
{
    "choices": [
        {
            "finish_reason": "stop",
            "index": 0,
            "logprobs": null,
            "message": {
                "content": "Hello! I'm your smart assistant. What can I do for you?",
                "role": "assistant"
            }
        }
    ],
    "created": 1755084403,
    "id": "chatcmpl-3b0397f277f511f0b47f729e3aa55728",
    "model": "model",
    "object": "chat.completion",
    "usage": {
        "completion_tokens": 55,
        "completion_tokens_details": {
            "accepted_prediction_tokens": 55,
            "reasoning_tokens": 5,
            "rejected_prediction_tokens": 0
        },
        "prompt_tokens": 5,
        "total_tokens": 60
    }
}
```

Failure:

```json
{
  "code": 102,
  "message": "The last content of this conversation is not from user."
}
```

---

### Create OpenAI-compatible agent completion

:::caution REMOVED ALIAS
RAGFlow 1.0 Go does not serve `POST /api/v1/agents_openai/{agent_id}/chat/completions`. Use the endpoint below and move `agent_id` into the request body.
:::

**POST** `/api/v1/agents/chat/completions`

Creates a model response for a given chat conversation.

This API follows the same request and response format as OpenAI's API. It allows you to interact with the model in a manner similar to how you would with [OpenAI's API](https://platform.openai.com/docs/api-reference/chat/create).

#### Request

- Method: POST
- URL: `/api/v1/agents/chat/completions`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"agent_id"`: `string`
  - `"openai-compatible"`: `boolean`
  - `"messages"`: `object list`
  - `"stream"`: `boolean`
  - `"session_id"`: `string` (optional)

##### Request example

```bash
curl --request POST \
     --url http://{address}/api/v1/agents/chat/completions \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{
        "agent_id": "{agent_id}",
        "openai-compatible": true,
        "messages": [{"role": "user", "content": "Say this is a test!"}],
        "stream": true
      }'
```

##### Body parameters

- `agent_id` (*Body parameter*) `string`, *Required*
  The ID of the agent to run.

- `openai-compatible` (*Body parameter*) `boolean`, *Required*
  Set this field to `true` to use the OpenAI-compatible request and response format.

- `messages` (*Body parameter*) `list[object]`, *Required*
  A list of historical chat messages used to generate the response. This must contain at least one message with the `user` role.

- `stream` (*Body parameter*) `boolean`
  Whether to receive the response as a stream. Set this to `false` explicitly if you prefer to receive the entire response in one go instead of as a stream.

- `session_id` (*Body parameter*) `string`
  Agent session id.

#### Response

Stream:

```json
...

data: {
    "id": "c39f6f9c83d911f0858253708ecb6573",
    "object": "chat.completion.chunk",
    "model": "d1f79142831f11f09cc51795b9eb07c0",
    "choices": [
        {
            "delta": {
                "content": " terminal"
            },
            "finish_reason": null,
            "index": 0
        }
    ]
}

data: {
    "id": "c39f6f9c83d911f0858253708ecb6573",
    "object": "chat.completion.chunk",
    "model": "d1f79142831f11f09cc51795b9eb07c0",
    "choices": [
        {
            "delta": {
                "content": "."
            },
            "finish_reason": null,
            "index": 0
        }
    ]
}

data: {
    "id": "c39f6f9c83d911f0858253708ecb6573",
    "object": "chat.completion.chunk",
    "model": "d1f79142831f11f09cc51795b9eb07c0",
    "choices": [
        {
            "delta": {
                "content": "",
                "reference": {
                    "chunks": {
                        "20": {
                            "id": "4b8935ac0a22deb1",
                            "content": "```cd /usr/ports/editors/neovim/ && make install```## Android[Termux](https://github.com/termux/termux-app) offers a Neovim package.",
                            "document_id": "4bdd2ff65e1511f0907f09f583941b45",
                            "document_name": "INSTALL22.md",
                            "document_metadata": {
                                "author": "bob",
                                "year": "2023",
                                "source": "internal"
                            },
                            "dataset_id": "456ce60c5e1511f0907f09f583941b45",
                            "image_id": "",
                            "positions": [
                                [
                                    12,
                                    11,
                                    11,
                                    11,
                                    11
                                ]
                            ],
                            "url": null,
                            "similarity": 0.5697155305154673,
                            "vector_similarity": 0.7323851005515574,
                            "term_similarity": 0.5000000005,
                            "doc_type": ""
                        }
                    },
                    "doc_aggs": {
                        "INSTALL22.md": {
                            "doc_name": "INSTALL22.md",
                            "doc_id": "4bdd2ff65e1511f0907f09f583941b45",
                            "count": 3
                        },
                        "INSTALL.md": {
                            "doc_name": "INSTALL.md",
                            "doc_id": "4bd7fdd85e1511f0907f09f583941b45",
                            "count": 2
                        },
                        "INSTALL(1).md": {
                            "doc_name": "INSTALL(1).md",
                            "doc_id": "4bdfb42e5e1511f0907f09f583941b45",
                            "count": 2
                        },
                        "INSTALL3.md": {
                            "doc_name": "INSTALL3.md",
                            "doc_id": "4bdab5825e1511f0907f09f583941b45",
                            "count": 1
                        }
                    }
                }
            },
            "finish_reason": null,
            "index": 0
        }
    ]
}

data: [DONE]
```

Non-stream:

```json
{
    "choices": [
        {
            "finish_reason": "stop",
            "index": 0,
            "logprobs": null,
            "message": {
                "content": "\nTo install Neovim, the process varies depending on your operating system:\n\n### For Windows:\n1. **Download from GitHub**: \n   - Visit the [Neovim releases page](https://github.com/neovim/neovim/releases)\n   - Download the latest Windows installer (nvim-win64.msi)\n   - Run the installer and follow the prompts\n\n2. **Using winget** (Windows Package Manager):\n...",
                "reference": {
                    "chunks": {
                        "20": {
                            "content": "```cd /usr/ports/editors/neovim/ && make install```## Android[Termux](https://github.com/termux/termux-app) offers a Neovim package.",
                            "dataset_id": "456ce60c5e1511f0907f09f583941b45",
                            "doc_type": "",
                            "document_id": "4bdd2ff65e1511f0907f09f583941b45",
                            "document_name": "INSTALL22.md",
                            "document_metadata": {
                                "author": "bob",
                                "year": "2023",
                                "source": "internal"
                            },
                            "id": "4b8935ac0a22deb1",
                            "image_id": "",
                            "positions": [
                                [
                                    12,
                                    11,
                                    11,
                                    11,
                                    11
                                ]
                            ],
                            "similarity": 0.5697155305154673,
                            "term_similarity": 0.5000000005,
                            "url": null,
                            "vector_similarity": 0.7323851005515574
                        }
                    },
                    "doc_aggs": {
                        "INSTALL(1).md": {
                            "count": 2,
                            "doc_id": "4bdfb42e5e1511f0907f09f583941b45",
                            "doc_name": "INSTALL(1).md"
                        },
                        "INSTALL.md": {
                            "count": 2,
                            "doc_id": "4bd7fdd85e1511f0907f09f583941b45",
                            "doc_name": "INSTALL.md"
                        },
                        "INSTALL22.md": {
                            "count": 3,
                            "doc_id": "4bdd2ff65e1511f0907f09f583941b45",
                            "doc_name": "INSTALL22.md"
                        },
                        "INSTALL3.md": {
                            "count": 1,
                            "doc_id": "4bdab5825e1511f0907f09f583941b45",
                            "doc_name": "INSTALL3.md"
                        }
                    }
                },
                "role": "assistant"
            }
        }
    ],
    "created": null,
    "id": "c39f6f9c83d911f0858253708ecb6573",
    "model": "d1f79142831f11f09cc51795b9eb07c0",
    "object": "chat.completion",
    "param": null,
    "usage": {
        "completion_tokens": 415,
        "completion_tokens_details": {
            "accepted_prediction_tokens": 0,
            "reasoning_tokens": 0,
            "rejected_prediction_tokens": 0
        },
        "prompt_tokens": 6,
        "total_tokens": 421
    }
}
```

Failure:

```json
{
  "code": 102,
  "message": "The last content of this conversation is not from user."
}
```

## DATASET MANAGEMENT

---

### Create dataset

**POST** `/api/v1/datasets`

Creates a dataset.

#### Request

- Method: POST
- URL: `/api/v1/datasets`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"name"`: `string`
  - `"parse_type"`: `int`
  - `"parser_id"`: `string`
  - `"pipeline_id"`: `string`
  - `"language"`: `string`
  - `"embedding_model"`: `string`
  - `"permission"`: `string`
  - `"parser_config"`: `object`

##### A basic request example

```bash
curl --request POST \
     --url http://{address}/api/v1/datasets \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{
      "name": "test_1",
      "language": "English",
      "parse_type": 1,
      "parser_id": "general"
      }'
```

##### A request example specifying ingestion pipeline

:::caution WARNING
Do not include `"parser_id"` when specifying an ingestion pipeline.
:::

```bash
curl --request POST \
  --url http://{address}/api/v1/datasets \
  --header 'Content-Type: application/json' \
  --header 'Authorization: Bearer <YOUR_API_KEY>' \
  --data '{
   "name": "test-sdk",
   "language": "English",
   "parse_type": 2,
   "pipeline_id": "<PIPELINE_ID_32_HEX>"
  }'
```

##### Body parameters

- `"name"`: `string`, *Required*
  The unique name of the dataset to create. It must adhere to the following requirements:
  - Basic Multilingual Plane (BMP) only
  - Maximum 128 characters
  - Case-insensitive
  If the name is already taken, the dataset is created with a numbered suffix such as `test_1(1)`, `test_1(2)`, and so on.

- `"language"`: `string`
  Optional document/dataset language, for example: `"English"` or `"Chinese"`. Leading and trailing whitespace are stripped. After trimming, it must contain at least 1 character and at most 32 characters. The limit counts characters, not UTF-8 bytes. No restricted list of language values is enforced. If omitted, the server/database default is used.

- `"embedding_model"`: `string`
  The name of the embedding model to use. For example: `"BAAI/bge-large-zh-v1.5@BAAI"`.
  - Maximum 255 characters
  - Must follow `model_name@model_factory` format

- `"permission"`: `string`
  Specifies who can access the dataset to create. Available options:
  - `"me"`: (Default) Only you can manage the dataset.
  - `"team"`: All team members can manage the dataset.

- `"parser_id"`: `enum<string>`
  The built-in parser to use. Required when `"parse_type"` is `1`.
  - `"general"`: General (default)
  - `"qa"`: Q&A
  - `"manual"`: Manual
  - `"table"`: Table
  - `"paper"`: Paper
  - `"book"`: Book
  - `"laws"`: Laws
  - `"presentation"`: Presentation
  - `"picture"`: Picture
  - `"one"`: One
  - `"audio"`: Audio
  - `"email"`: Email
  - Must be omitted when `"parse_type"` is `2`.

- `"parser_config"`: `object`
  The configuration settings for the dataset parser. RAGFlow 1.0 stores parser settings per ingestion-pipeline component; use component-scoped keys (keys containing `:`) as returned by the API. Legacy flat keys are ignored.

- `"parse_type"`: `int`, *Required*
  The parser selection mode:
  - `1`: BuiltIn. Requires `"parser_id"`.
  - `2`: Pipeline. Requires `"pipeline_id"`.

- `"pipeline_id"`: `string`
  The ingestion pipeline ID. Can be found in the corresponding URL in the RAGFlow UI.
  - Required when `"parse_type"` is `2`.
  - Must be a 32-character lowercase hexadecimal string, e.g., `"d0bebe30ae2211f0970942010a8e0005"`.
  - Must be omitted when `"parse_type"` is `1`.

:::caution WARNING
`"parse_type"` is required when creating a dataset. Choose exactly one mode:

- `"parse_type": 1` with `"parser_id"` for a builtin parser.
- `"parse_type": 2` with `"pipeline_id"` for an ingestion pipeline.

`"chunk_method"`, `"avatar"`, `"description"`, and `"auto_metadata_config"` are not accepted by the RAGFlow 1.0 create endpoint. Use `"parser_id"` instead of `"chunk_method"`; set avatar and description with the update endpoint, and metadata configuration with the metadata endpoint.
:::

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "chunk_count": 0,
        "create_time": 1745836841611,
        "created_by": "3af81804241d11f0a6a79f24fc270c7f",
        "document_count": 0,
        "embedding_model": "BAAI/bge-large-zh-v1.5@BAAI",
        "id": "3b4de7d4241d11f0a6a79f24fc270c7f",
        "language": "English",
        "name": "RAGFlow example",
        "pagerank": 0,
        "parser_config": {
            "GeneralChunker:SixApplesFall": {
                "chunk_token_size": 128,
                "delimiters": ["\n", "!?;。；！？"],
                "parent_child": {
                    "use_parent_child": false,
                    "children_delimiter": "\n"
                }
            }
        },
        "parser_id": "general",
        "permission": "me",
        "similarity_threshold": 0.2,
        "tenant_id": "3af81804241d11f0a6a79f24fc270c7f",
        "token_num": 0,
        "keywords_similarity_weight": 0.7
    }
}
```

Failure:

```json
{
    "code": 101,
    "message": "Field: <name> - Message: <String should have at least 1 character> - Value: <>"
}
```

---

### Delete datasets

**DELETE** `/api/v1/datasets`

Deletes datasets by ID.

#### Request

- Method: DELETE
- URL: `/api/v1/datasets`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"ids"`: `list[string]` or `null`
  - `"delete_all"`: `boolean`

##### Request example

```bash
curl --request DELETE \
     --url http://{address}/api/v1/datasets \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{
     "ids": ["d94a8dc02c9711f0930f7fbc369eab6d", "e94a8dc02c9711f0930f7fbc369eab6e"]
     }'
```

```bash
curl --request DELETE \
     --url http://{address}/api/v1/datasets \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{
     "delete_all": true
     }'
```

##### Body parameters

- `"ids"`: `list[string]` or `null`
  Specifies the datasets to delete:
  - If omitted, or set to `null` or an empty array, no datasets are deleted.
  - If an array of IDs is provided, only the datasets matching those IDs are deleted.
- `"delete_all"`: `boolean`
  Whether to delete all datasets owned by the current user when `"ids"` is omitted, or set to `null` or an empty array. Defaults to `false`.

#### Response

Success:

```json
{
    "code": 0
}
```

Failure:

```json
{
    "code":108,
    "message":"User '<tenant_id>' lacks permission for datasets: '<dataset_ids>'"
}

```

---

### Update dataset

**PUT** `/api/v1/datasets/{dataset_id}`

Updates configurations for a specified dataset.

#### Request

- Method: PUT
- URL: `/api/v1/datasets/{dataset_id}`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"name"`: `string`
  - `"avatar"`: `string`
  - `"description"`: `string`
  - `"language"`: `string`
  - `"embedding_model"`: `string`
  - `"permission"`: `string`
  - `"pagerank"`: `int`
  - `"parse_type"`: `int`
  - `"parser_id"`: `string`
  - `"pipeline_id"`: `string`
  - `"parser_config"`: `object`

##### Request example

```bash
curl --request PUT \
     --url http://{address}/api/v1/datasets/{dataset_id} \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '
     {
          "name": "updated_dataset"
     }'
```

##### Request parameters

- `dataset_id`: (*Path parameter*)
  The ID of the dataset to update.
- `"name"`: (*Body parameter*), `string`
  The revised name of the dataset.
  - Basic Multilingual Plane (BMP) only
  - Maximum 128 characters
  - Case-insensitive
- `"avatar"`: (*Body parameter*), `string`
  The updated base64 encoding of the avatar.
  - Maximum 65535 characters
- `"embedding_model"`: (*Body parameter*), `string`
  The updated embedding model name.
  - Ensure that `"chunk_count"` is `0` before updating `"embedding_model"`.
  - Maximum 255 characters
  - Must follow `model_name@model_factory` format
- `"language"`: (*Body parameter*), `string`
  Optional document/dataset language, for example: `"English"` or `"Chinese"`. Leading and trailing whitespace are stripped. After trimming, it must contain at least 1 character and at most 32 characters. The limit counts characters, not UTF-8 bytes. No restricted list of language values is enforced. If omitted, the existing dataset language remains unchanged.
- `"permission"`: (*Body parameter*), `string`
  The updated dataset permission. Available options:
  - `"me"`: (Default) Only you can manage the dataset.
  - `"team"`: All team members can manage the dataset.
- `"pagerank"`: (*Body parameter*), `int`
  Refer to [Set page rank](https://ragflow.io/docs/dev/dataset_configuration).
  - Default: `0`
  - Minimum: `0`
  - Maximum: `100`
- `"parse_type"`: (*Body parameter*), `int`
  The parser selection mode: `1` for a builtin parser (`parser_id` required) or `2` for an ingestion pipeline (`pipeline_id` required). Required whenever `parser_id` or `pipeline_id` is provided.
- `"parser_id"`: (*Body parameter*), `string`
  The builtin parser ID. Required when `parse_type` is `1`; must be omitted when `parse_type` is `2`.
- `"pipeline_id"`: (*Body parameter*), `string`
  The ingestion pipeline ID. Required when `parse_type` is `2`; must be omitted when `parse_type` is `1`.
- `"parser_config"`: (*Body parameter*), `object`
  The configuration settings for the dataset parser. RAGFlow 1.0 stores parser settings per ingestion-pipeline component; use component-scoped keys (keys containing `:`) as returned by the API. Legacy flat keys are ignored.

`chunk_method` is not supported by RAGFlow 1.0; use `parse_type` together with `parser_id` or `pipeline_id`.


#### Response

Success:

```json
{
    "code": 0
}
```

Failure:

```json
{
    "code": 102,
    "message": "Can't change tenant_id."
}
```

---

### List datasets

**GET** `/api/v1/datasets?page={page}&page_size={page_size}&orderby={orderby}&desc={desc}&sort={sort}&name={dataset_name}&id={dataset_id}&include_parsing_status={include_parsing_status}`

Lists datasets.

#### Request

- Method: GET
- URL: `/api/v1/datasets?page={page}&page_size={page_size}&orderby={orderby}&desc={desc}&sort={sort}&name={dataset_name}&id={dataset_id}&include_parsing_status={include_parsing_status}`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request GET \
     --url http://{address}/api/v1/datasets?page={page}&page_size={page_size}&orderby={orderby}&desc={desc}&sort={sort}&name={dataset_name}&id={dataset_id} \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

```bash
# List datasets with parsing status
curl --request GET \
     --url 'http://{address}/api/v1/datasets?include_parsing_status=true' \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Query parameters

- `page`
  Specifies the page on which the datasets will be displayed. Defaults to `1`.
- `page_size`
  The number of datasets on each page. Defaults to `30`.
- `orderby`
  The field by which datasets should be sorted. Available options:
  - `create_time` (default)
  - `update_time`
- `desc`
  Indicates whether the retrieved datasets should be sorted in descending order. Defaults to `true`.
- `sort`
  Orders by several fields at once, written as `column:direction` terms separated by commas, such as `name:asc,create_time:desc`. A term with no direction is ascending. `sort` takes precedence over `orderby` and `desc`, which keep working on their own. A term naming a field this list does not sort by is skipped. When `sort` yields no terms at all, `orderby` and `desc` decide the order. When it yields terms whose fields are all skipped, the result is ordered by `create_time` in the direction of the first term, and the older pair is not read.
- `name`
  The name of the dataset to retrieve.
- `id`
  The ID of the dataset to retrieve.
- `include_parsing_status`
  Whether to include document parsing status counts in the response. Defaults to `false`. When set to `true`, each dataset object in the response will include the following additional fields:
  - `unstart_count`: Number of documents not yet started parsing.
  - `running_count`: Number of documents currently being parsed.
  - `cancel_count`: Number of documents whose parsing was canceled.
  - `done_count`: Number of documents that have been successfully parsed.
  - `fail_count`: Number of documents whose parsing failed.

#### Response

Success:

```json
{
    "code": 0,
    "data": [
        {
            "avatar": "",
            "chunk_count": 59,
            "create_date": "Sat, 14 Sep 2024 01:12:37 GMT",
            "create_time": 1726276357324,
            "created_by": "69736c5e723611efb51b0242ac120007",
            "description": null,
            "document_count": 1,
            "embedding_model": "BAAI/bge-large-zh-v1.5",
            "id": "6e211ee0723611efa10a0242ac120007",
            "language": "English",
            "name": "mysql",
            "parser_id": "general",
            "parser_config": {
                "GeneralChunker:SixApplesFall": {
                    "chunk_token_size": 8192,
                    "delimiters": ["\n"]
                }
            },
            "permission": "me",
            "similarity_threshold": 0.2,
            "status": "1",
            "tenant_id": "69736c5e723611efb51b0242ac120007",
            "token_num": 12744,
            "update_date": "Thu, 10 Oct 2024 04:07:23 GMT",
            "update_time": 1728533243536,
            "keywords_similarity_weight": 0.7
        }
    ],
    "total_datasets": 1
}
```

Success (with `include_parsing_status=true`):

```json
{
    "code": 0,
    "data": [
        {
            "avatar": null,
            "cancel_count": 0,
            "chunk_count": 30,
            "parser_id": "qa",
            "create_date": "2026-03-09T18:57:13",
            "create_time": 1773053833094,
            "created_by": "928f92a210b911f1ac4cc39e0b8fa3ad",
            "description": null,
            "document_count": 1,
            "done_count": 1,
            "embedding_model": "text-embedding-v2@Tongyi-Qianwen",
            "fail_count": 0,
            "id": "ba6586c21ba611f1a3dc476f0709e75e",
            "language": "English",
            "name": "Test Dataset",
            "parser_config": {
                "Extractor:AutoExtractDefault": {
                    "llm_id": "deepseek-chat@DeepSeek"
                }
            },
            "permission": "me",
            "running_count": 0,
            "similarity_threshold": 0.2,
            "status": "1",
            "tenant_id": "928f92a210b911f1ac4cc39e0b8fa3ad",
            "token_num": 1746,
            "unstart_count": 0,
            "update_date": "2026-03-09T18:59:32",
            "update_time": 1773053972723,
            "keywords_similarity_weight": 0.7
        }
    ],
    "total_datasets": 1
}
```

Failure:

```json
{
    "code": 102,
    "message": "The dataset doesn't exist"
}
```

---

## FILE MANAGEMENT WITHIN DATASET

---

### Upload documents

**POST** `/api/v1/datasets/{dataset_id}/documents`

Uploads documents to a specified dataset.

This endpoint supports three creation modes via the optional `type` query parameter:

- `type=local` or omitted: Upload one or more local files using `multipart/form-data`.
- `type=web`: Crawl a web page and save it as a document.
- `type=empty`: Create an empty virtual document by name.

#### Request

- Method: POST
- URL: `/api/v1/datasets/{dataset_id}/documents`
- Query:
  - `type`: Optional. One of `local`, `web`, or `empty`. Defaults to `local`.
- Headers:
  - `'Content-Type: multipart/form-data'` for `type=local` and `type=web`
  - `'Content-Type: application/json'` for `type=empty`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - For `type=local`: form field `'file=@{FILE_PATH}'`
  - For `type=web`: form fields `'name'` and `'url'`
  - For `type=empty`: JSON body with `'name'`

##### Request example

```bash
curl --request POST \
     --url http://{address}/api/v1/datasets/{dataset_id}/documents \
     --header 'Content-Type: multipart/form-data' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --form 'file=@./test1.txt' \
     --form 'file=@./test2.pdf'
```

```bash
curl --request POST \
     --url 'http://{address}/api/v1/datasets/{dataset_id}/documents?type=web' \
     --header 'Content-Type: multipart/form-data' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --form 'name=example-page' \
     --form 'url=https://example.com'
```

```bash
curl --request POST \
     --url 'http://{address}/api/v1/datasets/{dataset_id}/documents?type=empty' \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{"name":"blank.txt"}'
```

##### Request parameters

- `dataset_id`: (*Path parameter*)
  The ID of the dataset to which the documents will be uploaded.
- `type`: (*Query parameter*)
  Controls how the document is created:
  - `local`: Upload files.
  - `web`: Crawl a URL into a document.
  - `empty`: Create an empty document without file upload.
- `'file'`: (*Body parameter*)
  A document to upload. Required when `type=local`.
- `'name'`: (*Body parameter*)
  The document name. Required when `type=web` or `type=empty`.
- `'url'`: (*Body parameter*)
  The source URL to crawl. Required when `type=web`.

#### Response

Success:

```json
{
    "code": 0,
    "data": [
        {
            "chunk_method": "naive",
            "created_by": "69736c5e723611efb51b0242ac120007",
            "dataset_id": "527fa74891e811ef9c650242ac120006",
            "id": "b330ec2e91ec11efbc510242ac120004",
            "location": "1.txt",
            "name": "1.txt",
            "parser_config": {
                "chunk_token_num": 128,
                "delimiter": "\\n",
                "html4excel": false,
                "layout_recognize": "DeepDOC"
            },
            "run": "UNSTART",
            "size": 17966,
            "thumbnail": "",
            "type": "doc"
        }
    ]
}
```

Failure:

```json
{
    "code": 101,
    "message": "No file part!"
}
```

---

### Update document

**PATCH** `/api/v1/datasets/{dataset_id}/documents/{document_id}`

Updates configurations for a specified document.

Saving parser settings preserves existing chunks, chunk images, counters, and parsing progress. The saved settings take effect on the next parse; this update does not start parsing or delete existing results. Use the document parse action to clear existing chunks and re-parse with the saved settings.

#### Request

- Method: PATCH
- URL: `/api/v1/datasets/{dataset_id}/documents/{document_id}`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"name"`:`string`
  - `"meta_fields"`:`object`
  - `"chunk_method"`:`string`
  - `"parser_config"`:`object`

##### Request example

```bash
curl --request PATCH \
     --url http://{address}/api/v1/datasets/{dataset_id}/documents/{document_id} \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --header 'Content-Type: application/json' \
     --data '
     {
          "name": "manual.txt",
          "chunk_method": "manual",
          "parser_config": {"chunk_token_num": 128}
     }'

```

##### Request parameters

- `dataset_id`: (*Path parameter*)
  The ID of the associated dataset.
- `document_id`: (*Path parameter*)
  The ID of the document to update.
- `"name"`: (*Body parameter*), `string`
- `"meta_fields"`: (*Body parameter*), `dict[str, Any]` The meta fields of the document.
- `"chunk_method"`: (*Body parameter*), `string`
  The parsing method to apply to the document:
  - `"naive"`: General
  - `"manual"`: Manual
  - `"qa"`: Q&A
  - `"table"`: Table
  - `"paper"`: Paper
  - `"book"`: Book
  - `"laws"`: Laws
  - `"presentation"`: Presentation
  - `"picture"`: Picture
  - `"one"`: One
  - `"email"`: Email
- `"parser_config"`: (*Body parameter*), `object`
  The configuration settings for the dataset parser. The attributes in this JSON object vary with the selected `"chunk_method"`:
  - If `"chunk_method"` is `"naive"`, the `"parser_config"` object contains the following attributes:
    - `"chunk_token_num"`: Defaults to `256`.
    - `"layout_recognize"`: Defaults to `"DeepDOC"`.
    - `"html4excel"`: Indicates whether to convert Excel documents into HTML format. Defaults to `false`.
    - `"delimiter"`: Defaults to `"\n"`.
    - `"task_page_size"`: Defaults to `12`. For PDF only.
- `"enabled"`: (*Body parameter*), `integer`
  Whether the document should be **available** in the knowledge base.
  - `1` → （available）
  - `0` → （unavailable）

#### Response

Success:

```json
{
  "code": 0,
  "data": {
    "id": "cd38dd72d4a611f0af9c71de94a988ef",
    "name": "large.md",
    "type": "doc",
    "suffix": "md",
    "size": 2306906,
    "location": "large.md",
    "source_type": "local",
    "status": "1",
    "run": "DONE",
    "dataset_id": "5f546a1ad4a611f0af9c71de94a988ef",

    "chunk_method": "naive",
    "chunk_count": 2,
    "token_count": 8126,

    "created_by": "eab7f446cb5a11f0ab334fbc3aa38f35",
    "create_date": "Tue, 09 Dec 2025 10:28:52 GMT",
    "create_time": 1765247332122,
    "update_date": "Wed, 17 Dec 2025 10:51:16 GMT",
    "update_time": 1765939876819,

    "process_begin_at": "Wed, 17 Dec 2025 10:33:55 GMT",
    "process_duration": 14.8615,
    "progress": 1.0,

    "progress_msg": [
      "10:33:58 Task has been received.",
      "10:33:59 Page(1~100000001): Start to parse.",
      "10:33:59 Page(1~100000001): Finish parsing.",
      "10:34:07 Page(1~100000001): Generate 2 chunks",
      "10:34:09 Page(1~100000001): Embedding chunks (2.13s)",
      "10:34:09 Page(1~100000001): Indexing done (0.31s).",
      "10:34:09 Page(1~100000001): Task done (11.68s)"
    ],

    "parser_config": {
      "chunk_token_num": 512,
      "delimiter": "\n",
      "auto_keywords": 0,
      "auto_questions": 0,
      "topn_tags": 3,
      "layout_recognize": "DeepDOC",
      "html4excel": false,
      "image_context_size": 0,
      "table_context_size": 0
    },

    "meta_fields": {},
    "pipeline_id": "",
    "thumbnail": ""
  }
}

```

Failure:

```json
{
    "code": 102,
    "message": "The dataset does not have the document."
}
```

---

### Download document

**GET** `/api/v1/datasets/{dataset_id}/documents/{document_id}`

Downloads a document from a specified dataset.

#### Request

- Method: GET
- URL: `/api/v1/datasets/{dataset_id}/documents/{document_id}`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Output:
  - `'{PATH_TO_THE_FILE}'`

##### Request example

```bash
curl --request GET \
     --url http://{address}/api/v1/datasets/{dataset_id}/documents/{document_id} \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --output ./ragflow.txt
```

##### Path parameters

- `dataset_id`
  The associated dataset ID.
- `document_id`
  The ID of the document to download.

#### Response

Success:

```json
This is a test to verify the file download feature.
```

Failure:

```json
{
    "code": 102,
    "message": "You do not own the dataset 7898da028a0511efbf750242ac1220005."
}
```

---

### List documents

**GET** `/api/v1/datasets/{dataset_id}/documents?page={page}&page_size={page_size}&orderby={orderby}&desc={desc}&keywords={keywords}&id={document_id}&name={document_name}&create_time_from={timestamp}&create_time_to={timestamp}&suffix={file_suffix}&run={run_status}&metadata_condition={json}`

Lists documents in a specified dataset.

To retrieve a specific document's settings and metadata, pass its document ID in the `id` query parameter: `/api/v1/datasets/{dataset_id}/documents?id={document_id}`.

#### Request

- Method: GET
- URL: `/api/v1/datasets/{dataset_id}/documents?page={page}&page_size={page_size}&orderby={orderby}&desc={desc}&keywords={keywords}&id={document_id}&name={document_name}&create_time_from={timestamp}&create_time_to={timestamp}&suffix={file_suffix}&run={run_status}&metadata_condition={json}`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request examples

**A basic request with pagination:**

```bash
curl --request GET \
     --url http://{address}/api/v1/datasets/{dataset_id}/documents?page=1&page_size=10 \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Request parameters

- `dataset_id`: (*Path parameter*)
  The associated dataset ID.
- `keywords`: (*Query parameter*), `string`
  The keywords used to match document titles.
- `page`: (*Query parameter*), `integer`
  Specifies the page on which the documents will be displayed. Defaults to `1`.
- `page_size`: (*Query parameter*), `integer`
  The maximum number of documents on each page. Defaults to `30`.
- `orderby`: (*Query parameter*), `string`
  The field by which documents should be sorted. Available options:
  - `create_time` (default)
  - `update_time`
- `desc`: (*Query parameter*), `boolean`
  Indicates whether the retrieved documents should be sorted in descending order. Defaults to `true`.
- `id`: (*Query parameter*), `string`
  The ID of the document to retrieve.
- `create_time_from`: (*Query parameter*), `integer`
  Unix timestamp for filtering documents created after this time. 0 means no filter. Defaults to `0`.
- `create_time_to`: (*Query parameter*), `integer`
  Unix timestamp for filtering documents created before this time. 0 means no filter. Defaults to `0`.
- `suffix`: (*Query parameter*), `array[string]`
  Filter by file suffix. Supports multiple values, e.g., `pdf`, `txt`, and `docx`. Defaults to all suffixes.
- `run`: (*Query parameter*), `array[string]`
  Filter by document processing status. Supports numeric, text, and mixed formats:
  - Numeric format: `["0", "1", "2", "3", "4", "5"]`
  - Text format: `[UNSTART, RUNNING, CANCEL, DONE, FAIL, SCHEDULE]`
  - Mixed format: `[UNSTART, 1, DONE]` (mixing numeric and text formats)
  - Status mapping:
    - `0` / `UNSTART`: Document not yet processed
    - `1` / `RUNNING`: Document is currently being processed
    - `2` / `CANCEL`: Document processing was canceled
    - `3` / `DONE`: Document processing completed successfully
    - `4` / `FAIL`: Document processing failed
    - `5` / `SCHEDULE`: Document is scheduled and waiting to be processed
  Defaults to all statuses.
- `metadata_condition`: (*Query parameter*), `object` (JSON in query)
  Optional metadata filter applied to documents when `document_ids` is not provided. Uses the same structure as retrieval:
  - `logic`: `"and"` (default) or `"or"`
  - `conditions`: array of `{ "name": string, "comparison_operator": string, "value": string }`
    - `comparison_operator` supports: `is`, `not is`, `contains`, `not contains`, `in`, `not in`, `start with`, `end with`, `>`, `<`, `≥`, `≤`, `empty`, `not empty`

##### Usage examples

**A request with multiple filtering parameters**

```bash
curl --request GET \
     --url 'http://{address}/api/v1/datasets/{dataset_id}/documents?suffix=pdf&run=DONE&page=1&page_size=10' \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

**Filter by metadata (query JSON):**

```bash
curl -G \
  --url "http://{address}/api/v1/datasets/{dataset_id}/documents" \
  --header 'Authorization: Bearer <YOUR_API_KEY>' \
  --data-urlencode 'metadata_condition={"logic":"and","conditions":[{"name":"tags","comparison_operator":"is","value":"bar"},{"name":"author","comparison_operator":"is","value":"alice"}]}'
```

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "docs": [
            {
                "chunk_count": 0,
                "create_date": "Mon, 14 Oct 2024 09:11:01 GMT",
                "create_time": 1728897061948,
                "created_by": "69736c5e723611efb51b0242ac120007",
                "id": "3bcfbf8a8a0c11ef8aba0242ac120006",
                "knowledgebase_id": "7898da028a0511efbf750242ac120005",
                "location": "Test_2.txt",
                "name": "Test_2.txt",
                "parser_config": {
                    "chunk_token_count": 128,
                    "delimiter": "\n",
                    "layout_recognize": "DeepDOC",
                    "task_page_size": 12
                },
                "chunk_method": "naive",
                "process_begin_at": null,
                "process_duration": 0.0,
                "progress": 0.0,
                "progress_msg": "",
                "run": "UNSTART",
                "size": 7,
                "source_type": "local",
                "status": "1",
                "thumbnail": null,
                "token_count": 0,
                "type": "doc",
                "update_date": "Mon, 14 Oct 2024 09:11:01 GMT",
                "update_time": 1728897061948
            }
        ],
        "total_datasets": 1
    }
}
```

Failure:

```json
{
    "code": 102,
    "message": "You don't own the dataset 7898da028a0511efbf750242ac1220005. "
}
```

---

### Delete documents

**DELETE** `/api/v1/datasets/{dataset_id}/documents`

Deletes documents by ID.

#### Request

- Method: DELETE
- URL: `/api/v1/datasets/{dataset_id}/documents`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"ids"`: `list[string]`
  - `"delete_all"`: `boolean`

##### Request example

```bash
curl --request DELETE \
     --url http://{address}/api/v1/datasets/{dataset_id}/documents \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '
     {
          "ids": ["id_1","id_2"]
     }'
```

```bash
curl --request DELETE \
     --url http://{address}/api/v1/datasets/{dataset_id}/documents \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{
          "delete_all": true
     }'
```

##### Request parameters

- `dataset_id`: (*Path parameter*)
  The associated dataset ID.
- `"ids"`: (*Body parameter*), `list[string]`
  The IDs of the documents to delete.
  - If omitted, or set to `null` or an empty array, no documents are deleted.
  - If an array of IDs is provided, only the documents matching those IDs are deleted.
- `"delete_all"`: (*Body parameter*), `boolean`
  Whether to delete all documents in the specified dataset when `"ids"` is omitted, or set to `null` or an empty array. Defaults to `false`.

#### Response

Success:

```json
{
    "code": 0
}.
```

Failure:

```json
{
    "code": 102,
    "message": "You do not own the dataset 7898da028a0511efbf750242ac1220005."
}
```

---

### Parse documents

**POST** `/api/v1/datasets/{dataset_id}/chunks`

Parses documents in a specified dataset using the built-in chunking pipeline.

:::note
This endpoint only supports datasets that use the built-in chunking pipeline. For datasets configured with an ingestion pipeline, use `POST /api/v1/documents/ingest` instead.
:::

#### Request

- Method: POST
- URL: `/api/v1/datasets/{dataset_id}/chunks`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"document_ids"`: `list[string]`
  - `"user_id"`: `string` (optional)

##### Request example

```bash
curl --request POST \
     --url http://{address}/api/v1/datasets/{dataset_id}/chunks \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '
     {
          "document_ids": ["97a5f1c2759811efaa500242ac120004","97ad64b6759811ef9fc30242ac120004"],
          "user_id": "end-user-123"
     }'
```

##### Request parameters

- `dataset_id`: (*Path parameter*)
  The dataset ID.
- `"document_ids"`: (*Body parameter*), `list[string]`, *Required*
  The IDs of the documents to parse.
- `"user_id"`: (*Body parameter*), `string`, *Optional*
  End-user identifier forwarded as the OpenAI `user` field on embedding requests for this parse job. Omitted when unset. The value is carried on the worker queue only; it is not stored on Task rows.

#### Response

Success:

```json
{
    "code": 0
}
```

Failure:

```json
{
    "code": 102,
    "message": "`document_ids` is required"
}
```

---

### Ingest documents

**POST** `/api/v1/documents/ingest`

Starts, cancels, or reruns ingestion for documents. Use this endpoint for documents in datasets configured with an ingestion pipeline.

#### Request

- Method: POST
- URL: `/api/v1/documents/ingest`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"doc_ids"`: `list[string]`
  - `"run"`: `string`
  - `"delete"`: `boolean`
  - `"user_id"`: `string` (optional)

##### Request example

```bash
curl --request POST \
     --url http://{address}/api/v1/documents/ingest \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '
     {
          "doc_ids": ["97a5f1c2759811efaa500242ac120004"],
          "run": "1",
          "delete": true,
          "user_id": "end-user-123"
     }'
```

##### Body parameters

- `"doc_ids"`: `list[string]`, *Required*
  The IDs of the documents to ingest.
- `"run"`: `string`, *Required*
  The ingestion action. Use `"1"` to start ingestion and `"2"` to cancel ingestion.
- `"delete"`: `boolean`
  Whether to delete existing tasks and chunks before rerunning. Defaults to `false`.
- `"user_id"`: `string`, *Optional*
  End-user identifier forwarded as the OpenAI `user` field on embedding requests when `run` starts ingestion. Omitted when unset.

#### Response

Success:

```json
{
    "code": 0,
    "data": true
}
```

Failure:

```json
{
    "code": 102,
    "message": "document not found"
}
```

---

### Stop parsing documents

**DELETE** `/api/v1/datasets/{dataset_id}/chunks`

Stops parsing specified documents.

#### Request

- Method: DELETE
- URL: `/api/v1/datasets/{dataset_id}/chunks`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"document_ids"`: `list[string]`

##### Request example

```bash
curl --request DELETE \
     --url http://{address}/api/v1/datasets/{dataset_id}/chunks \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '
     {
          "document_ids": ["97a5f1c2759811efaa500242ac120004","97ad64b6759811ef9fc30242ac120004"]
     }'
```

##### Request parameters

- `dataset_id`: (*Path parameter*)
  The associated dataset ID.
- `"document_ids"`: (*Body parameter*), `list[string]`, *Required*
  The IDs of the documents for which the parsing should be stopped.

#### Response

Success:

```json
{
    "code": 0
}
```

Failure:

```json
{
    "code": 102,
    "message": "`document_ids` is required"
}
```

---

## CHUNK MANAGEMENT WITHIN DATASET

---

### Add chunk

**POST** `/api/v1/datasets/{dataset_id}/documents/{document_id}/chunks`

Adds a chunk to a specified document in a specified dataset.

#### Request

- Method: POST
- URL: `/api/v1/datasets/{dataset_id}/documents/{document_id}/chunks`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"content"`: `string`
  - `"important_keywords"`: `list[string]`
  - `"tag_kwd"`: `list[string]`
  - `"questions"`: `list[string]`
  - `"image_base64"`: `string`
  - `"user_id"`: `string` (optional)

##### Request example

```bash
curl --request POST \
     --url http://{address}/api/v1/datasets/{dataset_id}/documents/{document_id}/chunks \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '
     {
          "content": "<CHUNK_CONTENT_HERE>",
          "image_base64": "<BASE64_ENCODED_IMAGE>"
     }'
```

##### Request parameters

- `dataset_id`: (*Path parameter*)
  The associated dataset ID.
- `document_id`: (*Path parameter*)
  The associated document ID.
- `"content"`: (*Body parameter*), `string`, *Required*
  The text content of the chunk.
- `"important_keywords"`: (*Body parameter*), `list[string]`
  The key terms or phrases to tag with the chunk.
- `"tag_kwd"`: (*Body parameter*), `list[string]`
  Tag keywords to associate with the chunk.
- `"questions"`: (*Body parameter*), `list[string]`
  Optional questions to use when embedding the chunk.
- `"image_base64"`: (*Body parameter*), `string`
  A base64-encoded image to associate with the chunk.
- `"user_id"`: (*Body parameter*), `string`, *Optional*
  End-user identifier forwarded as the OpenAI `user` field on the embedding request for this chunk. Omitted when unset.

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "chunk": {
            "content": "who are you",
            "create_time": "2024-12-30 16:59:55",
            "create_timestamp": 1735549195.969164,
            "dataset_id": "72f36e1ebdf411efb7250242ac120006",
            "document_id": "61d68474be0111ef98dd0242ac120006",
            "id": "12ccdc56e59837e5",
            "image_id": "",
            "important_keywords": [],
            "tag_kwd": [],
            "questions": []
        }
    }
}
```

Failure:

```json
{
    "code": 102,
    "message": "`content` is required"
}
```

---

### List chunks

**GET** `/api/v1/datasets/{dataset_id}/documents/{document_id}/chunks?keywords={keywords}&page={page}&page_size={page_size}&id={chunk_id}`

Lists chunks in a specified document.

#### Request

- Method: GET
- URL: `/api/v1/datasets/{dataset_id}/documents/{document_id}/chunks?keywords={keywords}&page={page}&page_size={page_size}&id={chunk_id}`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request GET \
     --url http://{address}/api/v1/datasets/{dataset_id}/documents/{document_id}/chunks?keywords={keywords}&page={page}&page_size={page_size}&id={chunk_id} \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Request parameters

- `dataset_id`: (*Path parameter*)
  The associated dataset ID.
- `document_id`: (*Path parameter*)
  The associated document ID.
- `keywords`(*Query parameter*), `string`
  The keywords used to match chunk content.
- `page`(*Query parameter*), `integer`
  Specifies the page on which the chunks will be displayed. Defaults to `1`.
- `page_size`(*Query parameter*), `integer`
  The maximum number of chunks on each page. Defaults to `30`.
- `id`(*Query parameter*), `string`
  The ID of the chunk to retrieve. You can also use `GET /api/v1/datasets/{dataset_id}/documents/{document_id}/chunks/{chunk_id}` to retrieve one chunk.

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "chunks": [
            {
                "available": true,
                "content": "This is a test content.",
                "docnm_kwd": "1.txt",
                "document_id": "b330ec2e91ec11efbc510242ac120004",
                "id": "b48c170e90f70af998485c1065490726",
                "image_id": "",
                "important_keywords": [],
                "tag_kwd": [],
                "positions": []
            }
        ],
        "doc": {
            "chunk_count": 1,
            "chunk_method": "naive",
            "create_date": "Thu, 24 Oct 2024 09:45:27 GMT",
            "create_time": 1729763127646,
            "created_by": "69736c5e723611efb51b0242ac120007",
            "dataset_id": "527fa74891e811ef9c650242ac120006",
            "id": "b330ec2e91ec11efbc510242ac120004",
            "location": "1.txt",
            "name": "1.txt",
            "parser_config": {
                "chunk_token_num": 128,
                "delimiter": "\\n",
                "html4excel": false,
                "layout_recognize": "DeepDOC"
            },
            "process_begin_at": "Thu, 24 Oct 2024 09:56:44 GMT",
            "process_duration": 0.54213,
            "progress": 0.0,
            "progress_msg": "Task dispatched...",
            "run": "2",
            "size": 17966,
            "source_type": "local",
            "status": "1",
            "thumbnail": "",
            "token_count": 8,
            "type": "doc",
            "update_date": "Thu, 24 Oct 2024 11:03:15 GMT",
            "update_time": 1729767795721
        },
        "total": 1
    }
}
```

Failure:

```json
{
    "code": 102,
    "message": "you don't own the document 5c5999ec7be811ef9cab0242ac12000e5"
}
```

---

### Get chunk

**GET** `/api/v1/datasets/{dataset_id}/documents/{document_id}/chunks/{chunk_id}`

Retrieves a specified chunk in a specified document. Runtime fields such as vector and token fields are not returned.

#### Request

- Method: GET
- URL: `/api/v1/datasets/{dataset_id}/documents/{document_id}/chunks/{chunk_id}`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request GET \
     --url http://{address}/api/v1/datasets/{dataset_id}/documents/{document_id}/chunks/{chunk_id} \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Path parameters

- `dataset_id`
  The associated dataset ID.
- `document_id`
  The associated document ID.
- `chunk_id`
  The ID of the chunk to retrieve.

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "available_int": 1,
        "content_with_weight": "This is a test content.",
        "doc_id": "b330ec2e91ec11efbc510242ac120004",
        "docnm_kwd": "1.txt",
        "id": "b48c170e90f70af998485c1065490726",
        "img_id": "",
        "important_kwd": [],
        "question_kwd": [],
        "tag_kwd": []
    }
}
```

Failure:

```json
{
    "code": 100,
    "message": "Chunk not found"
}
```

---

### Delete chunks

**DELETE** `/api/v1/datasets/{dataset_id}/documents/{document_id}/chunks`

Deletes chunks by ID.

#### Request

- Method: DELETE
- URL: `/api/v1/datasets/{dataset_id}/documents/{document_id}/chunks`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"chunk_ids"`: `list[string]`
  - `"delete_all"`: `boolean`

##### Request example

```bash
curl --request DELETE \
     --url http://{address}/api/v1/datasets/{dataset_id}/documents/{document_id}/chunks \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '
     {
          "chunk_ids": ["test_1", "test_2"]
     }'
```

```bash
curl --request DELETE \
     --url http://{address}/api/v1/datasets/{dataset_id}/documents/{document_id}/chunks \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{
          "delete_all": true
     }'
```

##### Request parameters

- `dataset_id`: (*Path parameter*)
  The associated dataset ID.
- `document_id`: (*Path parameter*)
  The associated document ID.
- `"chunk_ids"`: (*Body parameter*), `list[string]`
  The IDs of the chunks to delete.
  - If omitted, or set to `null` or an empty array, no chunks are deleted.
  - If an array of IDs is provided, only the chunks matching those IDs are deleted.
- `"delete_all"`: (*Body parameter*), `boolean`
  Whether to delete all chunks of the specified document when `"chunk_ids"` is omitted, or set to `null` or an empty array. Defaults to `false`.

#### Response

Success:

```json
{
    "code": 0
}
```

Failure:

```json
{
    "code": 102,
    "message": "rm_chunk deleted chunks 0, expect 1"
}
```

---

### Update chunk

**PATCH** `/api/v1/datasets/{dataset_id}/documents/{document_id}/chunks/{chunk_id}`

Updates content or configurations for a specified chunk.

:::caution REMOVED ALIAS
`PUT /api/v1/datasets/{dataset_id}/documents/{document_id}/chunks/{chunk_id}` is not available in 1.0. Use this endpoint instead.
:::

#### Request

- Method: PATCH
- URL: `/api/v1/datasets/{dataset_id}/documents/{document_id}/chunks/{chunk_id}`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"content"`: `string`
  - `"important_keywords"`: `list[string]`
  - `"questions"`: `list[string]`
  - `"positions"`: `list`
  - `"tag_kwd"`: `list[string]`
  - `"available"`: `boolean`
  - `"image_base64"`: `string`
  - `"user_id"`: `string` (optional)

##### Request example

```bash
curl --request PATCH \
     --url http://{address}/api/v1/datasets/{dataset_id}/documents/{document_id}/chunks/{chunk_id} \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '
     {
          "content": "ragflow123",
          "important_keywords": []
     }'
```

##### Request parameters

- `dataset_id`: (*Path parameter*)
  The associated dataset ID.
- `document_id`: (*Path parameter*)
  The associated document ID.
- `chunk_id`: (*Path parameter*)
  The ID of the chunk to update.
- `"content"`: (*Body parameter*), `string`
  The text content of the chunk.
- `"important_keywords"`: (*Body parameter*), `list[string]`
  A list of key terms or phrases to tag with the chunk.
- `"questions"`: (*Body parameter*), `list[string]`
  Optional questions to use when embedding the chunk.
- `"positions"`: (*Body parameter*), `list`
  Updated source positions for the chunk.
- `"tag_kwd"`: (*Body parameter*), `list[string]`
  Updated tag keywords.
- `"available"`: (*Body parameter*) `boolean`
  The chunk's availability status in the dataset. Value options:
  - `true`: Available (default)
  - `false`: Unavailable
- `"image_base64"`: (*Body parameter*), `string`
  Base64-encoded image content to associate with the chunk.
- `"user_id"`: (*Body parameter*), `string`, *Optional*
  End-user identifier forwarded as the OpenAI `user` field on the embedding request for this update. Omitted when unset.

#### Response

Success:

```json
{
    "code": 0
}
```

Failure:

```json
{
    "code": 102,
    "message": "Can't find this chunk 29a2d9987e16ba331fb4d7d30d99b71d2"
}
```

---

### Update chunk availability

**PATCH** `/api/v1/datasets/{dataset_id}/documents/{document_id}/chunks`

Updates or switches the availability status of specified chunks, controlling whether they are available for retrieval.

#### Request

- Method: PATCH
- URL: `/api/v1/datasets/{dataset_id}/documents/{document_id}/chunks`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"chunk_ids"`: `list[string]` (*Required*)
  - `"available_int"`: `integer` (*Optional*)
  - `"available"`: `boolean` (*Optional*)

##### Request example

```bash
curl --request PATCH \
     --url http://{address}/api/v1/datasets/{dataset_id}/documents/{document_id}/chunks \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '
     {
          "chunk_ids": ["chunk_id_1", "chunk_id_2"],
          "available_int": 1
     }'
```

##### Request parameters

- `dataset_id`: (*Path parameter*)
  The ID of the dataset.
- `document_id`: (*Path parameter*)
  The ID of the document.
- `"chunk_ids"`: (*Body parameter*), `list[string]` (*Required*)
  IDs of the chunks whose availability status is to be updated.
- `"available_int"`: (*Body parameter*), `integer` (*Optional*)
  Availability status for the specified chunks. You must provide either `"available_int"` or `"available"`. If both are provided, `"available_int"` is used.
  - `1`: Available,
  - `0`: Unavailable.
- `"available"`: (*Body parameter*), `boolean` (*Optional*)
  Availability status of the specified chunks. Used when `"available_int"` is not provided.
  - `true`: Available,
  - `false`: Unavailable.

#### Response

Success:

```json
{
    "code": 0,
    "data": true
}
```

Failure:

```json
{
    "code": 102,
    "message": "You don't own the dataset {dataset_id}."
}
```

```json
{
    "code": 102,
    "message": "`chunk_ids` is required."
}
```

```json
{
    "code": 102,
    "message": "`available_int` or `available` is required."
}
```

```json
{
    "code": 102,
    "message": "document not found"
}
```

```json
{
    "code": 102,
    "message": "Index updating failure"
}
```

---

### Retrieve a metadata summary from a dataset

**GET** `/api/v1/datasets/{dataset_id}/metadata/summary`

Aggregates metadata values across all documents in a dataset.

#### Request

- Method: GET
- URL: `/api/v1/datasets/{dataset_id}/metadata/summary`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Response

Success:

```json
{
  "code": 0,
  "data": {
    "summary": {
      "tags": {
        "type": "string",
        "values": [["bar", 2], ["foo", 1], ["baz", 1]]
      },
      "author": {
        "type": "string",
        "values": [["alice", 2], ["bob", 1]]
      }
    }
  }
}
```

---

### Update or delete metadata

**POST** `/api/v1/datasets/{dataset_id}/metadata/update`

Batch update or delete document-level metadata within a specified dataset. If both `document_ids` and `metadata_condition` are omitted, all documents within that dataset are selected. When both are provided, the intersection is used.

#### Request

- Method: POST
- URL: `/api/v1/datasets/{dataset_id}/metadata/update`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `selector`: `object`
  - `updates`: `list[object]`
  - `deletes`: `list[object]`

#### Request parameters

- `dataset_id`: (*Path parameter*)
  The associated dataset ID.
- `"selector"`: (*Body parameter*), `object`, *optional*
  A document selector:
  - `"document_ids"`: `list[string]` *optional*
    The associated document ID.
  - `"metadata_condition"`: `object`, *optional*
    - `"logic"`: Defines the logic relation between conditions if multiple conditions are provided. Options:
      - `"and"` (default)
      - `"or"`
    - `"conditions"`: `list[object]` *optional*
      Each object: `{ "name": string, "comparison_operator": string, "value": string }`
      - `"name"`: `string` The key name to search by.
      - `"comparison_operator"`: `string` Available options:
        - `"is"`
        - `"not is"`
        - `"contains"`
        - `"not contains"`
        - `"in"`
        - `"not in"`
        - `"start with"`
        - `"end with"`
        - `">"`
        - `"<"`
        - `"≥"`
        - `"≤"`
        - `"empty"`
        - `"not empty"`
      - `"value"`: `string` The key value to search by.
- `"updates"`: (*Body parameter*), `list[object]`, *optional*
  Replaces metadata of the retrieved documents. Each object: `{ "key": string, "match": string, "value": string }`.
  - `"key"`: `string` The name of the key to update.
  - `"match"`: `string` *optional* The current value of the key to update. When omitted, the corresponding keys are updated to `"value"` regardless of their current values.
  - `"value"`: `string` The new value to set for the specified keys.
- `"deletes"`: (*Body parameter*), `list[object]`, *optional*
  Deletes metadata of the retrieved documents. Each object: `{ "key": string, "value": string }`.
  - `"key"`: `string` The name of the key to delete.
  - `"value"`: `string` *Optional* The value of the key to delete.
    - When provided, only keys with a matching value are deleted.
    - When omitted, all specified keys are deleted.

##### Request example

```bash
curl --request POST \
     --url http://{address}/api/v1/datasets/{dataset_id}/metadata/update \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{
       "selector": {
         "metadata_condition": {
           "logic": "and",
           "conditions": [
             {"name": "author", "comparison_operator": "is", "value": "alice"}
           ]
         }
       },
       "updates": [
         {"key": "tags", "match": "foo", "value": "foo_new"}
       ],
       "deletes": [
         {"key": "obsolete_key"},
         {"key": "author", "value": "alice"}
       ]
     }'
```

##### Response

Success:

```json
{
  "code": 0,
  "data": {
    "updated": 1,
    "matched_docs": 2
  }
}
```

---

### Retrieve chunks

**POST** `/api/v1/retrieval`

Retrieves chunks from specified datasets.

#### Request

- Method: POST
- URL: `/api/v1/retrieval`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"question"`: `string`
  - `"dataset_ids"`: `list[string]`
  - `"document_ids"`: `list[string]`
  - `"page"`: `integer`
  - `"page_size"`: `integer`
  - `"similarity_threshold"`: `float`
  - `"keywords_similarity_weight"`: `float`
  - `"vector_similarity_weight"`: `float` (legacy fallback)
  - `"top_k"`: `integer` (deprecated; use `"knn_top_k"`)
  - `"knn_top_k"`: `integer`
  - `"knn_num_candidates"`: `integer`
  - `"rerank_candidates_count"`: `integer`
  - `"rerank_id"`: `string`
  - `"keyword"`: `boolean`
  - `"highlight"`: `boolean`
  - `"cross_languages"`: `list[string]`
  - `"metadata_condition"`: `object`
  - `"use_kg"`: `boolean`
  - `"include_knowledge_compilation"`: `boolean`
  - `"knowledge_compilation_scope"`: `string`

##### Request example

```bash
curl --request POST \
     --url http://{address}/api/v1/retrieval \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '
     {
          "question": "What is advantage of ragflow?",
          "dataset_ids": ["b2a62730759d11ef987d0242ac120004"],
          "document_ids": ["77df9ef4759a11ef8bdd0242ac120004"],
          "knn_top_k": 1024,
          "knn_num_candidates": 2048,
          "rerank_candidates_count": 64,
          "include_knowledge_compilation": true,
          "metadata_condition": {
            "logic": "and",
            "conditions": [
              {
                "name": "author",
                "comparison_operator": "=",
                "value": "Toby"
              },
              {
                "name": "url",
                "comparison_operator": "not contains",
                "value": "amd"
              }
            ]
          }
     }'
```

##### Body parameters

- `"question"`: `string`, *Required*
  The user query or query keywords.
- `"dataset_ids"`: `list[string]`, *Required*
  The IDs of the datasets to search. At least one dataset ID must be provided.
- `"document_ids"`: `list[string]`
  Limits the search to specific documents within the datasets specified by `"dataset_ids"`. Ensure that all selected documents use the same embedding model. Defaults to an empty list.
- `"page"`: `integer`
  Specifies the page on which the chunks will be displayed. Defaults to `1`.
- `"page_size"`
  The maximum number of chunks on each page. Defaults to `30`.
- `"similarity_threshold"`
  The minimum similarity score. Defaults to `0.2`.
- `"keywords_similarity_weight"`: `float`
  The weight of term similarity. Defaults to `0.7`; the vector cosine similarity weight is calculated as `1 - keywords_similarity_weight`.
- `"vector_similarity_weight"`: `float`
  Legacy fallback used when `"keywords_similarity_weight"` is omitted. If both fields are provided, they must sum to `1`.
- `"top_k"`: `integer`
  **Deprecated.** An alias for `"knn_top_k"`. If both parameters are provided, `"knn_top_k"` takes precedence.
- `"knn_top_k"`: `integer`
  The number of chunks engaged in vector cosine computation. Defaults to `1024`.
- `"knn_num_candidates"`: `integer`
  The number of approximate nearest-neighbor candidates considered for vector search. It must be greater than or equal to `"knn_top_k"`. Defaults to the greater of `2048` and `"knn_top_k"`. This parameter currently applies only to Elasticsearch.
- `"rerank_candidates_count"`: `integer`
  The number of initial retrieval candidates to rank. It must be at least `"page"` multiplied by `"page_size"`. Defaults to `64`.
- `"include_knowledge_compilation"`: `boolean`
  Whether to include knowledge-compilation chunks in the results. Defaults to `true`.
- `"knowledge_compilation_scope"`: `string`
  Selects which searchable knowledge-compilation chunks to include: `"dataset"` for dataset artifacts, `"document"` for document artifacts, or `"all"` for both. Defaults to `"dataset"` when omitted, `null`, or an empty string. Ordinary source chunks remain eligible. When `"include_knowledge_compilation"` is `false`, all compiled chunks are excluded regardless of scope. Unsupported scope values and non-string values return an argument error. Intermediate wiki rows and disabled chunks remain excluded.
  With `"document_ids"` or metadata filtering, document artifacts and source chunks are limited to the selected documents; dataset artifacts must reference a selected document in their `source_doc_ids`. This parameter is also supported by `POST /api/v1/datasets/search` and `POST /api/v1/datasets/{dataset_id}/search`.
- `"use_kg"`: `boolean`
  Whether to search chunks related to the generated knowledge graph for multi-hop queries. Defaults to `False`. Before enabling this, ensure you have successfully constructed a knowledge graph for the specified datasets. See [here](../guides/knowledge_compilation/built_in_templates_and_dedicated_configuration.md#graph) for details.
- `"rerank_id"`: `string`
  The ID of the rerank model.
- `"keyword"`: `boolean`
  Indicates whether to enable keyword-based matching:
  - `true`: Enable keyword-based matching.
  - `false`: Disable keyword-based matching (default).
- `"highlight"`: `boolean`
  Specifies whether to enable highlighting of matched terms in the results:
  - `true`: Enable highlighting of matched terms.
  - `false`: Disable highlighting of matched terms (default).
- `"cross_languages"`: (*Body parameter*) `list[string]`
  The languages that should be translated into, in order to achieve keywords retrievals in different languages.
- `"metadata_condition"`: `object`
  The metadata condition used for filtering chunks:
  - `"logic"`: `string`
    - `"and"`: Return only results that satisfy *every* condition (default).
    - `"or"`: Return results that satisfy *any* condition.
  - `"conditions"`: `array`
    A list of metadata filter conditions.
    - `"name"`: `string` - The metadata field name to filter by, e.g., `"author"`, `"company"`, `"url"`. Ensure this parameter before use. See [Set metadata](../guides/dataset/metadata_management.md) for details.
    - `comparison_operator`: `string` - The comparison operator. Can be one of:
      - `"contains"`
      - `"not contains"`
      - `"start with"`
      - `"empty"`
      - `"not empty"`
      - `"="`
      - `"≠"`
      - `">"`
      - `"<"`
      - `"≥"`
      - `"≤"`
    - `"value"`: `string` - The value to compare.

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "chunks": [
            {
                "content": "ragflow content",
                "content_ltks": "ragflow content",
                "document_id": "5c5999ec7be811ef9cab0242ac120005",
                "document_keyword": "1.txt",
                "highlight": "<em>ragflow</em> content",
                "id": "d78435d142bd5cf6704da62c778795c5",
                "image_id": "",
                "important_keywords": [
                    ""
                ],
                "tag_kwd": [],
                "dataset_id": "c7ee74067a2c11efb21c0242ac120006",
                "positions": [
                    ""
                ],
                "similarity": 0.9669436601210759,
                "term_similarity": 1.0,
                "vector_similarity": 0.8898122004035864
            }
        ],
        "doc_aggs": [
            {
                "count": 1,
                "doc_id": "5c5999ec7be811ef9cab0242ac120005",
                "doc_name": "1.txt"
            }
        ],
        "total": 1
    }
}
```

Failure:

```json
{
    "code": 102,
    "message": "`dataset_ids` is required."
}
```

---

## CHAT ASSISTANT MANAGEMENT

---

### Create chat assistant

**POST** `/api/v1/chats`

Creates a chat assistant.

#### Request

- Method: POST
- URL: `/api/v1/chats`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"name"`: `string`
  - `"icon"`: `string`
  - `"dataset_ids"`: `list[string]`
  - `"llm_id"`: `string`
  - `"llm_setting"`: `object`
  - `"prompt_config"`: `object`

##### Request example

```shell
curl --request POST \
     --url http://{address}/api/v1/chats \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{
    "dataset_ids": ["0b2cbc8c877f11ef89070242ac120005"],
    "name":"new_chat_1"
}'
```

##### Body parameters

- `"name"`: `string`, *Required*
  The name of the chat assistant.
  If a chat assistant with the same name already exists, the new one gets a numbered suffix such as `new_chat_1(1)`.
- `"icon"`: `string`
  Base64 encoding of the avatar.
- `"dataset_ids"`: `list[string]`
  The unique identifiers for the associated datasets. If omitted or set to `[]`, an empty chat assistant is created; datasets can be attached at a later time.
- `"llm_id"`: `string`
  The identifier of the chat model. If not specified, the system defaults to the user's pre-configured chat model.
- `"llm_setting"`: `object`
  A configuration object defining the LLM parameters for the assistant. The `llm_setting` object may contain the following attributes:
  - `"model_type"`: `string`
    A model type specifier. Only `"chat"` and `"image2text"` are recognized; any other inputs, or when omitted, are treated as `"chat"`.
  - `"temperature"`: `float`
    Controls the randomness of the model's predictions. A lower temperature results in more conservative responses, while a higher temperature yields more creative and diverse responses. Defaults to `0.1`.
  - `"top_p"`: `float`
    Also known as "nucleus sampling", this parameter sets a threshold to select a smaller set of words to sample from. It focuses on the most likely words, cutting off the less probable ones. Defaults to `0.3`
  - `"presence_penalty"`: `float`
    This discourages the model from repeating the same information by penalizing words that have already appeared in the conversation. Defaults to `0.4`.
  - `"frequency penalty"`: `float`
    Similar to the presence penalty, this reduces the model's tendency to repeat the same words frequently. Defaults to `0.7`.
- `"prompt_config"`: `object`
  Instructions for the LLM to follow. A `prompt_config` object may contain the following attributes:
  - `"system"`: `string` The prompt content.
  - `"prologue"`: `string` The opening greeting for the user.
  - `"parameters"`: `object[]` This argument lists the variables to use in the system prompt. Note that:
    - `"knowledge"` is a reserved variable, which represents the retrieved chunks.
    - All the variables in `"system"` should be curly bracketed.
  - `"empty_response"`: `string` If nothing is retrieved in the dataset for the user's question, this will be used as the response. To allow the LLM to improvise when nothing is found, leave this blank.
  - `"quote"`: `boolean` Whether the source of text should be displayed. Defaults to `true`.
  - `"tts"`: `boolean`
  - `"refine_multiturn"`: `boolean`
  - `"reasoning"`: `boolean`
  - `"cross_languages"`: `list[string]`
  - `"web_search_provider"`: `string` The web search service to use. Supported values are `"brave"`, `"exa"`, `"firecrawl"`, `"linkup"`, `"parallel"`, `"querit"`, `"search1api"`, `"serply"`, `"tavily"`, and `"youcom"`. If omitted, Tavily is selected only when `"tavily_api_key"` is configured; otherwise web search is disabled.
  - `"tavily_api_key"`: `string`
  - `"brave_api_key"`: `string` The Brave Search API key. Set `web_search_provider` to `"brave"` when using this field.
  - `"exa_api_key"`: `string` The Exa API key. Set `web_search_provider` to `"exa"` when using this field.
  - `"firecrawl_api_key"`: `string` The [Firecrawl](https://www.firecrawl.dev/search) API key. Set `web_search_provider` to `"firecrawl"` when using this field. See the [Firecrawl Search API reference](https://docs.firecrawl.dev/api-reference/endpoint/search) for details.
  - `"linkup_api_key"`: `string` The Linkup API key. Set `web_search_provider` to `"linkup"` when using this field.
  - `"parallel_api_key"`: `string` The Parallel API key. Set `web_search_provider` to `"parallel"` when using this field.
  - `"querit_api_key"`: `string` The Querit API key. Set `web_search_provider` to `"querit"` when using this field.
  - `"search1api_api_key"`: `string` The [Search1API](https://s1.dev) API key. Set `web_search_provider` to `"search1api"` when using this field. See the [Search1API documentation](https://s1.dev/docs/basic/search) for details.
  - `"serply_api_key"`: `string` The [Serply](https://serply.io) API key. Set `web_search_provider` to `"serply"` when using this field. See the [Serply documentation](https://serply.io/docs) for details.
  - `"youcom_api_key"`: `string` The You.com API key. Set `web_search_provider` to `"youcom"` when using this field. Optional: You.com serves a rate-limited keyless endpoint, so `"youcom"` works with this field omitted, and a key lifts those limits.
- `"similarity_threshold"`: `float`
- `"keywords_similarity_weight"`: `float`
- `"vector_similarity_weight"`: `float`, legacy fallback. If both weights are provided, they must sum to `1`.
- `"top_n"`: `int`
- `"top_k"`: `int`
- `"rerank_id"`: `string`

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "icon": "",
        "create_date": "Thu, 24 Oct 2024 11:18:29 GMT",
        "create_time": 1729768709023,
        "dataset_ids": [
            "527fa74891e811ef9c650242ac120006"
        ],
        "kb_names": [
            "dataset_1"
        ],
        "description": "A helpful Assistant",
        "id": "b1f2f15691f911ef81180242ac120003",
        "language": "English",
        "llm_id": "qwen-plus@Tongyi-Qianwen",
        "llm_setting": {
            "frequency_penalty": 0.7,
            "presence_penalty": 0.4,
            "temperature": 0.1,
            "top_p": 0.3
        },
        "name": "12234",
        "prompt_config": {
            "empty_response": "Sorry! No relevant content was found in the knowledge base!",
            "prologue": "Hi! I'm your assistant. What can I do for you?",
            "quote": true,
            "system": "You are an intelligent assistant...",
            "parameters": [
                {
                    "key": "knowledge",
                    "optional": false
                }
            ]
        },
        "rerank_id": "",
        "similarity_threshold": 0.2,
        "keywords_similarity_weight": 0.7,
        "top_n": 6,
        "prompt_type": "simple",
        "status": "1",
        "tenant_id": "69736c5e723611efb51b0242ac120007",
        "top_k": 1024,
        "update_date": "Thu, 24 Oct 2024 11:18:29 GMT",
        "update_time": 1729768709023
    }
}
```

Failure:

```json
{
    "code": 102,
    "message": "`name` is required"
}
```

---

### Update chat assistant

**PUT** `/api/v1/chats/{chat_id}`

Overwrites the existing configuration for a specified chat assistant.

Use this endpoint only when providing a complete configuration. Any fields omitted from the request will be reset to their server-side default values. For partial updates, use `PATCH /api/v1/chats/{chat_id}` instead.

#### Request

- Method: PUT
- URL: `/api/v1/chats/{chat_id}`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"name"`: `string`
  - `"icon"`: `string`
  - `"dataset_ids"`: `list[string]`
  - `"llm_id"`: `string`
  - `"llm_setting"`: `object`
  - `"prompt_config"`: `object`

##### Request example

```bash
curl --request PUT \
     --url http://{address}/api/v1/chats/{chat_id} \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '
     {
          "name":"Test",
          "icon":"",
          "dataset_ids":["0b2cbc8c877f11ef89070242ac120005"],
          "llm_id":"qwen-plus@Tongyi-Qianwen",
          "llm_setting":{"temperature":0.1,"top_p":0.3,"presence_penalty":0.4,"frequency_penalty":0.7},
          "prompt_config":{
               "system":"You are an intelligent assistant...",
               "prologue":"Hi! I'\''m your assistant. What can I do for you?",
               "parameters":[{"key":"knowledge","optional":false}],
               "empty_response":"Sorry! No relevant content was found in the knowledge base!",
               "quote":true
          },
          "similarity_threshold":0.2,
          "keywords_similarity_weight":0.7,
          "top_n":6,
          "top_k":1024,
          "rerank_id":""
     }'
```

#### Parameters

- `chat_id`: (*Path parameter*)
  The ID of the chat assistant to update.
- `"name"`: (*Body parameter*), `string`, *Required*
  The revised name of the chat assistant.
- `"icon"`: (*Body parameter*), `string`
  Base64 encoding of the avatar.
- `"dataset_ids"`: (*Body parameter*), `list[string]`
  The IDs of the associated datasets.
- `"llm_id"`: (*Body parameter*), `string`
  The chat model name. If not set, the user's default chat model is used.
- `"llm_setting"`: (*Body parameter*), `object`
  The LLM settings for the chat assistant. An `llm_setting` object contains the following attributes:
  - `"model_type"`: `string`
    A model type specifier. Supported values are `"chat"` and `"image2text"`. If the field is omitted or an unrecognized value is provided, it defaults to `"chat"`.
  - `"temperature"`: `float`
    Controls the randomness of the model's predictions. A lower temperature results in more conservative responses, while a higher temperature yields more creative and diverse responses. Defaults to `0.1`.
  - `"top_p"`: `float`
    Also known as "nucleus sampling", this parameter sets a threshold to select a smaller set of words to sample from. It focuses on the most likely words, cutting off the less probable ones. Defaults to `0.3`
  - `"presence_penalty"`: `float`
    This discourages the model from repeating the same information by penalizing words that have already appeared in the conversation. Defaults to `0.4`.
  - `"frequency penalty"`: `float`
    Similar to the presence penalty, this reduces the model's tendency to repeat the same words frequently. Defaults to `0.7`.
- `"prompt_config"`: (*Body parameter*), `object`
- `"similarity_threshold"`: (*Body parameter*), `float`
- `"keywords_similarity_weight"`: (*Body parameter*), `float`
- `"vector_similarity_weight"`: (*Body parameter*), `float`, legacy fallback. If both weights are provided, they must sum to `1`.
- `"top_n"`: (*Body parameter*), `int`
- `"top_k"`: (*Body parameter*), `int`
- `"rerank_id"`: (*Body parameter*), `string`

For `PUT` requests, any fields omitted from the request body are reset to their server-side default values.

#### Response

Success: returns the full updated chat assistant object.

```json
{
    "code": 0,
    "data": {
        "id": "04d0d8e28d1911efa3630242ac120006",
        "name": "Test",
        "description": "A helpful Assistant",
        "icon": "",
        "dataset_ids": ["527fa74891e811ef9c650242ac120006"],
        "kb_names": ["dataset_1"],
        "llm_id": "qwen-plus@Tongyi-Qianwen",
        "llm_setting": {
            "frequency_penalty": 0.7,
            "presence_penalty": 0.4,
            "temperature": 0.1,
            "top_p": 0.3
        },
        "prompt_config": {
            "empty_response": "Sorry! No relevant content was found in the knowledge base!",
            "prologue": "Hi! I'm your assistant. What can I do for you?",
            "quote": true,
            "system": "You are an intelligent assistant...",
            "parameters": [{"key": "knowledge", "optional": false}]
        },
        "similarity_threshold": 0.2,
        "keywords_similarity_weight": 0.7,
        "top_n": 6,
        "top_k": 1024,
        "rerank_id": "",
        "status": "1",
        "tenant_id": "69736c5e723611efb51b0242ac120007",
        "create_time": 1729232406637,
        "update_time": 1729232406638
    }
}
```

Failure:

```json
{
    "code": 102,
    "message": "duplicated chat name"
}
```

---

### Get chat assistant

**GET** `/api/v1/chats/{chat_id}`

Retrieves a specified chat assistant.

#### Request

- Method: GET
- URL: `/api/v1/chats/{chat_id}`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request GET \
     --url http://{address}/api/v1/chats/{chat_id} \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Path parameters

- `chat_id`
  The ID of the chat assistant to retrieve.

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "icon": "",
        "create_date": "Fri, 18 Oct 2024 06:20:06 GMT",
        "create_time": 1729232406637,
        "description": "A helpful Assistant",
        "id": "04d0d8e28d1911efa3630242ac120006",
        "dataset_ids": ["527fa74891e811ef9c650242ac120006"],
        "kb_names": ["dataset_1"],
        "language": "English",
        "llm_id": "qwen-plus@Tongyi-Qianwen",
        "llm_setting": {
            "temperature": 0.1,
            "top_p": 0.3
        },
        "name": "my_chat",
        "prompt_config": {
            "empty_response": "Sorry! No relevant content was found in the knowledge base!",
            "prologue": "Hi! I'm your assistant. What can I do for you?",
            "quote": true,
            "system": "You are an intelligent assistant...",
            "parameters": [{"key": "knowledge", "optional": false}]
        },
        "rerank_id": "",
        "similarity_threshold": 0.2,
        "keywords_similarity_weight": 0.7,
        "top_n": 6,
        "status": "1",
        "tenant_id": "69736c5e723611efb51b0242ac120007",
        "update_date": "Fri, 18 Oct 2024 06:20:06 GMT",
        "update_time": 1729232406638
    }
}
```

Failure:

```json
{
    "code": 102,
    "message": "no authorization"
}
```

---

### Partially update chat assistant

**PATCH** `/api/v1/chats/{chat_id}`

Performs a partial update on a specified chat assistant.

Unspecified fields are preserved, while nested objects, such as `llm_setting` and `prompt_config`, are deep-merged with the existing configuration. This is the recommended endpoint for renaming an assistant or modifying a specific subset of settings.

#### Request

- Method: PATCH
- URL: `/api/v1/chats/{chat_id}`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body: any subset of the fields accepted by `PUT /api/v1/chats/{chat_id}`

##### Request example

```bash
curl --request PATCH \
     --url http://{address}/api/v1/chats/{chat_id} \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{
    "llm_id": "gpt-4o",
    "llm_setting": {"temperature": 0.5}
}'
```

#### Response

Success: returns the full updated chat assistant object (same structure as `PUT /api/v1/chats/{chat_id}`).

```json
{
    "code": 0,
    "data": {
        "id": "04d0d8e28d1911efa3630242ac120006",
        "name": "Renamed assistant",
        "llm_id": "qwen-plus@Tongyi-Qianwen",
        "..."  : "..."
    }
}
```

Failure:

```json
{
    "code": 102,
    "message": "no authorization"
}
```

---

### Delete chat assistant

**DELETE** `/api/v1/chats/{chat_id}`

Deletes a chat assistant by ID.

#### Request

- Method: DELETE
- URL: `/api/v1/chats/{chat_id}`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request DELETE \
     --url http://{address}/api/v1/chats/{chat_id} \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Path parameters

- `chat_id`
  The ID of the chat assistant to delete.

#### Response

Success:

```json
{
    "code": 0,
    "data": true
}
```

Failure:

```json
{
    "code": 102,
    "message": "no authorization"
}
```

---

### Delete chat assistants

**DELETE** `/api/v1/chats`

Deletes chat assistants by ID.

#### Request

- Method: DELETE
- URL: `/api/v1/chats`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"ids"`: `list[string]`
  - `"delete_all"`: `boolean`

##### Request example

```bash
curl --request DELETE \
     --url http://{address}/api/v1/chats \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '
     {
          "ids": ["test_1", "test_2"]
     }'
```

```bash
curl --request DELETE \
     --url http://{address}/api/v1/chats \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{
          "delete_all": true
     }'
```

##### Body parameters

- `"ids"`: `list[string]`
  The IDs of the chat assistants to delete.
  - If omitted, or set to `null` or an empty array, no chat assistants are deleted.
  - If an array of IDs is provided, only the chat assistants matching those IDs are deleted.
- `"delete_all"`: `boolean`
  Whether to delete all chat assistants owned by the current user when `"ids"` is omitted, or set to`null` or an empty array. Defaults to `false`.

#### Response

Success:

```json
{
    "code": 0
}
```

Failure:

```json
{
    "code": 102,
    "message": "ids are required"
}
```

---

### List chat assistants

**GET** `/api/v1/chats?page={page}&page_size={page_size}&orderby={orderby}&desc={desc}&sort={sort}&keywords={keywords}&owner_ids={owner_id}&name={chat_name}&id={chat_id}`

Lists chat assistants.

#### Request

- Method: GET
- URL: `/api/v1/chats?page={page}&page_size={page_size}&orderby={orderby}&desc={desc}&sort={sort}&keywords={keywords}&owner_ids={owner_id}&name={chat_name}&id={chat_id}`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request GET \
     --url http://{address}/api/v1/chats?page={page}&page_size={page_size}&orderby={orderby}&desc={desc}&sort={sort}&keywords={keywords}&owner_ids={owner_id}&name={chat_name}&id={chat_id} \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Query parameters

- `page`: `integer`
  Specifies the page on which the chat assistants will be displayed. Defaults to `1`.
- `page_size`: `integer`
  The number of chat assistants on each page. Defaults to `30`.
- `orderby`: `string`
  The attribute by which the results are sorted. Available options:
  - `create_time` (default)
  - `update_time`
- `desc`: `boolean`
  Indicates whether the retrieved chat assistants should be sorted in descending order. Defaults to `true`.
- `sort`: `string`
  Orders by several fields at once, written as `column:direction` terms separated by commas, such as `name:asc,create_time:desc`. A term with no direction is ascending. `sort` takes precedence over `orderby` and `desc`, which keep working on their own. A term naming a field this list does not sort by is skipped. When `sort` yields no terms at all, `orderby` and `desc` decide the order. When it yields terms whose fields are all skipped, the result is ordered by `create_time` in the direction of the first term, and the older pair is not read.
- `keywords`: `string`
  Case-insensitive fuzzy match against chat assistant names.
- `owner_ids`: `string` (repeatable)
  Filter by owner tenant IDs. Can be specified multiple times: `?owner_ids=id1&owner_ids=id2`.
- `id`: `string`
  The ID of the chat assistant to retrieve with exact match.
- `name`: `string`
  The name of the chat assistant to retrieve with exact match.

When `id` or `name` is provided, exact filtering takes precedence over `keywords`.

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "chats": [
            {
                "icon": "",
                "create_date": "Fri, 18 Oct 2024 06:20:06 GMT",
                "create_time": 1729232406637,
                "description": "A helpful Assistant",
                "id": "04d0d8e28d1911efa3630242ac120006",
                "dataset_ids": ["527fa74891e811ef9c650242ac120006"],
                "kb_names": ["dataset_1"],
                "language": "English",
                "llm_id": "qwen-plus@Tongyi-Qianwen",
                "llm_setting": {
                    "frequency_penalty": 0.7,
                    "presence_penalty": 0.4,
                    "temperature": 0.1,
                    "top_p": 0.3
                },
                "name": "13243",
                "prompt_config": {
                    "empty_response": "Sorry! No relevant content was found in the knowledge base!",
                    "prologue": "Hi! I'm your assistant. What can I do for you?",
                    "quote": true,
                    "system": "You are an intelligent assistant...",
                    "parameters": [
                        {
                            "key": "knowledge",
                            "optional": false
                        }
                    ]
                },
                "rerank_id": "",
                "similarity_threshold": 0.2,
                "keywords_similarity_weight": 0.7,
                "top_n": 6,
                "prompt_type": "simple",
                "status": "1",
                "tenant_id": "69736c5e723611efb51b0242ac120007",
                "update_date": "Fri, 18 Oct 2024 06:20:06 GMT",
                "update_time": 1729232406638
            }
        ],
        "total": 1
    }
}
```

Failure:

```json
{
    "code": 102,
    "message": "The chat doesn't exist"
}
```

---

## SESSION MANAGEMENT

---

### Create session with chat assistant

**POST** `/api/v1/chats/{chat_id}/sessions`

Creates a session with a chat assistant.

#### Request

- Method: POST
- URL: `/api/v1/chats/{chat_id}/sessions`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"name"`: `string`
  - `"user_id"`: `string` (optional)

##### Request example

```bash
curl --request POST \
     --url http://{address}/api/v1/chats/{chat_id}/sessions \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '
     {
          "name": "new session"
     }'
```

##### Request parameters

- `chat_id`: (*Path parameter*)
  The ID of the associated chat assistant.
- `"name"`: (*Body parameter*), `string`
  The name of the chat session to create.
- `"user_id"`: (*Body parameter*), `string`
  Optional user-defined ID.

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "chat_id": "2ca4b22e878011ef88fe0242ac120005",
        "create_date": "Fri, 11 Oct 2024 08:46:14 GMT",
        "create_time": 1728636374571,
        "id": "4606b4ec87ad11efbc4f0242ac120006",
        "messages": [
            {
                "content": "Hi! I am your assistant, can I help you?",
                "role": "assistant"
            }
        ],
        "name": "new session",
        "update_date": "Fri, 11 Oct 2024 08:46:14 GMT",
        "update_time": 1728636374571
    }
}
```

Failure:

```json
{
    "code": 102,
    "message": "`name` can not be empty."
}
```

---

### Update chat assistant's session

**PATCH** `/api/v1/chats/{chat_id}/sessions/{session_id}`

Updates a session of a specified chat assistant.

:::caution REMOVED ALIAS
`PUT /api/v1/chats/{chat_id}/sessions/{session_id}` is not available in 1.0. Use this endpoint instead.
:::

#### Request

- Method: PATCH
- URL: `/api/v1/chats/{chat_id}/sessions/{session_id}`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"name"`: `string`

##### Request example

```bash
curl --request PATCH \
     --url http://{address}/api/v1/chats/{chat_id}/sessions/{session_id} \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '
     {
          "name": "<REVISED_SESSION_NAME_HERE>"
     }'
```

##### Request parameters

- `chat_id`: (*Path parameter*)
  The ID of the associated chat assistant.
- `session_id`: (*Path parameter*)
  The ID of the session to update.
- `"name"`: (*Body parameter*), `string`
  The revised name of the session.

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "chat_id": "2ca4b22e878011ef88fe0242ac120005",
        "create_date": "Fri, 11 Oct 2024 08:46:14 GMT",
        "create_time": 1728636374571,
        "id": "4606b4ec87ad11efbc4f0242ac120006",
        "messages": [
            {
                "content": "Hi! I am your assistant, can I help you?",
                "role": "assistant"
            }
        ],
        "name": "updated session name",
        "update_date": "Fri, 11 Oct 2024 08:46:14 GMT",
        "update_time": 1728636374571,
        "user_id": ""
    }
}
```

Failure:

```json
{
    "code": 102,
    "message": "`name` can not be empty."
}
```

---

### List chat assistant's sessions

**GET** `/api/v1/chats/{chat_id}/sessions?page={page}&page_size={page_size}&orderby={orderby}&desc={desc}&sort={sort}&name={session_name}&id={session_id}&user_id={user_id}`

Lists sessions associated with a specified chat assistant.

#### Request

- Method: GET
- URL: `/api/v1/chats/{chat_id}/sessions?page={page}&page_size={page_size}&orderby={orderby}&desc={desc}&sort={sort}&name={session_name}&id={session_id}&user_id={user_id}`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request GET \
     --url http://{address}/api/v1/chats/{chat_id}/sessions?page={page}&page_size={page_size}&orderby={orderby}&desc={desc}&sort={sort}&name={session_name}&id={session_id}&user_id={user_id} \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Request parameters

- `chat_id`: (*Path parameter*)
  The ID of the associated chat assistant.
- `page`: (*Query parameter*), `integer`
  Specifies the page on which the sessions will be displayed. Defaults to `1`.
- `page_size`: (*Query parameter*), `integer`
  The number of sessions on each page. Defaults to `30`. If set to `0`, an empty list is returned.
- `orderby`: (*Query parameter*), `string`
  The field by which sessions should be sorted. Available options:
  - `create_time` (default)
  - `update_time`
- `desc`: (*Query parameter*), `boolean`
  Indicates whether the retrieved sessions should be sorted in descending order. Defaults to `true`.
- `sort`: (*Query parameter*), `string`
  Orders by several fields at once, written as `column:direction` terms separated by commas, such as `name:asc,create_time:desc`. A term with no direction is ascending. `sort` takes precedence over `orderby` and `desc`, which keep working on their own. A term naming a field this list does not sort by is skipped. When `sort` yields no terms at all, `orderby` and `desc` decide the order. When it yields terms whose fields are all skipped, the result is ordered by `create_time` in the direction of the first term, and the older pair is not read.
- `name`: (*Query parameter*) `string`
  The name of the chat session to retrieve.
- `id`: (*Query parameter*), `string`
  The ID of the chat session to retrieve.
- `user_id`: (*Query parameter*), `string`
  The optional user-defined ID passed in when creating session.

#### Response

Success:

```json
{
    "code": 0,
    "data": [
        {
            "chat_id": "2ca4b22e878011ef88fe0242ac120005",
            "create_date": "Fri, 11 Oct 2024 08:46:43 GMT",
            "create_time": 1728636403974,
            "id": "578d541e87ad11ef96b90242ac120006",
            "messages": [
                {
                    "content": "Hi! I am your assistant, can I help you?",
                    "role": "assistant"
                }
            ],
            "name": "new session",
            "reference": [],
            "update_date": "Fri, 11 Oct 2024 08:46:43 GMT",
            "update_time": 1728636403974,
            "user_id": ""
        }
    ]
}
```

Failure:

```json
{
    "code": 102,
    "message": "The session doesn't exist"
}
```

---

### Get chat assistant's session

**GET** `/api/v1/chats/{chat_id}/sessions/{session_id}`

Gets a specific session of a specified chat assistant, including its messages, references, and avatar.

#### Request

- Method: GET
- URL: `/api/v1/chats/{chat_id}/sessions/{session_id}`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request GET \
     --url http://{address}/api/v1/chats/{chat_id}/sessions/{session_id} \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Path parameters

- `chat_id`
  The ID of the associated chat assistant.
- `session_id`
  The ID of the session to retrieve.

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "chat_id": "2ca4b22e878011ef88fe0242ac120005",
        "id": "4606b4ec87ad11efbc4f0242ac120006",
        "name": "new session",
        "avatar": "data:image/png;base64,...",
        "messages": [
            {
                "content": "Hi! I am your assistant, can I help you?",
                "role": "assistant"
            }
        ],
        "reference": []
    }
}
```

Failure:

```json
{
    "code": 102,
    "message": "Session not found!"
}
```

---

### Delete a message from a chat assistant's session

**DELETE** `/api/v1/chats/{chat_id}/sessions/{session_id}/messages/{msg_id}`

Deletes a user message and its paired assistant reply from a specified chat assistant session.

#### Request

- Method: DELETE
- URL: `/api/v1/chats/{chat_id}/sessions/{session_id}/messages/{msg_id}`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request DELETE \
     --url http://{address}/api/v1/chats/{chat_id}/sessions/{session_id}/messages/{msg_id} \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Path parameters

- `chat_id`
  The ID of the associated chat assistant.
- `session_id`
  The ID of the session that owns the message.
- `msg_id`
  The ID of the message to delete.

#### Response

Success: returns the updated session object.

```json
{
    "code": 0,
    "data": {
        "chat_id": "2ca4b22e878011ef88fe0242ac120005",
        "id": "4606b4ec87ad11efbc4f0242ac120006",
        "messages": [],
        "reference": []
    }
}
```

Failure:

```json
{
    "code": 102,
    "message": "Session not found!"
}
```

---

### Update message feedback in a chat assistant's session

**PUT** `/api/v1/chats/{chat_id}/sessions/{session_id}/messages/{msg_id}/feedback`

Updates feedback for an assistant message in a specified chat assistant session.

#### Request

- Method: PUT
- URL: `/api/v1/chats/{chat_id}/sessions/{session_id}/messages/{msg_id}/feedback`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"thumbup"`: `boolean`
  - `"feedback"`: `string` (optional)

##### Request example

```bash
curl --request PUT \
     --url http://{address}/api/v1/chats/{chat_id}/sessions/{session_id}/messages/{msg_id}/feedback \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{
          "thumbup": false,
          "feedback": "The answer missed the cited document."
     }'
```

##### Request parameters

- `chat_id`: (*Path parameter*)
  The ID of the associated chat assistant.
- `session_id`: (*Path parameter*)
  The ID of the session that owns the message.
- `msg_id`: (*Path parameter*)
  The ID of the assistant message to update.
- `"thumbup"`: (*Body parameter*), `boolean`
  Whether the assistant message is marked as positive feedback.
- `"feedback"`: (*Body parameter*), `string`
  Optional feedback text, typically used when `"thumbup"` is `false`.

#### Response

Success: returns the updated session object.

```json
{
    "code": 0,
    "data": {
        "chat_id": "2ca4b22e878011ef88fe0242ac120005",
        "id": "4606b4ec87ad11efbc4f0242ac120006",
        "messages": [
            {
                "id": "message-id",
                "role": "assistant",
                "content": "Here is the answer.",
                "thumbup": false,
                "feedback": "The answer missed the cited document."
            }
        ]
    }
}
```

Failure:

```json
{
    "code": 102,
    "message": "Session not found!"
}
```

---

### Delete chat assistant's sessions

**DELETE** `/api/v1/chats/{chat_id}/sessions`

Deletes sessions of a chat assistant by ID.

#### Request

- Method: DELETE
- URL: `/api/v1/chats/{chat_id}/sessions`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"ids"`: `list[string]`
  - `"delete_all"`: `boolean`

##### Request example

```bash
curl --request DELETE \
     --url http://{address}/api/v1/chats/{chat_id}/sessions \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '
     {
          "ids": ["test_1", "test_2"]
     }'
```

```bash
curl --request DELETE \
     --url http://{address}/api/v1/chats/{chat_id}/sessions \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{
          "delete_all": true
     }'
```

##### Request parameters

- `chat_id`: (*Path parameter*)
  The ID of the associated chat assistant.
- `"ids"`: (*Body parameter*), `list[string]`
  The IDs of the sessions to delete.
  - If omitted, or set to `null` or an empty array, no sessions are deleted.
  - If an array of IDs is provided, only the sessions matching those IDs are deleted.
- `"delete_all"`: (*Body parameter*), `boolean`
  Whether to delete all sessions of the specified chat assistant when `"ids"` is omitted, or set to `null` or an empty array. Defaults to `false`.

#### Response

Success:

```json
{
    "code": 0
}
```

Failure:

```json
{
    "code": 102,
    "message": "The chat doesn't own the session"
}
```

---

### Converse with chat assistant

**POST** `/api/v1/chat/completions`

Starts a chat completion request. The same endpoint supports three modes:

:::caution REMOVED ALIAS
`POST /api/v1/chats/{chat_id}/completions` is not available in 1.0. Use this endpoint instead.
:::

- No `chat_id`: talk directly with the tenant's default chat model.
- With `chat_id` but no `session_id`: use that chat's configuration and automatically create a new session.
- With both `chat_id` and `session_id`: continue an existing chat session.

:::tip NOTE

- In streaming mode, not all responses include a reference, as this depends on the system's judgment.
- In streaming mode, the last message is an empty message:

  ```json
  data:
  {
    "code": 0,
    "data": true
  }
  ```

:::

#### Request

- Method: POST
- URL: `/api/v1/chat/completions`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:

  - `"question"`: `string`
  - `"messages"`: `list[object]`
  - `"store_history_messages"`: `boolean` (optional)
  - `"stream"`: `boolean`
  - `"chat_id"`: `string` (optional)
  - `"session_id"`: `string` (optional)
  - `"llm_id"`: `string` (optional)
  - `"legacy"`: `boolean` (optional)

##### Request example

```bash
curl --request POST \
     --url http://{address}/api/v1/chat/completions \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data-binary '
     {
          "messages": [
              {
                  "role": "user",
                  "content": "Who are you?"
              }
          ]
     }'
```

```bash
curl --request POST \
     --url http://{address}/api/v1/chat/completions \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data-binary '
     {
          "chat_id": "{chat_id}",
          "stream": true,
          "session_id":"9fa7691cb85c11ef9c5f0242ac120005",
          "messages": [
              {
                  "role": "user",
                  "content": "Who are you?"
              }
          ]
     }'
```

##### Body parameters

- `"question"`: `string`
  The user question. Provide either `"question"` or `"messages"`. When both are provided, `"question"` takes precedence unless `"store_history_messages"` is `false`.
- `"messages"`: `list[object]`
  The conversation messages. The last message must have the `user` role. When `"store_history_messages"` is `false`, this field is required and the full message list is used instead of `"question"`.
- `"store_history_messages"`: `boolean`
  Controls whether conversation history is stored. It defaults to `true`; the only supported explicit value is `false`. When set to `false`, `"messages"` is required and the supplied message list is processed without storing it as conversation history.
- `"stream"`: `boolean`
  Enables streaming output:
  - `true`: Enable streaming (default).
  - `false`: Disable streaming.
- `"chat_id"`
  Optional chat assistant ID. If omitted, the tenant's default chat model is used directly.
- `"session_id"`
  Optional session ID. If `chat_id` is provided but `session_id` is omitted, a new session will be generated automatically.
- `"llm_id"`: `string`
  Optional model override when a specific chat model should be used for this request.
- `"legacy"`: `boolean`
  Defaults to `false`. Enables backward compatibility with RAGFlow v0.23.0 for streaming responses. When set to `true`:
  - Cumulative output: The `"answer"` field in each chunk returns the entire text generated so far, rather than just the new tokens (deltas).
  - No reasoning markers: The `start_to_think` and `end_to_think` signals are stripped from the stream.

#### Response

Success without `chat_id` or `session_id`:

```json
data:{
    "code": 0,
    "message": "success",
    "data": {
        "answer": "I am an assistant powered by the tenant's default chat model.",
        "reference": {},
        "audio_binary": null,
        "id": "b01eed84b85611efa0e90242ac120005",
        "session_id": ""
    }
}
data:{
    "code": 0,
    "message": "success",
    "data": true
}
```

Success with `chat_id` and `session_id`:

Streaming response example with `chat_id` and `session_id`:

```json
data:{
    "code": 0,
    "message": "success",
    "data": {
        "answer": "",
        "reference": {
            "chunks": []
        },
        "audio_binary": null,
        "prompt": "",
        "created_at": 1781250170.37759,
        "final": false,
        "start_to_think": true,
        "id": "76961783-1523-43f7-8148-19da08247922",
        "session_id": "4edfabd6663211f1943e217dfc5f0165",
        "chat_id": "d90fd732646f11f1803d2fb3c77f9b23"
    }
}
data:{
    "code": 0,
    "message": "success",
    "data": {
        "answer": "The user just said \"hello\". I should respond warmly and ask how I can help.",
        "reference": {
            "chunks": []
        },
        "audio_binary": null,
        "prompt": "",
        "created_at": 1781250170.3778317,
        "final": false,
        "id": "76961783-1523-43f7-8148-19da08247922",
        "session_id": "4edfabd6663211f1943e217dfc5f0165",
        "chat_id": "d90fd732646f11f1803d2fb3c77f9b23"
    }
}
data:{
    "code": 0,
    "message": "success",
    "data": {
        "answer": " Let's keep it short and friendly.",
        "reference": {
            "chunks": []
        },
        "audio_binary": null,
        "prompt": "",
        "created_at": 1781250171.101234,
        "final": false,
        "id": "76961783-1523-43f7-8148-19da08247922",
        "session_id": "4edfabd6663211f1943e217dfc5f0165",
        "chat_id": "d90fd732646f11f1803d2fb3c77f9b23"
    }
}
data:{
    "code": 0,
    "message": "success",
    "data": {
        "answer": "",
        "reference": {
            "chunks": []
        },
        "audio_binary": null,
        "prompt": "",
        "created_at": 1781250171.5262048,
        "final": false,
        "end_to_think": true,
        "id": "76961783-1523-43f7-8148-19da08247922",
        "session_id": "4edfabd6663211f1943e217dfc5f0165",
        "chat_id": "d90fd732646f11f1803d2fb3c77f9b23"
    }
}
data:{
    "code": 0,
    "message": "success",
    "data": {
        "answer": "Hello! 👋 Welcome!",
        "reference": {
            "chunks": []
        },
        "audio_binary": null,
        "prompt": "",
        "created_at": 1781250171.5266216,
        "final": false,
        "id": "76961783-1523-43f7-8148-19da08247922",
        "session_id": "4edfabd6663211f1943e217dfc5f0165",
        "chat_id": "d90fd732646f11f1803d2fb3c77f9b23"
    }
}
data:{
    "code": 0,
    "message": "success",
    "data": true
}
```

For `legacy: true`, the same request keeps the thinking content inside `answer` as literal `<think>` tags, and appends the final answer after `</think>`:

```json
data:{
    "code": 0,
    "message": "success",
    "data": {
        "answer": "<think>The user just said \"hello\".",
        "reference": {
            "chunks": []
        },
        "audio_binary": null,
        "prompt": "",
        "created_at": 1781250170.3778317,
        "final": false,
        "id": "76961783-1523-43f7-8148-19da08247922",
        "session_id": "4edfabd6663211f1943e217dfc5f0165",
        "chat_id": "d90fd732646f11f1803d2fb3c77f9b23"
    }
}
data:{
    "code": 0,
    "message": "success",
    "data": {
        "answer": "<think>The user just said \"hello\". I should respond warmly and ask how I can help.",
        "reference": {
            "chunks": []
        },
        "audio_binary": null,
        "prompt": "",
        "created_at": 1781250170.901234,
        "final": false,
        "id": "76961783-1523-43f7-8148-19da08247922",
        "session_id": "4edfabd6663211f1943e217dfc5f0165",
        "chat_id": "d90fd732646f11f1803d2fb3c77f9b23"
    }
}
data:{
    "code": 0,
    "message": "success",
    "data": {
        "answer": "<think>The user just said \"hello\". I should respond warmly and ask how I can help. Let's keep it short and friendly.</think>Hello! 👋 Welcome!",
        "reference": {
            "chunks": []
        },
        "audio_binary": null,
        "prompt": "",
        "created_at": 1781250171.5262048,
        "final": false,
        "id": "76961783-1523-43f7-8148-19da08247922",
        "session_id": "4edfabd6663211f1943e217dfc5f0165",
        "chat_id": "d90fd732646f11f1803d2fb3c77f9b23"
    }
}
data:{
    "code": 0,
    "message": "success",
    "data": true
}
```


Failure:

```json
{
    "code": 102,
    "message": "Please input your question."
}
```

---

### Create session with agent

**POST** `/api/v1/agents/{agent_id}/sessions`

Creates a session with an agent.

#### Request

- Method: POST
- URL: `/api/v1/agents/{agent_id}/sessions?user_id={user_id}`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"user_id"`: `string` (optional)
  - Other parameters:
    The variables specified in the **Begin** component.

##### Request example

If the **Begin** component in your agent does not take required parameters:

```bash
curl --request POST \
     --url http://{address}/api/v1/agents/{agent_id}/sessions \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{
     }'
```

##### Request parameters

- `agent_id`: (*Path parameter*)
  The ID of the associated agent.
- `user_id`: (*Body or query parameter*), `string`, *Optional*
  A user-defined ID associated with the created session. It can be provided either in the JSON request body or as a URL query parameter. If both are provided, the value in the request body takes precedence. If omitted, the tenant ID associated with the current API key is used.

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "agent_id": "dbb4ed366e8611f09690a55a6daec4ef",
        "dsl": {
            "components": {
                "Message:EightyJobsAsk": {
                    "downstream": [],
                    "obj": {
                        "component_name": "Message",
                        "params": {
                            "content": [
                                "{begin@var1}{begin@var2}"
                            ],
                            "debug_inputs": {},
                            "delay_after_error": 2.0,
                            "description": "",
                            "exception_default_value": null,
                            "exception_goto": null,
                            "exception_method": null,
                            "inputs": {},
                            "max_retries": 0,
                            "message_history_window_size": 22,
                            "outputs": {
                                "content": {
                                    "type": "str",
                                    "value": null
                                }
                            },
                            "stream": true
                        }
                    },
                    "upstream": [
                        "begin"
                    ]
                },
                "begin": {
                    "downstream": [
                        "Message:EightyJobsAsk"
                    ],
                    "obj": {
                        "component_name": "Begin",
                        "params": {
                            "debug_inputs": {},
                            "delay_after_error": 2.0,
                            "description": "",
                            "enablePrologue": true,
                            "enable_tips": true,
                            "exception_default_value": null,
                            "exception_goto": null,
                            "exception_method": null,
                            "inputs": {
                                "var1": {
                                    "name": "var1",
                                    "optional": false,
                                    "options": [],
                                    "type": "line",
                                    "value": null
                                },
                                "var2": {
                                    "name": "var2",
                                    "optional": false,
                                    "options": [],
                                    "type": "line",
                                    "value": null
                                }
                            },
                            "max_retries": 0,
                            "message_history_window_size": 22,
                            "mode": "conversational",
                            "outputs": {},
                            "prologue": "Hi! I'm your assistant. What can I do for you?",
                            "tips": "Please fill in the form"
                        }
                    },
                    "upstream": []
                }
            },
            "globals": {
                "sys.conversation_turns": 0,
                "sys.files": [],
                "sys.query": "",
                "sys.user_id": ""
            },
            "graph": {
                "edges": [
                    {
                        "data": {
                            "isHovered": false
                        },
                        "id": "xy-edge__beginstart-Message:EightyJobsAskend",
                        "markerEnd": "logo",
                        "source": "begin",
                        "sourceHandle": "start",
                        "style": {
                            "stroke": "rgba(151, 154, 171, 1)",
                            "strokeWidth": 1
                        },
                        "target": "Message:EightyJobsAsk",
                        "targetHandle": "end",
                        "type": "buttonEdge",
                        "zIndex": 1001
                    }
                ],
                "nodes": [
                    {
                        "data": {
                            "form": {
                                "enablePrologue": true,
                                "inputs": {
                                    "var1": {
                                        "name": "var1",
                                        "optional": false,
                                        "options": [],
                                        "type": "line"
                                    },
                                    "var2": {
                                        "name": "var2",
                                        "optional": false,
                                        "options": [],
                                        "type": "line"
                                    }
                                },
                                "mode": "conversational",
                                "prologue": "Hi! I'm your assistant. What can I do for you?"
                            },
                            "label": "Begin",
                            "name": "begin"
                        },
                        "dragging": false,
                        "id": "begin",
                        "measured": {
                            "height": 112,
                            "width": 200
                        },
                        "position": {
                            "x": 270.64098070942583,
                            "y": -56.320928437811176
                        },
                        "selected": false,
                        "sourcePosition": "left",
                        "targetPosition": "right",
                        "type": "beginNode"
                    },
                    {
                        "data": {
                            "form": {
                                "content": [
                                    "{begin@var1}{begin@var2}"
                                ]
                            },
                            "label": "Message",
                            "name": "Message_0"
                        },
                        "dragging": false,
                        "id": "Message:EightyJobsAsk",
                        "measured": {
                            "height": 57,
                            "width": 200
                        },
                        "position": {
                            "x": 279.5,
                            "y": 190
                        },
                        "selected": true,
                        "sourcePosition": "right",
                        "targetPosition": "left",
                        "type": "messageNode"
                    }
                ]
            },
            "history": [],
            "memory": [],
            "messages": [],
            "path": [],
            "retrieval": [],
            "task_id": "dbb4ed366e8611f09690a55a6daec4ef"
        },
        "id": "0b02fe80780e11f084adcfdc3ed1d902",
        "message": [
            {
                "content": "Hi! I'm your assistant. What can I do for you?",
                "role": "assistant"
            }
        ],
        "source": "agent",
        "user_id": "c3fb861af27a11efa69751e139332ced"
    }
}
```

Failure:

```json
{
    "code": 102,
    "message": "Agent not found."
}
```

---

### Converse with agent

**POST** `/api/v1/agents/chat/completions`

Asks a specified agent a question to start an AI-powered conversation.

Uses a single completion endpoint for all agent conversations.

:::caution REMOVED ALIAS
`POST /api/v1/agents/{agent_id}/completions` is not available in 1.0. Use this endpoint instead.
:::

#### Request

- Method: POST
- URL: `/api/v1/agents/chat/completions`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`

#### Standard mode

Use this mode for the native agent API.

##### Body

- `"agent_id"`: `string`
- `"question"`: `string`
- `"stream"`: `boolean`
- `"session_id"`: `string` (optional)
- `"inputs"`: `object` (optional)
- `"files"`: `list[object]` (optional)
- `"user_id"`: `string` (optional)
- `"return_trace"`: `boolean` (optional, default `false`)
- `"chat_template_kwargs"`: `object` (optional)

#### Streaming events to handle

When `stream=true`, the server sends Server-Sent Events (SSE). A client should handle these events:

- `message`: Streaming content from the **Message** components.
- `message_end`: End of a **Message** component, which may include `reference` or `attachment`.
- `node_finished`: A component finishes. `data.inputs`, `data.outputs`, `data.error`, and `data.elapsed_time` describe the node result. If `return_trace=true`, the same event also contains `data.trace`.

The stream terminates with `[DONE]`.

:::info IMPORTANT
You can include custom parameters in the request body, but they must be defined in the [Begin](../guides/agent/agent_workflow/basic_component.md) component first.
:::

##### Request examples

If the **Begin** component does not take parameters:

```bash
curl --request POST \
     --url http://{address}/api/v1/agents/chat/completions \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data-binary '
     {
        "agent_id": "AGENT_ID",
        "question": "Hello",
        "stream": false
     }'
```

- If the **Begin** component takes parameters, include their values in the body of `"inputs"` as follows:

```bash
curl --request POST \
     --url http://{address}/api/v1/agents/chat/completions \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data-binary '
     {
        "agent_id": "AGENT_ID",
        "question": "",
        "stream": false,
        "inputs": {
            "line_var": {
                "type": "line",
                "value": "I am line_var"
            },
            "int_var": {
                "type": "integer",
                "value": 1
            },
            "paragraph_var": {
                "type": "paragraph",
                "value": "a\nb\nc"
            },
            "option_var": {
                "type": "options",
                "value": "option 2"
            },
            "boolean_var": {
                "type": "boolean",
                "value": true
            }
        }
     }'
```

To continue an existing session:

```bash
curl --request POST \
     --url http://{address}/api/v1/agents/chat/completions \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data-binary '
     {
        "agent_id": "AGENT_ID",
        "question": "Hello again",
        "stream": true,
        "session_id": "cb2f385cb86211efa36e0242ac120005"
     }'
```

##### Body parameters

- `"agent_id"`: `string`, *Required*
  The ID of the associated agent.
- `"question"`: `string`
  The question to start an AI-powered conversation.
- `"stream"`: `boolean`
  Indicates whether to output responses in a streaming way:
  - `true`: Enable streaming (default).
  - `false`: Disable streaming.
- `"session_id"`
  The ID of the session. If it is not provided, a new session will be generated.
- `"inputs"`: `object`
  Values for variables defined in the **Begin** component. Each variable value must be an object containing a `"value"` field and may include a `"type"` field.
- `"files"`: `array`
  File descriptors returned by the Agent file upload endpoint. RAGFlow makes the uploaded files available to the Agent through `sys.files`.
- `"user_id"`: `string`
  The optional user-defined ID. Valid *only* when no `session_id` is provided.
- `"chat_template_kwargs"`: `object`
  Optional passthrough parameters for the underlying LLM's chat template. Commonly used to toggle thinking/reasoning modes on supported models (e.g., `{"enable_thinking": false}`).

:::tip NOTE
Before sending a file in a conversation, upload it as multipart form data with the field name `file` to `POST http://{address}/api/v1/agents/{agent_id}/upload`. The endpoint accepts one or more files and returns a file descriptor for one file or an array of descriptors for multiple files. Pass the returned descriptor or descriptors in the `files` array of the conversation request.
:::

##### Response

Standard mode stream:

```json
data: {
    "event": "message",
    "message_id": "cecdcb0e83dc11f0858253708ecb6573",
    "created_at": 1756364483,
    "task_id": "d1f79142831f11f09cc51795b9eb07c0",
    "data": {
        "content": "Hello"
    },
    "session_id": "cd097ca083dc11f0858253708ecb6573"
}

data: {
    "event": "message_end",
    "message_id": "cecdcb0e83dc11f0858253708ecb6573",
    "created_at": 1756364483,
    "task_id": "d1f79142831f11f09cc51795b9eb07c0",
    "data": {
        "reference": {}
    },
    "session_id": "cd097ca083dc11f0858253708ecb6573"
}

data:[DONE]
```

When `extra_body.reference_metadata.include` is `true`, each reference chunk may include a `document_metadata` object.

Standard mode non-stream:

```json
{
    "code": 0,
    "data": {
        "data": {
            "content": "Hello",
            "reference": {},
            "trace": []
        },
        "message_id": "c4692a2683d911f0858253708ecb6573",
        "session_id": "c39f6f9c83d911f0858253708ecb6573",
        "task_id": "d1f79142831f11f09cc51795b9eb07c0"
    }
}
```

If one or more components produce structured output, set `return_trace=true` and inspect that component output from `trace`.

#### OpenAI-compatible mode

Use the same endpoint and add `"openai-compatible": true`.

##### Body

- `"agent_id"`: `string`
- `"messages"`: `list[object]`
- `"openai-compatible"`: `boolean`, must be `true`
- `"stream"`: `boolean`
- `"session_id"`: `string` (optional)
- `"model"`: `string` (optional, accepted for compatibility)
- `"chat_template_kwargs"`: `object` (optional)

##### Request examples

Streaming request:

```bash
curl --request POST \
     --url http://{address}/api/v1/agents/chat/completions \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data-binary '
     {
        "agent_id": "AGENT_ID",
        "openai-compatible": true,
        "stream": true,
        "messages": [
            {
                "role": "user",
                "content": "Hello"
            }
        ],
        "chat_template_kwargs": {
            "enable_thinking": true
        }
     }'
```

Non-stream request with existing session:

```bash
curl --request POST \
     --url http://{address}/api/v1/agents/chat/completions \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data-binary '
     {
        "agent_id": "AGENT_ID",
        "openai-compatible": true,
        "stream": false,
        "session_id": "cb2f385cb86211efa36e0242ac120005",
        "messages": [
            {
                "role": "user",
                "content": "Hello"
            }
        ]
     }'
```

##### Body parameters

- `"agent_id"`: `string`, *Required*
  The ID of the associated agent.
- `"messages"`: `list[object]`, *Required*
  OpenAI-style chat messages.
- `"openai-compatible"`: `boolean`, *Required*
  Must be `true` to enable OpenAI-compatible responses.
- `"stream"`: `boolean`
  Whether to return streaming chunks.
- `"session_id"`: `string`
  Optional existing session ID.
- `"model"`: `string`
  Optional compatibility field. The server still routes by `agent_id`.
- `"chat_template_kwargs"`: `object`
  Optional passthrough parameters for the underlying LLM's chat template. Commonly used to toggle thinking/reasoning modes on supported models (e.g., `{"enable_thinking": false}`).

##### Response

OpenAI-compatible stream:

```json
data: {
    "id": "chatcmpl-xxx",
    "object": "chat.completion.chunk",
    "model": "AGENT_ID",
    "choices": [
        {
            "delta": {
                "content": "Hello"
            },
            "finish_reason": null,
            "index": 0
        }
    ]
}

data: [DONE]
```

OpenAI-compatible non-stream:

```json
{
    "id": "chatcmpl-xxx",
    "object": "chat.completion",
    "model": "AGENT_ID",
    "choices": [
        {
            "finish_reason": "stop",
            "index": 0,
            "message": {
                "role": "assistant",
                "content": "Hello",
                "reference": {}
            }
        }
    ],
    "usage": {
        "prompt_tokens": 6,
        "completion_tokens": 1,
        "total_tokens": 7
    }
}
```

Failure:

```json
{
    "code": 102,
    "message": "Agent not found."
}
```

---

### List agent sessions

**GET** `/api/v1/agents/{agent_id}/sessions?page={page}&page_size={page_size}&orderby={orderby}&desc={desc}&id={session_id}&user_id={user_id}&keywords={keywords}&from_date={from_date}&to_date={to_date}&dsl={dsl}&exp_user_id={exp_user_id}`

Lists sessions associated with a specified agent.

#### Request

- Method: GET
- URL: `/api/v1/agents/{agent_id}/sessions?page={page}&page_size={page_size}&orderby={orderby}&desc={desc}&id={session_id}&user_id={user_id}&keywords={keywords}&from_date={from_date}&to_date={to_date}&dsl={dsl}&exp_user_id={exp_user_id}`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request GET \
     --url 'http://{address}/api/v1/agents/{agent_id}/sessions?page={page}&page_size={page_size}&orderby={orderby}&desc={desc}&id={session_id}&user_id={user_id}&keywords={keywords}&from_date={from_date}&to_date={to_date}&dsl={dsl}&exp_user_id={exp_user_id}' \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Request parameters

- `agent_id`: (*Path parameter*)
  The ID of the associated agent.
- `page`: (*Query parameter*), `integer`
  Specifies the page on which the sessions will be displayed. Defaults to `1`.
- `page_size`: (*Query parameter*), `integer`
  The number of sessions on each page. Defaults to `30`.
- `orderby`: (*Query parameter*), `string`
  The field by which sessions should be sorted. Available options:
  - `create_time`
  - `update_time` (default)
- `desc`: (*Query parameter*), `boolean`
  Indicates whether the retrieved sessions should be sorted in descending order. Defaults to `true`.
- `id`: (*Query parameter*), `string`
  The ID of the agent session to retrieve.
- `user_id`: (*Query parameter*), `string`
  The optional user-defined ID passed in when creating session.
- `dsl`: (*Query parameter*), `boolean`
  Indicates whether to include the dsl field of the sessions in the response. Defaults to `true`.
- `keywords`: (*Query parameter*), `string`
  Fuzzy-searches the session ID, session name, and session messages.
- `from_date`: (*Query parameter*), `string`
  Filters sessions whose applicable date is on or after this date.
- `to_date`: (*Query parameter*), `string`
  Filters sessions whose applicable date is on or before this date.
- `exp_user_id`: (*Query parameter*), `string`
  Returns only the IDs and names of sessions associated with the specified external user ID. When provided, the endpoint uses this special listing mode and does not apply the other pagination and filtering parameters.

#### Response

Success:

```json
{
    "code": 0,
    "data": [{
        "agent_id": "e9e2b9c2b2f911ef801d0242ac120006",
        "dsl": {
            "answer": [],
            "components": {
                "Answer:OrangeTermsBurn": {
                    "downstream": [],
                    "obj": {
                        "component_name": "Answer",
                        "params": {}
                    },
                    "upstream": []
                },
                "Generate:SocialYearsRemain": {
                    "downstream": [],
                    "obj": {
                        "component_name": "Generate",
                        "params": {
                            "cite": true,
                            "frequency_penalty": 0.7,
                            "llm_id": "gpt-4o___OpenAI-API@OpenAI-API-Compatible",
                            "message_history_window_size": 12,
                            "parameters": [],
                            "presence_penalty": 0.4,
                            "prompt": "Please summarize the following paragraph. Pay attention to the numbers and do not make things up. The paragraph is as follows:\n{input}\nThis is what you need to summarize.",
                            "temperature": 0.1,
                            "top_p": 0.3
                        }
                    },
                    "upstream": []
                },
                "begin": {
                    "downstream": [],
                    "obj": {
                        "component_name": "Begin",
                        "params": {}
                    },
                    "upstream": []
                }
            },
            "graph": {
                "edges": [],
                "nodes": [
                    {
                        "data": {
                            "label": "Begin",
                            "name": "begin"
                        },
                        "height": 44,
                        "id": "begin",
                        "position": {
                            "x": 50,
                            "y": 200
                        },
                        "sourcePosition": "left",
                        "targetPosition": "right",
                        "type": "beginNode",
                        "width": 200
                    },
                    {
                        "data": {
                            "form": {
                                "cite": true,
                                "frequencyPenaltyEnabled": true,
                                "frequency_penalty": 0.7,
                                "llm_id": "gpt-4o___OpenAI-API@OpenAI-API-Compatible",
                                "maxTokensEnabled": true,
                                "message_history_window_size": 12,
                                "parameters": [],
                                "presencePenaltyEnabled": true,
                                "presence_penalty": 0.4,
                                "prompt": "Please summarize the following paragraph. Pay attention to the numbers and do not make things up. The paragraph is as follows:\n{input}\nThis is what you need to summarize.",
                                "temperature": 0.1,
                                "temperatureEnabled": true,
                                "topPEnabled": true,
                                "top_p": 0.3
                            },
                            "label": "Generate",
                            "name": "Generate Answer_0"
                        },
                        "dragging": false,
                        "height": 105,
                        "id": "Generate:SocialYearsRemain",
                        "position": {
                            "x": 561.3457829707513,
                            "y": 178.7211182312641
                        },
                        "positionAbsolute": {
                            "x": 561.3457829707513,
                            "y": 178.7211182312641
                        },
                        "selected": true,
                        "sourcePosition": "right",
                        "targetPosition": "left",
                        "type": "generateNode",
                        "width": 200
                    },
                    {
                        "data": {
                            "form": {},
                            "label": "Answer",
                            "name": "Dialogue_0"
                        },
                        "height": 44,
                        "id": "Answer:OrangeTermsBurn",
                        "position": {
                            "x": 317.2368194777658,
                            "y": 218.30635555445093
                        },
                        "sourcePosition": "right",
                        "targetPosition": "left",
                        "type": "logicNode",
                        "width": 200
                    }
                ]
            },
            "history": [],
            "messages": [],
            "path": [],
            "reference": []
        },
        "id": "792dde22b2fa11ef97550242ac120006",
        "message": [
            {
                "content": "Hi! I'm your smart assistant. What can I do for you?",
                "role": "assistant"
            }
        ],
        "source": "agent",
        "user_id": ""
    }]
}
```

Failure:

```json
{
    "code": 102,
    "message": "You don't own the agent ccd2f856b12311ef94ca0242ac1200052."
}
```

---

### Delete agent's sessions

**DELETE** `/api/v1/agents/{agent_id}/sessions`

Deletes sessions of an agent by ID.

#### Request

- Method: DELETE
- URL: `/api/v1/agents/{agent_id}/sessions`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"ids"`: `list[string]`
  - `"delete_all"`: `boolean`

##### Request example

```bash
curl --request DELETE \
     --url http://{address}/api/v1/agents/{agent_id}/sessions \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '
     {
          "ids": ["test_1", "test_2"]
     }'
```

```bash
curl --request DELETE \
     --url http://{address}/api/v1/agents/{agent_id}/sessions \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{
          "delete_all": true
     }'
```

##### Request parameters

- `agent_id`: (*Path parameter*)
  The ID of the associated agent.
- `"ids"`: (*Body parameter*), `list[string]`
  The IDs of the sessions to delete.
  - If omitted, or set to `null` or an empty array, no sessions are deleted.
  - If an array of IDs is provided, only the sessions matching those IDs are deleted.
- `"delete_all"`: (*Body parameter*), `boolean`
  Whether to delete all sessions of the specified agent when `"ids"` is omitted, or set to `null` or an empty array. Defaults to `false`.

#### Response

Success:

```json
{
    "code": 0
}
```

Failure:

```json
{
    "code": 102,
    "message": "The agent doesn't own the session cbd31e52f73911ef93b232903b842af6"
}
```

---

### Text-to-speech

**POST** `/api/v1/chat/audio/speech`

Converts text to speech audio using the tenant's default TTS model, returning a streaming audio response.

#### Request

- Method: POST
- URL: `/api/v1/chat/audio/speech`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_LOGIN_TOKEN>'`
- Body:
  - `"text"`: `string` *(Required)* The text to synthesize.

##### Request example

```bash
curl --request POST \
     --url http://{address}/api/v1/chat/audio/speech \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_LOGIN_TOKEN>' \
     --output audio.mp3 \
     --data '{"text": "Hello, how can I help you today?"}'
```

#### Response

Success: binary `audio/mpeg` stream with headers `Cache-Control: no-cache`, `Connection: keep-alive`, `X-Accel-Buffering: no`.

Failure:

```json
{
    "code": 102,
    "message": "No default TTS model is set"
}
```

---

### Speech-to-text

**POST** `/api/v1/chat/audio/transcription`

Transcribes an audio file using the tenant's default ASR (automatic speech recognition) model.

#### Request

- Method: POST
- URL: `/api/v1/chat/audio/transcription`
- Headers:
  - `'Authorization: Bearer <YOUR_LOGIN_TOKEN>'`
- Body (multipart/form-data):
  - `"file"`: audio file (`.wav`, `.mp3`, `.m4a`, `.aac`, `.flac`, `.ogg`, `.webm`, `.opus`, `.wma`)
  - `"stream"`: `string` `"true"` for SSE streaming, `"false"` (default) for a single JSON response.

##### Request example

```bash
curl --request POST \
     --url http://{address}/api/v1/chat/audio/transcription \
     --header 'Authorization: Bearer <YOUR_LOGIN_TOKEN>' \
     --form file=@recording.wav \
     --form stream=false
```

#### Response

Success (non-streaming):

```json
{
    "code": 0,
    "data": {
        "text": "Hello, how can I help you today?"
    }
}
```

Success (streaming): SSE events with `data: {"event": "partial", "text": "..."}`.

Failure:

```json
{
    "code": 102,
    "message": "Unsupported audio format: .mp4. Allowed: .aac, .flac, .m4a, .mp3, .ogg, .opus, .wav, .webm, .wma"
}
```

---

### Generate mind map

**POST** `/api/v1/chat/mindmap`

Generates a mind map from a question and a set of knowledge base IDs.

#### Request

- Method: POST
- URL: `/api/v1/chat/mindmap`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_LOGIN_TOKEN>'`
- Body:
  - `"question"`: `string` *(Required)* The central question or topic.
  - `"kb_ids"`: `list[string]` *(Required)* Knowledge base IDs to search.
  - `"search_id"`: `string` *(Optional)* ID of a saved search configuration to merge additional `kb_ids` and settings.

##### Request example

```bash
curl --request POST \
     --url http://{address}/api/v1/chat/mindmap \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_LOGIN_TOKEN>' \
     --data '{
         "question": "What is retrieval-augmented generation?",
         "kb_ids": ["kb-abc123"]
     }'
```

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "name": "Retrieval-Augmented Generation",
        "children": [...]
    }
}
```

Failure:

```json
{
    "code": 500,
    "message": "..."
}
```

---

### Generate related questions

**POST** `/api/v1/chat/recommendation`

Generates five to ten alternative question strings from the user's original query to retrieve more relevant search results.

:::caution REMOVED ALIAS
`POST /api/v1/sessions/related_questions` is not available in 1.0. Use this endpoint instead.
:::

This operation requires a `Bearer Login Token`, which typically expires with in 24 hours. You can find it in the Request Headers in your browser easily as shown below:

![Image](https://raw.githubusercontent.com/infiniflow/ragflow-docs/main/images/login_token.jpg)

:::tip NOTE
The chat model autonomously determines the number of questions to generate based on the instruction, typically between five and ten.
:::

#### Request

- Method: POST
- URL: `/api/v1/chat/recommendation`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_LOGIN_TOKEN>'`
- Body:
  - `"question"`: `string` *(Required)* The original user question.
  - `"search_id"`: `string` *(Optional)* ID of a saved search configuration to use custom LLM settings.

##### Request example

```bash
curl --request POST \
     --url http://{address}/api/v1/chat/recommendation \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_LOGIN_TOKEN>' \
     --data '{
          "question": "What are the key advantages of Neovim over Vim?"
     }'
```

##### Body parameters

- `"question"`: `string`
  The original user question.
- `"search_id"`: `string`
  ID of a saved search configuration to use custom LLM settings. If provided, the LLM model and generation settings from the search configuration will be used.

#### Response

Success:

```json
{
    "code": 0,
    "data": [
        "What makes Neovim superior to Vim in terms of features?",
        "How do the benefits of Neovim compare to those of Vim?",
        "What advantages does Neovim offer that are not present in Vim?",
        "In what ways does Neovim outperform Vim in functionality?",
        "What are the most significant improvements in Neovim compared to Vim?",
        "What unique advantages does Neovim bring to the table over Vim?",
        "How does the user experience in Neovim differ from Vim in terms of benefits?",
        "What are the top reasons to switch from Vim to Neovim?",
        "What features of Neovim are considered more advanced than those in Vim?"
    ],
    "message": "success"
}
```

Failure:

```json
{
    "code": 401,
    "data": null,
    "message": "<Unauthorized '401: Unauthorized'>"
}
```

---

## AGENT MANAGEMENT

---

### List agents

**GET** `/api/v1/agents`

Lists agents and compilation template groups accessible to the current user.

#### Request

- Method: GET
- URL: `/api/v1/agents`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request GET \
     --url 'http://{address}/api/v1/agents?page=1&page_size=30&orderby=create_time&desc=true&keywords=example' \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Query parameters

- `page`: `integer`
  Specifies the page on which the agents will be displayed. Defaults to `1`.
- `page_size`: `integer`
  The number of agents on each page. Defaults to `30`.
- `orderby`: `string`
  The attribute by which the results are sorted. Available options:
  - `create_time` (default)
  - `update_time`
- `desc`: `boolean`
  Indicates whether the retrieved agents should be sorted in descending order. Defaults to `true`.
- `sort`: `string`
  Orders by several fields at once, written as `column:direction` terms separated by commas, such as `name:asc,create_time:desc`. A term with no direction is ascending. `sort` takes precedence over `orderby` and `desc`, which keep working on their own. A term naming a field this list does not sort by is skipped. When `sort` yields no terms at all, `orderby` and `desc` decide the order. When it yields terms whose fields are all skipped, the result is ordered by `create_time` in the direction of the first term, and the older pair is not read.
- `keywords`: `string`
  Fuzzy-searches agents by title.
- `canvas_category`: `string`
  Filters agents by one or more comma-separated canvas categories.
- `canvas_type`: `string`
  Filters agents by canvas type.
- `owner_ids`: `string`
  Filters agents by comma-separated authorized owner IDs.
- `tags`: `string`
  Filters agents by comma-separated tags.

#### Response

Success:

```json
{
  "code": 0,
  "data": {
    "canvas": [
      {
        "avatar": null,
        "canvas_category": "agent_canvas",
        "canvas_type": "",
        "description": null,
        "id": "d12e0f02a13c11f19804611a4dfe1a85",
        "nickname": "test",
        "permission": "me",
        "release_time": null,
        "tags": "",
        "tenant_avatar": null,
        "tenant_id": "fc117a7ea10011f1b894bf34cf9cba96",
        "title": "111",
        "type": "agent",
        "update_time": 1787741800476
      }
    ],
    "total": 1
  },
  "message": "success"
}
```

##### Response fields

- `data`: `object`
  The result container.
- `data.canvas`: `list[object]`
  A list of agents and, when applicable, compilation template groups.
- `data.canvas[].type`: `string`
  The item type:
  - `agent`: An agent.
  - `compilation_template_group`: A compilation template group.
- `data.total`: `integer`
  The total number of matched items before pagination.
- `message`: `string`
  The result message.


---

### Create agent

**POST** `/api/v1/agents`

Create an agent.

#### Request

- Method: POST
- URL: `/api/v1/agents`
- Headers:
  - `'Content-Type: application/json`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"title"`: `string`
  - `"description"`: `string`
  - `"dsl"`: `object`

##### Request example

```bash
curl --request POST \
     --url http://{address}/api/v1/agents \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{
         "title": "Test Agent",
         "description": "A test agent",
         "dsl": {
           // ... Canvas DSL here ...
         }
     }'
```

##### Body parameters

- `title`: `string`, *Required*
  The title of the agent.
  If an agent with the same title already exists, the new one gets a numbered suffix such as `Test Agent(1)`.
- `description`: `string`
  The description of the agent. Defaults to `None`.
- `dsl`: `object`, *Required*
  The canvas DSL object of the agent.

#### Response

Success:

```json
{
    "code": 0,
    "data": true,
    "message": "success"
}
```

Failure:

```json
{
    "code": 101,
    "message": "no DSL data in request"
}
```

---

### Update agent

**PUT** `/api/v1/agents/{agent_id}`

Update an agent by id.

#### Request

- Method: PUT
- URL: `/api/v1/agents/{agent_id}`
- Headers:
  - `'Content-Type: application/json`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"title"`: `string`
  - `"description"`: `string`
  - `"dsl"`: `object`

##### Request example

```bash
curl --request PUT \
     --url http://{address}/api/v1/agents/58af890a2a8911f0a71a11b922ed82d6 \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{
         "title": "Test Agent",
         "description": "A test agent",
         "dsl": {
           // ... Canvas DSL here ...
         }
     }'
```

##### Request parameters

- `agent_id`: (*Path parameter*), `string`
  The id of the agent to be updated.
- `title`: (*Body parameter*), `string`
  The title of the agent.
- `description`: (*Body parameter*), `string`
  The description of the agent.
- `dsl`: (*Body parameter*), `object`
  The canvas DSL object of the agent.

Only specify the parameter you want to change in the request body. If a parameter does not exist or is `None`, it won't be updated.

#### Response

Success:

```json
{
    "code": 0,
    "data": true,
    "message": "success"
}
```

Failure (duplicate title):

```json
{
    "code": 102,
    "message": "Test Agent already exists."
}
```

Failure (permission denied):

```json
{
    "code": 103,
    "message": "Only owner of canvas authorized for this operation."
}
```

---

### Delete agent

**DELETE** `/api/v1/agents/{agent_id}`

Delete an agent by id.

#### Request

- Method: DELETE
- URL: `/api/v1/agents/{agent_id}`
- Headers:
  - `'Content-Type: application/json`
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request DELETE \
     --url http://{address}/api/v1/agents/58af890a2a8911f0a71a11b922ed82d6 \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{}'
```

##### Path parameters

- `agent_id`: `string`
  The id of the agent to be deleted.

#### Response

Success:

```json
{
    "code": 0,
    "data": true,
    "message": "success"
}
```

Failure:

```json
{
    "code": 103,
    "message": "Only owner of canvas authorized for this operation."
}
```

---



### Delete agent version

**DELETE** `/api/v1/agents/{agent_id}/versions/{version_id}`

Deletes one saved version belonging to the specified agent. The current agent
and its other saved versions remain unchanged. This also allows deleting the
last saved version.

#### Request

- Method: DELETE
- URL: `/api/v1/agents/{agent_id}/versions/{version_id}`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body: none.

##### Request example

```bash
curl --request DELETE \
     --url http://{address}/api/v1/agents/{agent_id}/versions/{version_id} \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Path parameters

- `agent_id`: `string`, required. The agent whose history contains the version.
- `version_id`: `string`, required. The saved version to delete.

#### Response

Success:

```json
{
    "code": 0,
    "data": true,
    "message": "success"
}
```

The caller must have permission to edit the agent. A missing or inaccessible
agent, a missing version, or a version belonging to a different agent returns
business code `103` with the message `"Make sure you have permission to access the agent."`.

---

### Apply agent version

**POST** `/api/v1/agents/{agent_id}/versions/{version_id}/apply`

Restores the saved version's workflow DSL into the current agent as an unpublished
draft. The agent's title, description, ownership, sharing, and other metadata are
preserved. The source version and existing history are retained. The restored DSL
passes the same validation and normalization as an ordinary agent update.

Applying saves the restored workflow to version history using the normal save
behavior: it creates a new draft version when the latest DSL differs or the
latest version is published, and refreshes an identical latest draft. Publish
the agent separately when the restored workflow is ready for release.

#### Request

- Method: POST
- URL: `/api/v1/agents/{agent_id}/versions/{version_id}/apply`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body: none.

##### Request example

```bash
curl --request POST \
     --url http://{address}/api/v1/agents/{agent_id}/versions/{version_id}/apply \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Path parameters

- `agent_id`: `string`, required. The agent to update.
- `version_id`: `string`, required. A saved version belonging to that agent.

#### Response

Success:

```json
{
    "code": 0,
    "data": true,
    "message": "success"
}
```

The caller must have permission to edit the agent. A missing or inaccessible
agent, a missing version, or a version belonging to a different agent returns
business code `103` with the message `"Make sure you have permission to access the agent."`.
A version without a DSL or a workflow that fails validation returns business
code `102`; the current agent and its history remain unchanged.

---

## MEMORY MANAGEMENT

### Create Memory

**POST** `/api/v1/memories`

Create a new memory.

#### Request

- Method: POST
- URL: `/api/v1/memories`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"name"`: `string`
  - `"memory_type"`: `list[string]`
  - `"embd_id"`: `string`.
  - `"llm_id"`: `string`

##### Request example

```bash
curl --location 'http://{address}/api/v1/memories' \
--header 'Content-Type: application/json' \
--header 'Authorization: Bearer <YOUR_API_KEY>' \
--data-raw '{
    "name": "new_memory_1",
    "memory_type": ["raw", "semantic"],
    "embd_id": "BAAI/bge-large-zh-v1.5@BAAI",
    "llm_id": "glm-4-flash@ZHIPU-AI"
}'
```

##### Body parameters

- `name` : `string`, *Required*

  The unique name of the memory to create. It must adhere to the following requirements:

  - Basic Multilingual Plane (BMP) only
  - Maximum 128 characters

- `memory_type`: `list[enum<string>]`,  *Required*

  Specifies the types of memory to extract. Available options:

  - `raw`: The raw dialogue content between the user and the agent . *Required by default*.
  - `semantic`: General knowledge and facts about the user and world.
  - `episodic`:  Time-stamped records of specific events and experiences.
  - `procedural`: Learned skills, habits, and automated procedures.

- `embd_id`: `string`, *Required*

  The name of the embedding model to use. For example: `"BAAI/bge-large-zh-v1.5@BAAI"`

  - Maximum 255 characters
  - Must follow `model_name@model_factory` format

- `llm_id`: `string`, *Required*

  The name of the chat model to use. For example: `"glm-4-flash@ZHIPU-AI"`

  - Maximum 255 characters
  - Must follow `model_name@model_factory` format

#### Response

Success:

```json
{
	"code": 0,
	"data": {
	...your new memory here
	},
	"message": "success"
}
```

Failure:

```json
{
    "code": 101,
    "message": "Memory name cannot be empty or whitespace."
}
```



### Update Memory

**PUT** `/api/v1/memories/{memory_id}`

Updates configurations for a specified memory.

#### Request

- Method: PUT
- URL: `/api/v1/memories/{memory_id}`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"name"`: `string`
  - `"avatar"`: `string`
  - `"permissions"`: `string`
  - `"llm_id"`: `string`
  - `"description"`: `string`
  - `"memory_size"`: `int`
  - `"forgetting_policy"`: `string`
  - `"temperature"`: `float`
  - `"system_prompt"`: `string`
  - `"user_prompt"`: `string`

##### Request example

```bash
curl --location --request PUT 'http://{address}/api/v1/memories/d6775d4eeada11f08ca284ba59bc53c7' \
--header 'Content-Type: application/json' \
--header 'Authorization: Bearer <YOUR_API_KEY>' \
--data '{
    "name": "name_update",
}'
```

##### Request parameters

- `memory_id`: (*Path parameter*)

  The ID of the memory to update.

- `name`: (*Body parameter*), `string`, *Optional*

  The revised name of the memory.

  - Basic Multilingual Plane (BMP) only
  - Maximum 128 characters, *Optional*

- `avatar`: (*Body parameter*), `string`, *Optional*

  The updated base64 encoding of the avatar.

  - Maximum 65535 characters

- `permissions`: (*Body parameter*), `enum<string>`, *Optional*

  The updated memory permission. Available options:

  - `"me"`: (Default) Only you can manage the memory.
  - `"team"`: All team members can manage the memory.

- `llm_id`: (*Body parameter*), `string`, *Optional*

  The name of the chat model to use. For example: `"glm-4-flash@ZHIPU-AI"`

  - Maximum 255 characters
  - Must follow `model_name@model_factory` format

- `description`: (*Body parameter*), `string`, *Optional*

  The description of the memory. Defaults to `None`.

- `memory_size`: (*Body parameter*), `int`, *Optional*

  Defaults to `5 MiB` (`5242880` bytes). Accounts for each message's content + its embedding vector (≈ Content + Dimensions × 8 Bytes). Example: A 1 KiB message with a 1024-dimension embedding uses approximately 9 KiB. The 5 MiB default limit holds approximately 500 such messages.

  - Maximum `5 MiB` (`5242880` bytes)

- `forgetting_policy`: (*Body parameter*), `enum<string>`, *Optional*

  Evicts existing data based on the chosen policy when the size limit is reached, freeing up space for new messages. Available options:

  - `"FIFO"`: (Default) Prioritize messages with the earliest `forget_at` time for removal. When the pool of messages that have `forget_at` set is insufficient, it falls back to selecting messages in ascending order of their `valid_at` (oldest first).

- `temperature`: (*Body parameter*), `float`, *Optional*

  Adjusts output randomness. Lower = more deterministic; higher = more creative.

  - Range [0, 1]

- `system_prompt`: (*Body parameter*), `string`, *Optional*

  Defines the system-level instructions and role for the AI assistant. It is automatically assembled based on the selected `memory_type` by `PromptAssembler` in `memory/utils/prompt_util.py`. This prompt sets the foundational behavior and context for the entire conversation.

  - Keep the `OUTPUT REQUIREMENTS` and `OUTPUT FORMAT` parts unchanged.

- `user_prompt`: (*Body parameter*), `string`, *Optional*

  Represents the user's custom setting, which is the specific question or instruction the AI needs to respond to directly. Defaults to `None`.

#### Response

Success:

```json
{
	"code": 0,
	"data": {
	...your updated memory here
	},
	"message": "success"
}
```

Failure:

```json
{
    "code": 101,
    "message": "Memory name cannot be empty or whitespace."
}
```



### List Memory

**GET** `/api/v1/memories?tenant_id={tenant_ids}&memory_type={memory_types}&storage_type={storage_type}&keywords={keywords}&page={page}&page_size={page_size}`

List memories.

#### Request

- Method: GET
- URL:  `/api/v1/memories?tenant_id={tenant_ids}&memory_type={memory_types}&storage_type={storage_type}&keywords={keywords}&page={page}&page_size={page_size}`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --location 'http://{address}/api/v1/memories?keywords=&page_size=50&page=1&memory_type=semantic%2Cepisodic' \
--header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Query parameters

- `tenant_id`: `string` or `list[string]`, *Optional*

  The owner's ID, supports search multiple IDs.

- `memory_type`: `enum<string>` or `list[enum<string>]`, *Optional*

  The type of memory (as set during creation). A memory matches if its type is **included in** the provided value(s). Available options:

  - `raw`
  - `semantic`
  - `episodic`
  - `procedural`

- `storage_type`: `enum<string>`, *Optional*

  The storage format of messages. Available options:

  - `table`: (Default)

- `keywords`: `string`, *Optional*

  The name of memory to retrieve, supports fuzzy search.

- `page`: `int`, *Optional*

  Specifies the page on which the memories will be displayed. Defaults to `1`.

- `page_size`: `int`, *Optional*

  The number of memories on each page. Defaults to `50`.

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "memory_list": [
            {
                "avatar": null,
                "create_date": "Tue, 06 Jan 2026 16:36:47 GMT",
                "create_time": 1767688607040,
                "description": null,
                "id": "d6775d4eeada11f08ca284ba59bc53c7",
                "memory_type": [
                    "raw",
                    "semantic"
                ],
                "name": "new_memory_1",
                "owner_name": "Lynn",
                "permissions": "me",
                "storage_type": "table",
                "tenant_id": "55777efac9df11f09cd07f49bd527ade"
            },
            ...other 3 memories here
        ],
        "total_count": 4
    },
    "message": "success"
}
```

Failure:

```json
{
    "code": 500,
    "message": "Internal Server Error."
}
```



### Get Memory Config

**GET** `/api/v1/memories/{memory_id}/config`

Get the configuration of a specified memory.

#### Request

- Method: GET
- URL: `/api/v1/memories/{memory_id}/config`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --location 'http://{address}/api/v1/memories/6c8983badede11f083f184ba59bc53c7/config' \
--header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Path parameters

- `memory_id`: `string`, *Required*

  The ID of the memory.

#### Response

Success

```json
{
    "code": 0,
    "data": {
        "avatar": null,
        "create_date": "Mon, 22 Dec 2025 10:32:13 GMT",
        "create_time": 1766370733354,
        "description": null,
        "embd_id": "BAAI/bge-large-zh-v1.5@SILICONFLOW",
        "forgetting_policy": "FIFO",
        "id": "6c8983badede11f083f184ba59bc53c7",
        "llm_id": "glm-4.5-flash@ZHIPU-AI",
        "memory_size": 5242880,
        "memory_type": [
            "raw",
            "semantic",
            "episodic",
            "procedural"
        ],
        "name": "mem1222",
        "owner_name": null,
        "permissions": "me",
        "storage_type": "table",
        "system_prompt": ...your prompt here,
        "temperature": 0.5,
        "tenant_id": "55777efac9df11f09cd07f49bd527ade",
        "update_date": null,
        "update_time": null,
        "user_prompt": null
    },
    "message": "success"
}
```

Failure

```json
{
    "code": 404,
    "data": null,
    "message": "Memory '{memory_id}' not found."
}
```



### Delete Memory

**DELETE** `/api/v1/memories/{memory_id}`

Delete a specified memory.

#### Request

- Method: DELETE
- URL: `/api/v1/memories/{memory_id}`
- Headers:
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --location --request DELETE 'http://{address}/api/v1/memories/d6775d4eeada11f08ca284ba59bc53c7' \
--header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Path parameters

- `memory_id`: `string`, *Required*

  The ID of the memory to delete.

#### Response

Success

```json
{
    "code": 0,
    "data": null,
    "message": "success"
}
```

Failure

```json
{
    "code": 404,
    "data": null,
    "message": "Resource not found"
}
```



### List messages of a memory

**GET** `/api/v1/memories/{memory_id}?agent_id={agent_id}&keywords={keywords}&page={page}&page_size={page_size}`

List the messages of a specified memory.

#### Request

- Method: GET
- URL: `/api/v1/memories/{memory_id}?agent_id={agent_id}&keywords={keywords}&page={page}&page_size={page_size}`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --location 'http://{address}/api/v1/memories/6c8983badede11f083f184ba59bc53c?page=1' \
--header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Request parameters

- `memory_id`: (*Path parameter*), `string`, *Required*

  The ID of the memory to show messages.

- `agent_id`: (*Query parameter*), `string` or `list[string]`, *Optional*

  Filters messages by the ID of their source agent. Supports multiple values.

- `keywords`: (*Query parameter*), `string`, *Optional*

  Filters messages by session ID. Despite the parameter name, its value is applied to the `session_id` field.

- `page`: (*Query parameter*), `int`, *Optional*

  Specifies the page on which the messages will be displayed. Defaults to `1`.

- `page_size`: (*Query parameter*), `int`, *Optional*

  The number of messages on each page. Defaults to `50`.

#### Response

Success

```json
{
    "code": 0,
    "data": {
        "messages": {
            "message_list": [
                {
                    "agent_id": "8db9c8eddfcc11f0b5da84ba59bc53c7",
                    "agent_name": "memory_agent_1223",
                    "extract": [
                        {
                            "agent_id": "8db9c8eddfcc11f0b5da84ba59bc53c7",
                            "agent_name": "memory_agent_1223",
                            "forget_at": "None",
                            "invalid_at": "None",
                            "memory_id": "6c8983badede11f083f184ba59bc53c7",
                            "message_id": 236,
                            "message_type": "semantic",
                            "session_id": "65b89ab8e96411f08d4e84ba59bc53c7",
                            "source_id": 233,
                            "status": true,
                            "user_id": "",
                            "valid_at": "2026-01-04 19:56:46"
                        },
                        ...other extracted messages
                    ],
                    "forget_at": "None",
                    "invalid_at": "None",
                    "memory_id": "6c8983badede11f083f184ba59bc53c7",
                    "message_id": 233,
                    "message_type": "raw",
                    "session_id": "65b89ab8e96411f08d4e84ba59bc53c7",
                    "source_id": "None",
                    "status": true,
                    "task": {
                        "progress": 1.0,
                        "progress_msg": "\n2026-01-04 19:56:46 Prepared prompts and LLM.\n2026-01-04 19:57:48 Get extracted result from LLM.\n2026-01-04 19:57:48 Extracted 6 messages from raw dialogue.\n2026-01-04 19:57:48 Prepared embedding model.\n2026-01-04 19:57:48 Embedded extracted content.\n2026-01-04 19:57:48 Saved messages to storage.\n2026-01-04 19:57:48 Message saved successfully."
                    },
                    "user_id": "",
                    "valid_at": "2026-01-04 19:56:42"
                },
                {
                    "agent_id": "8db9c8eddfcc11f0b5da84ba59bc53c7",
                    "agent_name": "memory_agent_1223",
                    "extract": [],
                    "forget_at": "None",
                    "invalid_at": "None",
                    "memory_id": "6c8983badede11f083f184ba59bc53c7",
                    "message_id": 226,
                    "message_type": "raw",
                    "session_id": "d982a8cbe96111f08a1384ba59bc53c7",
                    "source_id": "None",
                    "status": true,
                    "task": {
                        "progress": -1.0,
                        "progress_msg": "Failed to insert message into memory. Details: 6c8983badede11f083f184ba59bc53c7_228:{'type': 'document_parsing_exception', 'reason': \"[1:230] failed to parse field [valid_at] of type [date] in document with id '6c8983badede11f083f184ba59bc53c7_228'. Preview of field's value: ''\", 'caused_by': {'type': 'illegal_argument_exception', 'reason': 'cannot parse empty date'}}; 6c8983badede11f083f184ba59bc53c7_229:{'type': 'document_parsing_exception', 'reason': \"[1:230] failed to parse field [valid_at] of type [date] in document with id '6c8983badede11f083f184ba59bc53c7_229'. Preview of field's value: ''\", 'caused_by': {'type': 'illegal_argument_exception', 'reason': 'cannot parse empty date'}}; 6c8983badede11f083f184ba59bc53c7_230:{'type': 'document_parsing_exception', 'reason': \"[1:230] failed to parse field [valid_at] of type [date] in document with id '6c8983badede11f083f184ba59bc53c7_230'. Preview of field's value: ''\", 'caused_by': {'type': 'illegal_argument_exception', 'reason': 'cannot parse empty date'}}; 6c8983badede11f083f184ba59bc53c7_231:{'type': 'document_parsing_exception', 'reason': \"[1:230] failed to parse field [valid_at] of type [date] in document with id '6c8983badede11f083f184ba59bc53c7_231'. Preview of field's value: ''\", 'caused_by': {'type': 'illegal_argument_exception', 'reason': 'cannot parse empty date'}}; 6c8983badede11f083f184ba59bc53c7_232:{'type': 'document_parsing_exception', 'reason': \"[1:230] failed to parse field [valid_at] of type [date] in document with id '6c8983badede11f083f184ba59bc53c7_232'. Preview of field's value: ''\", 'caused_by': {'type': 'illegal_argument_exception', 'reason': 'cannot parse empty date'}}"
                    },
                    "user_id": "",
                    "valid_at": "2026-01-04 19:38:26"
                },
                ...other 11 messages
            ],
            "total_count": 13
        },
        "storage_type": "table"
    },
    "message": "success"
}
```

Failure

```
{
    "code": 404,
    "data": null,
    "message": "Memory '{memory_id}' not found."
}
```



### Add Message

**POST** `/api/v1/messages`

Add a message to specified memories.

#### Request

- Method: POST
- URL: `/api/v1/messages`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"memory_id"`: `list[string]`
  - `"agent_id"`: `string`
  - `"session_id"`: `string`
  - `"user_id"`: `string`
  - `"user_input"`: `string`
  - `"agent_response"`: `string`

##### Request example

```bash
curl --location 'http://{address}/api/v1/messages' \
--header 'Content-Type: application/json' \
--header 'Authorization: Bearer <YOUR_API_KEY>' \
--data '{
    "memory_id": ["6c8983badede11f083f184ba59bc53c7", "87ebb892df1711f08d6b84ba59bc53c7"],
    "agent_id": "8db9c8eddfcc11f0b5da84ba59bc53c7",
    "session_id": "bf0a50abeb8111f0917884ba59bc53c7",
    "user_id": "55777efac9df11f09cd07f49bd527ade",
    "user_input": "your user input here",
    "agent_response": "your agent response here"

}'
```

##### Body parameters

- `memory_id`: `list[string]`, *Required*

  The IDs of the memories to save messages.

- `agent_id`: `string`, *Required*

  The ID of the message's source agent.

- `session_id`: `string`, *Required*

  The ID of the message's session.

- `user_id`: `string`, *Optional*

  The user participating in the conversation with the agent. Honoured only when the request is authenticated with an API key. For API key authentication, this field must be a non-empty string; surrounding whitespace is stripped, and a missing, blank, or non-string value causes the request to fail. Any other authentication, whether a JWT bearer token or a browser session, ignores this field and attributes the message to the authenticated user.

- `user_input`: `string`, *Required*

  The text input provided by the user.

- `agent_response`: `string`, *Required*

  The text response generated by the AI agent.

#### Response

Success

```json
{
    "code": 0,
    "data": null,
    "message": "All add to task."
}
```

Failure

```json
{
    "code": 500,
    "data": null,
    "message": "Some messages failed to add. Detail: {fail information}"
}
```



### Forget Message

**DELETE** `/api/v1/messages/{memory_id}:{message_id}`

Forget a specified message. After forgetting, this message will not be retrieved by agents, and it will also be prioritized for cleanup by the forgetting policy.

#### Request

- Method: DELETE
- URL: `/api/v1/messages/{memory_id}:{message_id}`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --location --request DELETE 'http://{address}/api/v1/messages/6c8983badede11f083f184ba59bc53c7:272' \
--header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Path parameters

- `memory_id`: `string`, *Required*

  The ID of the memory to which the specified message belongs.

- `message_id`: `string`, *Required*

  The ID of the message to forget.

#### Response

Success

```json
{
    "code": 0,
    "data": null,
    "message": "success"
}
```

Failure

```json
{
    "code": 404,
    "data": null,
    "message": "Memory '{memory_id}' not found."
}
```



### Update message status

**PUT** `/api/v1/messages/{memory_id}:{message_id}`

Update message status, enable or disable a message. Once a message is disabled, it will not be retrieved by agents.

#### Request

- Method: PUT
- URL: `/api/v1/messages/{memory_id}:{message_id}`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"status"`: `bool`

##### Request example

```bash
curl --location --request PUT 'http://{address}/api/v1/messages/6c8983badede11f083f184ba59bc53c7:270' \
--header 'Content-Type: application/json' \
--header 'Authorization: Bearer <YOUR_API_KEY>' \
--data '{
    "status": false
}'
```

##### Request parameters

- `memory_id`: (*Path parameter*), `string`, *Required*

  The ID of the memory to which the specified message belongs.

- `message_id`: (*Path parameter*), `string`, *Required*

  The ID of the message to enable or disable.

- `status`: (*Body parameter*), `bool`, *Required*

  The status of message. `True` = `enabled`, `False` = `disabled`.

#### Response

Success

```json
{
    "code": 0,
    "data": null,
    "message": "success"
}
```

Failure

```json
{
    "code": 404,
    "data": null,
    "message": "Memory '{memory_id}' not found."
}
```

### Search Message

**GET** `/api/v1/messages/search?query={query}&memory_id={memory_id}&similarity_threshold={similarity_threshold}&keywords_similarity_weight={keywords_similarity_weight}&top_n={top_n}`

Searches and retrieves messages from memory based on the provided `query` and other configuration parameters.

#### Request

- Method: GET
- URL: `/api/v1/messages/search?query={query}&memory_id={memory_id}&similarity_threshold={similarity_threshold}&keywords_similarity_weight={keywords_similarity_weight}&top_n={top_n}`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --location 'http://{address}/api/v1/messages/search?query=%22who%20are%20you%3F%22&memory_id=6c8983badede11f083f184ba59bc53c7&similarity_threshold=0.2&keywords_similarity_weight=0.7&top_n=10' \
--header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Query parameters

- `query`: `string`, *Required*

  The search term or natural language question used to find relevant messages.

- `memory_id`: `string` or `list[string]`, *Required*

  The IDs of the memories to search.  Supports multiple values.

- `agent_id`: `string`, *Optional*

  The ID of the message's source agent. Defaults to `None`.

- `session_id`: `string`, *Optional*

  The ID of the message's session. Defaults to `None`.

- `user_id`: `string`, *Optional*

  The user participating in the conversation with the agent. Defaults to `None`.

- `similarity_threshold`: `float`, *Optional*

  The minimum cosine similarity score required for a message to be considered a match. A higher value  yields more precise but fewer results. Defaults to `0.2`.

  - Range [0.0, 1.0]

- `keywords_similarity_weight`: `float`, *Optional*

  Controls the influence of keyword matching versus semantic (embedding-based) matching in the final relevance score. A value of 0.5 gives them equal weight. Defaults to `0.7`.

  - Range [0.0, 1.0]

- `top_n`: `int`, *Optional*

  The maximum number of most relevant messages to return. This limits the result set size for efficiency. Defaults to `5`.

#### Response

Success

```json
{
    "code": 0,
    "data": [
        {
            "agent_id": "8db9c8eddfcc11f0b5da84ba59bc53c7",
            "content": "User Input: who am I?\nAgent Response: To address the question \"who am I?\", let's follow the logical steps outlined in the instructions:\n\n1. **Understand the User's Request**: The user is asking for a clarification or identification of their own self. This is a fundamental question about personal identity.\n\n2. **Decompose the Request**: The request is quite simple and doesn't require complex decomposition. The core task is to provide an answer that identifies the user in some capacity.\n\n3. **Execute the Subtask**:\n   - **Identify the nature of the question**: The user is seeking to understand their own existence or their sense of self.\n   - **Assess the context**: The context is not explicitly given, so the response will be general.\n   - **Provide a response**: The answer should acknowledge the user's inquiry into their identity.\n\n4. **Validate Accuracy and Consistency**: The response should be consistent with the general understanding of the question. Since the user has not provided specific details about their identity, the response should be broad and open-ended.\n\n5. **Summarize the Final Result**: The user is asking \"who am I?\" which is an inquiry into their own identity. The answer is that the user is the individual who is asking the question. Without more specific information, a detailed description of their identity cannot be provided.\n\nSo, the final summary would be:\n\nThe user is asking the question \"who am I?\" to seek an understanding of their own identity. The response to this question is that the user is the individual who is posing the question. Without additional context or details, a more comprehensive description of the user's identity cannot be given.",
            "forget_at": "None",
            "invalid_at": "None",
            "memory_id": "6c8983badede11f083f184ba59bc53c7",
            "message_id": 61,
            "message_type": "raw",
            "session_id": "ebf8025de52211f0b56684ba59bc53c7",
            "source_id": "None",
            "status": true,
            "user_id": "",
            "valid_at": "2025-12-30 09:57:49"
        },
        ...other 2 matched messages here
    ],
    "message": "success"
}
```

Failure

```json
{
    "code": 500,
    "message": "Internal Server Error."
}
```



### Get Recent Messages

**GET** `/api/v1/messages?memory_id={memory_id}&agent_id={agent_id}&session_id={session_id}&limit={limit}`

Retrieves the most recent messages from specified memories. Typically, accepts a `limit` parameter to control the number of messages returned.

#### Request

- Method: GET
- URL: `/api/v1/messages?memory_id={memory_id}&agent_id={agent_id}&session_id={session_id}&limit={limit}`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --location 'http://{address}/api/v1/messages?memory_id=6c8983badede11f083f184ba59bc53c7&limit=10' \
--header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Query parameters

- `memory_id`: `string` or `list[string]`, *Required*

  The IDs of the memories to search.  Supports multiple values.

- `agent_id`: `string`, *Optional*

  The ID of the message's source agent. Defaults to `None`.

- `session_id`: `string`, *Optional*

  The ID of the message's session. Defaults to `None`.

- `limit`: `int`, *Optional*

  Control the number of messages returned. Defaults to `10`.

#### Response

Success

```json
{
    "code": 0,
    "data": [
        {
            "agent_id": "8db9c8eddfcc11f0b5da84ba59bc53c7",
            "content": "User Input: what is pineapple?\nAgent Response: A pineapple is a tropical fruit known for its sweet, tangy flavor and distinctive, spiky appearance. Here are the key facts:\nScientific Name: Ananas comosus\nPhysical Description: It has a tough, spiky, diamond-patterned outer skin (rind) that is usually green, yellow, or brownish. Inside, the juicy yellow flesh surrounds a fibrous core.\nGrowth: Unlike most fruits, pineapples do not grow on trees. They grow from a central stem as a composite fruit, meaning they are formed from many individual berries that fuse together around the core. They grow on a short, leafy plant close to the ground.\nUses: Pineapples are eaten fresh, cooked, grilled, juiced, or canned. They are a popular ingredient in desserts, fruit salads, savory dishes (like pizzas or ham glazes), smoothies, and cocktails.\nNutrition: They are a good source of Vitamin C, manganese, and contain an enzyme called bromelain, which aids in digestion and can tenderize meat.\nSymbolism: The pineapple is a traditional symbol of hospitality and welcome in many cultures.\nAre you asking about the fruit itself, or its use in a specific context?",
            "forget_at": "None",
            "invalid_at": "None",
            "memory_id": "6c8983badede11f083f184ba59bc53c7",
            "message_id": 269,
            "message_type": "raw",
            "session_id": "bf0a50abeb8111f0917884ba59bc53c7",
            "source_id": "None",
            "status": true,
            "user_id": "",
            "valid_at": "2026-01-07 16:49:12"
        },
        ...other 9 messages here
    ],
    "message": "success"
}
```

Failure

```json
{
    "code": 500,
    "message": "Internal Server Error."
}
```



### Get Message Content

**GET** `/api/v1/messages/{memory_id}:{message_id}/content`

Retrieves the full content and embed vector of a specific message using its unique message ID.

#### Request

- Method: GET
- URL: `/api/v1/messages/{memory_id}:{message_id}/content`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --location 'http://{address}/api/v1/messages/6c8983badede11f083f184ba59bc53c7:270/content' \
--header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Path parameters

- `memory_id`: `string`, *Required*

  The ID of the memory to which the specified message belongs.

- `message_id`: `string`, *Required*

  The ID of the message.

#### Response

Success

```json
{
    "code": 0,
    "data": {
        "agent_id": "8db9c8eddfcc11f0b5da84ba59bc53c7",
        "content": "Pineapples are tropical fruits known for their sweet, tangy flavor and distinctive, spiky appearance",
        "content_embed": [
        	0.03641991,
            ...embed vector here
        ],
        "forget_at": null,
        "id": "6c8983badede11f083f184ba59bc53c7_270",
        "invalid_at": null,
        "memory_id": "6c8983badede11f083f184ba59bc53c7",
        "message_id": 270,
        "message_type": "semantic",
        "session_id": "bf0a50abeb8111f0917884ba59bc53c7",
        "source_id": 269,
        "status": false,
        "user_id": "",
        "valid_at": "2026-01-07 16:48:37",
        "zone_id": 0
    },
    "message": "success"
}
```

Failure

```json
{
    "code": 404,
    "data": null,
    "message": "Memory '{memory_id}' not found."
}
```



---

## System

---

### Check system health

**GET** `/api/v1/system/healthz`

Check the health status of RAGFlow's dependencies: metadata database, Kvrocks cache, document engine, object storage, and NATS message queue.

:::caution REMOVED ALIAS
`GET /v1/system/healthz` is not available in 1.0. Use this endpoint instead.
:::

#### Request

- Method: GET
- URL: `/api/v1/system/healthz`
- Headers:
  - 'Content-Type: application/json'
  (no Authorization required)

##### Request example

```bash
curl --request GET \
     --url http://{address}/api/v1/system/healthz \
     --header 'Content-Type: application/json'
```

---

#### Responses

- **200 OK** – All services healthy

```http
HTTP/1.1 200 OK
Content-Type: application/json

{
  "db": "ok",
  "redis": "ok",
  "doc_engine": "ok",
  "storage": "ok",
  "message_queue": "ok",
  "status": "ok"
}
```

- **500 Internal Server Error** – At least one service unhealthy

```http
HTTP/1.1 500 INTERNAL SERVER ERROR
Content-Type: application/json

{
  "db": "ok",
  "redis": "nok",
  "doc_engine": "ok",
  "storage": "ok",
  "message_queue": "ok",
  "status": "nok",
  "_meta": {
    "redis": {
      "elapsed": "5.2",
      "error": "Lost connection!"
    }
  }
}
```

Explanation:

- Each service is reported as "ok" or "nok".
- The `redis` field reports the Redis-compatible Kvrocks cache; `message_queue` reports the NATS connection.
- The top-level `status` reflects overall health.
- If any service is "nok", detailed error info appears in `_meta`.

---

## FILE MANAGEMENT

---

### Upload file

**POST** `/api/v1/files`

Uploads one or multiple files to the system.

:::caution REMOVED ALIAS
`POST /api/v1/file/upload` is not available in 1.0. Use this endpoint instead.
:::

#### Request

- Method: POST
- URL: `/api/v1/files`
- Headers:
  - `'Content-Type: multipart/form-data'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Form:
  - `'file=@{FILE_PATH}'`
  - `'parent_id'`: `string` (optional)

##### Request example

```bash
curl --request POST \
     --url http://{address}/api/v1/files \
     --header 'Content-Type: multipart/form-data' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --form 'file=@./test1.txt' \
     --form 'file=@./test2.pdf' \
     --form 'parent_id={workspace_id}'
```

##### Request parameters

- `'file'`: (*Form parameter*), `file`, *Required*
  The file(s) to upload. Multiple files can be uploaded in a single request.
- `'parent_id'`: (*Form parameter*), `string`
  The parent folder ID where the file will be uploaded. If not specified, files will be uploaded to the root folder.

#### Response

Success:

```json
{
    "code": 0,
    "data": [
        {
            "id": "b330ec2e91ec11efbc510242ac120004",
            "name": "test1.txt",
            "size": 17966,
            "type": "doc",
            "parent_id": "527fa74891e811ef9c650242ac120006",
            "location": "test1.txt",
            "create_time": 1729763127646
        }
    ]
}
```

Failure:

```json
{
    "code": 400,
    "message": "No file part!"
}
```

---

### Upload document

**POST** `/api/v1/documents/upload`

Uploads a file and creates the respective document.

:::caution REMOVED ALIAS
`POST /v1/document/upload_info` and `POST /api/v1/file/upload_info` are not available in 1.0. Use this endpoint instead.
:::

#### Request

- Method: POST
- URL: `/api/v1/documents/upload`
- Headers:
  - `'Content-Type: multipart/form-data'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Form:
  - `'file=@{FILE_PATH}'` (mutually exclusive with `url`)
- Query:
  - `url`: URL to crawl and convert to a runtime attachment (mutually exclusive with `file`).

##### Request example

Upload a local file:

```bash
curl --request POST \
     --url http://{address}/api/v1/documents/upload \
     --header 'Content-Type: multipart/form-data' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --form 'file=@./test1.pdf'
```

Crawl a URL:

```bash
curl --request POST \
     --url 'http://{address}/api/v1/documents/upload?url=https://example.com/page' \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Request parameters

- `'file'`: (*Form parameter*), `file`, *Optional*
  The file to upload. Mutually exclusive with `url`; either `file` or `url` must be provided.
- `url`: (*Query parameter*), `string`, *Optional*
  A URL to crawl and store as an attachment. Mutually exclusive with `file`; either `url` or `file` must be provided.

#### Response

Success:

```json
{
    "code": 0,
    "data": {
      "created_at": 1772451421.7924063,
      "created_by": "be951084066611f18f5f00155d2f98f4",
      "extension": "pdf",
      "id": "2143a03d162c11f1b80f00155d334d02",
      "mime_type": "application/pdf",
      "name": "test1.pdf",
      "preview_url": null,
      "size": 49705
    },
    "message": "success"
}
```

Failure:

```json
{
    "code": 400,
    "message": "Provide either multipart file(s) or ?url=...!"
}
```

---

### Download attachment

**GET** `/api/v1/agents/attachments/{attachment_id}/download`

:::caution REMOVED ALIAS
The previous endpoints `GET /v1/document/download/{doc_id}` and `GET /api/v1/document/download/{doc_id}` are not available in 1.0. Use this endpoint instead.
:::

Downloads a runtime attachment previously uploaded for use in the agent system.

#### Request

- Method: GET
- URL: `/api/v1/agents/attachments/{attachment_id}/download`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Query parameter:
  - `ext`: `string` (Optional)

##### Request example

```bash
curl --request GET \
     --url 'http://{address}/api/v1/agents/attachments/{attachment_id}/download?ext=pdf' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --output ./downloaded_attachment.pdf
```

##### Request parameters

- `attachment_id`: (*Path parameter*), `string`, *Required*
  The attachment ID whose file should be downloaded.
- `ext`: (*Query parameter*), `string`, *Optional*
  A file extension hint specifying the response's Content-Type. Defaults to `"markdown"`. Available values:
  - `"markdown"`
  - `"html"`
  - `"pdf"`
  - `"docx"`
  - `"xlsx"`
  - `"csv"`

#### Response

Success:

Returns the file content as a binary stream with the relevant Content-Type header.

Failure:

```json
{
    "code": 500,
    "message": "Internal server error"
}
```

---

### Create file or folder

**POST** `/api/v1/files`

Creates a new file or folder in the system.

:::caution REMOVED ALIAS
`POST /api/v1/file/create` is not available in 1.0. Use this endpoint instead.
:::

#### Request

- Method: POST
- URL: `/api/v1/files`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"name"`: `string`
  - `"parent_id"`: `string` (optional)
  - `"type"`: `string`

##### Request example

```bash
curl --request POST \
     --url http://{address}/api/v1/files \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{
          "name": "New Folder",
          "type": "folder",
          "parent_id": "{workspace_id}"
     }'
```

##### Body parameters

- `"name"`: `string`, *Required*
  The name of the file or folder to create. If the name is already taken in the parent folder, the new entry gets a numbered suffix such as `New Folder(1)`.
- `"parent_id"`: `string`
  The parent folder ID. If not specified, the file/folder will be created in the root folder.
- `"type"`: `string`
  The type of the file to create. Available options:
  - `"folder"`: Create a folder
  - `"virtual"`: Create a virtual file

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "id": "b330ec2e91ec11efbc510242ac120004",
        "name": "New Folder",
        "type": "folder",
        "parent_id": "527fa74891e811ef9c650242ac120006",
        "size": 0,
        "create_time": 1729763127646
    }
}
```

Failure:

```json
{
    "code": 400,
    "message": "Folder name cannot contain \"/\""
}
```

---

### List files

**GET** `/api/v1/files?parent_id={parent_id}&keywords={keywords}&page={page}&page_size={page_size}&orderby={orderby}&desc={desc}&sort={sort}`

Lists files and folders under a specific folder.

:::caution REMOVED ALIAS
`GET /api/v1/file/list` is not available in 1.0. Use this endpoint instead.
:::

#### Request

- Method: GET
- URL: `/api/v1/files?parent_id={parent_id}&keywords={keywords}&page={page}&page_size={page_size}&orderby={orderby}&desc={desc}&sort={sort}`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request GET \
     --url 'http://{address}/api/v1/files?parent_id={folder_id}&page=1&page_size=15' \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Query parameters

- `parent_id`: `string`
  The folder ID to list files from. If not specified, the root folder is used by default.
- `keywords`: `string`
  Search keyword to filter files by name.
- `page`: `integer`
  Specifies the page on which the files will be displayed. Defaults to `1`.
- `page_size`: `integer`
  The number of files on each page. Defaults to `15`.
- `orderby`: `string`
  The field by which files should be sorted. Available options:
  - `create_time` (default)
- `desc`: `boolean`
  Indicates whether the retrieved files should be sorted in descending order. Defaults to `true`.
- `sort`: `string`
  Orders by several fields at once, written as `column:direction` terms separated by commas, such as `name:asc,create_time:desc`. A term with no direction is ascending. `sort` takes precedence over `orderby` and `desc`, which keep working on their own. A term naming a field this list does not sort by is skipped. When `sort` yields no terms at all, `orderby` and `desc` decide the order. When it yields terms whose fields are all skipped, the result is ordered by `create_time` in the direction of the first term, and the older pair is not read.

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "total": 10,
        "files": [
            {
                "id": "b330ec2e91ec11efbc510242ac120004",
                "name": "test1.txt",
                "type": "doc",
                "size": 17966,
                "parent_id": "527fa74891e811ef9c650242ac120006",
                "create_time": 1729763127646
            }
        ],
        "parent_folder": {
            "id": "527fa74891e811ef9c650242ac120006",
            "name": "Parent Folder"
        }
    }
}
```

Failure:

```json
{
    "code": 404,
    "message": "Folder not found!"
}
```

---

### Get parent folder

**GET** `/api/v1/files/{file_id}/parent`

Retrieves the immediate parent folder information of a specified file.

:::caution REMOVED ALIAS
`GET /api/v1/file/parent_folder?file_id=...` is not available in 1.0. Use this endpoint instead.
:::

#### Request

- Method: GET
- URL: `/api/v1/files/{file_id}/parent`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request GET \
     --url 'http://{address}/api/v1/files/{file_id}/parent' \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Path parameters

- `file_id`: `string`, *Required*
  The ID of the file whose immediate parent folder to retrieve.

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "parent_folder": {
            "id": "527fa74891e811ef9c650242ac120006",
            "name": "Parent Folder"
        }
    }
}
```

Failure:

```json
{
    "code": 404,
    "message": "Folder not found!"
}
```

---

### Get all parent folders

**GET** `/api/v1/files/{file_id}/ancestors`

Retrieves all parent folders of a specified file in the folder hierarchy.

:::caution REMOVED ALIAS
`GET /api/v1/file/all_parent_folder?file_id=...` is not available in 1.0. Use this endpoint instead.
:::

#### Request

- Method: GET
- URL: `/api/v1/files/{file_id}/ancestors`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request GET \
     --url 'http://{address}/api/v1/files/{file_id}/ancestors' \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Path parameters

- `file_id`: `string`, *Required*
  The ID of the file whose parent folders to retrieve.

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "parent_folders": [
            {
                "id": "527fa74891e811ef9c650242ac120006",
                "name": "Parent Folder 1"
            },
            {
                "id": "627fa74891e811ef9c650242ac120007",
                "name": "Parent Folder 2"
            }
        ]
    }
}
```

Failure:

```json
{
    "code": 404,
    "message": "Folder not found!"
}
```

---

### Delete files

**DELETE** `/api/v1/files`

Deletes one or multiple files or folders.

:::caution REMOVED ALIAS
`POST /api/v1/file/rm` is not available in 1.0. Use this endpoint instead.
:::

#### Request

- Method: DELETE
- URL: `/api/v1/files`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"ids"`: `list[string]`

##### Request example

```bash
curl --request DELETE \
     --url http://{address}/api/v1/files \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{
          "ids": ["file_id_1", "file_id_2"]
     }'
```

##### Body parameters

- `"ids"`: `list[string]`, *Required*
  The IDs of the files or folders to delete.

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "success_count": 2
    }
}
```

Failure:

```json
{
    "code": 102,
    "message": "Partially deleted 1 files with 1 errors",
    "data": {
        "success_count": 1,
        "errors": [
            "No authorization for file file1"
        ]
    }
}
```

---

### Download file

**GET** `/api/v1/files/{file_id}`

Downloads a file from the system.

:::caution REMOVED ALIAS
`GET /api/v1/file/get/{file_id}` is not available in 1.0. Use this endpoint instead.
:::

#### Request

- Method: GET
- URL: `/api/v1/files/{file_id}`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request GET \
     --url http://{address}/api/v1/files/{file_id} \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --output ./downloaded_file.txt
```

##### Path parameters

- `file_id`: `string`, *Required*
  The ID of the file to download.

#### Response

Success:

Returns the file content as a binary stream with appropriate Content-Type headers.

Failure:

```json
{
    "code": 404,
    "message": "document not found"
}
```

---

### Move or rename files

**POST** `/api/v1/files/move`

Moves and/or renames files or folders. Follows Linux `mv` semantics: at least one of `dest_file_id` or `new_name` must be provided.

:::caution REMOVED ALIAS
The previous endpoints `POST /api/v1/file/mv` and `POST /api/v1/file/rename` are not available in 1.0. Use this endpoint instead.
:::

- `dest_file_id` only: move files to a new folder, names unchanged.
- `new_name` only: rename a single file or folder in place, no storage operation.
- Both: move and rename simultaneously.

#### Request

- Method: POST
- URL: `/api/v1/files/move`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"src_file_ids"`: `list[string]`, *Required*
  - `"dest_file_id"`: `string`, *Optional*
  - `"new_name"`: `string`, *Optional*

##### Request examples

Move files to a folder:

```bash
curl --request POST \
     --url http://{address}/api/v1/files/move \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{
          "src_file_ids": ["file_id_1", "file_id_2"],
          "dest_file_id": "{destination_folder_id}"
     }'
```

Rename a file in place:

```bash
curl --request POST \
     --url http://{address}/api/v1/files/move \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{
          "src_file_ids": ["{file_id}"],
          "new_name": "new_name.txt"
     }'
```

##### Body parameters

- `"src_file_ids"`: `list[string]`, *Required*
  The IDs of the files or folders to move or rename.
- `"dest_file_id"`: `string`, *Optional*
  The ID of the destination folder. Omit to rename in place.
- `"new_name"`: `string`, *Optional*
  New name for the file or folder. Only valid when `src_file_ids` contains a single entry. Note: Changing file extensions is *not* supported.

#### Response

Success:

```json
{
    "code": 0,
    "data": true
}
```

Failure:

```json
{
    "code": 404,
    "message": "File or Folder not found!"
}
```

or

```json
{
    "code": 404,
    "message": "Parent folder not found!"
}
```

or

```json
{
    "code": 400,
    "message": "The extension of file can't be changed"
}
```

or

```json
{
    "code": 400,
    "message": "duplicated file name in the same folder"
}
```

---

### Links files to datasets and convert to documents

**POST** `/api/v1/files/link-to-datasets`

Converts files to documents and links them to specified datasets.

:::caution REMOVED ALIAS
`POST /api/v1/file/convert` is not available in 1.0. Use this endpoint instead.
:::

#### Request

- Method: POST
- URL: `/api/v1/files/link-to-datasets`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `"file_ids"`: `list[string]`
  - `"kb_ids"`: `list[string]`

##### Request example

```bash
curl --request POST \
     --url http://{address}/api/v1/files/link-to-datasets \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{
          "file_ids": ["file_id_1", "file_id_2"],
          "kb_ids": ["dataset_id_1", "dataset_id_2"]
     }'
```

##### Body parameters

- `"file_ids"`: `list[string]`, *Required*
  The IDs of the files to convert. If a folder ID is provided, all files within that folder will be converted.
- `"kb_ids"`: `list[string]`, *Required*
  The IDs of the target datasets.

#### Response

Success:

```json
{
    "code": 0,
    "data": [
        {
            "id": "file2doc_id_1",
            "file_id": "file_id_1",
            "document_id": "document_id_1"
        }
    ]
}
```

Failure:

```json
{
    "code": 404,
    "message": "File not found!"
}
```

or

```json
{
    "code": 404,
    "message": "Can't find this dataset!"
}
```

---

### Create commit

**POST** `/api/v1/workspaces/{workspace_id}/commits`

Creates a new snapshot commit for the specified workspace. This endpoint also supports:
- `/api/v1/datasets/{dataset_id}/commits` (resolves dataset to its workspace)

#### Request

- Method: POST
- URL: `/api/v1/workspaces/{workspace_id}/commits`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:
  - `'message'`: `string` (required)
    The commit message.
  - `'files'`: `list[object]` (required)
    The list of file changes. Each file change is an object with the following fields:

##### Request example

```bash
curl --request POST \
     --url http://{address}/api/v1/workspaces/{workspace_id}/commits \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --data '{
          "message": "update config files",
          "files": [
               {"file_id": "file_uuid", "file_name": "config.json", "operation": "modify", "content": "{\"key\": \"value\"}"},
               {"file_id": "file_uuid", "file_name": "readme.md", "operation": "add", "content": "# New README"}
          ]
     }'
```

##### Body parameters

- `"message"`: `string`, *Required*
  The commit message describing the changes.
- `"files"`: `list[object]`, *Required*
  Each file change object supports the following fields:

  | Field | Type | Required | Description |
  |-------|------|----------|-------------|
  | `file_id` | `string` | Yes | The file ID |
  | `file_name` | `string` | Only for add/rename | The file name |
  | `operation` | `string` | Yes | `"add"`, `"modify"`, `"delete"`, or `"rename"` |
  | `content` | `string` | Only for add/modify | The file content |
  | `old_name` | `string` | Only for rename | The old file name |
  | `new_name` | `string` | Only for rename | The new file name |

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "id": "commit_uuid",
        "folder_id": "folder_uuid",
        "parent_id": null,
        "message": "update config files",
        "author_id": "user_uuid",
        "file_count": 2,
        "tree_state": "{\"file_uuid\": {\"hash\": \"abcd1234\", \"location\": \".objects/abcd1234\", \"name\": \"config.json\", \"size\": 1024, \"status\": \"1\", \"parent_id\": \"folder_uuid\"}}",
        "create_time": 1718200000000
    }
}
```

:::note
`tree_state` is a JSON string containing a flat map of file entries. Each entry includes `parent_id` to track which sub-folder the file belonged to at commit time. Sub-folders are inferred from `parent_id` values.
:::

Failure:

```json
{
    "code": 101,
    "message": "required argument are missing: message"
}
```

---

### List commits

**GET** `/api/v1/workspaces/{workspace_id}/commits`

Lists all commits for the specified folder with pagination. Also available at:
- `/api/v1/datasets/{dataset_id}/commits`

#### Request

- Method: GET
- URL: `/api/v1/workspaces/{workspace_id}/commits`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Query:
  - `'page'`: `int` (optional, default: 1)
  - `'page_size'`: `int` (optional, default: 15)
  - `'order_by'`: `string` (optional, default: `"create_time"`)
  - `'desc'`: `bool` (optional, default: `true`)

##### Request example

```bash
curl --request GET \
     --url 'http://{address}/api/v1/workspaces/{workspace_id}/commits?page=1&page_size=15' \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Query parameters

- `"page"`: `int`, *Optional*
  Page number. Defaults to 1.
- `"page_size"`: `int`, *Optional*
  Number of items per page. Defaults to 15.
- `"order_by"`: `string`, *Optional*
  Sort field. Defaults to `"create_time"`.
- `"desc"`: `bool`, *Optional*
  Sort descending. Defaults to `true`.

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "total": 2,
        "page": 1,
        "page_size": 15,
        "commits": [
            {
                "id": "commit_uuid",
                "folder_id": "folder_uuid",
                "parent_id": null,
                "message": "first commit",
                "author_id": "user_uuid",
                "file_count": 3,
                "create_time": 1718200000000
            }
        ]
    }
}
```

---

### Get commit

**GET** `/api/v1/workspaces/{workspace_id}/commits/{commit_id}`

Retrieves the details of a specific commit, including its file changes. Also available at:
- `/api/v1/datasets/{dataset_id}/commits/{commit_id}`

#### Request

- Method: GET
- URL: `/api/v1/workspaces/{workspace_id}/commits/{commit_id}`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request GET \
     --url http://{address}/api/v1/workspaces/{workspace_id}/commits/{commit_id} \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Path parameters

- `"workspace_id"`: `string`, *Required*
  The workspace ID.
- `"commit_id"`: `string`, *Required*
  The commit ID.

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "id": "commit_uuid",
        "folder_id": "folder_uuid",
        "parent_id": null,
        "message": "added config files",
        "author_id": "user_uuid",
        "file_count": 2,
        "create_time": 1718200000000,
        "files": [
            {
                "file_id": "file_uuid",
                "operation": "add",
                "old_hash": null,
                "new_hash": "abcd1234",
                "old_name": null,
                "new_name": null
            }
        ]
    }
}
```

Failure:

```json
{
    "code": 102,
    "message": "Commit not found in workspace"
}
```

---

### List commit files

**GET** `/api/v1/workspaces/{workspace_id}/commits/{commit_id}/files`

Lists the file changes associated with a specific commit. Also available at:
- `/api/v1/datasets/{dataset_id}/commits/{commit_id}/files`

#### Request

- Method: GET
- URL: `/api/v1/workspaces/{workspace_id}/commits/{commit_id}/files`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request GET \
     --url http://{address}/api/v1/workspaces/{workspace_id}/commits/{commit_id}/files \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

#### Response

Success:

```json
{
    "code": 0,
    "data": [
        {
            "id": "item_uuid",
            "file_id": "file_uuid",
            "operation": "add",
            "old_hash": null,
            "new_hash": "abcd1234",
            "old_location": null,
            "new_location": ".objects/abcd1234",
            "old_name": null,
            "new_name": null
        }
    ]
}
```

---

### Diff commits

**GET** `/api/v1/workspaces/{workspace_id}/commits/diff?from={commit_id}&to={commit_id}`

Compares two commits and returns the differences. Also available at:
- `/api/v1/datasets/{dataset_id}/commits/diff?from=...&to=...`

#### Request

- Method: GET
- URL: `/api/v1/workspaces/{workspace_id}/commits/diff`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Query:
  - `'from'`: `string` (required)
    The source commit ID.
  - `'to'`: `string` (required)
    The target commit ID.

##### Request example

```bash
curl --request GET \
     --url 'http://{address}/api/v1/workspaces/{workspace_id}/commits/diff?from=from_commit_id&to=to_commit_id' \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Query parameters

- `"from"`: `string`, *Required*
  The source commit ID.
- `"to"`: `string`, *Required*
  The target commit ID.

#### Response

Success:

```json
{
    "code": 0,
    "data": [
        {
            "file_id": "file_uuid",
            "file_name": "config.json",
            "operation": "modify",
            "old_hash": "abc123",
            "new_hash": "def456",
            "old_location": ".objects/abc123",
            "new_location": ".objects/def456"
        }
    ]
}
```

Failure:

```json
{
    "code": 102,
    "message": "Commit not found in workspace"
}
```

---

### Get uncommitted changes

**GET** `/api/v1/workspaces/{workspace_id}/changes`

Returns the uncommitted changes for the specified folder (similar to `git status`). Also available at:
- `/api/v1/datasets/{dataset_id}/changes`

#### Request

- Method: GET
- URL: `/api/v1/workspaces/{workspace_id}/changes`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request GET \
     --url http://{address}/api/v1/workspaces/{workspace_id}/changes \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

#### Response

Success:

```json
{
    "code": 0,
    "data": [
        {
            "file_id": "file_uuid",
            "file_name": "new.txt",
            "operation": "add"
        },
        {
            "file_id": "file_uuid",
            "file_name": "config.json",
            "operation": "modify"
        },
        {
            "file_id": "file_uuid",
            "file_name": "old.md",
            "operation": "delete"
        }
    ]
}
```

---

### Get commit tree

**GET** `/api/v1/workspaces/{workspace_id}/commits/{commit_id}/tree`

Retrieves the full folder tree snapshot as it existed at a specific commit. Also available at:
- `/api/v1/datasets/{dataset_id}/commits/{commit_id}/tree`

#### Request

- Method: GET
- URL: `/api/v1/workspaces/{workspace_id}/commits/{commit_id}/tree`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request GET \
     --url http://{address}/api/v1/workspaces/{workspace_id}/commits/{commit_id}/tree \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "id": "folder_uuid",
        "name": "workspace_name",
        "type": "folder",
        "children": [
            {
                "id": "file_uuid",
                "name": "config.json",
                "type": "file",
                "hash": "abcd1234",
                "size": 1024,
                "status": "1",
                "location": ".objects/abcd1234"
            },
            {
                "id": "sub_folder_uuid",
                "name": "sub_folder_name",
                "type": "folder",
                "children": [
                    {
                        "id": "file_uuid_2",
                        "name": "nested.txt",
                        "type": "file",
                        "hash": "ef5678",
                        "size": 512,
                        "status": "1",
                        "location": ".objects/ef5678"
                    }
                ]
            }
        ]
    }
}
```

---

### Get commit file content

**GET** `/api/v1/workspaces/{workspace_id}/commits/{commit_id}/files/{file_id}/content`

Retrieves the file content as it existed at a specific commit. Also available at:
- `/api/v1/datasets/{dataset_id}/commits/{commit_id}/files/{file_id}/content`

#### Request

- Method: GET
- URL: `/api/v1/workspaces/{workspace_id}/commits/{commit_id}/files/{file_id}/content`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request GET \
     --url http://{address}/api/v1/workspaces/{workspace_id}/commits/{commit_id}/files/{file_id}/content \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "content": "file content as it existed in that commit"
    }
}
```

Failure:

```json
{
    "code": 102,
    "message": "File not found in this commit"
}
```

---

### Get a workspace file version history

**GET** `/api/v1/workspace-files/{file_id}/versions`

Returns the version history for a specific file across all commits.

#### Request

- Method: GET
- URL: `/api/v1/workspace-files/{file_id}/versions`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request GET \
     --url http://{address}/api/v1/workspace-files/{file_id}/versions \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

#### Response

Success:

```json
{
    "code": 0,
    "data": [
        {
            "commit_id": "commit_uuid",
            "operation": "modify",
            "hash": "def456",
            "create_time": 1718200000000,
            "message": "updated file"
        },
        {
            "commit_id": "commit_uuid",
            "operation": "add",
            "hash": "abc123",
            "create_time": 1718100000000,
            "message": "initial commit"
        }
    ]
}
```

---

## SEARCH APP MANAGEMENT

### Create search app

**POST** `/api/v1/searches`

Creates a search app.

#### Request

- Method: POST
- URL: `/api/v1/searches`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:

```json
{
    "name": "my_search_app",
    "description": "optional description"
}
```

##### Request example

```bash
curl --request POST \
     --url 'http://{address}/api/v1/searches' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --header 'Content-Type: application/json' \
     --data '{
         "name": "my_search_app",
         "description": "My first search app"
     }'
```

##### Body parameters

- `"name"`: `string`, *Required*
  The name of the search app. Must be unique and no longer than 255 characters.
- `"description"`: `string`
  A brief description of the search app.

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "search_id": "b330ec2e91ec11efbc510242ac120006"
    }
}
```

Failure:

```json
{
    "code": 102,
    "message": "Search name can't be empty."
}
```

---

### List search apps

**GET** `/api/v1/searches?keywords={keywords}&page={page}&page_size={page_size}&orderby={orderby}&desc={desc}&sort={sort}&owner_ids={owner_ids}`

Lists search apps for the current user.

#### Request

- Method: GET
- URL: `/api/v1/searches?keywords={keywords}&page={page}&page_size={page_size}&orderby={orderby}&desc={desc}&sort={sort}&owner_ids={owner_ids}`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request GET \
     --url 'http://{address}/api/v1/searches?page=1&page_size=20' \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Query parameters

- `keywords`: `string`
  Search keyword to filter search apps by name.
- `page`: `integer`
  Specifies the page number. Defaults to `1`. Values less than `1` fall back to `1`.
- `page_size`: `integer`
  The number of items per page. Defaults to `30`. Values less than `1` fall back to `30`. The maximum value is `100`.
- `orderby`: `string`
  The field to sort by. Defaults to `create_time`.
- `desc`: `boolean`
  Whether to sort in descending order. Defaults to `true`.
- `sort`: `string`
  Orders by several fields at once, written as `column:direction` terms separated by commas, such as `name:asc,create_time:desc`. A term with no direction is ascending. `sort` takes precedence over `orderby` and `desc`, which keep working on their own. A term naming a field this list does not sort by is skipped. When `sort` yields no terms at all, `orderby` and `desc` decide the order. When it yields terms whose fields are all skipped, the result is ordered by `create_time` in the direction of the first term, and the older pair is not read.
- `owner_ids`: `string` (repeatable)
  Filter by owner tenant IDs. Can be specified multiple times: `?owner_ids=id1&owner_ids=id2`.

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "total": 2,
        "search_apps": [
            {
                "id": "b330ec2e91ec11efbc510242ac120006",
                "name": "my_search_app",
                "description": "My first search app",
                "tenant_id": "7c8983badede11f083f184ba59bc53c7",
                "create_time": 1729763127646
            }
        ]
    }
}
```

---

### Get search app

**GET** `/api/v1/searches/{search_id}`

Gets the details of a search app.

#### Request

- Method: GET
- URL: `/api/v1/searches/{search_id}`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request GET \
     --url 'http://{address}/api/v1/searches/b330ec2e91ec11efbc510242ac120006' \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Path parameters

- `search_id`: `string`, *Required*
  The ID of the search app to retrieve.

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "id": "b330ec2e91ec11efbc510242ac120006",
        "name": "my_search_app",
        "description": "My first search app",
        "tenant_id": "7c8983badede11f083f184ba59bc53c7",
        "search_config": {},
        "create_time": 1729763127646
    }
}
```

Failure:

```json
{
    "code": 102,
    "message": "Can't find this Search App!"
}
```

---

### Update search app

**PUT** `/api/v1/searches/{search_id}`

Updates a search app.

#### Request

- Method: PUT
- URL: `/api/v1/searches/{search_id}`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_API_KEY>'`
- Body:

```json
{
    "name": "updated_name",
    "search_config": {"top_k": 5}
}
```

##### Request example

```bash
curl --request PUT \
     --url 'http://{address}/api/v1/searches/b330ec2e91ec11efbc510242ac120006' \
     --header 'Authorization: Bearer <YOUR_API_KEY>' \
     --header 'Content-Type: application/json' \
     --data '{
         "name": "updated_name",
         "search_config": {"top_k": 5}
     }'
```

##### Request parameters

- `search_id`: (*Path parameter*), `string`, *Required*
  The ID of the search app to update.
- `"name"`: (*Body parameter*), `string`, *Required*
  The new name of the search app.
- `"search_config"`: (*Body parameter*), `object`, *Required*
  Configuration fields to update. Merged with the existing config.

#### Response

Success:

```json
{
    "code": 0,
    "data": {
        "id": "b330ec2e91ec11efbc510242ac120006",
        "name": "updated_name",
        "search_config": {"top_k": 5},
        "create_time": 1729763127646
    }
}
```

Failure:

```json
{
    "code": 109,
    "message": "no authorization"
}
```

---

### Delete search app

**DELETE** `/api/v1/searches/{search_id}`

Deletes a search app.

#### Request

- Method: DELETE
- URL: `/api/v1/searches/{search_id}`
- Headers:
  - `'Authorization: Bearer <YOUR_API_KEY>'`

##### Request example

```bash
curl --request DELETE \
     --url 'http://{address}/api/v1/searches/b330ec2e91ec11efbc510242ac120006' \
     --header 'Authorization: Bearer <YOUR_API_KEY>'
```

##### Path parameters

- `search_id`: `string`, *Required*
  The ID of the search app to delete.

#### Response

Success:

```json
{
    "code": 0,
    "data": true
}
```

Failure:

```json
{
    "code": 109,
    "message": "no authorization"
}
```

---

### Search completion

**POST** `/api/v1/searches/{search_id}/completions`

Generates an answer using the saved search app configuration and returns the result as a Server-Sent Events stream.

#### Request

- Method: POST
- URL: `/api/v1/searches/{search_id}/completions`
- Headers:
  - `'Content-Type: application/json'`
  - `'Authorization: Bearer <YOUR_LOGIN_TOKEN>'`
- Body:
  - `"question"`: `string` *(Required)* The user question.
  - `"kb_ids"`: `list[string]` *(Optional)* Fallback dataset IDs. Used only when the search app config does not already define `kb_ids`.

##### Request example

```bash
curl --request POST \
     --url http://{address}/api/v1/searches/{search_id}/completions \
     --header 'Content-Type: application/json' \
     --header 'Authorization: Bearer <YOUR_LOGIN_TOKEN>' \
     --data '{
         "question": "What is retrieval-augmented generation?"
     }'
```

##### Request parameters

- `search_id`: (*Path parameter*), `string`, *Required*
  The ID of the search app.
- `"question"`: (*Body parameter*), `string`, *Required*
  The user question.
- `"kb_ids"`: (*Body parameter*), `list[string]`
  Optional fallback dataset IDs when the search app config does not define them.

#### Response

Success (streaming):

```text
data: {"code": 0, "message": "success", "data": {"answer": "...", "reference": {...}}}

data: {"code": 0, "message": "success", "data": true}
```

Failure:

```json
{
    "code": 109,
    "message": "no authorization"
}
```
