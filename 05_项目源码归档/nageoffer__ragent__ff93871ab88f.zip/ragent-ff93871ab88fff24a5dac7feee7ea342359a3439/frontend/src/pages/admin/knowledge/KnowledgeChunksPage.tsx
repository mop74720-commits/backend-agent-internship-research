import { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { CircleHelp, PenSquare, Plus, RefreshCw, ShieldCheck, ShieldX, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { RelativeTime } from "@/components/RelativeTime";

import type { KnowledgeChunk, KnowledgeDocument, PageResult } from "@/services/knowledgeService";
import {
  batchToggleChunks,
  createChunk,
  deleteChunk,
  toggleChunk,
  getChunksPage,
  getDocument,
  getKnowledgeBase,
  updateChunk
} from "@/services/knowledgeService";
import { getErrorMessage } from "@/utils/error";

const PAGE_SIZE = 10;

const truncateText = (value?: string | null, max = 120) => {
  if (!value) return "-";
  if (value.length <= max) return value;
  return `${value.slice(0, max)}...`;
};

const enabledLabel = (enabled?: number | null) => (enabled === 1 ? "启用" : "禁用");

export function KnowledgeChunksPage() {
  const { kbId, docId } = useParams();
  const navigate = useNavigate();
  const [doc, setDoc] = useState<KnowledgeDocument | null>(null);
  const [kbName, setKbName] = useState("");
  const [pageData, setPageData] = useState<PageResult<KnowledgeChunk> | null>(null);
  const [pageNo, setPageNo] = useState(1);
  const [loading, setLoading] = useState(false);
  const [enabledFilter, setEnabledFilter] = useState<number | undefined>();
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [createOpen, setCreateOpen] = useState(false);
  const [editDialog, setEditDialog] = useState<{ open: boolean; chunk: KnowledgeChunk | null }>({
    open: false,
    chunk: null
  });
  const [deleteTarget, setDeleteTarget] = useState<KnowledgeChunk | null>(null);
  const chunks = pageData?.records || [];

  const selectedList = useMemo(() => Array.from(selectedIds), [selectedIds]);

  const loadDocument = useCallback(async () => {
    if (!docId) return;
    try {
      const data = await getDocument(docId);
      setDoc(data);
    } catch (error) {
      toast.error(getErrorMessage(error, "加载文档失败"));
      console.error(error);
    }
  }, [docId]);

  const loadChunks = useCallback(async (current = pageNo, enabled = enabledFilter) => {
    if (!docId) return;
    setLoading(true);
    try {
      const data = await getChunksPage(docId, {
        current,
        size: PAGE_SIZE,
        enabled
      });
      setPageData(data);
    } catch (error) {
      toast.error(getErrorMessage(error, "加载分块失败"));
      console.error(error);
    } finally {
      setLoading(false);
    }
  }, [docId, enabledFilter, pageNo]);

  useEffect(() => {
    loadDocument();
  }, [loadDocument]);

  useEffect(() => {
    if (kbId) {
      getKnowledgeBase(kbId).then(kb => setKbName(kb.name)).catch(() => {});
    }
  }, [kbId]);

  useEffect(() => {
    loadChunks();
  }, [loadChunks]);

  useEffect(() => {
    setSelectedIds(new Set());
  }, [docId, enabledFilter]);

  const allSelected = chunks.length > 0 && chunks.every((chunk) => selectedIds.has(String(chunk.id)));

  const toggleSelectAll = () => {
    if (allSelected) {
      setSelectedIds(new Set());
      return;
    }
    const next = new Set(selectedIds);
    chunks.forEach((chunk) => next.add(String(chunk.id)));
    setSelectedIds(next);
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleBatchToggle = async (enabled: boolean) => {
    if (!docId) return;
    if (selectedList.length === 0) {
      toast.error("请选择需要操作的分块");
      return;
    }
    const targetValue = enabled ? 1 : 0;
    const selectedChunks = chunks.filter((c) => selectedList.includes(String(c.id)));
    const needChange = selectedChunks.some((c) => c.enabled !== targetValue);
    if (!needChange) {
      toast.info(enabled ? "所选分块已全部启用" : "所选分块已全部禁用");
      return;
    }
    try {
      await batchToggleChunks(docId, enabled, selectedList);
      toast.success(enabled ? "批量启用成功" : "批量禁用成功");
      setSelectedIds(new Set());
      await loadChunks(pageNo, enabledFilter);
    } catch (error) {
      toast.error(getErrorMessage(error, enabled ? "批量启用失败" : "批量禁用失败"));
      console.error(error);
    }
  };

  const handleDelete = async () => {
    if (!docId || !deleteTarget) return;
    try {
      await deleteChunk(docId, String(deleteTarget.id));
      toast.success("删除成功");
      setDeleteTarget(null);
      await loadChunks(pageNo, enabledFilter);
    } catch (error) {
      toast.error(getErrorMessage(error, "删除失败"));
      console.error(error);
    }
  };

  const handleToggleEnabled = async (chunk: KnowledgeChunk) => {
    if (!docId) return;
    try {
      const enable = chunk.enabled !== 1;
      await toggleChunk(docId, String(chunk.id), enable);
      toast.success(enable ? "已启用" : "已禁用");
      await loadChunks(pageNo, enabledFilter);
    } catch (error) {
      toast.error(getErrorMessage(error, "操作失败"));
      console.error(error);
    }
  };

  return (
    <div className="admin-page">
      <div className="admin-page-header">
        <div>
          <h1 className="admin-page-title">分块管理</h1>
          <p className="admin-page-subtitle">
            {doc?.docName || docId} {kbName ? `（知识库: ${kbName}）` : ""}
          </p>
        </div>
        <div className="admin-page-actions">
          <Button variant="outline" onClick={() => navigate(-1)}>
            返回文档
          </Button>
          <Button className="admin-primary-gradient" onClick={() => setCreateOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            新建分块
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <CardTitle>Chunk 列表</CardTitle>
              <CardDescription>支持编辑、启停、批量操作</CardDescription>
            </div>
            <div className="flex flex-1 flex-wrap items-center justify-end gap-2">
              <Select
                value={enabledFilter === undefined ? "all" : String(enabledFilter)}
                onValueChange={(value) => {
                  setPageNo(1);
                  setEnabledFilter(value === "all" ? undefined : Number(value));
                }}
              >
                <SelectTrigger className="w-[160px]">
                  <SelectValue placeholder="启用状态" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部状态</SelectItem>
                  <SelectItem value="1">启用</SelectItem>
                  <SelectItem value="0">禁用</SelectItem>
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                onClick={() => {
                  setPageNo(1);
                  loadChunks(1, enabledFilter);
                }}
              >
                <RefreshCw className="mr-2 h-4 w-4" />
                刷新
              </Button>
              <Button variant="outline" onClick={() => handleBatchToggle(true)} disabled={selectedList.length === 0}>
                <ShieldCheck className="mr-2 h-4 w-4" />
                批量启用
              </Button>
              <Button variant="outline" onClick={() => handleBatchToggle(false)} disabled={selectedList.length === 0}>
                <ShieldX className="mr-2 h-4 w-4" />
                批量禁用
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="py-8 text-center text-muted-foreground">加载中...</div>
          ) : chunks.length === 0 ? (
            <div className="py-8 text-center text-muted-foreground">暂无分块</div>
          ) : (
            <Table className="min-w-[960px]">
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[48px]">
                    <input type="checkbox" checked={allSelected} onChange={toggleSelectAll} />
                  </TableHead>
                  <TableHead className="w-[70px]">序号</TableHead>
                  <TableHead>内容</TableHead>
                  <TableHead className="w-[90px]">状态</TableHead>
                  <TableHead className="w-[90px]">字符数</TableHead>
                  <TableHead className="w-[90px]">
                    <span className="inline-flex items-center gap-1">
                      Token
                      <TooltipProvider delayDuration={0}>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <CircleHelp className="h-3.5 w-3.5 text-muted-foreground" />
                          </TooltipTrigger>
                          <TooltipContent side="top">
                            <span className="text-xs font-normal">预估Token数，仅提供参考</span>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </span>
                  </TableHead>
                  <TableHead className="w-[170px]">更新时间</TableHead>
                  <TableHead className="w-[140px] text-left">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {chunks.map((chunk) => (
                  <TableRow key={chunk.id}>
                    <TableCell>
                      <input
                        type="checkbox"
                        checked={selectedIds.has(String(chunk.id))}
                        onChange={() => toggleSelect(String(chunk.id))}
                      />
                    </TableCell>
                    <TableCell>{chunk.chunkIndex ?? "-"}</TableCell>
                    <TableCell className="max-w-[360px] text-sm text-muted-foreground break-all">
                      {truncateText(chunk.content)}
                    </TableCell>
                    <TableCell>
                      <Badge variant={chunk.enabled === 1 ? "default" : "outline"}>
                        {enabledLabel(chunk.enabled)}
                      </Badge>
                    </TableCell>
                    <TableCell>{chunk.charCount ?? "-"}</TableCell>
                    <TableCell>{chunk.tokenCount ?? "-"}</TableCell>
                    <TableCell><RelativeTime value={chunk.updateTime} /></TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button size="sm" variant="outline" onClick={() => setEditDialog({ open: true, chunk })}>
                          <PenSquare className="mr-0.1 h-4 w-4" />
                          编辑
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => handleToggleEnabled(chunk)}>
                          {chunk.enabled === 1 ? "禁用" : "启用"}
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-destructive hover:text-destructive"
                          onClick={() => setDeleteTarget(chunk)}
                        >
                          <Trash2 className="mr-0.1 h-4 w-4" />
                          删除
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}

          {pageData ? (
            <div className="mt-4 flex flex-wrap items-center justify-between gap-2 text-sm text-slate-500">
              <span>共 {pageData.total} 条</span>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={() => setPageNo((prev) => Math.max(1, prev - 1))} disabled={pageData.current <= 1}>
                  上一页
                </Button>
                <span>
                  {pageData.current} / {pageData.pages}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setPageNo((prev) => Math.min(pageData.pages || 1, prev + 1))}
                  disabled={pageData.current >= pageData.pages}
                >
                  下一页
                </Button>
              </div>
            </div>
          ) : null}
        </CardContent>
      </Card>

      <ChunkDialog
        mode="create"
        open={createOpen}
        onOpenChange={setCreateOpen}
        onSubmit={async (payload) => {
          if (!docId) return;
          await createChunk(docId, { content: payload.content, index: payload.index });
          toast.success("创建成功");
          setCreateOpen(false);
          await loadChunks(pageNo, enabledFilter);
        }}
      />

      <ChunkDialog
        mode="edit"
        open={editDialog.open}
        chunk={editDialog.chunk}
        onOpenChange={(open) => setEditDialog({ open, chunk: open ? editDialog.chunk : null })}
        onSubmit={async (payload) => {
          if (!docId || !editDialog.chunk) return;
          await updateChunk(docId, String(editDialog.chunk.id), { content: payload.content });
          toast.success("更新成功");
          setEditDialog({ open: false, chunk: null });
          await loadChunks(pageNo, enabledFilter);
        }}
      />

      <AlertDialog open={Boolean(deleteTarget)} onOpenChange={(open) => (!open ? setDeleteTarget(null) : null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除分块？</AlertDialogTitle>
            <AlertDialogDescription>该分块将被删除且向量会清理。</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">
              删除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

    </div>
  );
}

interface ChunkDialogProps {
  mode: "create" | "edit";
  open: boolean;
  chunk?: KnowledgeChunk | null;
  onOpenChange: (open: boolean) => void;
  onSubmit: (payload: { content: string; index?: number | null }) => Promise<void>;
}

function ChunkDialog({ mode, open, chunk, onOpenChange, onSubmit }: ChunkDialogProps) {
  const [content, setContent] = useState("");
  const [chunkIndex, setChunkIndex] = useState<string>("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    if (mode === "edit") {
      setContent(chunk?.content || "");
      setChunkIndex("");
      return;
    }
    setContent("");
    setChunkIndex("");
  }, [open, mode, chunk]);

  const handleSubmit = async () => {
    const trimmed = content.trim();
    if (!trimmed) {
      toast.error("请输入内容");
      return;
    }

    const indexValue = chunkIndex.trim() === "" ? null : Number(chunkIndex);
    if (chunkIndex.trim() !== "" && (Number.isNaN(indexValue) || !Number.isInteger(indexValue) || (indexValue as number) < 0)) {
      toast.error("序号必须为非负整数");
      return;
    }

    setSaving(true);
    try {
      await onSubmit({ content: trimmed, index: indexValue });
    } catch (error) {
      toast.error(getErrorMessage(error, mode === "create" ? "创建失败" : "更新失败"));
      console.error(error);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="sm:max-w-[760px] overflow-hidden flex flex-col max-h-[85vh]"
        onOpenAutoFocus={(e) => e.preventDefault()}
        onCloseAutoFocus={(e) => { e.preventDefault(); requestAnimationFrame(() => (document.activeElement as HTMLElement)?.blur()); }}
      >
        <DialogHeader>
          <DialogTitle>{mode === "create" ? "新建分块" : "编辑分块"}</DialogTitle>
          <DialogDescription>手动维护分块内容</DialogDescription>
        </DialogHeader>
        <div className="flex flex-1 flex-col gap-4 overflow-y-auto px-2 pb-3 sidebar-scroll">
          {mode === "create" && (
            <div className="flex items-baseline gap-3 pt-1">
              <label className="shrink-0 text-sm font-medium">序号</label>
              <Input
                type="number"
                min={0}
                step={1}
                placeholder="0、1..."
                className="[appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none h-8 w-24"
                value={chunkIndex}
                onChange={(e) => setChunkIndex(e.target.value)}
              />
              <span className="text-xs text-muted-foreground">留空则自动追加到末尾</span>
            </div>
          )}
          <div className="flex min-h-0 flex-1 flex-col">
            <label className="text-sm font-medium">内容</label>
            <Textarea
              className="mt-2 flex-1 min-h-[280px] resize-none chunk-editor-textarea"
              value={content}
              onChange={(event) => setContent(event.target.value)}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
            取消
          </Button>
          <Button onClick={handleSubmit} disabled={saving}>
            {saving ? "保存中..." : "保存"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
