/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.nageoffer.ai.ragent.infra.chat;

import com.nageoffer.ai.ragent.framework.convention.GroundingChunk;
import com.nageoffer.ai.ragent.framework.convention.SourceRef;

import java.util.List;

/**
 * 流式响应回调接口（StreamCallback）
 * <p>
 * 用途说明：
 * - 用于处理大模型（LLM）或 RAG 系统的流式输出
 * - 在模型生成回答过程中，会多次触发 onContent() 推送增量内容
 * - 回答结束时触发 onComplete()，出现异常时触发 onError()
 * <p>
 * 使用场景：
 * - SSE / WebSocket 流式响应
 * - 后端对接本地大模型（如 Ollama、DeepSeek、Qwen）的流式推送
 * - 前端实时渲染消息、流式拼接回答
 * <p>
 * 注意事项：
 * - onContent() 调用次数不定，由模型输出节奏决定
 * - onComplete() 必须保证在正常结束时调用一次
 * - onError() 应当捕获所有异常，避免影响客户端体验
 */
public interface StreamCallback {

    /**
     * 记录当前回答对应的用户消息 ID
     *
     * @param messageId 用户消息 ID
     */
    default void onReplyToMessageId(String messageId) {
    }

    /**
     * 接收一次增量内容（Delta Token 或部分片段）
     * <p>
     * 说明：
     * - 模型推送的每一段内容都会通过该方法回调
     * - 内容可能为字符、单词、句子，取决于模型分片策略
     * <p>
     * 示例：
     * onContent("你好");
     * onContent("，我可以帮你解答问题");
     *
     * @param content 当前推送的增量内容（非完整回答）
     */
    void onContent(String content);

    /**
     * 接收思考过程增量内容（如果模型支持）
     * <p>
     * 默认空实现，未支持思考的场景可以忽略
     *
     * @param content 当前推送的思考内容
     */
    default void onThinking(String content) {
    }

    /**
     * 接收回答来源（文档级）
     * <p>
     * 检索完成后回调一次 由实现方暂存 随完成事件（onComplete）一并下发 默认空实现
     *
     * @param sources 文档级来源列表
     */
    default void onSources(List<SourceRef> sources) {
    }

    /**
     * 接收推荐问题 grounding 片段
     * <p>
     * 检索完成后回调一次 由实现方暂存 随 assistant 消息一并落库 供后续推荐追问生成 grounding 默认空实现
     *
     * @param chunks grounding 片段列表
     */
    default void onGroundingChunks(List<GroundingChunk> chunks) {
    }

    /**
     * 整个推理流程结束（全部内容推送完毕）
     * <p>
     * 用途：
     * - 通知上层进行 UI 收尾动作，如：停止 loading、滚动到底部、拼接完整回答等
     * - 确保在所有 onContent() 调用完成后触发
     */
    void onComplete();

    /**
     * 流式推送过程中出现异常
     * <p>
     * 常见场景：
     * - 模型内部错误
     * - 网络中断
     * - 超时
     * - 解析异常
     *
     * @param error 异常对象，包含具体错误信息
     */
    void onError(Throwable error);
}
