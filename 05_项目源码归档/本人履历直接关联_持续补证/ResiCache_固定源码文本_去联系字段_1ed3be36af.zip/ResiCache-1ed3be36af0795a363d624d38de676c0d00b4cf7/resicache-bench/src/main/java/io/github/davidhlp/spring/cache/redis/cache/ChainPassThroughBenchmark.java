package io.github.davidhlp.spring.cache.redis.cache;

import io.github.davidhlp.spring.cache.redis.chain.CacheHandler;
import io.github.davidhlp.spring.cache.redis.chain.CacheOperation;
import io.github.davidhlp.spring.cache.redis.chain.HandlerResult;
import io.github.davidhlp.spring.cache.redis.chain.model.CacheContext;
import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.infra.Blackhole;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/**
 * Benchmark: Chain pass-through vs direct ConcurrentHashMap lookup.
 *
 * <p>Measures the baseline execution overhead of ResiCache's {@link ChainEngine}
 * pass-through against direct method execution and direct map lookup, without Spring AOP or Redis I/O.
 */
@BenchmarkMode(Mode.Throughput)
@OutputTimeUnit(TimeUnit.SECONDS)
@State(Scope.Benchmark)
@Warmup(iterations = 3, time = 1)
@Measurement(iterations = 5, time = 1)
@Fork(1)
public class ChainPassThroughBenchmark {

    private ChainEngine engine;
    private CacheHandlerChain facade;
    private CacheContext sampleContext;
    private List<CacheHandler> passthroughChain;
    private List<CacheHandler> mutableBaseline;
    private Map<String, Object> mapBaseline;
    private static final String KEY = "order:1001";
    private static final String VALUE = "order-payload-data";

    private static class PassthroughHandler implements CacheHandler {
        @Override
        public HandlerResult handle(CacheContext context) {
            return HandlerResult.continueChain();
        }
    }

    @Setup(Level.Trial)
    public void setup() {
        engine = new ChainEngine();
        sampleContext = CacheContext.of(CacheInput.builder()
                .operation(CacheOperation.GET)
                .cacheName("orders")
                .redisKey(KEY)
                .actualKey(KEY)
                .build());
        passthroughChain = List.of(new PassthroughHandler());
        facade = new CacheHandlerChain(engine).addHandler(passthroughChain.get(0));
        mutableBaseline = new java.util.ArrayList<>(passthroughChain);
        mapBaseline = new ConcurrentHashMap<>();
        mapBaseline.put(KEY, VALUE);
    }

    /** Current facade reuses its published immutable handler list. */
    @Benchmark
    public Object immutableFacade() {
        return facade.execute(sampleContext);
    }

    /** Former facade path: take the mutation lock and copy a mutable list per call. */
    @Benchmark
    public Object copiedFacadeBaseline() {
        List<CacheHandler> snapshot;
        synchronized (this) {
            snapshot = List.copyOf(mutableBaseline);
        }
        return engine.execute(snapshot, sampleContext);
    }

    /**
     * Baseline 1: Direct method invocation (zero caching overhead).
     */
    @Benchmark
    public Object directInvocation() {
        return VALUE;
    }

    /**
     * Baseline 2: Direct ConcurrentHashMap lookup.
     */
    @Benchmark
    public Object concurrentMapLookup() {
        return mapBaseline.get(KEY);
    }

    /**
     * ResiCache: ChainEngine pass-through overhead (1 no-op passthrough handler).
     */
    @Benchmark
    public void chainPassThrough(Blackhole bh) {
        bh.consume(engine.execute(passthroughChain, sampleContext));
    }
}
