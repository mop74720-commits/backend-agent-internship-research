package io.github.davidhlp.spring.cache.redis.cache;






import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Redis缓存注册器配置.
 *
 * <p>负责缓存操作注册器的bean配置和缓存操作元数据管理.
 */
@Slf4j
@Configuration(proxyBeanMethods = false)
class RedisCacheRegistryConfiguration {

    /**
     * 创建 RedisCacheRegister 实例.
     *
     * @return RedisCacheRegister 实例
     */
    @Bean
    @ConditionalOnMissingBean
    public RedisCacheRegister redisCacheRegister() {
        log.debug("Created RedisCacheRegister for cache operation registry");
        return new RedisCacheRegister();
    }
}
