package io.github.davidhlp.spring.cache.redis.cache;

import io.micrometer.core.instrument.MeterRegistry;
import jakarta.annotation.PreDestroy;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import lombok.extern.slf4j.Slf4j;
import org.springframework.lang.NonNull;

/**
 * Internal bounded refresh executor with per-key deduplication and bounded retries.
 * Completed and cancelled futures remove themselves from the in-flight index;
 * no periodic scheduler is needed. Cancellation is best-effort and does not
 * promise interruption of the runnable. Shutdown waits for accepted work.
 */
@Slf4j
class ThreadPoolEarlyExpirationExecutor implements RefreshCancellation {

    private final ExecutorService executorService;
    private final ConcurrentHashMap<String, CompletableFuture<Void>> inFlight;
    private static final String THREAD_NAME_PREFIX = "early-expiration-";

    private final RefreshRetryPolicy retryPolicy;
    private final RefreshTaskMetrics metrics;

    /**
     * 默认构造函数（测试 / 无配置 fallback）：硬编码 {@code 2/10/100} 池参数。
     *
     * <p>生产装配走 {@link io.github.davidhlp.spring.cache.redis.cache.RedisProCacheConfiguration#earlyExpirationExecutor}
     * {@code @Bean}，从 {@code resi-cache.early-expiration.*} properties 读池参数。
     */
    public ThreadPoolEarlyExpirationExecutor() {
        this(2, 10, 100, null);
    }

    /**
     * 配置化构造（生产 {@code @Bean} 主路径）：用 {@code resi-cache.early-expiration}
     * 池参数创建线程池。
     *
     * @param corePoolSize   核心线程数
     * @param maxPoolSize    最大线程数
     * @param queueCapacity  任务队列容量
     * @param meterRegistry  Micrometer registry（可选，为 {@code null} 时不注册指标）
     */
    public ThreadPoolEarlyExpirationExecutor(int corePoolSize, int maxPoolSize, int queueCapacity, MeterRegistry meterRegistry) {
        this(createExecutor(corePoolSize, maxPoolSize, queueCapacity),
             new ConcurrentHashMap<>(), meterRegistry);
    }

    /**
     * 构造函数，允许注入自定义的执行器服务和进行中的任务映射（测试主路径：直接控制
     * {@code ExecutorService} / {@code inFlight}，绕开配置化构造）。
     *
     * @param executorService 线程池执行器服务
     * @param inFlight        正在进行中的任务映射
     * @param meterRegistry   Micrometer meter注册表（可选，为null时不注册指标）
     */
    ThreadPoolEarlyExpirationExecutor(
            ExecutorService executorService,
            ConcurrentHashMap<String, CompletableFuture<Void>> inFlight,
            MeterRegistry meterRegistry) {
        this.executorService = executorService;
        this.inFlight = inFlight;
        this.retryPolicy = new RefreshRetryPolicy();

        try {
            // 初始化 Micrometer 指标（注册逻辑收敛于 RefreshTaskMetrics）
            this.metrics = new RefreshTaskMetrics(meterRegistry, inFlight, executorService);
            // 从实际 executor 读取打印，避免日志撒谎
            String poolDesc = (executorService instanceof ThreadPoolExecutor tpe)
                    ? "core=" + tpe.getCorePoolSize() + ", max=" + tpe.getMaximumPoolSize()
                    : executorService.getClass().getSimpleName();
            log.info("ThreadPoolEarlyExpirationExecutor initialized: {}, maxRetries={}",
                    poolDesc, RefreshRetryPolicy.MAX_RETRY_COUNT);
        } catch (RuntimeException e) {
            // 初始化失败时，确保清理已创建的资源
            executorService.shutdownNow();
            throw e;
        }
    }

    /**
     * 创建线程池执行器（池容量由调用方传入）。
     *
     * @param corePoolSize   核心线程数
     * @param maxPoolSize    最大线程数
     * @param queueCapacity  任务队列容量
     * @return 配置好的线程池执行器
     */
    private static ExecutorService createExecutor(int corePoolSize, int maxPoolSize, int queueCapacity) {
        return new ThreadPoolExecutor(
                corePoolSize,
                maxPoolSize,
                60L,
                TimeUnit.SECONDS,
                new LinkedBlockingQueue<>(queueCapacity),
                new EarlyExpirationThreadFactory(),
                new ThreadPoolExecutor.CallerRunsPolicy());
    }

    /**
     * 提交一个提前过期任务到执行器中
     * 如果给定键的任务已经在执行中，则跳过提交
     *
     * @param key  与提前过期任务关联的键
     * @param task 要执行的提前过期任务
     */
    public void submit(String key, Runnable task) {
        if (key == null || task == null) {
            return;
        }
        AtomicBoolean scheduled = new AtomicBoolean(false);

        // A completion callback may still be pending when the next submission arrives.
        inFlight.computeIfPresent(key, (k, existing) -> existing.isDone() ? null : existing);

        CompletableFuture<Void> future =
                inFlight.computeIfAbsent(
                        key,
                        k -> {
                            scheduled.set(true);
                            return CompletableFuture.runAsync(
                                    () -> retryPolicy.executeWithRetry(k, task),
                                    executorService);
                        });

        if (scheduled.get()) {
            metrics.recordSubmitted();
            // Register only after publication: CallerRunsPolicy can complete
            // inline, and removing inside computeIfAbsent is a recursive update.
            future.whenComplete((result, throwable) -> {
                inFlight.remove(key, future);
                metrics.recordCompleted();
                if (throwable != null) {
                    FailureReport.error(log, "Async early-expiration failed after all retries",
                            null, key, throwable);
                }
            });
        }
        if (!scheduled.get() && !future.isDone()) {
            log.debug("Key {} is already being refreshed, skipping", key);
        }
    }

    /**
     * 取消与给定键关联的提前过期任务
     *
     * @param key 要取消的提前过期任务的键
     */
    @Override
    public void cancel(String key) {
        if (key == null) {
            return;
        }
        CompletableFuture<Void> future = inFlight.remove(key);
        if (future != null) {
            metrics.recordCancelled();
            boolean cancelled = future.cancel(true);
            log.debug(
                    "Cancelled async early-expiration for key: {} (cancelled={}, done={})",
                    key,
                    cancelled,
                    future.isDone());
        }
    }

    /**
     * 获取当前正在进行的提前过期任务数量
     *
     * @return 正在进行的任务数量
     */
    public int getActiveCount() {
        return inFlight.size();
    }

    /**
     * 关闭执行器，释放所有资源
     * 此方法在应用关闭时自动调用
     */
    @PreDestroy
    public void shutdown() {
        log.info("Shutting down early-expiration executor thread pool...");
        shutdownGracefully(executorService, 10, "Pre-refresh executor");
        // Drop completed entries after pool shutdown as a final cleanup pass.
        inFlight.entrySet().removeIf(e -> e.getValue() == null || e.getValue().isDone());
    }

    /**
     * 优雅关闭单个 ExecutorService：先 {@code shutdown()} 拒收新任务，等待已有任务在
     * {@code timeoutSeconds} 内结束；超时则 {@code shutdownNow()} 强制中断，中断期间同样强制关闭。
     *
     * @param executor       待关闭的执行器
     * @param timeoutSeconds 优雅等待超时（秒）
     * @param name           日志中标识该执行器的名称
     */
    private void shutdownGracefully(ExecutorService executor, long timeoutSeconds, String name) {
        executor.shutdown();
        try {
            if (!executor.awaitTermination(timeoutSeconds, TimeUnit.SECONDS)) {
                executor.shutdownNow();
                log.warn("{} did not terminate gracefully, forced shutdown", name);
            } else {
                log.info("{} shut down successfully", name);
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
            Thread.currentThread().interrupt();
            log.error("{} shutdown interrupted", name, e);
        }
    }

    /**
     * 为提前过期线程创建命名线程的工厂类
     */
    private static final class EarlyExpirationThreadFactory implements ThreadFactory {
        private final AtomicInteger threadNumber = new AtomicInteger(1);

        /**
         * 创建一个新的提前过期线程
         *
         * @param r 线程要执行的任务
         * @return 配置好的线程实例
         */
        @Override
        public Thread newThread(@NonNull Runnable r) {
            Thread thread = new Thread(r, THREAD_NAME_PREFIX + threadNumber.getAndIncrement());
            thread.setDaemon(true);
            thread.setPriority(Thread.NORM_PRIORITY);
            return thread;
        }
    }
}
