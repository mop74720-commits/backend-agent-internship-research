/**
 * 缓存处理器责任链包（Chain of Responsibility Pattern）
 *
 * <h2>设计模式</h2>
 * <ul>
 *   <li><b>责任链模式</b>：将缓存操作拆分为多个独立的处理器，每个处理器负责特定功能</li>
 *   <li><b>策略模式</b>：每个处理器内部使用策略模式处理不同的操作类型</li>
 * </ul>
 *
 * <h2>责任链顺序</h2>
 * <pre>
 * CacheOperation Request
 *     ↓
 * 1. BloomFilterHandler    - 布隆过滤器检查（防止缓存穿透）
 *     ↓
 * 2. SyncLockHandler          - 同步锁处理（防止缓存击穿）
 *     ↓
 * 3. EarlyExpirationHandler   - 热点 Key 提前异步刷新
 *     ↓
 * 4. TtlHandler               - TTL 计算和配置
 *     ↓
 * 5. NullValueHandler         - 空值处理
 *     ↓
 * 6. {@link io.github.davidhlp.spring.cache.redis.cache.ActualCacheHandler}
 *                              - 实际缓存操作
 *     ↓
 * CacheResult
 * </pre>
 *
 * <h2>核心类说明</h2>
 * <ul>
 *   <li><b>CacheHandler</b>：处理器接口（{@code handle(context)} 为主契约;引擎另调
 *       {@code handle(context, ChainContinuation)}，其 default 忽略句柄并委派前者）</li>
 *   <li><b>ChainContinuation</b>：引擎交给当前节点的「推进剩余链」句柄 —— 需要在自己的
 *       临界区内跑完后继的 handler（如 {@code sync=true} 的分布式锁内推进）用它，
 *       否则链推进完全由 Engine 承担</li>
 *   <li><b>AbstractCacheHandler</b>：抽象处理器，handle 退化为
 *       {@code shouldHandle ? doHandle : continueChain}（链推进由 Engine 承担）</li>
 *   <li><b>CacheHandlerChain</b>：责任链 facade —— 维护 handler 列表 + 委派
 *       {@code execute} 到 {@link io.github.davidhlp.spring.cache.redis.cache.ChainEngine}</li>
 *   <li><b>CacheHandlerChainFactory</b>：责任链工厂 —— 自动发现 + 排序 + 过滤 +
 *       装配 + 注册 4 个标准 {@link io.github.davidhlp.spring.cache.redis.chain.observer.ChainObserver}</li>
 *   <li><b>ChainEngine</b>：责任链推进引擎 —— 节点推进 + decision switch +
 *       观测编排 + post-process 的单一 seam</li>
 *   <li><b>ChainObserver</b>：观测注入点 —— aroundChain + perNode 四钩子 default no-op</li>
 *   <li><b>CacheContext</b>：上下文对象，贯穿整个责任链</li>
 *   <li><b>CacheResult</b>：结果对象</li>
 *   <li><b>CacheOperation</b>：操作类型枚举</li>
 * </ul>
 *
 * <h2>设计优势</h2>
 * <ul>
 *   <li>单一职责：每个处理器只负责一个功能</li>
 *   <li>开闭原则：可以轻松添加新的处理器而不修改现有代码</li>
 *   <li>可测试性：每个处理器可以独立测试</li>
 *   <li>灵活性：可以动态组合不同的处理器</li>
 *   <li>可维护性：代码结构清晰，易于理解和维护</li>
 * </ul>
 *
 * <h2>使用示例</h2>
 * <pre>{@code
 * // 创建责任链
 * CacheHandlerChain chain = chainFactory.createChain();
 *
 * // 构建上下文
 * CacheContext context = CacheContext.of(CacheInput.builder()
 *     .operation(CacheOperation.GET)
 *     .cacheName("user")
 *     .redisKey("user::123")
 *     .build());
 *
 * // 执行责任链
 * CacheResult result = chain.execute(context);
 * }</pre>
 *
 * @author David
 * @version 2.0
 * @since 2.0
 */
package io.github.davidhlp.spring.cache.redis.chain;
