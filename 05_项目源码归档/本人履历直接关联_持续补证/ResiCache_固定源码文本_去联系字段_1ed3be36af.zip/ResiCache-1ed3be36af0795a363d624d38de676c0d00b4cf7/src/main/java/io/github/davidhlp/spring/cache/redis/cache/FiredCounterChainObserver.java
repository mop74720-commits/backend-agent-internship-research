package io.github.davidhlp.spring.cache.redis.cache;

import io.github.davidhlp.spring.cache.redis.chain.CacheHandler;
import io.github.davidhlp.spring.cache.redis.chain.model.CacheContext;
import io.github.davidhlp.spring.cache.redis.chain.observer.ChainObserver;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import org.springframework.core.annotation.Order;

/**
 * ChainObserver 的 perNode 实现 — per-handler uniform {@code resicache.handler.fired}
 * counter（handler tag = 运行时子类 SimpleName；cardinality bounded = handler 类数）。
 *
 * <p>本类把 fired counter 的"装配 + 自增"收口
 * 到单一 observer，{@code AbstractCacheHandler} 只保留子类的语义 counter
 * 注册钩子（{@code onAttachMetrics}）。
 *
 * <p>disabled handler 语义 counter 不注册；fired 与语义
 * counter 都在 handler 进链时统一注册。registry 由 {@link ResolvedMetrics} 单一决议、
 * 永不为 null；metrics 未启用时它是 no-op seam，本 observer 无副作用。
 *
 * <p>per-handler span child 可在本类的 {@code afterNode} 内挂载，
 * 零修改 Engine 即可与本 counter 同步打点。
 *
 * <p>线程安全：counter map 用 {@link ConcurrentHashMap}（lazy register 时多个
 * handler 类型竞争同 observer）；{@link Counter#increment()} 自身线程安全。
 */
@Order(4) // 执行顺序单一真值源=类级 @Order,见 MDCStampChainObserver 注释
final class FiredCounterChainObserver implements ChainObserver {

    private final MeterRegistry registry;
    /** 关闭路径唯一判据 —— 构造期从 seam 推导一次。 */
    private final boolean disabled;
    /** handler 类 → fired counter；同名同 tag 重复 register 幂等，故 map 仅按 type 持有。 */
    private final ConcurrentMap<Class<? extends CacheHandler>, Counter> firedCounters = new ConcurrentHashMap<>();

    public FiredCounterChainObserver(MeterRegistry registry) {
        this.registry = registry;
        this.disabled = MetricsWriter.disabled(registry);
    }

    @Override
    public Object onChainStart(CacheContext context) {
        // Counter 延迟到 afterNode 首次见到 handler 类时再注册（lazy），不在 start 时预热
        // —— onChainStart 拿不到 handler 列表（Engine 设计上不让 observer 接触 handlers 列表）
        // 本 observer 无 per-call 状态(per-handler counter 走 firedCounters map),
        // 返回 null token,onChainEnd 也走默认 no-op。
        return null;
    }

    @Override
    public void afterNode(CacheHandler handler, CacheContext context,
                          io.github.davidhlp.spring.cache.redis.chain.HandlerResult result) {
        if (disabled) {
            // 关闭路径:跳过 handlerLabel / ClassValue 查找、计数器注册、map 写入与 NoopCounter。
            return;
        }
        String handlerLabel = HandlerIdentity.of(handler).tag();
        Counter counter = firedCounters.computeIfAbsent(handler.getClass(), klass ->
                MetricsWriter.counter(registry, "resicache.handler.fired",
                        "Cache protection chain: number of times each handler was evaluated by the engine "
                                + "(per-handler observability; tag handler = runtime subclass simple name)",
                        "handler", handlerLabel));
        MetricsWriter.increment(counter);
    }

}
