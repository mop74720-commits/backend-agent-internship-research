package io.github.davidhlp.spring.cache.redis.cache;





import java.lang.reflect.Method;
import lombok.extern.slf4j.Slf4j;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.aop.support.AopUtils;
import org.springframework.cache.CacheManager;
import org.springframework.cache.interceptor.CacheInterceptor;
import org.springframework.cache.interceptor.CacheOperationSource;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.lang.Nullable;
/**
 * ResiCache 缓存拦截器 —— 单一 advice seam。
 *
 * <p>继承 Spring {@link CacheInterceptor} 以满足 {@code BeanFactoryCacheOperationSourceAdvisor}
 * 对 advice 的硬约束(Spring Cache 对 {@code CacheInterceptor} 子类有特殊处理:独立
 * {@code implements MethodInterceptor} 时 {@code @RedisCacheable} 装配会失效)。本类是 advisor
 * 直接持有的 advice —— 装配职责与拦截职责收口到同一处。
 *
 * <p>注解解析由 {@link RedisCacheOperationSource} 统一完成并写入
 * {@link RedisCacheRegister} 快照。
 *
 * <p><code>invoke()</code> 编排:
 * <ol>
 *   <li>reactive 返回类型({@code Mono}/{@code Flux})旁路 —— 不支持,直接 proceed</li>
 *   <li>{@link MethodMetadataResolver#activate} ThreadLocal 激活方法元数据(经 activate 进入作用域)</li>
 *   <li>{@code super.invoke} 触发 {@code CacheAspectSupport.execute} —— 链增强
 *       (Bloom/Sync/TTL/NullValue/ActualCache)由 {@code RedisProCacheWriter} 在
 *       cache.get/put/evict 路径触发</li>
 *   <li>{@code finally} 清除 ThreadLocal</li>
 * </ol>
 *
 * <p>构造期注入的 {@code cacheOperationSource}/{@code cacheManager}/{@code keyGenerator} 经
 * setter 落位后调用 {@code afterPropertiesSet()}。
 */
@Slf4j
class RedisCacheInterceptor extends CacheInterceptor {

    /** 方法元数据解析器 — ThreadLocal 边界 owner,interceptor 经 activate() 进入作用域 */
    private final MethodMetadataResolver methodMetadataResolver;

    /**
     * 构造 advice 并落位 Spring {@link CacheInterceptor} 依赖.
     *
     * @param cacheOperationSource    缓存操作源(注解解析入口)
     * @param cacheManager            缓存管理器
     * @param keyGenerator            键生成器
     * @param methodMetadataResolver  方法元数据解析器
     */
    public RedisCacheInterceptor(
            final CacheOperationSource cacheOperationSource,
            final CacheManager cacheManager,
            final KeyGenerator keyGenerator,
            final MethodMetadataResolver methodMetadataResolver) {
        this.methodMetadataResolver = methodMetadataResolver;
        setCacheOperationSource(cacheOperationSource);
        setCacheManager(cacheManager);
        setKeyGenerator(keyGenerator);
        afterPropertiesSet();
        log.debug("RedisCacheInterceptor initialized as Path C advice "
                + "(metadata resolver wired, deps injected)");
    }

    @Override
    @Nullable
    public Object invoke(final MethodInvocation invocation) throws Throwable {
        Method method = invocation.getMethod();
        Object target = invocation.getThis();
        org.springframework.util.Assert.state(target != null, "Target object must not be null");

        Class<?> targetClass = target.getClass();
        method = AopUtils.getMostSpecificMethod(method, targetClass);

        if (isReactiveType(method.getReturnType().getName())) {
            log.warn("Reactive return type {} on [{}.{}] is not supported — bypassing cache",
                    method.getReturnType().getName(), method.getDeclaringClass().getName(), method.getName());
            return invocation.proceed();
        }

        // 经 resolver.activate() 进入方法元数据作用域(try-with-resources 自动 restore),
        // 与 async 路径(writer runWithSnapshot)对称
        try (ScopedActivation ignored = methodMetadataResolver.activate(method, targetClass)) {
            return super.invoke(invocation);
        }
    }

    static boolean isReactiveType(String typeName) {
        return "reactor.core.publisher.Mono".equals(typeName)
                || "reactor.core.publisher.Flux".equals(typeName);
    }
}
