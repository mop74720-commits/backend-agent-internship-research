package io.github.davidhlp.spring.cache.redis.cache;







import io.github.davidhlp.spring.cache.redis.chain.CacheHandler;
import io.github.davidhlp.spring.cache.redis.chain.HandlerOrder;
import io.github.davidhlp.spring.cache.redis.chain.observer.ChainObserver;
import io.github.davidhlp.spring.cache.redis.config.RedisProCacheProperties;
import io.micrometer.core.instrument.MeterRegistry;
import java.util.*;
import java.util.function.Function;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 缓存处理器责任链工厂。
 *
 * <p>职责:自动发现 / 排序 / 过滤 / 构建 / 装配 metric + 按需注册 {@link ChainObserver}
 * 到 {@link ChainEngine}：
 *
 * <ol>
 *   <li>{@link MDCStampChainObserver} — 无 registry 依赖，必注册</li>
 *   <li>{@link ChainDebugLogChainObserver} — 无 registry 依赖，必注册</li>
 *   <li>{@link ChainTimerChainObserver} — registry 缺失时全 no-op，仍注册</li>
 *   <li>{@link FiredCounterChainObserver} — registry 缺失时全 no-op，仍注册</li>
 * </ol>
 *
 * <p>observer 装配时机：首次 {@link #createChain} 调时。ChainHandlerChain
 * 自身不持有 metric 状态，所有 per-handler / per-chain 观测收口到 Engine 的
 * observer 列表。Timer 在节点 around-hook 中记录 handler + decision + cacheName。
 *
 * <p>设计要点：
 * <ul>
 *   <li>观测逻辑全部在 {@link ChainEngine} 单一 seam，由本工厂统一装配 4 个
 *       observer，Engine / handler 子类零感知</li>
 *   <li>新增观测维度(如 OTel/Span)只需新增 {@code SpanObserver},Engine / handler
 *       子类零修改</li>
 * </ul>
 */
@Slf4j
@Component
class CacheHandlerChainFactory {

    /** 自动注入所有 CacheHandler 实现 */
    private final List<CacheHandler> handlers;

    /** 配置属性 */
    private final RedisProCacheProperties properties;

    /** Resolved metrics choice for chain observers and handlers. */
    private final ResolvedMetrics resolvedMetrics;

    /** 推进引擎 — 由 Spring 注入，工厂首次 createChain 时注册 observer 并装配链。 */
    private final ChainEngine engine;

    /**
     * 4 个可禁用防护机制 toggle 单一事实源 — 新增第 5 个机制时仅追加一行。
     *
     * <p>注意:不含 TTL — {@code TtlHandler} 兼担基础 TTL 计算,禁用会导致
     * {@code ActualCacheHandler} 写入无 TTL 永久缓存(数据陈旧 + 内存泄漏)。
     *
     * <p>每条 toggle 两要素:{@code order} 字段(既是短路枚举,又是 disableName 的派生源 ——
     * 绑定属性使用 {@code resi-cache.protection.<disableName>-enabled}
     * (如 {@code bloom-filter-enabled}),与 {@code HandlerOrder#getDisableName()} 对应)、
     * {@code getter} 字段(per-mechanism 覆盖读取,null = 继承 enabled)。
     * {@code ProtectionToggleGuardTest} 用反射按 disableName 反查 property 并断言 getter
     * 读的正是该 property,故新增机制漏配属性时直接红。
     */
    private static final List<Toggle> PROTECTION_TOGGLES = List.of(
            new Toggle(HandlerOrder.BLOOM_FILTER,
                    RedisProCacheProperties.ProtectionProperties::getBloomFilterEnabled),
            new Toggle(HandlerOrder.SYNC_LOCK,
                    RedisProCacheProperties.ProtectionProperties::getSyncLockEnabled),
            new Toggle(HandlerOrder.EARLY_EXPIRATION,
                    RedisProCacheProperties.ProtectionProperties::getEarlyExpirationEnabled),
            new Toggle(HandlerOrder.NULL_VALUE,
                    RedisProCacheProperties.ProtectionProperties::getNullValueEnabled));

    /**
     * 单条 protection 机制 toggle 描述 —— 机制身份({@link HandlerOrder})与其属性读取器
     * ({@link RedisProCacheProperties.ProtectionProperties} 上对应的 {@code *Enabled} 字段)。
     *
     * <p>configuration path 不再单独持有:它由 {@link HandlerOrder#getDisableName()} 派生
     * (两者曾经是同一字面量的两份拷贝)。
     *
     * @param order  防护机制对应的 {@link HandlerOrder}(disableName 的真值源)
     * @param getter 从 {@link RedisProCacheProperties.ProtectionProperties} 读取
     *               Boolean 字段(null = 继承 enabled,非 null = 单独覆盖)
     */
    record Toggle(
            HandlerOrder order,
            Function<RedisProCacheProperties.ProtectionProperties, Boolean> getter) {
    }

    /**
     * 只读快照 —— 供 {@code ProtectionToggleGuardTest} 校验「表 ↔ 绑定属性」一致。
     * 生产代码无需读取(禁用解析已内联)。
     */
    static List<Toggle> protectionToggles() {
        return PROTECTION_TOGGLES;
    }

    /**
     * 主构造 — P1-API-001-C:注入有序 {@link ChainObserver} beans 单一装配。
     * {@code @Autowired} 使 Spring 在多个 public 构造器间选择本构造
     * (无默认构造器时必须有显式 @Autowired)。
     */
    @org.springframework.beans.factory.annotation.Autowired
    public CacheHandlerChainFactory(List<CacheHandler> handlers,
                                 RedisProCacheProperties properties,
                                 ResolvedMetrics resolvedMetrics,
                                 ChainEngine engine,
                                 List<ChainObserver> observers) {
        this.handlers = handlers;
        this.properties = properties;
        this.resolvedMetrics = resolvedMetrics;
        this.engine = engine;
        this.observers = observers == null ? List.of() : observers;
    }

    /** 缓存的责任链实例（单例，避免 handler 列表被并发重建） */
    private volatile CacheHandlerChain cachedChain;

    /**
     * Ordered ChainObserver beans — 标准(MDC/DebugLog/Timer/FiredCounter)与用户
     * observer 均为 Spring Bean,经 {@code List<ChainObserver>} 注入(P1-API-001-C)。
     * 用户只需声明 {@code ChainObserver} Bean 即被自动装配;顺序由 {@code @Order} 决定。
     */
    private final List<ChainObserver> observers;

    /**
     * 创建或获取责任链（单例模式，确保 observer 注册与链构建仅执行一次）。
     *
     * <p>首次调用时：
     * <ol>
     *   <li>注册注入的 ChainObserver 列表到 Engine(MDC / DebugLog / Timer /
     *       FiredCounter + 用户 observer;按 {@code @Order} 排序,按类型去重)</li>
     *   <li>按 {@code @HandlerPriority} 排序 + 过滤禁用 + 构建链 + 注入 registry</li>
     *   <li>委派给 {@link CacheHandlerChain}</li>
     * </ol>
     *
     * @return 配置好的责任链
     */
    public CacheHandlerChain createChain() {
        if (cachedChain != null) {
            return cachedChain;
        }

        synchronized (this) {
            if (cachedChain != null) {
                return cachedChain;
            }

            // 1) 装配 observer(单一装配点):注册序即派发序,注入列表由 Spring 按其支持的
            //    顺序来源排好(@Order、Ordered、@Bean 方法注解、元注解/代理),本工厂不再
            //    二次排序 —— 实例级比较器只看得到类级注解,会把 Spring 认得而它看不到的
            //    顺序(如 @Bean 方法上的 @Order(0))丢掉。
            //    idempotent 由本方法的单例缓存 miss pattern 保证,首次 miss 后不会再进本块。
            registerObserversOnce();

            // 2) 构建链
            CacheHandlerChain chain = new CacheHandlerChain(engine);

            // 为每个 enabled AbstractCacheHandler 注入已解析的 registry
            MeterRegistry registry = resolvedMetrics.meterRegistry();

            // 3) 收集禁用集合 — 用户自定义 disabled + 总开关 + per-mechanism 覆盖
            // null-safe:测试用 mock/stub 的 properties 可能不设 protection,默认视为开启
            Set<String> disabled = new HashSet<>(properties.getDisabledHandlers());
            resolveProtectionDisabled(properties, disabled);

            // 按 @HandlerPriority 注解排序(身份三项的解析见 HandlerIdentity)
            List<CacheHandler> sortedHandlers = handlers.stream()
                .sorted(Comparator.comparingInt(handler -> HandlerIdentity.of(handler).order()))
                .toList();

            // 添加到链，过滤禁用的 Handler
            for (CacheHandler handler : sortedHandlers) {
                HandlerIdentity identity = HandlerIdentity.of(handler);

                if (disabled.contains(identity.disableName())) {
                    log.info("Handler disabled by configuration: {}", identity.tag());
                    continue;
                }

                chain.addHandler(handler);
                if (handler instanceof MetricAttachable metricAttachable) {
                    metricAttachable.attachMeterRegistry(registry);
                }
                log.debug("Added handler to chain: {} (order={})",
                          identity.tag(),
                          identity.order());
            }

            log.info("Handler chain created with {} handlers: {}",
                     chain.size(), chain.getHandlerNames());

            cachedChain = chain;
            return cachedChain;
        }
    }

    /**
     * 注册注入的 observer 到 Engine — 单一装配点。
     *
     * <p>注册顺序即 {@code STABILITY.md §4} 承诺的 observer 执行顺序,也就是 Spring 解析
     * 注入列表时给出的顺序(observation order = registration order)。标准
     * MDC→DebugLog→Timer→FiredCounter 由各 observer 类级 {@code @Order(1..4)} 声明,Spring
     * 与用户 observer 的其他顺序来源({@code Ordered}、{@code @Bean} 方法上的 {@code @Order}、
     * 元注解/代理)同样由 Spring 解析 —— 工厂因此保持注入序,不再按类级注解二次排序。按类型
     * 去重(同名同 tag counter 重复注册幂等,但 observer 实例重复注册会双计 — 去重保证
     * 每个 observer 类恰好注册一次),随后按序 addObserver。
     *
     * <p>registry 缺失时:MDC/DebugLog 无 registry 依赖;Timer/FiredCounter
     * observer 内部 lazy 检测,registry 缺失时全 no-op。
     */
    private void registerObserversOnce() {
        Set<Class<?>> seen = new HashSet<>();
        for (ChainObserver observer : observers) {
            if (observer == null || !seen.add(observer.getClass())) {
                continue;
            }
            engine.addObserver(observer);
            log.debug("Registered ChainObserver: {}", observer.getClass().getSimpleName());
        }
    }

    /**
     * 解析 protection 机制禁用集合 — 处理两条独立路径,追加到 {@code disabled} 集合:
     * <ul>
     *   <li>总开关 {@code protection.enabled=false} → 全 4 个防护 handler 短路</li>
     *   <li>per-mechanism 字段为 {@link Boolean#FALSE} → 单独覆盖该机制</li>
     * </ul>
     *
     * <p>输入 {@code disabled} 可含调用方已有的其他禁用项(自定义 handler),本方法
     * 仅追加,不动既有项。无 protection 配置(测试 mock)时默认视为开启 — 不追加任何禁用项。
     */
    private static void resolveProtectionDisabled(RedisProCacheProperties properties, Set<String> disabled) {
        RedisProCacheProperties.ProtectionProperties protection =
                properties == null ? null : properties.getProtection();
        if (protection == null) {
            return;
        }

        if (!protection.isEnabled()) {
            // 总开关关闭:从单一 PROTECTION_TOGGLES 列表派生 4 个 disableName,避免平行列表漂移
            PROTECTION_TOGGLES.stream()
                    .map(toggle -> toggle.order().getDisableName())
                    .forEach(disabled::add);
            log.info("Protection chain disabled by resi-cache.protection.enabled=false; "
                    + "protection handlers skipped, TTL preserved (bloom/lock/early-exp/null-value off)");
        } else {
            // per-mechanism 覆盖:遍历单一 PROTECTION_TOGGLES 列表,把显式 FALSE 的加到 disabled
            // Boolean.FALSE.equals(null) → false(null 表示"继承 enabled")
            for (Toggle toggle : PROTECTION_TOGGLES) {
                if (Boolean.FALSE.equals(toggle.getter().apply(protection))) {
                    disabled.add(toggle.order().getDisableName());
                    log.info("{} disabled by resi-cache.protection.{}.enabled=false",
                            toggle.order().getDescription(), toggle.order().getDisableName());
                }
            }
        }
    }
}
