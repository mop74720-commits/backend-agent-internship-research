package io.github.davidhlp.spring.cache.redis.cache;






import io.github.davidhlp.spring.cache.redis.config.RedisProCacheProperties;
import io.github.davidhlp.spring.cache.redis.protection.bloom.filter.BloomIFilter;
import java.time.Clock;
import java.util.HashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cache.CacheManager;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.cache.interceptor.SimpleKeyGenerator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.redis.cache.CacheStatisticsCollector;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

@Slf4j
@Configuration(proxyBeanMethods = false)
@Import({
        // 显式导入:ResolvedMetricsConfiguration 不是扫描候选,RedisProxyCachingConfiguration
        // 必须在不做内部包扫描的上下文里同样完成装配。
        ResolvedMetricsConfiguration.class,
        RedisProxyCachingConfiguration.class
})
@EnableConfigurationProperties(RedisProCacheProperties.class)
class RedisProCacheConfiguration {

    /**
     * 标准 ChainObserver beans — P1-API-001-C:标准和用户 observer 均为有序 Bean,
     * 由 {@link CacheHandlerChainFactory} 单一装配点注入 Engine。
     *
     * <p>执行顺序(MDC → DebugLog → Timer → FiredCounter)由 observer 类自身的
     * {@code @Order} 单一声明(见各 observer 类),Spring 注入列表时据此排序,工厂保持
     * 注入序,故 bean 方法不再重复声明。用户 observer 用 {@code Ordered} 或 {@code @Bean}
     * 方法上的 {@code @Order} 表达的顺序同样生效。MDC 先 stamp,DEBUG log 再读 requestId,
     * Timer/FiredCounter 最后打点。registry 由 {@link ResolvedMetrics} 单一决议;
     * metrics 未启用时它是 no-op seam,Timer/FiredCounter observer 照常装配。
     */
    @Bean
    public io.github.davidhlp.spring.cache.redis.cache.MDCStampChainObserver mdcStampChainObserver() {
        return new io.github.davidhlp.spring.cache.redis.cache.MDCStampChainObserver();
    }

    @Bean
    public io.github.davidhlp.spring.cache.redis.cache.ChainDebugLogChainObserver chainDebugLogChainObserver() {
        return new io.github.davidhlp.spring.cache.redis.cache.ChainDebugLogChainObserver();
    }

    @Bean
    public io.github.davidhlp.spring.cache.redis.cache.ChainTimerChainObserver chainTimerChainObserver(
            ResolvedMetrics resolvedMetrics) {
        return new io.github.davidhlp.spring.cache.redis.cache.ChainTimerChainObserver(
                resolvedMetrics.meterRegistry());
    }

    @Bean
    public io.github.davidhlp.spring.cache.redis.cache.FiredCounterChainObserver firedCounterChainObserver(
            ResolvedMetrics resolvedMetrics) {
        return new io.github.davidhlp.spring.cache.redis.cache.FiredCounterChainObserver(
                resolvedMetrics.meterRegistry());
    }

    @Bean
    @ConditionalOnMissingBean(MethodMetadataResolver.class)
    public MethodMetadataResolver methodMetadataResolver() {
        return new DefaultMethodMetadataResolver();
    }

    @Bean
    @ConditionalOnMissingBean(CacheErrorHandler.class)
    public CacheErrorHandler cacheErrorHandler(ResolvedMetrics resolvedMetrics) {
        // Failure-metrics contract:统一失败指标 reporter;metrics 未启用时
        // ResolvedMetrics 交出 no-op seam,此处不再按 null 分支。
        return new CacheErrorHandler(
                new CacheFailureReporter(
                        resolvedMetrics.meterRegistry()));
    }

    @Bean
    @ConditionalOnMissingBean(CacheOperationResolver.class)
    public CacheOperationResolver cacheOperationResolver(
            MethodMetadataResolver methodMetadataResolver,
            io.github.davidhlp.spring.cache.redis.cache.RedisCacheRegister register) {
        return new CacheOperationResolver(methodMetadataResolver, register);
    }

    @Bean
    @ConditionalOnMissingBean(BloomFilterConfig.class)
    public BloomFilterConfig bloomFilterConfig(RedisProCacheProperties properties) {
        // P1-CONFIG-001:布隆参数收口到 properties 统一模型(绑定期已校验),
        // 取代散读 @Value(绕过统一校验模型)。
        RedisProCacheProperties.BloomProperties bloom = properties.getBloom();
        return new BloomFilterConfig(
                bloom.getPrefix(),
                bloom.getBitSize(),
                bloom.getHashFunctions(),
                bloom.getHashCacheSize());
    }


    /**
     * Default Bloom implementation is one explicitly composed adapter. A user
     * supplied BloomIFilter replaces the entire composition by type.
     */
    @Bean
    @ConditionalOnMissingBean(BloomIFilter.class)
    public BloomIFilter bloomIFilter(
            @Qualifier("redisCacheTemplate") RedisTemplate<String, Object> redisTemplate,
            BloomFilterConfig config,
            ResolvedMetrics resolvedMetrics) {
        LocalBloomIFilter local = new LocalBloomIFilter(config);
        RedisBloomIFilter remote = new RedisBloomIFilter(
                redisTemplate, config, resolvedMetrics.meterRegistry());
        remote.init();
        return new HierarchicalBloomIFilter(local, remote);
    }

    @Bean
    @ConditionalOnMissingBean
    public RedisProCacheWriter redisProCacheWriter(
            CacheValueCodec valueCodec,
            CacheHandlerChainFactory chainFactory,
            CacheStatisticsCollector cacheStatisticsCollector,
            CacheOperationResolver operationResolver) {
        RedisProCacheWriter writer = new RedisProCacheWriter(
                cacheStatisticsCollector,
                valueCodec,
                chainFactory,
                operationResolver);
        log.info("Created RedisProCacheWriter with handler chain pattern");
        return writer;
    }

    @Bean
    @ConditionalOnMissingBean(RedisCacheConfiguration.class)
    public RedisCacheConfiguration defaultRedisCacheConfiguration(
            com.fasterxml.jackson.databind.ObjectMapper objectMapper,
            RedisProCacheProperties properties,
            SecureJacksonSerializerFactory serializerFactory) {
        SecureJacksonRedisSerializer valueSerializer =
                serializerFactory.create(objectMapper, properties.getSerializer());

        RedisCacheConfiguration config = RedisCacheConfiguration.defaultCacheConfig()
                .entryTtl(properties.getDefaultTtl())
                .serializeKeysWith(org.springframework.data.redis.serializer.RedisSerializationContext.SerializationPair.fromSerializer(new StringRedisSerializer()))
                .serializeValuesWith(org.springframework.data.redis.serializer.RedisSerializationContext.SerializationPair.fromSerializer(valueSerializer));

        if (properties.getKeyPrefix() != null && !properties.getKeyPrefix().isEmpty()) {
            config = config.computePrefixWith(cacheName -> properties.getKeyPrefix() + cacheName + "::");
            log.debug("Applied global key prefix: {}", properties.getKeyPrefix());
        }

        log.debug("Created default RedisCacheConfiguration with TTL: {}", properties.getDefaultTtl());
        return config;
    }

    @Bean
    @ConditionalOnMissingBean(CacheManager.class)
    public RedisProCacheManager cacheManager(
            RedisProCacheWriter redisProCacheWriter,
            RedisCacheConfiguration defaultRedisCacheConfiguration,
            ResolvedMetrics resolvedMetrics,
            BloomSupport bloomSupport,
            CacheOperationResolver operationResolver,
            SyncSupport syncSupport,
            SyncLockTimeout syncLockTimeout,
            RedisProCacheProperties properties) {
        Map<String, RedisCacheConfiguration> initialCacheConfigurations =
                buildInitialCacheConfigurations(properties, defaultRedisCacheConfiguration);

        ResiCacheFeatures features = ResiCacheFeatures.builder()
                .meterRegistry(resolvedMetrics.meterRegistry())
                .bloomSupport(bloomSupport)
                .operationResolver(operationResolver)
                .syncSupport(syncSupport)
                .syncLockTimeout(syncLockTimeout)
                .build();

        return new RedisProCacheManager(
                redisProCacheWriter,
                defaultRedisCacheConfiguration,
                features,
                initialCacheConfigurations,
                properties.isTransactionAware());
    }

    private Map<String, RedisCacheConfiguration> buildInitialCacheConfigurations(
            RedisProCacheProperties properties,
            RedisCacheConfiguration defaultConfig) {
        Map<String, RedisCacheConfiguration> result = new HashMap<>();
        if (properties.getCaches() == null || properties.getCaches().isEmpty()) {
            return result;
        }

        for (Map.Entry<String, RedisProCacheProperties.CacheConfig> entry
                : properties.getCaches().entrySet()) {
            String cacheName = entry.getKey();
            RedisProCacheProperties.CacheConfig cacheConfig = entry.getValue();
            RedisCacheConfiguration config = defaultConfig;

            if (cacheConfig.getTtl() != null) {
                config = config.entryTtl(cacheConfig.getTtl());
            }
            if (cacheConfig.getKeyPrefix() != null && !cacheConfig.getKeyPrefix().isEmpty()) {
                config = config.computePrefixWith(name -> cacheConfig.getKeyPrefix() + name + "::");
            }
            if (Boolean.FALSE.equals(cacheConfig.getCacheNullValues())) {
                config = config.disableCachingNullValues();
            }

            result.put(cacheName, config);
        }
        return result;
    }

    @Bean
    @ConditionalOnMissingBean(KeyGenerator.class)
    public KeyGenerator keyGenerator() {
        return new SimpleKeyGenerator();
    }

    @Bean
    @ConditionalOnMissingBean
    public CacheStatisticsCollector cacheStatisticsCollector() {
        return CacheStatisticsCollector.create();
    }

    @Bean
    @ConditionalOnMissingBean
    public Clock systemClock() {
        return Clock.systemUTC();
    }

    @Bean
    @ConditionalOnMissingBean(ThreadPoolEarlyExpirationExecutor.class)
    public ThreadPoolEarlyExpirationExecutor earlyExpirationExecutor(
            RedisProCacheProperties properties,
            ResolvedMetrics resolvedMetrics) {
        RedisProCacheProperties.EarlyExpirationProperties ee = properties.getEarlyExpiration();
        return new ThreadPoolEarlyExpirationExecutor(
                ee.getPoolSize(),
                ee.getMaxPoolSize(),
                ee.getQueueCapacity(),
                resolvedMetrics.meterRegistry());
    }

}
