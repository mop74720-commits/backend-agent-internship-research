package io.github.davidhlp.spring.cache.redis.cache;

import io.github.davidhlp.spring.cache.redis.chain.CacheResult;
import io.github.davidhlp.spring.cache.redis.chain.model.CacheContext;
import io.github.davidhlp.spring.cache.redis.chain.observer.ChainObserver;
import java.util.concurrent.ThreadLocalRandom;
import org.slf4j.MDC;
import org.springframework.core.annotation.Order;

/**
 * ChainObserver 的 aroundChain 实现 — 在链入口为本次执行 stamp 唯一 requestId
 * 进 MDC，使一次 GET/PUT 内所有 handler 的 {@code [chain]} DEBUG 行可被同一
 * id 关联；链出口恢复调用方原值（不误清宿主线程其它 MDC key，如 traceId）。
 *
 * <p>本类拥有并维护 {@link #MDC_REQUEST_ID_KEY}：在 {@code onChainStart} 写入，
 * 在 {@code onChainEnd} 恢复调用方原值；{@link ChainDebugLogChainObserver} 随后在
 * {@code afterNode} 读取该 key。
 *
 * <p>requestId 生成用 {@link ThreadLocalRandom}（非 SecureRandom）—
 * 缓存热路径每次 GET/PUT 必经，规避熵竞争 / 潜在阻塞；64-bit 随机数对
 * DEBUG 日志关联已足够（碰撞概率可忽略）。无符号十六进制输出避免负值符号扩展噪音。
 *
 * <p>onChainStart 把"调用方原 requestId"
 * 装入 {@link MdcScope} record 返回,onChainEnd 接收该 token 恢复 MDC。
 * observer 状态机完全自承,CacheContext 不承担 stringly-typed 通用 attributes 袋。
 * Engine 不感知 token 内部协议 —— 跨 observer 不混淆,
 * 因为 Engine 按 observer 注册 index 配对回传。
 *
 * <p>线程安全：MDC 本身是 ThreadLocal，每次 execute 调用在调用方线程内做
 * snapshot/restore 配对，无共享状态。
 */
// 标准 observer 执行顺序由类级 @Order 单一拥有(MDC→DebugLog→Timer→FiredCounter):
// Spring 注入 observer 列表时按同一注解排序,工厂保持注入序 —— 故本 observer 先 stamp
// requestId,ChainDebugLogChainObserver 才能在 afterNode 读到 MDC 中的 id。
@Order(1)
final class MDCStampChainObserver implements ChainObserver {
    static final String MDC_REQUEST_ID_KEY = "requestId";

    @Override
    public Object onChainStart(CacheContext context) {
        // snapshot/restore：只动自己的 key，try/finally 在 onChainEnd 恢复调用方原值
        // （不调 MDC.clear() 误清宿主线程其它 MDC，如 traceId）。
        String previousRequestId = MDC.get(MDC_REQUEST_ID_KEY);
        MDC.put(MDC_REQUEST_ID_KEY, generateRequestId());
        // 把"原值"装入 MdcScope record 返回,Engine 在 onChainEnd 配对回传。
        return new MdcScope(previousRequestId);
    }

    @Override
    public void onChainEnd(CacheContext context, Object scopeToken, CacheResult result) {
        // Engine 按 observer index 严格配对回传,故 token 必然是本人 onChainStart 返回的
        // MdcScope(见 ChainObserver 的 scope token 机制说明)—— 协议保证的类型,
        // 不做防御性 instanceof 重检。token 为 null 仅当本人 onChainStart 抛异常
        // (Engine 不产生 token),此时无原值可恢复。
        if (scopeToken == null) {
            return;
        }
        MdcScope scope = (MdcScope) scopeToken;
        if (scope.previousRequestId() == null) {
            MDC.remove(MDC_REQUEST_ID_KEY);
        } else {
            MDC.put(MDC_REQUEST_ID_KEY, scope.previousRequestId());
        }
    }

    /**
     * 用 {@link ThreadLocalRandom} 而非 {@code UUID.randomUUID()}：
     * {@code execute} 是缓存热路径（每次 GET/PUT 必经），需规避
     * {@code SecureRandom} 的熵竞争 / 潜在阻塞；64-bit 随机数对 DEBUG
     * 日志关联已足够（碰撞概率可忽略）。无符号十六进制输出避免负值符号扩展噪音。
     */
    private static String generateRequestId() {
        return Long.toUnsignedString(ThreadLocalRandom.current().nextLong(), 16);
    }

    /**
     * MDC scope token — per-call 状态值对象.
     *
     * <p>本 record 由 {@link #onChainStart} 构造,持有调用方在
     * {@code onChainStart} 之前的 MDC requestId 值(可能为 null),由
     * {@link #onChainEnd} 读取并恢复。Engine 不感知 record 内容,仅按
     * observer 注册 index 配对回传。
     *
     * <p>本 record 是 observer 私有(本类嵌套):当前仅 MDCStampChainObserver 一个
     * 消费者,未达提升为顶层类型的必要性(YAGNI)。其他 observer 若需类似
     * scope token,各自定义私有 record 即可,跨 observer 不共享 token 协议。
     *
     * @param previousRequestId 调用方预设的 requestId;null 表示"无预设"
     */
    private record MdcScope(String previousRequestId) {
    }
}
