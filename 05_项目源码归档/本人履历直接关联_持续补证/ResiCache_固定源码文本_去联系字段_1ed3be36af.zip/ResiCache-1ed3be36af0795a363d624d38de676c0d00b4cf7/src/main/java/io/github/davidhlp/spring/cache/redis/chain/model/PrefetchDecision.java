package io.github.davidhlp.spring.cache.redis.chain.model;



import org.springframework.lang.Nullable;

/**
 * 预取/提前过期决策 — {@link io.github.davidhlp.spring.cache.redis.cache.EarlyExpirationHandler}
 * 写入、由 {@link io.github.davidhlp.spring.cache.redis.cache.ActualCacheHandler} 读取的
 * 类型化跨 handler 消息.
 *
 * <p>三个字段皆是 {@code EarlyExpirationHandler} 同一次 GET 预取 + 判定的产物,
 * 生产者/消费者一一对应,与 {@link TtlDecision} / {@link NullDecision} 同构。
 *
 * <p><b>字段关系(运行期典型,非编译期约束)</b>:
 * <ul>
 *   <li>生产者 {@code EarlyExpirationHandler.doHandle} 在缓存命中时构造完整三元组:
 *       {@code earlyExpirationSkipped} 由 {@code decision.needsRefresh() && decision.isSync()} 派生</li>
 *   <li>{@link #empty()} 表示 EarlyExpirationHandler 未触发(非 GET 或未启用),
 *       消费者 {@code ActualCacheHandler.handleGet} 据此回退原生 Redis GET</li>
 * </ul>
 *
 * @param earlyExpirationSkipped 是否跳过实际缓存读(同步提前过期)。消费者 {@code ActualCacheHandler}
 *                               仍会被引擎调用,只是其真实 Redis GET 被本标记短路并返回 miss(触发回源)
 * @param prefetchedValue        EarlyExpirationHandler 已预取的缓存值(供 ActualCacheHandler 复用,避免双重 GET)
 * @param decision               提前过期决策;{@code null} 表示未判定或未触发
 */
public record PrefetchDecision(
        boolean earlyExpirationSkipped,
        @Nullable Object prefetchedValue,
        @Nullable EarlyExpirationDecision decision) {

    /** 无预取(EarlyExpirationHandler 未触发或缓存未命中)。 */
    public static PrefetchDecision empty() {
        return new PrefetchDecision(false, null, null);
    }

    /** 仅"跳过实际缓存读"的形态(供测试与 sync 跳过路径构造);消费者据此返回 miss。 */
    public static PrefetchDecision skipped() {
        return new PrefetchDecision(true, null, null);
    }

    /** 完整决策形态。 */
    public static PrefetchDecision of(boolean earlyExpirationSkipped,
                                      @Nullable Object prefetchedValue,
                                      @Nullable EarlyExpirationDecision decision) {
        return new PrefetchDecision(earlyExpirationSkipped, prefetchedValue, decision);
    }
}
