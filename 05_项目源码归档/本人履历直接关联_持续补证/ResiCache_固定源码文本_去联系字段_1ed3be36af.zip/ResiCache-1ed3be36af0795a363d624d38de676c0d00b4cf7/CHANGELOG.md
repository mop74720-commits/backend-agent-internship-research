# Changelog

All notable changes to ResiCache are documented here. Format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/); the project uses
[Semantic Versioning](https://semver.org/spec/v2.0.0.html) with the
pre-1.0 caveat below.

While the version is `0.x`, behavior and APIs outside the surfaces explicitly
covered by [`STABILITY.md`](./STABILITY.md) may change in any release,
including patch releases. Breaking changes are marked with ⚠️ in this
changelog. The stable 0.x surfaces and their exceptions are defined by
`STABILITY.md`; do not use this general pre-1.0 caveat to override that
contract.

> No local `v1.0` release tag is treated as an API-stability baseline here.
> Maven Central publishes `io.github.davidhlp:ResiCache` 0.0.1–0.0.5, 0.0.7,
> and 3.2.4, but every version (verified 2026-09-05 from the published
> POMs) is from the earlier Boot 3.2.4 / Java 17 / Redisson 3.17.6 line.
> They are usable only for report-only compatibility analysis; no Boot 4 /
> Java 21 artifact exists yet, so a blocking compatibility gate waits for a
> same-line published artifact with matching tag provenance.

The source-cleanup section labelled `0.0.2` below is repository history, not a
release note for the historical Central artifact with the same version. Current
source changes remain unreleased; publication is tracked in
[`COMPATIBILITY.md`](COMPATIBILITY.md).

## [Unreleased] — current development

### Documentation

- Reconcile adoption, configuration fallback, explicit serializer allowlists,
  synchronization timeout, batch migration/rollback, test tooling and public
  surface descriptions against the current source and CI. Preserve historical
  benchmark scores while removing unsupported performance-SLO labels.

### CI/CD

- Validate the packaged-consumer JDK before building, resolve PATH Java shims,
  and reject missing explicitly supplied candidates. Consolidate documentation
  checks in one guard with canonical-owner and POM-derived version assertions.
- Document migration CLI preparation, sidecar namespace and recovery limits;
  clarify root-file tracking and redact configuration/debug input in bug reports.
- Share verification across PR/main/merge-group/manual/release workflows; fail
  closed on malformed job results or missing/skipped integration evidence.
- Reuse verified artifacts for packaged Boot consumers and benchmark smoke;
  add real Sentinel and TLS client smoke tests without changing runtime APIs.
- Add pinned workflow tooling, dependency differential checks and weekly security
  reports; prepare tag/POM/Changelog-validated Central publishing and recovery
  using the exact signed candidate bytes.

### Fixed

- Declare Micrometer Core as a runtime dependency so a minimal packaged Boot
  consumer can start without Actuator. Metrics publishing remains opt-in;
  Actuator and Redisson remain optional.

The project is on a **single build line**: Spring Boot
4.0 / SDR 4.0 / Spring 7 / Java 21 / Redisson 3.50.0. Dual-branch
(`master` / `boot4`) is abandoned; the current build line is `main` and Boot
4 is configured directly in `pom.xml`. See [`COMPATIBILITY.md`](./COMPATIBILITY.md).

Current milestones:

- **⚠️ TTL precision and overflow fix** — positive fractional Duration TTLs now
  round up to whole seconds instead of truncating (`500ms` → `1s`, `1500ms` →
  `2s`). Final annotation, parameter and jitter TTLs saturate at
  `Long.MAX_VALUE / 2000` seconds, reserving signed millisecond headroom for
  Redis's epoch clock as documented in the reference. Jitter arithmetic is
  overflow-safe; large TTLs no longer wrap into a one-second expiry or fail
  Spring's Duration-to-millisecond conversion. Annotation
  precedence and null/zero/negative permanent-cache semantics are preserved.
  Deterministic regression tests strengthen serialization whitelisting,
  independent writes, disabled metrics, Bloom collisions, refresh lifecycle,
  retries, context restoration, and local expiry. Fixes #39.

- **Native annotation correctness and internal cleanup** — adapted Spring PUT
  and EVICT now use Spring's concrete operation classes and update/delete the
  cache in FULL and SELECTIVE mixed modes. A host Jackson 2 mapper takes
  precedence over the dedicated fallback, avoiding same-name bean conflicts.
  Eviction no longer constructs unused chain policy; Bloom annotation sizing
  hints are explicitly compatibility-only. Typed annotation mapping, immutable
  chain snapshots, request policy reuse, typed method metadata, and completion cleanup remove unused data flows and per-execution work. The v2 byte shape,
  stored compatibility metadata, and annotation signatures remain unchanged.
  Envelope implementation ownership moves to `VersionEnvelope` behind the
  existing bridge; unused members/parser/loggers and the unreachable zero-port
  fallback are removed. Executor cancellation tests now assert the promised
  effects and consistently close fixtures. JMH names describe their measured
  scope and a serializer/storage round-trip benchmark covers multiple sizes.
- **⚠️ Internal hash bean cleanup** — the unconsumed standalone `hashOperations`
  bean is no longer supplied. Applications needing it can declare their own bean
  or use `redisCacheTemplate.opsForHash()`; template hash support is unchanged.

- **⚠️ Bound JDK legacy migration resources** — decoding now rejects streams
  over 16 MiB, graphs deeper than 64, more than 100,000 references, or arrays
  over 1,000,000 elements before allocation, while preserving the class
  whitelist and host input filter. Larger entries must be regenerated with
  the current serializer. Newly read strings are counted explicitly because
  JDK input-filter callbacks skip them. Lenient JSON deserialization logs only exception
  types at WARN; detailed exceptions remain at DEBUG.

- **⚠️ Early-expiration task failures now reach retries** — actual async
  value reads and TTL CAS failures use the executor's existing three-attempt
  retry path instead of being swallowed inside the task. Exhausted failures
  remain isolated from cache reads and use fingerprint-only diagnostics;
  `prerefresh.completed` retains its task-termination meaning. Completion
  callbacks now attach after future publication, so inline execution cannot
  lose completion metrics or terminal diagnostics to a recursive map update. Required
  feature collaborators now fail at feature construction, with absent metrics
  normalized to the shared disabled registry; no public surface changes.

- **Annotation compatibility members are explicit** — `RedisCacheEvict.unless`
  remains source/binary compatible but is not evaluated on the current Spring
  eviction path; `RedisCacheable.type` and `RedisCachePut.type` remain metadata
  without runtime coercion or validation. Activating either behavior requires a
  separate operation-semantics decision and regression contract.

- **Native writer statistics contract** — `RedisProCacheWriter` now records
  Spring Data Redis GET/GET-hit/GET-miss/PUT/DELETE counters at the writer
  boundary, including PUT_IF_ABSENT insertion and exact CLEAN deletion counts.
  `withStatisticsCollector` is coherent: replacing the collector does not leave
  Bloom/early-refresh handlers incrementing the previous collector. Lock-wait
  duration is intentionally not reported yet and remains zero.

### Interface contract closure
- ⚠️ **Cache failure contract closure** — GET degrades to an observable miss;
  PUT, PUT_IF_ABSENT, and CLEAN propagate a typed runtime failure retaining the
  original cause; REMOVE remains observable best-effort. Callers that relied
  on swallowed write failures must catch the runtime failure or pin the
  previous 0.x version before migrating.
- ⚠️ **Single-adapter policy seams retired** — `TtlPolicy`, `NullValuePolicy`,
  `EarlyExpirationPolicy`, and `BloomHashStrategy` are no longer replaceable
  beans; TTL, null-value, early-expiration, and Bloom hashing decisions now
  live in their owning modules. Users who supplied one of these internal beans
  must remove the override and use the owning module's configuration.
- **Explicit auto-configuration** — removed library-root component scanning,
  added typed default Bean back-off, and made `NullValueEncoder` the shared
  handler dependency.
- **Async metadata closure** — capture now occurs before queueing work; worker
  activation restores prior ThreadLocal/MDC state in `finally`.
- **Integration naming closure** — `*IT` classes use `*IntegrationTest` and
  Surefire is the only Maven test lifecycle.
- ⚠️ **Sync without distributed backend fails fast** — `SyncSupport`
  no longer silently degrades to a single-JVM `synchronized` when
  `sync=true` is declared but no `LockManager` bean exists. Set
  `resi-cache.sync-lock.local-only=true` for explicit single-instance
  degradation.
- ⚠️ **Bloom CLEAN semantics** — ordinary cache eviction no longer clears the
  Bloom filter or relies on a rebuilding marker/TTL window. Bloom bits describe
  possible data-source membership: false-positives are safe, but a missing
  membership bit can short-circuit Redis lookup and loader execution. Seed or
  maintain membership before enabling it for an existing data set.
- ⚠️ **Read-through is availability-first** — `get(key, loader)` (default and
   sync paths) always returns a successful loader value; a cache write-back
   failure after a successful load is logged (redacted, no raw key) and never
   overrides the value. Loader failures still surface as Spring
   `Cache.ValueRetrievalException`. Explicit PUT/PUT_IF_ABSENT/CLEAN remain
   fail-fast typed.
- **Redis Cluster distributed-lock hash-tag pinning** —
  `DistributedLockManager` ensures the lock key lands in the same Redis
  Cluster slot as the cache key (via `{...}` hash-tag), so the lock and
  the data it guards co-locate on one node.
- **ThreadLocal destruction sequence** — closes
  the destroy-on-pool-shutdown leak path. TDD: dedicated unit test plus
  Testcontainers IT verifying thread-id reuse after `RedisProCacheManager`
  close.
- **SecureJackson type-id validation** — whitelist checks now cover field,
  wrapper-array, and configured type-property forms; the same
  `PolymorphicTypeValidator` is installed even when global typing is disabled.
- **CachedValue refresh metadata** — `ttl`, creation/access metadata, expiry
  state, and value version survive the envelope round-trip; process-local
  `startNanoTime` remains excluded from the wire format.
- **Early-expiration CAS** — the Lua script compares the cached value's
  `payload.version`, not the envelope format version, and policy evaluation no
  longer bypasses entries solely because their remaining TTL exceeds 60 seconds.
- **Loader/context seams** — CacheContext byte input is defensively copied and
  RedisProCache binds loader callbacks once at construction so callers do not
  reassemble orchestration parameters.
- **One read-through load protocol** — the default (non-sync) loader path no
  longer delegates to Spring's `RedisCache.get(key, loader)`; both loader
  paths run `LoaderOrchestrator.readThrough` (cache read → loader → write-back)
  and share one tolerance rule. The default path's write-back now carries the
  same put metrics as the sync path. Failing write-backs are still logged
  redacted and never override the loaded value.
- **Key privacy in failure diagnostics** — WARN/ERROR logs and typed exception
  messages omit the raw key; where no `cacheName` is available
  they carry `FailureDiagnostics.keyFingerprint` instead. Covers distributed
  lock acquire/release, `SyncRole` leader/follower failures, the async
  early-expiration retry path, chain post-processing, and the migration
  engine's fingerprint helper (now one implementation).
- **Redacted diagnostics at every failure site** — the chain’s observer dispatch and
  all six Bloom failure paths now render only the exception type chain at WARN/ERROR
  (`FailureDiagnostics.sanitizedFailure`) and keep the full stack at DEBUG, closing the
  remaining key-privacy gaps. Fail-open behavior and the Bloom failure counters are
  unchanged.
- **Sync early-expiration answers with a miss** — a synchronous early-expiration
  skip (`EarlyExpirationMode.SYNC`) now returns `CacheResult.miss()` through the
  chain instead of a null-byte `success`: `EarlyExpirationHandler` advances to
  `ActualCacheHandler`, which consumes the documented `PrefetchDecision` and
  answers the miss its Javadoc and current handler contract describe. Writer and Spring
  behavior is unchanged (null bytes, miss statistics, loader refresh); chain
  observers and SPI callers now receive `Outcome.MISS`.
- ⚠️ **`@RedisCachePut` metadata now resolves** — the chain used to read only
  the `@RedisCacheable` namespace, so a method annotated only with
  `@RedisCachePut` ran without its `ttl`, `useBloomFilter`, `sync`,
  `cacheNullValues` and early-expiration attributes (a writer that never filled
  the Bloom filter could leave a Bloom-enabled reader judging the key
  "definitely missing"). Write-only methods now honour their own declaration —
  including an explicitly set `ttl()`, which now overrides the cache-level TTL
  on that path where it previously could not. A
  method that also declares `@RedisCacheable` keeps using the read-side
  declaration, because the read-through write-back is part of the read
  operation.
- **One annotation policy snapshot** — each annotated element is parsed once into
  an immutable snapshot shared by the Spring operation source and annotation chain;
  policy namespaces are registered at element resolution instead of per invocation.
- **Concurrent writes are no longer merged** — a write inside the distributed
  lock takes an exclusive path instead of single-flight: joining another
  request's in-flight result would skip this request's write while still
  reporting success. Reads keep the single-flight behaviour. The local-only
  serial queue waits for its predecessor at most the resolved `syncTimeout` and
  fails closed when it expires, instead of blocking indefinitely behind a
  stalled operation.
- **WARN/ERROR render exception types, not stacks** — the redaction rule now
  covers throwables too (a stack trace prints its message, and
  `Cache.ValueRetrievalException` embeds the raw key); the full stack stays at
  DEBUG.
- **One early-refresh module** — the read → decision → schedule → TTL-shortening
  CAS cycle moved out of the chain handler into `EarlyRefresh`.
  `EarlyExpirationHandler` is now a thin chain adapter: it asks the module for
  one evaluation, publishes the typed `PrefetchDecision` (so the value the
  decision read is reused instead of fetched twice) and maps the outcome to
  `SKIP_ALL`/`CONTINUE`. The executor, retry policy and cancellation seam are
  unchanged (see [`STABILITY.md`](./STABILITY.md)).
- **Nested chain advancement is explicit (SPI addition, compatible)** —
  `CacheHandler` gains `default HandlerResult handle(CacheContext,
  ChainContinuation next)`; the default ignores `next` and delegates to
  `handle(context)`, so existing implementations need no change (the
  external-consumer gate compiles and runs an unmodified implementation, and
  now also one that uses the new hook). A handler can run the remainder of the
  chain inside its own critical section — this is how `sync=true` executes
  inside the distributed lock — which previously required reaching back into
  the engine through a static `ThreadLocal` snapshot and an `indexOf(this)`
  lookup. That machinery, plus the two test-only setters and the handler's
  engine field, is deleted; the engine now holds no static state.

### Single-build FIRE M0–M4

- Historical FIRE M0–M4 verification established the Boot 4.0 / SDR 4.0 /
  Spring 7 / Java 21 / Redisson 3.50 line; current branch is `main`.
  Release claims still require current CI evidence.
- Adapter touch-points in source: `RedisCacheWriter.remove` → `evict`,
  `clean` → `clear` (delegating impls), `RedisCacheConfiguration.getTtl()`
  → `getTtlFunction().getTimeToLive(...)`, `RedisCacheManager`
  constructor arg reorder, Boot 4 package relocations
  (`DataRedisAutoConfiguration` / `DataRedisProperties` /
  `health.contributor`), `redisson-spring-boot-starter` → `redisson` core
  (the starter hard-references Boot 3 classes).
- CI: `.github/workflows/ci-boot4.yml` and the `compatibility` job in
  `  ci.yml` removed; Boot 4 is the sole line.

### Serializer hardening

- `SecureJacksonSerializerFactory` (@Component) — single entry point for
  `SecureJacksonRedisSerializer` wiring; eliminates the wired/unwired
  two-track bug from the earlier round. New unit test
  `SecureJacksonSerializerFactoryTest` with negative-wiring guard.
- **Wildcard `.*` suffix in `serializer.allowed-package-prefixes`** —
  `WhitelistPolicy.matchesPrefix` allows `com.example.*` to match any
  depth below `com.example.` (dot-boundary protected); literal prefixes
  keep their unchanged behavior.
- `SerializerWhitelistStartupGuard` (@Component + IT) — emits WARN on
  `ApplicationReadyEvent` when whitelist is `null` / `[]`; closes the
  "silent runtime failure on whitelist misconfig" footgun.
- `SerializationPreFlightProbe` — opt-in startup scan (`probe-enabled` +
  `probe-sample-size`, default 100) detects legacy non-envelope values;
  diagnostic-only, non-fatal.

### Master switches and operational policy

- `resi-cache.enabled` master kill-switch (auto-config gated by
  `@ConditionalOnProperty(prefix="resi-cache", name="enabled",
  matchIfMissing=true)`).
- `resi-cache.protection.enabled` — disables protection-chain handlers
  but **preserves TTL** (TtlHandler computes the base TTL).
- `nativeAnnotationMode` default `FULL` → **`SELECTIVE`** ⚠️ — plain
  `@Cacheable` is now handled by Spring's native cache infrastructure
  (resolves the dual-advisor risk). Set
  `resi-cache.native-annotation-mode=FULL` to opt back into pre-0.0.3
  behavior.
- Per-handler observability — `resicache.handler.fired` counter (tag
  `handler` = subclass simple name) + `[chain]` DEBUG with MDC
  `requestId` correlating one GET/PUT across all evaluated handlers;
  built on `ThreadLocalRandom` (no `SecureRandom` contention on hot path).
- Reactive return-type detection now logs an explicit **"caching will NOT
  take effect"** warning instead of implying a graceful fallback.

### Diagnosability and contributor infrastructure

- `SecureJackson` whitelist rejection message now includes the remediation
  property key `resi-cache.serializer.allowed-package-prefixes`.
- `CONTRIBUTING.md` — bus-factor disclosure (Maintainers section; bus
  factor 1 documented); JDK requirement aligned to 21 (matches `pom.xml`).
- Composite GitHub Action `.github/actions/setup-jdk-21` — single source
  for CI/PR JDK distribution and Maven cache. Release intentionally uses its
  inline setup-java step because deploy credentials require extra inputs.
- GitHub contributor templates
  (`.github/ISSUE_TEMPLATE/{bug_report,feature_request,config}.yml` +
  `.github/PULL_REQUEST_TEMPLATE.md`); `CODEOWNERS` relocated to
  `.github/`.
- Versions reconciled across `README.md` / `README.zh-CN.md` /
  `CLAUDE.md` to **Boot 4.0.0 / Java 21 /
  Redisson 3.50.0 / Caffeine 3.1.8** (was 3.4.13 / 17+ / 3.27.0).
- **JetCache coverage arithmetic correction** — JetCache
  Issue #269 (TTL jitter) is **closed unimplemented**, so
  ResiCache–JetCache coverage is **3/5** (not 4/5); ResiCache's true
  technical increment is **Bloom + TTL jitter + pluggable responsibility
  chain**.

### Architecture remediation (2026-09-22 review, c1–c9)

- **One owner for failure reporting (c1)** — package-private `FailureReport`
  emits the sanctioned WARN/ERROR plus paired DEBUG line for every failure site,
  so callers state what failed instead of choosing log levels and re-deriving
  the fingerprint rule; no `keyFingerprint` concatenation or hand-paired DEBUG
  remains in `src/main`. Levels, count-once accounting, the failure metric
  dimensions and the raw-key privacy rule are unchanged; message rendering
  (field order and punctuation) is now produced by the one owner.
- **Metrics resolved at one non-null seam (c2)** — `resi-cache.metrics.enabled`
  is read in exactly one place and handed to every caller as a non-null metrics
  seam; when the opt-in is off (or no `MeterRegistry` bean exists) that seam
  publishes nothing and the application's registry beans are not even resolved,
  so an ambiguous registry set cannot fail an assembly that disabled metrics.
  The opt-in is declared in
  `additional-spring-configuration-metadata.json`. The key has no
  `RedisProCacheProperties` field: it is fixed, and binding it would require a
  tenth public nested type (`STABILITY.md` §4 churn) for an assembly detail.
- ⚠️ **Protection health is no longer gated by the metrics opt-in (c2)** —
  `RedisCacheHealthIndicator` now reports Redis connectivity and protection
  degradation regardless of `resi-cache.metrics.enabled`; previously the
  unrelated metrics switch could suppress the indicator.
- **The disabled metrics seam does no work (c2)** — with
  `resi-cache.metrics.enabled` off (the default) the resolved seam is a shared
  stateless registry, and every consumer short-circuits on it rather than
  registering through it: the chain's timer observer, the fired-counter observer
  and the failure reporter return before building a key; the per-cache registry,
  the handler attach hook, the refresh-task metrics and the Bloom filter take
  their existing null path; and the migration engine skips its per-key metric
  record. A disabled application therefore allocates and keeps no meter, no
  timer and no per-cache entry, and the chain timer observer neither reads the
  clock nor allocates a scope token on that path. Two earlier revisions of this
  change had moved that work instead of removing it — the retention into the
  timer observer's own per-cache-name map, and the per-key allocation into the
  migration engine. Metric names, tag keys and tag values are unchanged.
- **The degraded-protection warning fires once per context and reports the real
  mode (c2)** — `RedisCacheHealthIndicator` reports the actual sync-protection
  state, derived in one place by `SyncSupport`: `protection.degraded=local-only`
  only when no distributed lock backend is present and
  `resi-cache.sync-lock.local-only=true` was explicitly enabled,
  `protection.degraded=fail-fast` when no backend is present without that opt-in
  (so `sync=true` rejects instead of degrading), and no protection detail when a
  backend exists. The associated WARN fires at most once per context instead of
  on every `/actuator/health` probe, which matters where a load balancer or
  orchestrator probes frequently; the state itself is reported in every health
  response's details.
- **Observer order owned by the observer class (c3)** — the four standard
  observers declare `@Order(1..4)` on the class instead of on their `@Bean`
  methods, and the factory registers observers in the Spring-resolved injection
  order instead of re-sorting by an annotation only it could see; observers
  ordered through `Ordered`, a `@Bean`-method `@Order`, a meta-annotation or a
  proxy keep the position Spring gave them. The dispatch itself is typed at both
  levels — the chain-level and node-level results reach the end hooks as
  `CacheResult` / `HandlerResult` without a cast — and the chain observer
  protocol no longer checks its own scope token's runtime type.
- ⚠️ **`ChainObserver.beforeNode` removed (c3)** — the hook had no production
  implementer. An extension that overrode it must move that work to
  `onNodeStart` / `afterNode`; every other hook keeps its name and semantics.
  See `STABILITY.md` §4 for the migration note.
- ⚠️ **An annotated method without an explicit `ttl` now takes the configured TTL (c8)** —
  `@RedisCacheable#ttl` and `@RedisCachePut#ttl` default to `0`, which `TtlPolicy` reads as
  "no method-level declaration", so a method that does not set `ttl` falls through to
  `resi-cache.default-ttl` (default 30 minutes) instead of the previous implicit 60 seconds.
  An explicitly set positive `ttl` still wins and still applies its jitter.
  `TtlPolicy.DEFAULT_TTL_SECONDS` and its `null`-`Duration` branch are gone, and a zero,
  negative or `null` TTL all mean "no expiry", matching Spring Data Redis's own
  `DefaultRedisCacheWriter.shouldExpireWithin`; a direct writer/SPI `put(…, null)` therefore
  writes a persistent entry where it previously wrote a 60-second one.
- **Handler identity declared once (c4)** — order slot, protection disable name,
  metric/log tag and the ordering requirement of each slot are declared
  alongside `HandlerOrder` and resolved by `cache/HandlerIdentity`; emitted tag
  values are unchanged, and a handler with no declared identity keeps the
  previous class-simple-name tag.
- **One assembly root per boundary (c5)** — the runtime context and the operator
  CLI each name the beans they own by class instead of regex package-scan
  patterns, `resi-cache.enabled` is declared once, and the bean-backoff
  invariant enumerates `@Bean` methods.
- **One projection feeds both operation views (c6)** — the AOP operation and the
  policy view are derived from one `RedisCacheAttributes` instance per
  annotation, so a new annotation field has one mapping site and the policy
  lookup no longer depends on declaration order; the Spring/policy view split
  itself is retained.
- **Unreachable degradation modes deleted (c7)** — dead null guards, the
  `NullValueEncoder` wrapper and test-only factory surface are gone. The
  engine-side rejection of a malformed `HandlerResult` is retained because
  `STABILITY.md` §4 documents it.
- **TTL precedence in one module (c8)** — `TtlPolicy` owns the ordered
  resolution. The ownership extraction preserved behavior; the separate
  annotation-default change above removed the implicit 60-second fallback. See
  [`COMPATIBILITY.md`](./COMPATIBILITY.md) and
  [`docs/REFERENCE.md`](docs/REFERENCE.md).
- **Synchronization lifecycle owned by its state (c9)** — the single-flight
  lifecycle (enter → complete → exit → cleanup, exactly once) now lives with the
  state it mutates and the seven-argument static re-entry is gone; lock
  acquire/release order and failure paths are unchanged.

### Fixed

- **`resi-cache.serializer.*` properties were silently dropped by the
  `RedisTemplate<String, Object> redisCacheTemplate` bean** (writer path).
  Setting `allowed-package-prefixes` / `polymorphic-typing-enabled` was
  honored on the `@Cacheable` path but not by the writer path → two code
  paths, two different whitelists, silent inconsistency. Fixed by
  threading `RedisProCacheProperties.SerializerProperties` through the
  writer bean. Regression test: `RedisConnectionConfigurationTest`
  (Testcontainers, `@DynamicPropertySource`).
- **Redisson is now a true optional dependency** — `RedissonClient` bean
  and Redisson-specific configuration isolated under a class-level
  `@ConditionalOnClass(RedissonClient.class)`; booting without Redisson
  no longer risks a `NoClassDefFoundError`.
- **`.github/workflows/release.yml` `JAVA_VERSION` lag** —
  `env.JAVA_VERSION: '17'` was not synchronized in the FIRE cut;
  bumped to `'21'` to match `pom.xml <java.version>21</java.version>`.
- Whitelist rejection message now mentions the remediation property key.

## [0.0.2] — historical source cleanup

### Removed — over-engineering cleanup (~2,989 lines)

⚠️ The following were removed as dead / over-engineered code (had been
documented but never shipped as stable features):

- `wrapper/` — `CircuitBreakerCacheWrapper`, `RateLimiterCacheWrapper`
  → use [Resilience4j](https://resilience4j.readthedocs.io/)
- `spi/` Java ServiceLoader package (`BloomFilterProvider`,
  `LockProvider`, `RedissonLockProvider`, etc.) — same-named interfaces
  retained under `protection/breakdown/LockManager` and
  `protection/bloom/filter/BloomIFilter`; customizability is via Spring
  `@Bean` + `@ConditionalOnMissingBean`.
- `event/` — `CacheEvictedEvent`
- `evaluator/` — `SpelConditionEvaluator`
- `observability/CacheMetricsRecorder` (only
  `RedisCacheHealthIndicator` retained)

### Added

- Five protection mechanisms via a composable responsibility chain
  (single source of truth in `HandlerOrder`, gap = 100):
  - Bloom filter (100) — penetration
  - Distributed lock (200) — breakdown
  - Early expiration (250) — hot key
  - TTL jitter (300) — avalanche
  - Null value (400) — penetration
- Enhancement annotations: `@RedisCacheable`, `@RedisCachePut`,
  `@RedisCacheEvict`, `@RedisCaching`.
- `SecureJackson` whitelisted deserialization with `{version, payload}`
  envelope.
- `RedisCacheHealthIndicator` (actuator health).

## [0.0.1] — initial (unpublished)

Initial development; no separate changelog was maintained (superseded by
the 0.0.2 cleanup). Artifact version has been `0.0.x` throughout
development.

---

Link reference policy: this file links to the README within the
repo. External links point to upstream tooling (Resilience4j, Caffeine,
Keep a Changelog, SemVer).
