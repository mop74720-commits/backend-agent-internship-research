/**
 * Re-export seam — `User`, `LoginCredentials`, `LoginResponse`,
 * `RegisterRequest`, `Permission` and friends are owned by
 * `shared/auth-core/src/types.ts` as the single source of truth for both
 * frontends (see the auth-core source comment).
 *
 * Previously this file defined a parallel `User` shape with camelCase
 * fields (`isActive`, `joinedAt`, …) that no caller actually read at
 * runtime, and a parallel `LoginResponse`/`RegisterRequest` that drifted
 * from management's identical shapes. Both apps now consume the same
 * snake_case types from auth-core, removing the documented debt flagged in
 * the file's previous header comment.
 *
 * See the current authentication contract and its regression coverage.
 */
export type {
  LoginCredentials,
  RegisterRequest,
  LoginResponse,
  User,
  Permission,
  AuthStatus,
} from '@ulticode/auth-core'

/**
 * Console-only DTOs (not part of auth-core because they are not shared
 * with management) — kept here so callers that previously imported them
 * from `@/types/auth` continue to work.
 */
export interface LoginRequest {
  username: string
  password: string
}

export interface ForgotPasswordRequest {
  email: string
}

export interface ResetPasswordRequest {
  token: string
  newPassword: string
}
