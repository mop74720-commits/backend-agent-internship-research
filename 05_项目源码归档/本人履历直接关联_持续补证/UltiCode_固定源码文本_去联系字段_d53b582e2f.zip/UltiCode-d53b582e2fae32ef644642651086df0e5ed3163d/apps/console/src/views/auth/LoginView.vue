<script setup lang="ts">
/**
 * LoginView - Console login page
 *
 * Thin shell over the shared `AuthLayout` + `AuthPatternBackground`
 * components. The form's submit handler delegates to the local
 * `useAuthStore.login` so the store continues to own CSRF + redirect.
 */
import { useI18n } from "vue-i18n";
import { useAuthStore } from "@/stores/auth";
import AuthCard from "@ulticode/auth-ui/components/AuthCard.vue";
import AuthLayout from "@ulticode/auth-ui/layouts/AuthLayout.vue";
import AuthPatternBackground from "@ulticode/auth-ui/layouts/AuthPatternBackground.vue";
import LoginForm from "@ulticode/auth-ui/components/LoginForm.vue";

const { t } = useI18n();
const authStore = useAuthStore();

async function handleLogin(creds: { username: string; password: string }) {
  await authStore.login(creds);
}

defineOptions({
  name: "LoginView",
});
</script>

<template>
  <AuthLayout badge="CODE" version="v2.0.0">
    <template #form>
      <AuthCard>
        <LoginForm :on-submit="handleLogin" fallback-redirect="/problemset" />
      </AuthCard>
    </template>
    <template #pattern>
      <AuthPatternBackground
        :title="t('auth.layout.codingConsole')"
        :subtitle="t('auth.layout.codingConsoleSubtitle')"
      />
    </template>
  </AuthLayout>
</template>
