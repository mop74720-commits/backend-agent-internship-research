<script setup lang="ts">
import { ref, onMounted, onUnmounted, watch, computed } from "vue";
import * as echarts from "echarts";
import { useResizeObserver } from "@vueuse/core";
import { useI18n } from "vue-i18n";
import { Button } from "@ulticode/design-system/ui/button";
import { fetchLearningProgress } from "@/api/submission";
import type { LearningProgress } from "@/api/submission";
import { useChartPalette } from "@ulticode/design-system";
import { withSafeChartAnimation } from "./chartOptions";

const { t } = useI18n();

interface Props {
  loading?: boolean;
}

const props = withDefaults(defineProps<Props>(), {
  loading: false,
});

const chartRef = ref<HTMLDivElement | null>(null);
let chartInstance: echarts.ECharts | null = null;
const progressData = ref<LearningProgress | null>(null);
const dataLoading = ref(true);
const loadFailed = ref(false);
const chartPalette = useChartPalette();

const hasData = computed(
  () =>
    progressData.value &&
    (progressData.value.weeklyProgress.length > 0 ||
      progressData.value.difficultyProgress.length > 0),
);

const initChart = () => {
  if (!chartRef.value || !hasData.value) return;

  if (chartInstance) {
    chartInstance.dispose();
  }

  chartInstance = echarts.init(chartRef.value, undefined, {
    renderer: "canvas",
  });

  const colors = chartPalette.value;

  const weeks = progressData.value?.weeklyProgress.map((w) => w.week) || [];
  const problemsSolved =
    progressData.value?.weeklyProgress.map((w) => w.solved) || [];
  const timeSpent =
    progressData.value?.weeklyProgress.map((w) => w.timeSpent) || [];

  const series: echarts.SeriesOption[] = [
    {
      name: t("personal.learning.problemsSolved"),
      type: "bar",
      data: problemsSolved,
      itemStyle: {
        color: colors.series1,
        borderRadius: 0,
      },
      emphasis: {
        itemStyle: {
          color: colors.series1,
        },
      },
    },
    {
      name: t("personal.learning.timeSpent"),
      type: "line",
      yAxisIndex: 1,
      data: timeSpent,
      smooth: true,
      symbol: "circle",
      symbolSize: 6,
      lineStyle: {
        width: 2,
        color: colors.series2,
      },
      itemStyle: {
        color: colors.series2,
      },
    },
  ];

  const option: echarts.EChartsOption = {
    tooltip: {
      trigger: "axis",
      confine: true,
      backgroundColor: colors.background,
      borderColor: colors.tooltipBorder,
      borderRadius: 0,
      textStyle: {
        color: colors.foreground,
      },
      axisPointer: {
        type: "cross",
      },
    },
    legend: {
      data: [
        t("personal.learning.problemsSolved"),
        t("personal.learning.timeSpent"),
      ],
      bottom: 0,
      textStyle: {
        color: colors.muted,
        fontSize: 11,
      },
    },
    grid: {
      left: "3%",
      right: "5%",
      bottom: "15%",
      top: 32,
      containLabel: true,
    },
    xAxis: {
      type: "category",
      data: weeks,
      axisLine: {
        lineStyle: {
          color: colors.border,
        },
      },
      axisLabel: {
        color: colors.muted,
        fontSize: 10,
        rotate: 45,
      },
    },
    yAxis: [
      {
        type: "value",
        name: t("personal.learning.problemsSolved"),
        minInterval: 1,
        nameTextStyle: {
          align: "left",
          color: colors.muted,
          fontSize: 10,
        },
        axisLine: {
          lineStyle: {
            color: colors.border,
          },
        },
        axisLabel: {
          color: colors.muted,
          fontSize: 10,
        },
        splitLine: {
          lineStyle: {
            color: colors.border,
            type: "dashed",
          },
        },
      },
      {
        type: "value",
        name: t("personal.learning.hours"),
        nameTextStyle: {
          align: "right",
          color: colors.muted,
          fontSize: 10,
        },
        axisLine: {
          lineStyle: {
            color: colors.border,
          },
        },
        axisLabel: {
          color: colors.muted,
          fontSize: 10,
        },
        splitLine: {
          show: false,
        },
      },
    ],
    series,
  };

  chartInstance.setOption(withSafeChartAnimation(option));
};

const handleResize = () => {
  chartInstance?.resize();
};

useResizeObserver(chartRef, handleResize);

const loadData = async () => {
  dataLoading.value = true;
  loadFailed.value = false;
  try {
    progressData.value = await fetchLearningProgress();
  } catch (e) {
    progressData.value = null;
    loadFailed.value = true;
    console.error("Failed to load learning progress", e);
  } finally {
    dataLoading.value = false;
  }
};

onMounted(() => {
  loadData();
});

watch([hasData, dataLoading], () => {
  if (hasData.value && !dataLoading.value) {
    setTimeout(() => initChart(), 0);
  }
});

watch(chartPalette, () => initChart(), { flush: "post" });

onUnmounted(() => {
  chartInstance?.dispose();
  chartInstance = null;
});
</script>

<template>
  <div class="relative">
    <div
      v-if="props.loading || dataLoading"
      class="flex items-center justify-center h-[230px]"
    >
      <div
        class="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent"
      ></div>
    </div>
    <div
      v-else-if="loadFailed"
      role="alert"
      class="flex min-h-[230px] flex-col items-center justify-center gap-3 text-center"
    >
      <p class="text-sm text-destructive [overflow-wrap:anywhere]">
        {{ t("personal.learning.loadError") }}
      </p>
      <Button variant="outline" @click="loadData">
        {{ t("common.actions.retry") }}
      </Button>
    </div>
    <div
      v-else-if="!hasData"
      class="flex flex-col items-center justify-center h-[230px] text-center"
    >
      <p class="text-sm text-muted-foreground">
        {{ t("personal.learning.noProgress") }}
      </p>
    </div>
    <div v-else ref="chartRef" class="h-[230px] w-full"></div>
  </div>
</template>
