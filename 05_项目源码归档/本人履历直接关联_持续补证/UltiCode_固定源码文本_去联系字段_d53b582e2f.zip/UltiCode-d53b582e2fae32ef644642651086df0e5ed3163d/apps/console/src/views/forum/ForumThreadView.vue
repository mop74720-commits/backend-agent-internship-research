<script setup lang="ts">
import { Skeleton } from "@ulticode/design-system/ui/skeleton";
import ForumPostSkeleton from "@/views/forum/components/ForumPostSkeleton.vue";
import ThreadContent from "@/views/forum/components/ThreadContent.vue";
import { CommentThread } from "@/components/comments";
import { ref, computed } from "vue";
import { RouterLink } from "vue-router";
import { ArrowLeft, MessageSquare, Flag, List } from "@lucide/vue";
import { Button } from "@ulticode/design-system/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@ulticode/design-system/ui/popover";
import { useI18n } from "vue-i18n";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@ulticode/design-system/ui/alert-dialog";
import ReportDialog from "@/components/ReportDialog.vue";
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from "@ulticode/design-system/ui/avatar";
import { useForumThread } from "@/composables/useForumThread";
import { useContentNavigation } from "@/composables/useContentNavigation";
import { extractHeadings, slugifyHeading } from "@ulticode/markdown-utils";

const { t } = useI18n();

const {
  thread,
  isLoading,
  onSubmitComment,
  onEditComment,
  onDeleteComment,
  handleDeleteThread,
  handleEditThread,
  isOwner,
  handleThreadVote,
  handleCommentVote,
  handleThreadSave,
  countThreadComments,
  authorAvatarUrl,
  authorInitial,
  createdAgo,
} = useForumThread();

const reportDialogRef = ref<{ open: () => void } | null>(null);
const commentCount = computed(() =>
  countThreadComments(thread.value?.comments),
);
const tocTriggerRef = ref<{ $el: HTMLElement } | null>(null);
let isTOCNavigation = false;

const restoreTOCTriggerFocus = (event: Event) => {
  if (!isTOCNavigation) return;
  isTOCNavigation = false;
  event.preventDefault();
  tocTriggerRef.value?.$el.focus({ preventScroll: true });
};

const handleReport = () => {
  reportDialogRef.value?.open();
};

const getPostContent = (): string => {
  if (!thread.value) return "";
  if (thread.value.body) return thread.value.body;
  if (thread.value.excerpt) return thread.value.excerpt;
  if (thread.value.media) {
    const m = thread.value.media as {
      type?: string;
      markdown?: string;
      body?: string;
    };
    if (m && m.type === "text") {
      return m.markdown || m.body || "";
    } else if (Array.isArray(m)) {
      const textMedia = m.find(
        (item: { type?: string; markdown?: string; body?: string }) =>
          item.type === "text",
      );
      if (textMedia) return textMedia.markdown || textMedia.body || "";
    }
  }
  return "";
};

interface ForumHeading {
  id: string;
  text: string;
  level: number;
  exists: boolean;
}

const collectBoldFallbacks = (content: string): ForumHeading[] => {
  const lines = content.split("\n");
  const out: ForumHeading[] = [];
  const seen = new Set<string>();
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("```") || trimmed.startsWith("#")) {
      continue;
    }
    const boldLead = trimmed.match(/^\*\*([^*][^*]*?):\*\*\s*$/);
    if (boldLead) {
      const text = (boldLead[1] ?? "").trim();
      if (text) {
        const id = slugifyHeading(text);
        if (!seen.has(id)) {
          seen.add(id);
          out.push({ id, text, level: 3, exists: false });
        }
      }
      continue;
    }
    const standaloneBold = trimmed.match(/^\*\*([^*][^*]*?)\*\*\s*$/);
    if (standaloneBold) {
      const text = (standaloneBold[1] ?? "").trim();
      if (text && text.length <= 40) {
        const id = slugifyHeading(text);
        if (!seen.has(id)) {
          seen.add(id);
          out.push({ id, text, level: 3, exists: false });
        }
      }
    }
  }
  return out;
};

const headings = computed<ForumHeading[]>(() => {
  const content = getPostContent();
  const real = extractHeadings(content).map<ForumHeading>((h) => ({
    ...h,
    exists: true,
  }));

  // Fallback: when there are too few explicit headings, harvest bold
  // lead-ins / standalone bold lines so short posts still get a usable TOC.
  const fallback = real.length < 2 ? collectBoldFallbacks(content) : [];

  return [
    ...real,
    ...fallback,
    {
      id: "comments-section",
      text: t("forum.comments.title"),
      level: 2,
      exists: true,
    },
  ];
});

const {
  wrapperRef,
  activeHeadingId,
  isWideLayout,
  showMobileTOC,
  scrollToHeading,
} = useContentNavigation(headings, {
  resolveFallbackElement: (heading) => {
    const strongs = document.querySelectorAll(
      ".markdown-view strong, .markdown-view p",
    );
    for (const node of Array.from(strongs)) {
      if (
        (node.textContent || "").trim().replace(/[:：]\s*$/, "") ===
        heading.text
      ) {
        return node as HTMLElement;
      }
    }
    return null;
  },
  onAfterScroll: (el, heading) => {
    if (
      heading &&
      heading.exists === false &&
      el.tagName !== "H2" &&
      el.tagName !== "H3"
    ) {
      el.classList.add("ring-2", "ring-ring", "rounded-sm");
      window.setTimeout(() => {
        el.classList.remove("ring-2", "ring-ring", "rounded-sm");
      }, 1500);
    }
  },
});

const handleMobileTOCClick = (id: string) => {
  isTOCNavigation = true;
  scrollToHeading(id);
  showMobileTOC.value = false;
};
</script>

<template>
  <div
    ref="wrapperRef"
    class="mx-auto flex w-full max-w-7xl items-start gap-6 px-4 py-8 relative"
  >
    <main
      class="min-w-0 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500"
      :class="[isWideLayout ? 'max-w-4xl flex-1' : 'w-full']"
    >
      <div v-if="isLoading" class="space-y-6">
        <ForumPostSkeleton />
        <div class="space-y-4 pl-4 border-l border-border/40">
          <div class="flex gap-3" v-for="i in 3" :key="i">
            <Skeleton class="h-8 w-8" />
            <div class="space-y-2 flex-1">
              <Skeleton class="h-4 w-32" />
              <Skeleton class="h-4 w-full" />
            </div>
          </div>
        </div>
      </div>

      <template v-else-if="thread">
        <div class="space-y-4">
          <div
            class="rounded-xl border bg-card text-card-foreground overflow-hidden w-full"
          >
            <div class="flex flex-wrap items-center gap-2 px-4 sm:px-6 pt-4">
              <!-- Back Link: placed in the toolbar so the right sidebar's
                   Author Profile card shares the thread card's top edge -->
              <RouterLink
                to="/forum"
                class="inline-flex h-8 px-3 items-center justify-center rounded-lg border border-border dark:border-border bg-card text-foreground dark:text-muted-foreground hover:bg-accent dark:hover:bg-border hover:text-foreground dark:hover:text-foreground hover:border-border active:bg-border dark:active:bg-border active:scale-[0.98] transition-all font-bold text-xs shadow-sm"
              >
                <ArrowLeft class="h-3.5 w-3.5 mr-1.5" />
                <span>{{ t("forum.feedback.backToDiscussions") }}</span>
              </RouterLink>
              <!-- Mobile Table of Contents button (narrow container only) -->
              <Popover
                v-if="!isWideLayout && headings.length > 1"
                v-model:open="showMobileTOC"
              >
                <PopoverTrigger as-child>
                  <Button
                    ref="tocTriggerRef"
                    type="button"
                    variant="ghost"
                    size="sm"
                    class="px-2"
                  >
                    <List class="mr-1 h-3.5 w-3.5" />
                    {{ t("forum.sidebar.toc") }}
                  </Button>
                </PopoverTrigger>
                <PopoverContent
                  align="start"
                  :collision-padding="16"
                  :aria-label="t('forum.sidebar.toc')"
                  class="w-48 max-h-[var(--reka-popover-content-available-height)] p-3 gap-2 select-none font-mono"
                  @close-auto-focus="restoreTOCTriggerFocus"
                >
                  <div
                    class="shrink-0 text-xs font-bold uppercase tracking-wider text-muted-foreground/85 border-b border-border/50 pb-1"
                  >
                    {{ t("forum.sidebar.toc") }}
                  </div>
                  <nav
                    class="flex min-h-0 flex-col gap-1 max-h-60 overflow-y-auto"
                  >
                    <Button
                      variant="outline"
                      v-for="h in headings"
                      :key="h.id"
                      type="button"
                      class="text-left py-1 px-1.5 cursor-pointer select-none"
                      :class="[
                        activeHeadingId === h.id
                          ? 'border-primary text-primary font-bold bg-primary/5'
                          : 'border-transparent text-muted-foreground font-medium',
                      ]"
                      :style="{
                        paddingLeft: h.level === 3 ? '1rem' : '0.25rem',
                      }"
                      @click="handleMobileTOCClick(h.id)"
                    >
                      {{ h.text }}
                    </Button>
                  </nav>
                </PopoverContent>
              </Popover>

              <template v-if="isOwner()">
                <Button variant="outline" size="sm" @click="handleEditThread">
                  {{ t("forum.post.edit") }}
                </Button>
                <AlertDialog>
                  <AlertDialogTrigger as-child>
                    <Button variant="destructive" size="sm">{{
                      t("forum.post.delete")
                    }}</Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>{{
                        t("forum.post.deleteDialog.title")
                      }}</AlertDialogTitle>
                      <AlertDialogDescription>
                        {{ t("forum.post.deleteDialog.description") }}
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>{{
                        t("forum.post.deleteDialog.cancel")
                      }}</AlertDialogCancel>
                      <AlertDialogAction @click="handleDeleteThread">
                        {{ t("forum.post.deleteDialog.confirm") }}
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </template>
              <Button
                v-else
                variant="ghost"
                size="sm"
                class="px-2"
                @click="handleReport"
              >
                <Flag class="mr-1 h-3.5 w-3.5" />
                {{ t("forum.actions.report") }}
              </Button>
            </div>
            <ThreadContent
              :thread="thread"
              :comment-count="commentCount"
              @vote="handleThreadVote"
              @save="handleThreadSave"
            />
            <div
              id="comments-section"
              class="px-4 sm:px-6 py-4 border-t border-border/50"
            >
              <h2
                class="text-sm font-bold tracking-tight flex items-center gap-2"
              >
                <MessageSquare class="h-4 w-4" />
                {{ t("forum.comments.title") }}
                <span class="text-muted-foreground font-normal">
                  ({{ commentCount }})
                </span>
              </h2>
            </div>
            <CommentThread
              class="px-4 sm:px-6"
              :comments="thread.comments"
              :is-locked="thread.isLocked"
              @submit="onSubmitComment"
              @vote="handleCommentVote"
              @edit="onEditComment"
              @delete="onDeleteComment"
            />
          </div>
        </div>
      </template>

      <div
        v-else
        class="rounded-lg border border-dashed border-destructive/40 bg-destructive/5 p-6 text-sm text-destructive"
      >
        {{ t("forum.comments.failedToLoad") }}
      </div>
    </main>

    <!-- Right Sidebar Column: details & sticky TOC -->
    <aside
      v-if="isWideLayout && thread"
      class="flex flex-col gap-4 w-60 shrink-0 self-stretch sticky top-14 max-h-[calc(100vh-4rem)] overflow-y-auto select-none"
    >
      <!-- Author Profile Card -->
      <div
        class="rounded-xl border bg-card text-card-foreground overflow-hidden bg-card border border-border p-4 flex flex-col gap-3 w-full max-w-[16rem]"
      >
        <div class="flex items-center gap-2">
          <Avatar class="h-9 w-9 shrink-0">
            <AvatarImage
              :src="authorAvatarUrl"
              :alt="thread.author?.username"
            />
            <AvatarFallback>
              {{ authorInitial }}
            </AvatarFallback>
          </Avatar>
          <div class="flex flex-col min-w-0">
            <span
              class="font-bold text-xs text-foreground dark:text-foreground truncate leading-tight"
            >
              u/{{ thread.author?.username || "unknown" }}
            </span>
            <span
              class="text-xs text-muted-foreground truncate leading-none mt-0.5"
              v-if="thread.author?.karma !== undefined"
            >
              Reputation: {{ thread.author.karma }}
            </span>
          </div>
        </div>

        <div
          class="text-xs text-muted-foreground/80 flex flex-col gap-1 border-t border-border/50 pt-2 font-mono"
        >
          <div>发布于：{{ createdAgo }}</div>
          <div v-if="thread.community" class="truncate">
            社区：r/{{ thread.community.name }}
          </div>
          <div
            v-if="thread.flair"
            class="flex items-center gap-1.5 flex-wrap mt-1"
          >
            <span
              class="inline-block px-1.5 py-0.5 bg-muted border border-border text-xs text-foreground"
            >
              {{ thread.flair.text }}
            </span>
          </div>
        </div>
      </div>

      <!-- Table of Contents Widget -->
      <div
        v-if="headings.length > 1"
        class="w-full max-w-[16rem] self-stretch px-2 py-3"
      >
        <div
          class="mb-3 px-3 text-xs font-medium text-muted-foreground select-none"
        >
          {{ t("forum.sidebar.toc") }}
        </div>
        <nav :aria-label="t('forum.sidebar.toc')" class="flex flex-col gap-0.5 border-l border-border">
          <Button
            variant="ghost"
            v-for="h in headings"
            :key="h.id"
            type="button"
            class="h-auto min-h-8 w-full justify-start rounded-l-none border-l-2 border-transparent px-3 py-1.5 text-left text-sm whitespace-normal select-none cursor-pointer"
            :aria-current="activeHeadingId === h.id ? 'location' : undefined"
            :class="[
              activeHeadingId === h.id
                ? 'border-l-primary bg-accent text-accent-foreground font-medium'
                : 'text-muted-foreground hover:text-foreground',
            ]"
            :style="{ paddingLeft: h.level === 3 ? '1.5rem' : '0.75rem' }"
            @click="scrollToHeading(h.id)"
          >
            {{ h.text }}
          </Button>
        </nav>
      </div>
    </aside>
  </div>

  <ReportDialog
    v-if="thread"
    ref="reportDialogRef"
    entity-type="forum_post"
    :entity-id="thread.id"
  />
</template>
