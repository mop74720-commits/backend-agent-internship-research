<script setup lang="ts">
import { computed } from "vue";
import { useI18n } from "vue-i18n";
import type {
  SubmissionRecord,
  SubmissionStatusMeta,
} from "@/types/submission";
import { Loader2, Inbox } from "@lucide/vue";
import {
  Table,
  TableBody,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from "@ulticode/design-system/ui/table";

import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
} from "@ulticode/design-system/ui/empty";
import SemanticBadge from "@ulticode/badge-config/SemanticBadge.vue";
import {
  getStatusColor,
  getStatusLabelI18nKey,
} from "@ulticode/submission-status";

const props = defineProps<{
  submissions: SubmissionRecord[];
  isLoading: boolean;
  statusMetaByKey: Record<string, SubmissionStatusMeta>;
  isAuthenticated?: boolean;
}>();

const emit = defineEmits<{
  (e: "select", submission: SubmissionRecord): void;
}>();

const { t } = useI18n();

function getSubmissionLabel(status: string): string {
  const key = getStatusLabelI18nKey(status);
  return key ? t(key) : status;
}

const handleSelect = (submission: SubmissionRecord) => {
  emit("select", submission);
};

const showLoginPrompt = computed(
  () =>
    props.isAuthenticated === false &&
    !props.isLoading &&
    props.submissions.length === 0,
);
</script>

<template>
  <div class="h-full">
    <div v-if="isLoading" class="flex h-full items-center justify-center p-8">
      <Loader2 class="h-8 w-8 animate-spin text-muted-foreground" />
    </div>
    <template v-else-if="showLoginPrompt">
      <Empty class="flex h-full items-center justify-center px-6 py-8">
        <EmptyContent>
          <EmptyMedia variant="icon">
            <Inbox class="h-10 w-10 text-muted-foreground" />
          </EmptyMedia>
          <EmptyHeader>
            <p class="text-base font-semibold text-foreground">
              {{ t("problem.submissions.loginRequired") }}
            </p>
            <EmptyDescription>
              {{ t("problem.submissions.loginToViewSubmissions") }}
            </EmptyDescription>
          </EmptyHeader>
        </EmptyContent>
      </Empty>
    </template>
    <template v-else>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead class="w-[140px]">
              {{ t("problem.submissions.status") }}
            </TableHead>
            <TableHead class="w-[140px]">
              {{ t("problem.submissions.language") }}
            </TableHead>
            <TableHead class="w-[120px] text-center">
              {{ t("problem.submissions.runtime") }}
            </TableHead>
            <TableHead class="w-[120px] text-center">
              {{ t("problem.submissions.memory") }}
            </TableHead>
            <TableHead>{{ t("problem.submissions.notes") }}</TableHead>
          </TableRow>
        </TableHeader>

        <TableBody>
          <template v-if="props.submissions.length">
            <TableRow
              v-for="submission in props.submissions"
              :key="submission.id"
              class="cursor-pointer"
              @click="handleSelect(submission)"
            >
              <TableCell>
                <SemanticBadge
                  :color="getStatusColor(submission.status)"
                  :label="getSubmissionLabel(submission.status)"
                  size="xs"
                />
              </TableCell>
              <TableCell>{{ submission.language }}</TableCell>
              <TableCell class="text-center">
                {{ submission.runtime }}
              </TableCell>
              <TableCell class="text-center">
                {{ submission.memory }}
              </TableCell>
              <TableCell>
                {{ submission.notes || "—" }}
              </TableCell>
            </TableRow>
          </template>

          <TableRow v-else>
            <TableCell colspan="5" class="p-0">
              <Empty class="px-6 py-8">
                <EmptyContent>
                  <EmptyMedia variant="icon">
                    <Inbox class="h-6 w-6 text-muted-foreground" />
                  </EmptyMedia>
                  <EmptyHeader>
                    <p class="text-base font-semibold text-foreground">
                      {{ t("problem.submissions.noSubmissionsTitle") }}
                    </p>
                    <EmptyDescription>
                      {{ t("problem.submissions.noSubmissionsDesc") }}
                    </EmptyDescription>
                  </EmptyHeader>
                </EmptyContent>
              </Empty>
            </TableCell>
          </TableRow>
        </TableBody>
        <TableFooter v-if="props.submissions.length">
          <TableRow>
            <TableCell colspan="4">
              {{ t("personal.profile.totalProblems") }}
            </TableCell>
            <TableCell class="text-center">
              {{ props.submissions.length }}
            </TableCell>
          </TableRow>
        </TableFooter>
      </Table>
    </template>
  </div>
</template>
