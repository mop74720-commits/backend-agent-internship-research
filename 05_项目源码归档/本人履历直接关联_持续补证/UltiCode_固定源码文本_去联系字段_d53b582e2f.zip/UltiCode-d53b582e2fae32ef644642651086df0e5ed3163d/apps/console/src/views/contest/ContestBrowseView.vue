<script setup lang="ts">
/**
 * ContestBrowseView - Contest browse page with tabbed navigation
 *
 * Features:
 * - Tabbed navigation for ongoing, upcoming, and finished contests
 * - Supports initialTab prop for direct tab selection
 * - Uses contestStore for state management
 * - Integrates ContestCard components
 * - Shows loading skeletons during data fetch
 * - Shows empty state when no contests available
 */
import { ref, computed, onMounted, watch } from "vue";
import { useRoute, useRouter } from "vue-router";
import { storeToRefs } from "pinia";
import { createValueRequest } from "@ulticode/request-state";
import RetryButton from "@/components/common/loading/RetryButton.vue";
import { useI18n } from "vue-i18n";
import { Trophy, Calendar, CheckCircle, PlayCircle } from "@lucide/vue";
import { useContestBrowseStore } from "@/stores/contestBrowse";
import { Card, CardContent } from "@ulticode/design-system/ui/card";
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from "@ulticode/design-system/ui/tabs";
import { Skeleton } from "@ulticode/design-system/ui/skeleton";
import { Button } from "@ulticode/design-system/ui/button";
import { Separator } from "@ulticode/design-system/ui/separator";
import ContestCard from "./components/ContestCard.vue";
import { usePastContestsPager } from "@/composables/contest/usePastContestsPager";
import type { ContestListItem } from "@/types/contest";

const props = defineProps<{
  initialTab?: string;
}>();

const route = useRoute();
const router = useRouter();
const { t } = useI18n();
const contestStore = useContestBrowseStore();
const pastPager = usePastContestsPager();

// Store state
const { upcomingContests, runningContests, pastContests, loadingContests } =
  storeToRefs(contestStore);
const {
  page: currentPage,
  totalPages,
  loading: pastLoading,
  error: pastError,
} = pastPager;

// Local state
const activeTab = ref<string>("ongoing");
const initialLoading = ref(true);

const listRequest = createValueRequest({
  errorMessage: "Failed to load contests",
});
const listError = listRequest.error;

function loadLists() {
  return listRequest.run(() => contestStore.loadContests());
}

// Get contests based on active tab
const currentContests = computed<ContestListItem[]>(() => {
  switch (activeTab.value) {
    case "ongoing":
      return runningContests.value;
    case "upcoming":
      return upcomingContests.value;
    case "finished":
      return pastContests.value;
    default:
      return runningContests.value;
  }
});

const hasContests = computed(() => currentContests.value.length > 0);

function retryPastPage(): void {
  void pastPager.loadPage().catch(() => {
    // The pager owns and exposes the transition error state.
  });
}

// Watch for tab changes to update URL
watch(activeTab, (newTab) => {
  router.replace({ query: { ...route.query, tab: newTab } });
});

// Load data
async function loadData() {
  try {
    // Resolve initial tab: prop > query > default
    const allowedTabs = ["ongoing", "upcoming", "finished"];
    const resolvedTab =
      props.initialTab && allowedTabs.includes(props.initialTab)
        ? props.initialTab
        : allowedTabs.includes(route.query.tab as string)
          ? (route.query.tab as string)
          : "ongoing";
    activeTab.value = resolvedTab;

    await Promise.allSettled([loadLists(), pastPager.loadInitialPage()]);
  } catch {
    // Error handled by UI state
  } finally {
    initialLoading.value = false;
  }
}

// Initialize on mount
onMounted(loadData);
</script>

<template>
  <div
    class="max-w-7xl mx-auto w-full space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-10"
  >
    <!-- Page Header -->
    <div
      class="flex flex-col md:flex-row md:items-center justify-between gap-4"
    >
      <div class="space-y-1">
        <div class="flex items-center gap-3">
          <Trophy class="h-8 w-8 text-status-warning-mark" />
          <h1 class="text-3xl font-bold tracking-tight text-foreground">
            {{ t("contest.list.title") }}
          </h1>
        </div>
        <p class="text-muted-foreground">
          {{ t("contest.list.subtitle") }}
        </p>
      </div>
    </div>

    <Separator />

    <!-- Loading State -->
    <div
      v-if="initialLoading"
      role="status"
      class="flex flex-col items-center justify-center py-20"
    >
      <div
        class="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent"
      ></div>
      <p class="mt-4 text-sm text-muted-foreground">
        {{ t("contest.list.loading") }}
      </p>
    </div>

    <!-- Main Content -->
    <div v-else class="space-y-6">
      <!-- Tabbed Navigation -->
      <Tabs
        v-model="activeTab"
        class="w-full"
        :aria-busy="loadingContests || pastLoading"
      >
        <TabsList
          class="p-1 group-data-horizontal/tabs:h-auto sm:group-data-horizontal/tabs:h-12 w-full sm:w-auto grid grid-cols-3"
        >
          <TabsTrigger
            value="ongoing"
            class="h-auto min-w-0 flex-col gap-1 px-2 py-2 whitespace-normal sm:flex-row sm:gap-2 sm:px-6"
          >
            <PlayCircle class="h-4 w-4" />
            <span>{{ t("contest.list.running") }}</span>
            <span
              v-if="
                !loadingContests && !listError && runningContests.length > 0
              "
              class="ml-1 flex h-5 w-5 items-center justify-center rounded-full border border-status-error-mark bg-status-error-surface text-xs font-bold text-foreground"
            >
              {{ runningContests.length }}
            </span>
          </TabsTrigger>
          <TabsTrigger
            value="upcoming"
            class="h-auto min-w-0 flex-col gap-1 px-2 py-2 whitespace-normal sm:flex-row sm:gap-2 sm:px-6"
          >
            <Calendar class="h-4 w-4" />
            <span>{{ t("contest.list.upcoming") }}</span>
          </TabsTrigger>
          <TabsTrigger
            value="finished"
            class="h-auto min-w-0 flex-col gap-1 px-2 py-2 whitespace-normal sm:flex-row sm:gap-2 sm:px-6"
          >
            <CheckCircle class="h-4 w-4" />
            <span>{{ t("contest.list.finished") }}</span>
          </TabsTrigger>
        </TabsList>

        <div
          v-if="listError && activeTab !== 'finished'"
          role="alert"
          class="mt-6 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border p-4"
        >
          <p
            class="min-w-0 flex-1 text-sm text-destructive [overflow-wrap:anywhere]"
          >
            {{ t("contest.list.loadError") }}
          </p>
          <RetryButton @retry="!loadingContests && loadLists()" />
        </div>

        <!-- Ongoing Contests Tab -->
        <TabsContent v-if="!listError" value="ongoing" class="mt-6 space-y-6">
          <!-- Loading Skeletons -->
          <div
            v-if="loadingContests"
            class="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
          >
            <Card v-for="i in 3" :key="i">
              <CardContent class="p-5 space-y-4">
                <Skeleton class="h-4 w-20" />
                <Skeleton class="h-6 w-3/4" />
                <div class="space-y-2">
                  <Skeleton class="h-4 w-full" />
                  <Skeleton class="h-4 w-2/3" />
                </div>
                <Skeleton class="h-10 w-full" />
              </CardContent>
            </Card>
          </div>

          <!-- Contest Cards Grid -->
          <div
            v-else-if="hasContests"
            class="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
          >
            <ContestCard
              v-for="contest in currentContests"
              :key="contest.id"
              :contest="contest"
              variant="default"
            />
          </div>

          <!-- Empty State -->
          <div
            v-else
            class="flex flex-col items-center justify-center py-16 border-2 border-dashed rounded-lg bg-muted/5 text-center px-6"
          >
            <PlayCircle class="h-12 w-12 text-muted-foreground/30 mb-4" />
            <h3 class="text-lg font-bold">
              {{ t("contest.list.noContests") }}
            </h3>
            <p class="text-sm text-muted-foreground mt-1 max-w-[300px]">
              {{ t("contest.list.noContestsHint") }}
            </p>
          </div>
        </TabsContent>

        <!-- Upcoming Contests Tab -->
        <TabsContent v-if="!listError" value="upcoming" class="mt-6 space-y-6">
          <!-- Loading Skeletons -->
          <div
            v-if="loadingContests"
            class="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
          >
            <Card v-for="i in 3" :key="i">
              <CardContent class="p-5 space-y-4">
                <Skeleton class="h-4 w-20" />
                <Skeleton class="h-6 w-3/4" />
                <div class="space-y-2">
                  <Skeleton class="h-4 w-full" />
                  <Skeleton class="h-4 w-2/3" />
                </div>
                <Skeleton class="h-10 w-full" />
              </CardContent>
            </Card>
          </div>

          <!-- Contest Cards Grid -->
          <div
            v-else-if="hasContests"
            class="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
          >
            <ContestCard
              v-for="contest in currentContests"
              :key="contest.id"
              :contest="contest"
              variant="default"
            />
          </div>

          <!-- Empty State -->
          <div
            v-else
            class="flex flex-col items-center justify-center py-16 border-2 border-dashed rounded-lg bg-muted/5 text-center px-6"
          >
            <Calendar class="h-12 w-12 text-muted-foreground/30 mb-4" />
            <h3 class="text-lg font-bold">
              {{ t("contest.list.noContests") }}
            </h3>
            <p class="text-sm text-muted-foreground mt-1 max-w-[300px]">
              {{ t("contest.list.noUpcomingHint") }}
            </p>
          </div>
        </TabsContent>

        <!-- Finished Contests Tab -->
        <TabsContent value="finished" class="mt-6 space-y-6">
          <div
            v-if="pastError"
            role="alert"
            class="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border p-4"
          >
            <p
              class="min-w-0 flex-1 text-sm text-destructive [overflow-wrap:anywhere]"
            >
              {{ t("contest.list.loadError") }}
            </p>
            <RetryButton @retry="!pastLoading && retryPastPage()" />
          </div>
          <!-- Loading Skeletons -->
          <div
            v-else-if="pastLoading"
            class="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
          >
            <Card v-for="i in 3" :key="i">
              <CardContent class="p-5 space-y-4">
                <Skeleton class="h-4 w-20" />
                <Skeleton class="h-6 w-3/4" />
                <div class="space-y-2">
                  <Skeleton class="h-4 w-full" />
                  <Skeleton class="h-4 w-2/3" />
                </div>
                <Skeleton class="h-10 w-full" />
              </CardContent>
            </Card>
          </div>

          <!-- Contest Cards Grid -->
          <div
            v-else-if="hasContests"
            class="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
          >
            <ContestCard
              v-for="contest in currentContests"
              :key="contest.id"
              :contest="contest"
              variant="default"
            />
          </div>

          <!-- Empty State -->
          <div
            v-else
            class="flex flex-col items-center justify-center py-16 border-2 border-dashed rounded-lg bg-muted/5 text-center px-6"
          >
            <CheckCircle class="h-12 w-12 text-muted-foreground/30 mb-4" />
            <h3 class="text-lg font-bold">
              {{ t("contest.list.noContests") }}
            </h3>
            <p class="text-sm text-muted-foreground mt-1 max-w-[300px]">
              {{ t("contest.list.noFinishedHint") }}
            </p>
          </div>

          <!-- Pagination for finished contests -->
          <div
            v-if="
              !pastError &&
              hasContests &&
              activeTab === 'finished' &&
              totalPages > 1
            "
            class="flex items-center justify-center gap-2 pt-4"
          >
            <Button
              variant="outline"
              size="icon"
              class="w-9"
              :disabled="currentPage === 1 || pastLoading"
              @click="currentPage--"
            >
              <span class="sr-only">Previous page</span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
                stroke-linecap="round"
                stroke-linejoin="round"
              >
                <path d="m15 18-6-6 6-6" />
              </svg>
            </Button>
            <span class="text-sm text-muted-foreground">
              {{ currentPage }} / {{ totalPages }}
            </span>
            <Button
              variant="outline"
              size="icon"
              class="w-9"
              :disabled="currentPage === totalPages || pastLoading"
              @click="currentPage++"
            >
              <span class="sr-only">Next page</span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
                stroke-linecap="round"
                stroke-linejoin="round"
              >
                <path d="m9 18 6-6-6-6" />
              </svg>
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  </div>
</template>
