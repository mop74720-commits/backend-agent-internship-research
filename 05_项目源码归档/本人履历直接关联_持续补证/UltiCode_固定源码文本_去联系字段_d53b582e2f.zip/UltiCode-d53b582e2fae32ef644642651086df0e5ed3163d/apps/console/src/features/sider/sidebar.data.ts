import type { Component } from "vue";
import {
  Flame,
  LayoutGrid,
  TrendingUp,
  Globe,
  Home,
  Trophy,
  History,
  MessageSquare,
  FileText,
  HelpCircle,
  User,
  List,
  Bookmark,
  CheckCircle2,
  Bell,
  Lock,
} from "@lucide/vue";

export interface SidebarItem {
  title: string;
  label?: string;
  url?: string;
  icon?: Component;
  isActive?: boolean;
  isExpanded?: boolean;
  badge?: string;
  badgeVariant?: "default" | "secondary" | "destructive" | "outline";
  children?: SidebarItem[];
  action?: () => void;
  requiresAuth?: boolean;
}

export interface SidebarSection {
  name: string;
  items: SidebarItem[];
  collapsible?: boolean;
  requiresAuth?: boolean;
}

export const forumSidebarData: SidebarSection[] = [
  {
    name: "sidebar.forum.platform",
    items: [
      { title: "sidebar.forum.home", url: "/forum", icon: Home },
      {
        title: "sidebar.forum.popular",
        url: "/forum/popular",
        icon: TrendingUp,
      },
      { title: "sidebar.forum.explore", url: "/forum/explore", icon: Globe },
      { title: "sidebar.forum.allPosts", url: "/forum/all", icon: LayoutGrid },
    ],
  },
  {
    name: "sidebar.forum.mySpace",
    collapsible: true,
    requiresAuth: true,
    items: [
      {
        title: "sidebar.forum.myPosts",
        url: "/personal/forum-posts",
        icon: MessageSquare,
      },
      {
        title: "sidebar.forum.savedPosts",
        url: "/personal/bookmarks",
        icon: Bookmark,
      },
    ],
  },
  {
    name: "sidebar.forum.categories",
    collapsible: true,
    items: [],
  },
  {
    name: "sidebar.forum.resources",
    collapsible: true,
    items: [
      {
        title: "sidebar.forum.guidelines",
        url: "/forum/guidelines",
        icon: FileText,
      },
      {
        title: "sidebar.forum.feedback",
        url: "/forum/feedback",
        icon: HelpCircle,
      },
    ],
  },
];

import { PROBLEM_CATEGORIES } from "@/constants/problem-categories";

export const problemSidebarData: SidebarSection[] = [
  {
    name: "sidebar.problem.problemSet",
    items: [...PROBLEM_CATEGORIES] as unknown as SidebarItem[],
  },
];

export const contestSidebarData: SidebarSection[] = [
  {
    name: "sidebar.contest.contestSection",
    items: [
      { title: "sidebar.contest.contestHome", url: "/contest", icon: Home },
      {
        title: "sidebar.contest.pastContests",
        url: "/contest/past",
        icon: History,
      },
      {
        title: "sidebar.contest.myContests",
        url: "/contest/my",
        icon: Trophy,
        requiresAuth: true,
      },
    ],
  },
  {
    name: "sidebar.contest.ranking",
    collapsible: true,
    items: [
      {
        title: "sidebar.contest.globalRanking",
        url: "/contest/global-ranking",
        icon: Globe,
      },
      {
        title: "sidebar.contest.localRanking",
        url: "/contest/local-ranking",
        icon: Flame,
      },
    ],
  },
];

export const personalSidebarData: SidebarSection[] = [
  {
    name: "sidebar.personal.accountSettings",
    collapsible: true,
    requiresAuth: true,
    items: [
      {
        title: "sidebar.personal.accountSettingsGeneral",
        url: "/personal/account/general",
        icon: User,
      },
      {
        title: "sidebar.personal.accountSettingsSecurity",
        url: "/personal/account/security",
        icon: Lock,
      },
      {
        title: "sidebar.personal.accountSettingsNotifications",
        url: "/personal/account/notifications",
        icon: Bell,
      },
    ],
  },
  {
    name: "sidebar.personal.profile",
    requiresAuth: true,
    items: [
      { title: "sidebar.personal.profile", url: "/personal", icon: User },
    ],
  },
  {
    name: "sidebar.personal.notifications",
    requiresAuth: true,
    items: [
      {
        title: "sidebar.personal.notifications",
        url: "/personal/notifications",
        icon: Bell,
      },
    ],
  },
  {
    name: "sidebar.personal.activity",
    requiresAuth: true,
    items: [
      {
        title: "sidebar.personal.submissions",
        url: "/personal/submissions",
        icon: History,
      },
      { title: "sidebar.personal.agent", url: "/agent", icon: MessageSquare },
      {
        title: "sidebar.personal.solutions",
        url: "/personal/solutions",
        icon: CheckCircle2,
      },
      {
        title: "sidebar.personal.problemLists",
        url: "/personal/problem-lists",
        icon: List,
      },
      {
        title: "sidebar.personal.forumPosts",
        url: "/personal/forum-posts",
        icon: MessageSquare,
      },
      {
        title: "sidebar.personal.bookmarks",
        url: "/personal/bookmarks",
        icon: Bookmark,
      },
    ],
  },
];
