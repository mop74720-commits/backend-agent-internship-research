<script setup lang="ts">
import { ref } from "vue";
import { useI18n } from "vue-i18n";
import { Button } from "@ulticode/design-system/ui/button";
import { Kbd } from "@ulticode/design-system/ui/kbd";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@ulticode/design-system/ui/tooltip";
import { Search } from "@lucide/vue";
import GlobalSearch from "./GlobalSearch.vue";

const { t } = useI18n();
const showSearch = ref(false);
const shortcutLabel = /Mac|iPhone|iPad|iPod/.test(navigator.userAgent)
  ? "⌘ K"
  : "Ctrl K";

function openSearch() {
  showSearch.value = true;
}
</script>

<template>
  <div>
    <Tooltip>
      <TooltipTrigger as-child>
        <Button
          variant="outline"
          size="sm"
          class="uc-header-search"
          :aria-label="t('common.actions.search')"
          @click="openSearch"
        >
          <Search data-icon="inline-start" />
          <span class="hidden sm:inline">{{ t("common.actions.search") }}</span>
          <Kbd class="ml-auto hidden lg:inline-flex">{{ shortcutLabel }}</Kbd>
        </Button>
      </TooltipTrigger>
      <TooltipContent side="bottom">
        {{ t("common.actions.search") }} · {{ shortcutLabel }}
      </TooltipContent>
    </Tooltip>

    <GlobalSearch v-model:open="showSearch" />
  </div>
</template>
