<template>
  <div
    class="comment-node @container/comment relative grid min-w-0 grid-cols-[2rem_minmax(0,1fr)] gap-x-2"
  >
    <!-- Left Side: Avatar & Rail -->
    <div
      class="flex flex-col items-center flex-shrink-0 w-8 relative"
      ref="containerRef"
    >
      <!-- Curve Connector (Child draws this to connect to parent's rail) -->
      <CommentConnector
        :depth="depth"
        :is-active="isParentRailHovered"
        class="hidden @min-[24rem]/comment:block"
      />

      <!-- Parent Rail (I draw this for MY children) -->
      <CommentRail
        v-if="!isCollapsed && hasChildren"
        :height="railHeight"
        :is-active="isRailHovered"
        @click="toggleCollapse"
        @mouseenter="isRailHovered = true"
        @mouseleave="isRailHovered = false"
      />

      <!-- Avatar -->
      <div
        v-if="!isCollapsed"
        class="w-8 h-8 rounded-full overflow-hidden z-10 cursor-pointer border border-transparent hover:border-foreground/10 transition-all relative bg-background"
      >
        <div
          class="w-full h-full flex items-center justify-center text-foreground font-bold text-xs bg-muted"
        >
          <img
            v-if="comment.avatar"
            :src="comment.avatar"
            :alt="comment.author"
            class="w-full h-full object-cover"
          />
          <span v-else>{{ comment.author[0]?.toUpperCase() }}</span>
        </div>
      </div>

      <!-- Collapsed State Icon -->
      <div
        v-else
        class="mt-1 cursor-pointer hover:bg-accent p-1 rounded z-10"
        @click="toggleCollapse"
      >
        <Maximize2 class="h-3.5 w-3.5 text-muted-foreground" />
      </div>
    </div>

    <!-- Right Side: Content -->
    <div class="min-w-0">
      <!-- Header -->
      <div
        class="flex flex-wrap items-center gap-x-2 gap-y-1 mb-1 text-xs min-h-8"
      >
        <span
          class="break-words [overflow-wrap:anywhere] font-bold hover:underline cursor-pointer"
          :class="{ 'text-primary': comment.isOp }"
          @click="toggleCollapse"
        >
          {{ comment.author }}
        </span>
        <Badge v-if="comment.isOp" variant="secondary" class="px-1 h-3.5">
          {{ t("forum.author.op") }}
        </Badge>
        <span class="text-muted-foreground">•</span>
        <span
          class="text-muted-foreground hover:underline cursor-pointer"
          @click="toggleCollapse"
        >
          {{ comment.time }}
        </span>
        <span v-if="comment.editedAt" class="text-muted-foreground/60 text-xs"
          >({{ t("forum.comments.edited") }})</span
        >
        <span
          v-if="isCollapsed"
          class="text-muted-foreground text-xs italic ml-2 cursor-pointer select-none"
          @click="toggleCollapse"
        >
          {{ t("forum.comments.collapsed") }}
        </span>
        <span
          v-if="comment.replyCount && comment.replyCount > 0"
          class="text-muted-foreground/60 text-xs ml-auto"
        >
          {{ comment.replyCount }} {{ t("forum.comments.replies") }}
        </span>
      </div>

      <div v-if="!isCollapsed">
        <!-- Content Body -->
        <div v-if="!isEditing">
          <div class="text-sm break-words pr-4 mb-2">
            <MarkdownView
              :content="comment.content"
              :editor-id="`comment-${comment.id}`"
            />
          </div>

          <!-- Actions -->
          <div class="flex flex-wrap items-center gap-1 mt-2 select-none">
            <VoteControl
              :likes="likes"
              :dislikes="dislikes"
              :user-vote="userVote"
              class="origin-left"
              @vote="handleVote"
            />

            <ActionItem
              ref="replyTrigger"
              variant="button"
              :icon="MessageSquare"
              :label="t('common.actions.reply')"
              :aria-label="t('common.actions.reply')"
              @click="toggleReply"
            />
            <ActionItem
              variant="button"
              :icon="Share2"
              :label="t('common.actions.share')"
              :aria-label="t('common.actions.share')"
            />

            <DropdownMenu v-if="comment.isOwn">
              <DropdownMenuTrigger as-child>
                <Button
                  variant="ghost"
                  class="flex items-center gap-2 px-2 py-1"
                >
                  <MoreHorizontal class="h-4.5 w-4.5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start">
                <DropdownMenuGroup
                  ><DropdownMenuItem @click="toggleEdit" class="gap-2">
                    <Pencil class="h-3.5 w-3.5" />
                    {{ t("common.actions.edit") }}
                  </DropdownMenuItem>
                  <DropdownMenuItem class="gap-2" @click="handleDeleteClick">
                    <Trash2 class="h-3.5 w-3.5" />
                    {{ t("common.actions.delete") }}
                  </DropdownMenuItem></DropdownMenuGroup
                >
              </DropdownMenuContent>
            </DropdownMenu>
            <Button
              variant="ghost"
              v-else
              class="flex items-center gap-2 px-2 py-1"
              @click="handleReport"
            >
              <Flag class="h-4.5 w-4.5" />
            </Button>
          </div>
        </div>

        <!-- Edit Form -->
        <div v-if="isEditing" class="mb-3 mt-2">
          <CommentForm
            :parent-id="comment.id"
            :initial-content="comment.content"
            :on-cancel="() => (isEditing = false)"
            @submit="handleEditSubmit"
          />
        </div>

        <!-- Reply Input -->
        <div v-if="isReplying" class="mt-3 mb-2">
          <CommentForm
            :parent-id="comment.id"
            :on-cancel="cancelReply"
            @submit="handleReplySubmit"
          />
        </div>
      </div>
    </div>

    <!-- Children Container -->
    <div
      v-if="!isCollapsed && hasChildren"
      class="col-span-2 min-w-0 mt-2 @min-[12rem]/comment:ps-2 @min-[24rem]/comment:ps-0 @min-[24rem]/comment:col-span-1 @min-[24rem]/comment:col-start-2"
      ref="childrenContainerRef"
    >
      <div
        v-for="(child, index) in comment.children"
        :key="child.id"
        :ref="(el) => setLastChildRef(el, index)"
      >
        <CommentNode
          :comment="child"
          :depth="depth + 1"
          :is-parent-rail-hovered="isRailHovered"
          @reply="(id, content) => emit('reply', id, content)"
          @vote="(id, type) => emit('vote', id, type)"
          @edit="(id, content) => emit('edit', id, content)"
          @delete="(id) => emit('delete', id)"
        />
      </div>
    </div>

    <AlertDialog
      :open="showDeleteDialog"
      @update:open="showDeleteDialog = $event"
    >
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>{{
            t("forum.comments.deleteDialog.title")
          }}</AlertDialogTitle>
          <AlertDialogDescription>
            {{ t("forum.comments.deleteDialog.description") }}
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter class="gap-2 sm:gap-0">
          <AlertDialogCancel>{{
            t("forum.comments.deleteDialog.cancel")
          }}</AlertDialogCancel>
          <AlertDialogAction @click="confirmDelete">
            {{ t("forum.comments.deleteDialog.confirm") }}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>

    <ReportDialog
      ref="reportDialogRef"
      entity-type="forum_comment"
      :entity-id="String(comment.id)"
    />
  </div>
</template>

<script setup lang="ts">
import { Button } from "@ulticode/design-system/ui/button";

import {
  ref,
  computed,
  onMounted,
  onBeforeUnmount,
  nextTick,
  watch,
  type ComponentPublicInstance,
} from "vue";
import type { Comment } from "@/types/comment";
import CommentConnector from "./CommentConnector.vue";
import CommentRail from "./CommentRail.vue";
import CommentForm from "./CommentForm.vue";
import MarkdownView from "@/components/markdown/MarkdownView.vue";
import { ActionItem, VoteControl } from "@/components/edge-operations";
import { Badge } from "@ulticode/design-system/ui/badge";
import ReportDialog from "@/components/ReportDialog.vue";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuGroup,
} from "@ulticode/design-system/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@ulticode/design-system/ui/alert-dialog";
import {
  MessageSquare,
  Share2,
  MoreHorizontal,
  Maximize2,
  Flag,
  Pencil,
  Trash2,
} from "@lucide/vue";
import { useI18n } from "vue-i18n";

defineOptions({
  name: "CommentNode",
});

const props = withDefaults(
  defineProps<{
    comment: Comment;
    depth?: number;
    isParentRailHovered?: boolean;
  }>(),
  {
    depth: 0,
    isParentRailHovered: false,
  },
);

const emit = defineEmits<{
  (e: "reply", commentId: number | string, content: string): void;
  (e: "vote", commentId: number | string, voteType: 1 | -1): void;
  (e: "edit", commentId: number | string, content: string): void;
  (e: "delete", commentId: number | string): void;
}>();

const { t } = useI18n();

const isCollapsed = ref(false);
const isRailHovered = ref(false);
const isReplying = ref(false);
const isEditing = ref(false);
const showDeleteDialog = ref(false);
const reportDialogRef = ref<{ open: () => void } | null>(null);

const containerRef = ref<HTMLElement | null>(null);
const replyTrigger = ref<ComponentPublicInstance | null>(null);
const childrenContainerRef = ref<HTMLElement | null>(null);
const lastChildEl = ref<HTMLElement | null>(null);
const railHeight = ref(0);

const hasChildren = computed(() => (props.comment.children?.length ?? 0) > 0);
const userVote = ref(props.comment.userVote ?? 0);
const likes = ref(props.comment.likes ?? 0);
const dislikes = ref(props.comment.dislikes ?? 0);

// Update local state if props change (though usually we just rely on parent re-rendering)
watch(
  () => props.comment.userVote,
  (newVal) => {
    userVote.value = newVal ?? 0;
  },
);
watch(
  () => props.comment.likes,
  (newVal) => {
    likes.value = newVal ?? 0;
  },
);
watch(
  () => props.comment.dislikes,
  (newVal) => {
    dislikes.value = newVal ?? 0;
  },
);

const setLastChildRef = (
  el: ComponentPublicInstance | Element | null,
  index: number,
) => {
  if (index === (props.comment.children?.length ?? 0) - 1) {
    // If it's a component, get $el, otherwise use el directly
    lastChildEl.value = (el as ComponentPublicInstance)?.$el ?? el;
  }
};

const calculateRailHeight = () => {
  if (
    !isCollapsed.value &&
    hasChildren.value &&
    containerRef.value &&
    lastChildEl.value
  ) {
    const containerRect = containerRef.value.getBoundingClientRect();
    const lastChildRect = lastChildEl.value.getBoundingClientRect();

    // We want the line to end where the curve of the last child starts
    // In React code: lastChildCurveStartY = lastChildRect.top + 4;
    // The connector top is at child top. The curve starts at roughly 0 relative to child.
    // Let's match the React logic: `lastChildRect.top + 4 - containerTop`

    // Wait, the connector in React is `absolute -left-6 top-0`.
    // The curve M moves to `startY`.
    // The logic in React: `const lastChildCurveStartY = lastChildRect.top + 4;`

    const containerTop = containerRect.top;
    const lastChildTop = lastChildRect.top;

    // 4px seems to be an arbitrary offset used in the React example for visual alignment
    const distance = lastChildTop + 4 - containerTop;

    railHeight.value = distance;
  }
};

let resizeObserver: ResizeObserver | null = null;

onMounted(() => {
  calculateRailHeight();

  if (childrenContainerRef.value) {
    resizeObserver = new ResizeObserver(() => {
      calculateRailHeight();
    });
    resizeObserver.observe(childrenContainerRef.value);
  }
});

onBeforeUnmount(() => {
  if (resizeObserver) {
    resizeObserver.disconnect();
  }
});

watch([isCollapsed, hasChildren], () => {
  nextTick(calculateRailHeight);
});

const toggleCollapse = () => {
  isCollapsed.value = !isCollapsed.value;
};

const toggleReply = () => {
  isReplying.value = !isReplying.value;
};

const cancelReply = async () => {
  isReplying.value = false;
  await nextTick();
  const trigger = replyTrigger.value?.$el;
  if (trigger instanceof HTMLElement) trigger.focus({ preventScroll: true });
};

const toggleEdit = () => {
  isEditing.value = !isEditing.value;
};

const handleReplySubmit = (content: string) => {
  emit("reply", props.comment.id, content);
  isReplying.value = false;
  isCollapsed.value = false;
};

const handleEditSubmit = (content: string) => {
  emit("edit", props.comment.id, content);
  isEditing.value = false;
};

const handleDeleteClick = () => {
  showDeleteDialog.value = true;
};

const confirmDelete = () => {
  emit("delete", props.comment.id);
  showDeleteDialog.value = false;
};

const handleReport = () => {
  reportDialogRef.value?.open();
};

const handleVote = (type: 1 | -1) => {
  // Optimistic update
  if (userVote.value === type) {
    // toggle off
    userVote.value = 0;
    if (type === 1) {
      likes.value = Math.max(0, likes.value - 1);
    } else {
      dislikes.value = Math.max(0, dislikes.value - 1);
    }
    emit("vote", props.comment.id, type); // Backend handles toggle logic usually
  } else {
    // switch or new vote
    if (userVote.value === 1) {
      likes.value = Math.max(0, likes.value - 1);
    } else if (userVote.value === -1) {
      dislikes.value = Math.max(0, dislikes.value - 1);
    }
    if (type === 1) {
      likes.value += 1;
    } else {
      dislikes.value += 1;
    }
    userVote.value = type;
    emit("vote", props.comment.id, type);
  }
};
</script>
