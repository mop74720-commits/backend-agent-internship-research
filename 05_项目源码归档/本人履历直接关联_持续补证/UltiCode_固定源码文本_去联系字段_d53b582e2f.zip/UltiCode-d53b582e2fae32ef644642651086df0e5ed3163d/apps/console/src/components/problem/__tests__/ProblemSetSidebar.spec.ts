import { describe, it, expect, vi, beforeEach } from "vitest";
import { mount, flushPromises, RouterLinkStub } from "@vue/test-utils";
import { createPinia, setActivePinia } from "pinia";
import type * as VueI18n from "vue-i18n";
import ProblemSetSidebar from "../ProblemSetSidebar.vue";
import { fetchRandomProblem } from "@/api/problem";
import type { Problem } from "@/types/problem";

vi.mock("@/api/problem", () => ({
  fetchRandomProblem: vi.fn(),
}));

vi.mock("@/api/submission", () => ({
  fetchDailyActivity: vi.fn(),
}));

vi.mock("vue-i18n", async (importOriginal) => ({
  ...(await importOriginal<typeof VueI18n>()),
  useI18n: () => ({
    t: (key: string) => key,
    locale: { value: "en-US" },
  }),
}));

vi.mock("@ulticode/design-system/ui/calendar", () => ({
  Calendar: { template: '<div class="calendar-stub" />' },
}));

vi.mock("@ulticode/design-system/ui/card", () => ({
  Card: { template: "<div><slot /></div>" },
  CardContent: { template: "<div><slot /></div>" },
  CardHeader: { template: "<div><slot /></div>" },
  CardTitle: { template: "<div><slot /></div>" },
}));

vi.mock("@ulticode/design-system/ui/badge", () => ({
  Badge: { template: "<span><slot /></span>" },
}));

vi.mock("@lucide/vue", () => ({
  Trophy: { template: "<svg />" },
  ChevronDown: { template: "<svg />" },
  ChevronUp: { template: "<svg />" },
}));

describe("ProblemSetSidebar", () => {
  beforeEach(() => {
    setActivePinia(createPinia());
    vi.clearAllMocks();
  });

  it("keeps the compact week view expandable when content space is narrow", async () => {
    vi.mocked(fetchRandomProblem).mockRejectedValueOnce(
      new Error("No problem"),
    );
    const wrapper = mount(ProblemSetSidebar);
    await flushPromises();
    const content = wrapper.find('[class*="max-h"]');
    expect(content.classes()).toContain("max-h-0");
    await wrapper
      .find('[aria-label="problem.sidebar.toggleCalendar"]')
      .trigger("click");
    expect(content.classes()).toContain("max-h-[180px]");
    await wrapper
      .find('[aria-label="problem.sidebar.toggleCalendar"]')
      .trigger("click");
    expect(content.classes()).toContain("max-h-0");
    wrapper.unmount();
  });

  it("fetches random problem dynamically on mount", async () => {
    const mockProblem: Problem = {
      id: 42,
      title: "两数之和",
      slug: "two-sum",
      difficulty: "EASY",
      acceptance_rate: 50.0,
      tags: [],
    };
    vi.mocked(fetchRandomProblem).mockResolvedValueOnce(mockProblem);

    const wrapper = mount(ProblemSetSidebar, {
      global: {
        stubs: {
          RouterLink: RouterLinkStub,
        },
      },
    });
    await flushPromises();

    expect(fetchRandomProblem).toHaveBeenCalledTimes(1);
    expect(wrapper.text()).toContain("problem.sidebar.todayProblem");
    expect(wrapper.text()).toContain("两数之和");
    const link = wrapper.findComponent(RouterLinkStub);
    expect(link.exists()).toBe(true);
    expect(link.props().to).toBe("/problems/two-sum");
  });

  it("handles empty database or fetch error gracefully without failing", async () => {
    vi.mocked(fetchRandomProblem).mockRejectedValueOnce(
      new Error("No published problems available"),
    );

    const wrapper = mount(ProblemSetSidebar, {
      global: {
        stubs: {
          RouterLink: RouterLinkStub,
        },
      },
    });
    await flushPromises();

    expect(fetchRandomProblem).toHaveBeenCalledTimes(1);
    expect(wrapper.text()).not.toContain("problem.sidebar.todayProblem");
  });
});
