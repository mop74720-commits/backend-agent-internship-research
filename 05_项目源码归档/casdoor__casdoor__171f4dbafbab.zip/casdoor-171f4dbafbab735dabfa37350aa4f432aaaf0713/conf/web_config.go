// Copyright 2026 The Casdoor Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package conf

type WebConfig struct {
	ShowGithubCorner    bool   `json:"showGithubCorner"`
	ForceLanguage       string `json:"forceLanguage"`
	DefaultLanguage     string `json:"defaultLanguage"`
	IsDemoMode          bool   `json:"isDemoMode"`
	StaticBaseUrl       string `json:"staticBaseUrl"`
	DefaultApplication  string `json:"defaultApplication"`
	MaxItemsForFlatMenu int64  `json:"maxItemsForFlatMenu"`
	ThemeShowcase       bool   `json:"themeShowcase"`
	MarketplaceUrl      string `json:"marketplaceUrl"`
}

func GetWebConfig() *WebConfig {
	config := &WebConfig{}

	config.ShowGithubCorner = GetConfigBool("showGithubCorner")
	// an empty forceLanguage means "don't force any language", it must not become "en"
	config.ForceLanguage = GetConfigString("forceLanguage")
	if config.ForceLanguage != "" {
		config.ForceLanguage = GetLanguage(config.ForceLanguage)
	}
	config.DefaultLanguage = GetLanguage(GetConfigString("defaultLanguage"))
	config.IsDemoMode = IsDemoMode()
	config.StaticBaseUrl = GetConfigString("staticBaseUrl")
	config.DefaultApplication = GetConfigString("defaultApplication")
	if config.DefaultApplication == "" {
		config.DefaultApplication = "app-built-in"
	}

	maxItemsForFlatMenu, err := GetConfigInt64("maxItemsForFlatMenu")
	if err != nil {
		maxItemsForFlatMenu = 7
	}
	config.MaxItemsForFlatMenu = maxItemsForFlatMenu

	config.ThemeShowcase = GetConfigBool("themeShowcase") || IsDemoMode() || IsDemoDatabase()
	if config.ThemeShowcase {
		config.MarketplaceUrl = GetConfigString("marketplaceUrl")
	}

	return config
}
