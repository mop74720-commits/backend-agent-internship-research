// Copyright 2022 The Casdoor Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package controllers

type TokenRequest struct {
	Assertion           string `json:"assertion"`
	ClientId            string `json:"client_id"`
	ClientSecret        string `json:"client_secret"`
	ClientAssertion     string `json:"client_assertion"`
	ClientAssertionType string `json:"client_assertion_type"`
	GrantType           string `json:"grant_type"`
	Code                string `json:"code"`
	Verifier            string `json:"code_verifier"`
	Scope               string `json:"scope"`
	Nonce               string `json:"nonce"`
	Username            string `json:"username"`
	Password            string `json:"password"`
	CountryCode         string `json:"country_code"`
	Tag                 string `json:"tag"`
	Avatar              string `json:"avatar"`
	RefreshToken        string `json:"refresh_token"`
	SubjectToken        string `json:"subject_token"`
	SubjectTokenType    string `json:"subject_token_type"`
	Audience            string `json:"audience"`
	Resource            string `json:"resource"` // RFC 8707 Resource Indicator
}
