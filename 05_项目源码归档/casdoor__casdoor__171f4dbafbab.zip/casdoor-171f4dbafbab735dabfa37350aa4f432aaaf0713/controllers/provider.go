// Copyright 2021 The Casdoor Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package controllers

import (
	"encoding/json"

	"github.com/beego/beego/v2/core/utils/pagination"
	"github.com/casdoor/casdoor/conf"
	"github.com/casdoor/casdoor/idp"
	"github.com/casdoor/casdoor/object"
	"github.com/casdoor/casdoor/util"
)

// GetProviders
// @Title GetProviders
// @Tag Provider API
// @Description get providers
// @Param   owner     query    string  true        "The owner of providers"
// @Success 200 {array} object.Provider The Response object
// @router /get-providers [get]
func (c *ApiController) GetProviders() {
	owner := c.Ctx.Input.Query("owner")
	limit := c.Ctx.Input.Query("pageSize")
	page := c.Ctx.Input.Query("p")
	field := c.Ctx.Input.Query("field")
	value := c.Ctx.Input.Query("value")
	sortField := c.Ctx.Input.Query("sortField")
	sortOrder := c.Ctx.Input.Query("sortOrder")

	ok, isMaskEnabled := c.IsMaskedEnabled()
	if !ok {
		return
	}

	if limit == "" || page == "" {
		providers, err := object.GetProviders(owner)
		if err != nil {
			c.ResponseError(err.Error())
			return
		}

		c.ResponseOk(c.getMaskedProviders(providers, isMaskEnabled))
	} else {
		limit := util.ParseInt(limit)
		count, err := object.GetProviderCount(owner, field, value)
		if err != nil {
			c.ResponseError(err.Error())
			return
		}

		paginator := pagination.NewPaginator(c.Ctx.Request, limit, count)
		paginationProviders, err := object.GetPaginationProviders(owner, paginator.Offset(), limit, field, value, sortField, sortOrder)
		if err != nil {
			c.ResponseError(err.Error())
			return
		}

		providers := c.getMaskedProviders(paginationProviders, isMaskEnabled)
		c.ResponseOk(providers, paginator.Nums())
	}
}

// GetGlobalProviders
// @Title GetGlobalProviders
// @Tag Provider API
// @Description get Global providers
// @Success 200 {array} object.Provider The Response object
// @router /get-global-providers [get]
func (c *ApiController) GetGlobalProviders() {
	if !c.requireGlobalAdmin() {
		return
	}

	limit := c.Ctx.Input.Query("pageSize")
	page := c.Ctx.Input.Query("p")
	field := c.Ctx.Input.Query("field")
	value := c.Ctx.Input.Query("value")
	sortField := c.Ctx.Input.Query("sortField")
	sortOrder := c.Ctx.Input.Query("sortOrder")

	ok, isMaskEnabled := c.IsMaskedEnabled()
	if !ok {
		return
	}

	if limit == "" || page == "" {
		globalProviders, err := object.GetGlobalProviders()
		if err != nil {
			c.ResponseError(err.Error())
			return
		}

		c.ResponseOk(c.getMaskedProviders(globalProviders, isMaskEnabled))
	} else {
		limit := util.ParseInt(limit)
		count, err := object.GetGlobalProviderCount(field, value)
		if err != nil {
			c.ResponseError(err.Error())
			return
		}

		paginator := pagination.NewPaginator(c.Ctx.Request, limit, count)
		paginationGlobalProviders, err := object.GetPaginationGlobalProviders(paginator.Offset(), limit, field, value, sortField, sortOrder)
		if err != nil {
			c.ResponseError(err.Error())
			return
		}

		providers := c.getMaskedProviders(paginationGlobalProviders, isMaskEnabled)
		c.ResponseOk(providers, paginator.Nums())
	}
}

// GetProvider
// @Title GetProvider
// @Tag Provider API
// @Description get provider
// @Param   id     query    string  true        "The id ( owner/name ) of the provider"
// @Success 200 {object} object.Provider The Response object
// @router /get-provider [get]
func (c *ApiController) GetProvider() {
	id := c.Ctx.Input.Query("id")

	ok, isMaskEnabled := c.IsMaskedEnabled()
	if !ok {
		return
	}
	provider, err := object.GetProvider(id)
	if err != nil {
		c.ResponseError(err.Error())
		return
	}

	c.ResponseOk(c.getMaskedProvider(provider, isMaskEnabled))
}

// GetIdpDiscovery
// @Title GetIdpDiscovery
// @Tag Provider API
// @Description get the OIDC discovery document of an upstream identity provider
// @Param   issuer     query    string  true        "The issuer URL of the upstream OIDC identity provider"
// @Success 200 {object} idp.OidcDiscovery The Response object
// @router /get-idp-discovery [get]
func (c *ApiController) GetIdpDiscovery() {
	if _, ok := c.RequireAdmin(); !ok {
		return
	}

	issuer := c.Ctx.Input.Query("issuer")

	discovery, err := idp.GetOidcDiscoveryByAdmin(issuer, c.IsGlobalAdmin())
	if err != nil {
		c.ResponseError(err.Error())
		return
	}

	c.ResponseOk(discovery)
}

func (c *ApiController) requireProviderPermission(provider *object.Provider) bool {
	isGlobalAdmin, user := c.isGlobalAdmin()
	if isGlobalAdmin {
		return true
	}

	if provider.Owner == "admin" || user.Owner != provider.Owner {
		c.ResponseError(c.T("auth:Unauthorized operation"))
		return false
	}

	return true
}

func (c *ApiController) requireProviderSavePermission(provider *object.Provider) bool {
	if !c.requireProviderPermission(provider) {
		return false
	}

	isServerLocalLog := provider.Category == "Log" && (provider.Type == "System Log" || provider.Type == "SELinux Log" || provider.Type == "Agent")
	if isServerLocalLog && !c.IsGlobalAdmin() {
		c.ResponseError(c.T("auth:Unauthorized operation"))
		return false
	}

	return true
}

func isProviderVisibleToUser(provider *object.Provider, user *object.User) bool {
	return provider.Owner == "admin" || provider.Owner == user.Owner
}

func (c *ApiController) getMaskedProviders(providers []*object.Provider, isMaskEnabled bool) []*object.Provider {
	if isMaskEnabled {
		return object.GetMaskedProviders(providers, true)
	}

	isGlobalAdmin, user := c.isGlobalAdmin()
	for _, provider := range providers {
		isOwnProvider := isGlobalAdmin || (user != nil && user.IsAdmin && user.Owner == provider.Owner)
		object.GetMaskedProvider(provider, !isOwnProvider)
	}
	return providers
}

func (c *ApiController) getMaskedProvider(provider *object.Provider, isMaskEnabled bool) *object.Provider {
	if provider == nil {
		return nil
	}
	return c.getMaskedProviders([]*object.Provider{provider}, isMaskEnabled)[0]
}

// UpdateProvider
// @Title UpdateProvider
// @Tag Provider API
// @Description update provider
// @Param   id     query    string  true        "The id ( owner/name ) of the provider"
// @Param   body    body   object.Provider  true        "The details of the provider"
// @Success 200 {object} controllers.Response The Response object
// @router /update-provider [post]
func (c *ApiController) UpdateProvider() {
	id := c.Ctx.Input.Query("id")

	var provider object.Provider
	err := json.Unmarshal(c.Ctx.Input.RequestBody, &provider)
	if err != nil {
		c.ResponseError(err.Error())
		return
	}

	ok := c.requireProviderSavePermission(&provider)
	if !ok {
		return
	}

	if conf.IsDemoDatabase() {
		oldProvider, err := object.GetProvider(id)
		if err != nil {
			c.ResponseError(err.Error())
			return
		}
		if oldProvider != nil && (provider.Host != oldProvider.Host || provider.Endpoint != oldProvider.Endpoint || provider.Type != oldProvider.Type) {
			c.ResponseError(c.T("general:this operation is not allowed in demo mode"))
			return
		}
	}

	c.Data["json"] = wrapActionResponse(object.UpdateProvider(id, &provider))
	c.ServeJSON()
}

// AddProvider
// @Title AddProvider
// @Tag Provider API
// @Description add provider
// @Param   body    body   object.Provider  true        "The details of the provider"
// @Success 200 {object} controllers.Response The Response object
// @router /add-provider [post]
func (c *ApiController) AddProvider() {
	var provider object.Provider
	err := json.Unmarshal(c.Ctx.Input.RequestBody, &provider)
	if err != nil {
		c.ResponseError(err.Error())
		return
	}

	count, err := object.GetProviderCount("", "", "")
	if err != nil {
		c.ResponseError(err.Error())
		return
	}

	err = checkQuotaForProvider(int(count))
	if err != nil {
		c.ResponseError(err.Error())
		return
	}

	ok := c.requireProviderSavePermission(&provider)
	if !ok {
		return
	}

	c.Data["json"] = wrapActionResponse(object.AddProvider(&provider))
	c.ServeJSON()
}

// DeleteProvider
// @Title DeleteProvider
// @Tag Provider API
// @Description delete provider
// @Param   body    body   object.Provider  true        "The details of the provider"
// @Success 200 {object} controllers.Response The Response object
// @router /delete-provider [post]
func (c *ApiController) DeleteProvider() {
	var provider object.Provider
	err := json.Unmarshal(c.Ctx.Input.RequestBody, &provider)
	if err != nil {
		c.ResponseError(err.Error())
		return
	}

	ok := c.requireProviderPermission(&provider)
	if !ok {
		return
	}

	c.Data["json"] = wrapActionResponse(object.DeleteProvider(&provider))
	c.ServeJSON()
}
