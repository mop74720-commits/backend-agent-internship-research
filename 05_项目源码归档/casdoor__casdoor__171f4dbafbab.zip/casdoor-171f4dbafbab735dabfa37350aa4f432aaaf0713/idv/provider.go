// Copyright 2025 The Casdoor Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package idv

type IdvProvider interface {
	VerifyIdentity(idCardType string, idCard string, realName string) (bool, error)
}

func GetIdvProvider(typ string, clientId string, clientSecret string, endpoint string) IdvProvider {
	if typ == "Jumio" {
		return NewJumioIdvProvider(clientId, clientSecret, endpoint)
	} else if typ == "Alibaba Cloud" {
		return NewAlibabaCloudIdvProvider(clientId, clientSecret, endpoint)
	}
	// Default to Jumio for backward compatibility
	return NewJumioIdvProvider(clientId, clientSecret, endpoint)
}
