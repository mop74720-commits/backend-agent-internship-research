// Copyright 2021 The Casdoor Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package routers

import (
	"compress/gzip"
	stdcontext "context"
	"encoding/json"
	"fmt"
	"html"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/beego/beego/v2/core/logs"
	"github.com/beego/beego/v2/server/web/context"
	"github.com/casdoor/casdoor/conf"
	"github.com/casdoor/casdoor/controllers"
	"github.com/casdoor/casdoor/object"
	"github.com/casdoor/casdoor/util"
)

var (
	oldStaticBaseUrl = "https://cdn.casbin.org"
	newStaticBaseUrl = conf.GetConfigString("staticBaseUrl")
	enableGzip       = conf.GetConfigBool("enableGzip")
	frontendBaseDir  = conf.GetConfigString("frontendBaseDir")
)

func getWebBuildFolder() string {
	path := "web/build"
	if util.FileExist(filepath.Join(path, "index.html")) || frontendBaseDir == "" {
		return path
	}

	if util.FileExist(filepath.Join(frontendBaseDir, "index.html")) {
		return frontendBaseDir
	}

	path = filepath.Join(frontendBaseDir, "web/build")
	if util.FileExist(filepath.Join(path, "index.html")) {
		return path
	}

	casdoorDir := filepath.Join(filepath.Dir(frontendBaseDir), "casdoor")
	if util.FileExist(filepath.Join(casdoorDir, "index.html")) {
		return casdoorDir
	}
	if util.FileExist(filepath.Join(casdoorDir, "web/build", "index.html")) {
		return filepath.Join(casdoorDir, "web/build")
	}

	return path
}

// GetSwaggerFolder finds the swagger folder like getWebBuildFolder(), so an instance whose folder only has its own
// conf, logs and files can serve the swagger of the shared Casdoor code on the same machine
func GetSwaggerFolder() string {
	path := "swagger"
	if util.FileExist(filepath.Join(path, "swagger.json")) || frontendBaseDir == "" {
		return path
	}

	candidates := []string{
		filepath.Join(frontendBaseDir, "swagger"),
		filepath.Join(filepath.Dir(frontendBaseDir), "casdoor", "swagger"),
	}
	for _, candidate := range candidates {
		if util.FileExist(filepath.Join(candidate, "swagger.json")) {
			return candidate
		}
	}

	return path
}

func fastAutoSignin(ctx *context.Context) (string, error) {
	userId := getSessionUser(ctx)
	if userId == "" || isSessionExpired(ctx) {
		return "", nil
	}

	clientId := ctx.Input.Query("client_id")
	responseType := ctx.Input.Query("response_type")
	redirectUri := ctx.Input.Query("redirect_uri")
	scope := ctx.Input.Query("scope")
	state := ctx.Input.Query("state")
	nonce := ctx.Input.Query("nonce")
	codeChallenge := ctx.Input.Query("code_challenge")
	resource := ctx.Input.Query("resource")
	responseMode := ctx.Input.Query("response_mode")
	if clientId == "" || responseType != "code" || redirectUri == "" || (responseMode != "" && responseMode != "query") {
		return "", nil
	}

	// prompt=login and an expired max_age need the user to enter credentials on the sign-in page
	authTime, _ := ctx.Input.Session("authTime").(int64)
	if !object.IsSessionAuthFresh(ctx.Input.Query("prompt"), ctx.Input.Query("max_age"), authTime) {
		return "", nil
	}

	application, err := object.GetApplicationByClientId(clientId)
	if err != nil {
		return "", err
	}
	if application == nil {
		return "", nil
	}

	if !application.EnableAutoSignin {
		return "", nil
	}

	user, err := object.GetUser(userId)
	if err != nil {
		return "", err
	}
	if user == nil {
		return "", nil
	}

	isAllowed, err := isFastAutoSigninAllowed(ctx, user, application)
	if err != nil {
		return "", err
	}
	if !isAllowed {
		return "", nil
	}

	consentRequired, err := object.CheckConsentRequired(user, application, scope)
	if err != nil {
		return "", err
	}

	if consentRequired {
		return "", nil
	}

	code, err := object.GetOAuthCode(userId, clientId, "", "autoSignin", responseType, redirectUri, scope, state, nonce, codeChallenge, resource, ctx.Input.CruSession.SessionID(stdcontext.Background()), authTime, ctx.Request.Host, getAcceptLanguage(ctx))
	if err != nil {
		return "", err
	} else if code.Message != "" {
		// the sign-in page reports why no code can be issued, and lets the user sign in with another account
		return "", nil
	}

	sep := "?"
	if strings.Contains(redirectUri, "?") {
		sep = "&"
	}
	issuer := object.GetOidcIssuer(ctx.Request.Host)
	res := fmt.Sprintf("%s%scode=%s&state=%s&iss=%s", redirectUri, sep, url.QueryEscape(code.Code), url.QueryEscape(state), url.QueryEscape(issuer))
	return res, nil
}

func isFastAutoSigninAllowed(ctx *context.Context, user *object.User, application *object.Application) (bool, error) {
	if user.NeedUpdatePassword {
		return false, nil
	}

	isRestricted, err := isRestrictedClientSession(ctx)
	if err != nil || isRestricted {
		return false, err
	}

	// signed in to Casdoor with an account of another organization: show the sign-in page of this application
	isUserOfApplication, err := object.IsUserOfApplication(user, application)
	if err != nil || !isUserOfApplication {
		return false, err
	}

	err = object.CheckApplicationSignin(application, user, util.GetClientIpFromRequest(ctx.Request), getAcceptLanguage(ctx))
	if err != nil {
		return false, nil
	}

	organization, err := object.GetOrganizationByUser(user)
	if err != nil {
		return false, err
	}
	if object.IsNeedPromptMfa(organization, user) {
		return false, nil
	}

	if user.Type == "paid-user" && !user.IsGlobalAdmin() && !user.IsAdmin {
		return hasActiveSubscription(user)
	}
	return true, nil
}

func hasActiveSubscription(user *object.User) (bool, error) {
	subscriptions, err := object.GetSubscriptionsByUser(user.Owner, user.Name)
	if err != nil {
		return false, err
	}

	for _, subscription := range subscriptions {
		if subscription.State == object.SubStateActive {
			return true, nil
		}
	}
	return false, nil
}

func isSessionExpired(ctx *context.Context) bool {
	session, ok := ctx.Input.Session("SessionData").(string)
	if !ok {
		return false
	}

	sessionData := &controllers.SessionData{}
	if err := util.JsonToStruct(session, sessionData); err != nil {
		return true
	}
	return sessionData.ExpireTime != 0 && sessionData.ExpireTime < time.Now().Unix()
}

func StaticFilter(ctx *context.Context) {
	urlPath := ctx.Request.URL.Path

	if urlPath == "/.well-known/acme-challenge/filename" {
		http.ServeContent(ctx.ResponseWriter, ctx.Request, "acme-challenge", time.Now(), strings.NewReader("content"))
	}

	if strings.HasPrefix(urlPath, "/api/") || strings.HasPrefix(urlPath, "/.well-known/") {
		return
	}
	if serveAuthCallbackHandlerScript(ctx) {
		return
	}
	if serveProviderHintRedirectScript(ctx) {
		return
	}
	if serveWebManifest(ctx) {
		return
	}
	if strings.HasPrefix(urlPath, "/cas") && (strings.HasSuffix(urlPath, "/serviceValidate") || strings.HasSuffix(urlPath, "/proxy") || strings.HasSuffix(urlPath, "/proxyValidate") || strings.HasSuffix(urlPath, "/validate") || strings.HasSuffix(urlPath, "/p3/serviceValidate") || strings.HasSuffix(urlPath, "/p3/proxyValidate") || strings.HasSuffix(urlPath, "/samlValidate")) {
		return
	}
	if strings.HasPrefix(urlPath, "/scim") {
		return
	}

	if urlPath == "/login/oauth/authorize" {
		redirectUrl, err := fastAutoSignin(ctx)
		if err != nil {
			responseError(ctx, err.Error())
			return
		}

		if redirectUrl != "" {
			http.Redirect(ctx.ResponseWriter, ctx.Request, redirectUrl, http.StatusFound)
			return
		}

		if serveProviderHintRedirectPage(ctx) {
			return
		}
	}

	if serveAuthCallbackPage(ctx) {
		return
	}

	webBuildFolder := getWebBuildFolder()
	path := webBuildFolder
	if urlPath == "/" {
		path += "/index.html"
	} else {
		path += urlPath
	}

	// Preventing synchronization problems from concurrency
	ctx.Input.CruSession = nil

	organizationThemeCookie, err := appendThemeCookie(ctx, urlPath)
	if err != nil {
		fmt.Println(err)
	}

	if !filepath.IsLocal(strings.TrimPrefix(urlPath, "/")) || !util.FileExist(path) {
		path = webBuildFolder + "/index.html"
	}
	if strings.HasSuffix(path, "/index.html") {
		err = util.AppendWebConfigCookie(ctx)
		if err != nil {
			logs.Error("AppendWebConfigCookie failed in StaticFilter, error: %s", err)
		}
	}
	if !util.FileExist(path) {
		dir, err := os.Getwd()
		if err != nil {
			panic(err)
		}
		dir = strings.ReplaceAll(dir, "\\", "/")
		ctx.ResponseWriter.WriteHeader(http.StatusNotFound)
		errorText := fmt.Sprintf("The Casdoor frontend HTML file: \"index.html\" was not found, it should be placed at: \"%s/web/build/index.html\". For more information, see: https://casdoor.org/docs/basic/server-installation/#frontend-1", dir)
		http.ServeContent(ctx.ResponseWriter, ctx.Request, "Casdoor frontend has encountered error...", time.Now(), strings.NewReader(errorText))
		return
	}

	if oldStaticBaseUrl == newStaticBaseUrl {
		makeGzipResponse(ctx.ResponseWriter, ctx.Request, path, organizationThemeCookie)
	} else {
		serveFileWithReplace(ctx.ResponseWriter, ctx.Request, path, organizationThemeCookie)
	}
}

func serveFileWithReplace(w http.ResponseWriter, r *http.Request, name string, organizationThemeCookie *OrganizationThemeCookie) {
	f, err := os.Open(filepath.Clean(name))
	if err != nil {
		panic(err)
	}
	defer f.Close()

	d, err := f.Stat()
	if err != nil {
		panic(err)
	}

	modTime := d.ModTime()
	oldContent := util.ReadStringFromPath(name)
	newContent := oldContent
	if organizationThemeCookie != nil {
		newContent = addBrandingToHtml(newContent, organizationThemeCookie)
	}

	// Set the correct <html lang="..."> on the initial HTML response so browsers
	// do not mis-detect the page language (e.g. Chrome offering to translate a
	// Chinese page into Chinese because the static shell declares lang="en").
	if strings.HasSuffix(name, "index.html") {
		w.Header().Set("Cache-Control", "no-cache")
		lang := getIndexHtmlLanguage(r)
		newContent = strings.ReplaceAll(newContent, `<html lang="en">`, fmt.Sprintf(`<html lang="%s">`, lang))
		var cdnEnabled bool
		newContent, cdnEnabled = useFrontendCdn(newContent, name, r)
		if cdnEnabled {
			// the same file is served with or without the CDN (cookie), so a 304 by modification time could bring back
			// the cached CDN version after the page turned the CDN off
			modTime = time.Time{}
		}
		newContent = addBasePathToHtml(newContent)
		newContent = addWebConfigToHtml(newContent)
		newContent = addIssuerToHtml(newContent, r.Host)
	}

	newContent = strings.ReplaceAll(newContent, oldStaticBaseUrl, newStaticBaseUrl)

	http.ServeContent(w, r, d.Name(), modTime, strings.NewReader(newContent))
}

// addWebConfigToHtml puts the web config into the page too: a page embedded in another site does not get the
// jsonWebConfig cookie
func addWebConfigToHtml(content string) string {
	webConfig, err := json.Marshal(conf.GetWebConfig())
	if err != nil {
		return content
	}

	meta := fmt.Sprintf(`<meta name="casdoor-web-config" content="%s">`, html.EscapeString(string(webConfig)))
	return strings.Replace(content, "</head>", meta+"</head>", 1)
}

// addIssuerToHtml tells the frontend the issuer it has to send back as `iss` in authorization responses (RFC 9207)
func addIssuerToHtml(content string, host string) string {
	meta := fmt.Sprintf(`<meta name="casdoor-issuer" content="%s">`, html.EscapeString(object.GetOidcIssuer(host)))
	return strings.Replace(content, "</head>", meta+"</head>", 1)
}

type gzipResponseWriter struct {
	io.Writer
	http.ResponseWriter
}

func (w gzipResponseWriter) Write(b []byte) (int, error) {
	return w.Writer.Write(b)
}

func makeGzipResponse(w http.ResponseWriter, r *http.Request, path string, organizationThemeCookie *OrganizationThemeCookie) {
	if !enableGzip || !strings.Contains(r.Header.Get("Accept-Encoding"), "gzip") {
		serveFileWithReplace(w, r, path, organizationThemeCookie)
		return
	}
	w.Header().Set("Content-Encoding", "gzip")
	gz := gzip.NewWriter(w)
	defer gz.Close()
	gzw := gzipResponseWriter{Writer: gz, ResponseWriter: w}
	serveFileWithReplace(gzw, r, path, organizationThemeCookie)
}
