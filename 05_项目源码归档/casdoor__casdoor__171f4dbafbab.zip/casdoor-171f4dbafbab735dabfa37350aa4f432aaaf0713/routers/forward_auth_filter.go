// Copyright 2026 The Casdoor Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package routers

import (
	"github.com/beego/beego/v2/server/web/context"
	"github.com/casdoor/casdoor/service"
)

// ForwardAuthFilter runs before the other filters: the request is the auth subrequest of a reverse proxy,
// it carries the cookies and Origin of the protected app, not of Casdoor itself.
func ForwardAuthFilter(ctx *context.Context) {
	service.HandleForwardAuth(ctx.ResponseWriter, ctx.Request)
}
