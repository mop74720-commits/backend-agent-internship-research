// Copyright 2022 The Casdoor Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package object

import (
	"bytes"
	"compress/flate"
	"crypto"
	"crypto/rsa"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"encoding/xml"
	"errors"
	"fmt"
	"io"
	"net/url"
	"strings"
	"time"

	"github.com/beevik/etree"
	"github.com/casdoor/casdoor/util"
	"github.com/golang-jwt/jwt/v5"
	saml "github.com/russellhaering/gosaml2"
	dsig "github.com/russellhaering/goxmldsig"
)

// NewSamlResponse
// returns a saml2 response
func NewSamlResponse(application *Application, user *User, host string, certificate string, destination string, iss string, requestId string, sessionIndex string, redirectUri []string) (*etree.Element, error) {
	samlResponse := &etree.Element{
		Space: "samlp",
		Tag:   "Response",
	}
	now := time.Now().UTC().Format(time.RFC3339)
	expireTime := time.Now().UTC().Add(time.Hour * 24).Format(time.RFC3339)
	samlResponse.CreateAttr("xmlns:samlp", "urn:oasis:names:tc:SAML:2.0:protocol")
	samlResponse.CreateAttr("xmlns:saml", "urn:oasis:names:tc:SAML:2.0:assertion")
	samlResponse.CreateAttr("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance")
	samlResponse.CreateAttr("xmlns:xs", "http://www.w3.org/2001/XMLSchema")
	arId := util.GenerateUUID()

	samlResponse.CreateAttr("ID", fmt.Sprintf("_%s", arId))
	samlResponse.CreateAttr("Version", "2.0")
	samlResponse.CreateAttr("IssueInstant", now)
	samlResponse.CreateAttr("Destination", destination)
	// the "InResponseTo" attribute must be omitted for IdP-initiated SSO, as there is no AuthnRequest to respond to
	if requestId != "" {
		samlResponse.CreateAttr("InResponseTo", requestId)
	}
	samlResponse.CreateElement("saml:Issuer").SetText(host)

	samlResponse.CreateElement("samlp:Status").CreateElement("samlp:StatusCode").CreateAttr("Value", "urn:oasis:names:tc:SAML:2.0:status:Success")

	assertion := samlResponse.CreateElement("saml:Assertion")
	assertion.CreateAttr("xmlns:saml", "urn:oasis:names:tc:SAML:2.0:assertion")
	assertion.CreateAttr("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance")
	assertion.CreateAttr("xmlns:xs", "http://www.w3.org/2001/XMLSchema")
	assertion.CreateAttr("ID", fmt.Sprintf("_%s", util.GenerateUUID()))
	assertion.CreateAttr("Version", "2.0")
	assertion.CreateAttr("IssueInstant", now)
	assertion.CreateElement("saml:Issuer").SetText(host)
	subject := assertion.CreateElement("saml:Subject")
	nameIdValue, nameIdFormat := getSamlNameId(application, user)
	nameId := subject.CreateElement("saml:NameID")
	nameId.CreateAttr("Format", nameIdFormat)
	nameId.SetText(nameIdValue)
	subjectConfirmation := subject.CreateElement("saml:SubjectConfirmation")
	subjectConfirmation.CreateAttr("Method", "urn:oasis:names:tc:SAML:2.0:cm:bearer")
	subjectConfirmationData := subjectConfirmation.CreateElement("saml:SubjectConfirmationData")
	if requestId != "" {
		subjectConfirmationData.CreateAttr("InResponseTo", requestId)
	}
	subjectConfirmationData.CreateAttr("Recipient", destination)
	subjectConfirmationData.CreateAttr("NotOnOrAfter", expireTime)
	condition := assertion.CreateElement("saml:Conditions")
	condition.CreateAttr("NotBefore", now)
	condition.CreateAttr("NotOnOrAfter", expireTime)
	audience := condition.CreateElement("saml:AudienceRestriction")
	audience.CreateElement("saml:Audience").SetText(iss)
	// Add redirect URIs as audiences, but skip duplicates and empty values
	for _, value := range redirectUri {
		if value != "" && value != iss {
			audience.CreateElement("saml:Audience").SetText(value)
		}
	}
	authnStatement := assertion.CreateElement("saml:AuthnStatement")
	authnStatement.CreateAttr("AuthnInstant", now)
	authnStatement.CreateAttr("SessionIndex", sessionIndex)
	authnStatement.CreateAttr("SessionNotOnOrAfter", expireTime)
	authnStatement.CreateElement("saml:AuthnContext").CreateElement("saml:AuthnContextClassRef").SetText("urn:oasis:names:tc:SAML:2.0:ac:classes:PasswordProtectedTransport")

	if !application.DisableSamlAttributes {
		attributes := assertion.CreateElement("saml:AttributeStatement")

		email := attributes.CreateElement("saml:Attribute")
		email.CreateAttr("Name", "Email")
		email.CreateAttr("NameFormat", "urn:oasis:names:tc:SAML:2.0:attrname-format:basic")
		email.CreateElement("saml:AttributeValue").CreateAttr("xsi:type", "xs:string").Element().SetText(user.Email)

		name := attributes.CreateElement("saml:Attribute")
		name.CreateAttr("Name", "Name")
		name.CreateAttr("NameFormat", "urn:oasis:names:tc:SAML:2.0:attrname-format:basic")
		name.CreateElement("saml:AttributeValue").CreateAttr("xsi:type", "xs:string").Element().SetText(user.Name)

		displayName := attributes.CreateElement("saml:Attribute")
		displayName.CreateAttr("Name", "DisplayName")
		displayName.CreateAttr("NameFormat", "urn:oasis:names:tc:SAML:2.0:attrname-format:basic")
		displayName.CreateElement("saml:AttributeValue").CreateAttr("xsi:type", "xs:string").Element().SetText(user.DisplayName)

		err := ExtendUserWithRolesAndPermissions(user)
		if err != nil {
			return nil, err
		}

		for _, item := range application.SamlAttributes {
			role := attributes.CreateElement("saml:Attribute")
			role.CreateAttr("Name", item.Name)
			role.CreateAttr("NameFormat", item.NameFormat)

			valueList := replaceAttributeValue(user, item.Value)
			for _, value := range valueList {
				av := role.CreateElement("saml:AttributeValue")
				av.CreateAttr("xsi:type", "xs:string").Element().SetText(value)
			}
		}

		roles := attributes.CreateElement("saml:Attribute")
		roles.CreateAttr("Name", "Roles")
		roles.CreateAttr("NameFormat", "urn:oasis:names:tc:SAML:2.0:attrname-format:basic")

		for _, role := range user.Roles {
			roles.CreateElement("saml:AttributeValue").CreateAttr("xsi:type", "xs:string").Element().SetText(role.Name)
		}
	}

	return samlResponse, nil
}

func getSamlNameId(application *Application, user *User) (string, string) {
	nameIdFormat := "urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified"
	if application.UseEmailAsSamlNameId {
		nameIdFormat = "urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress"
	}

	if application.SamlNameIdTemplate != "" {
		return replaceSamlNameIdTemplate(user, application.SamlNameIdTemplate), nameIdFormat
	}
	if application.UseEmailAsSamlNameId {
		return user.Email, nameIdFormat
	}
	return user.Name, nameIdFormat
}

func replaceSamlNameIdTemplate(user *User, template string) string {
	emailLocalPart, emailDomain, _ := strings.Cut(user.Email, "@")
	return strings.NewReplacer(
		"$user.emailLocalPart", emailLocalPart,
		"$user.emailDomain", emailDomain,
		"$user.owner", user.Owner,
		"$user.name", user.Name,
		"$user.email", user.Email,
		"$user.id", user.Id,
		"$user.phone", user.Phone,
	).Replace(template)
}

type X509Key struct {
	X509Certificate string
	PrivateKey      string
}

func (x X509Key) GetKeyPair() (privateKey *rsa.PrivateKey, cert []byte, err error) {
	cert, _ = base64.StdEncoding.DecodeString(x.X509Certificate)
	privateKey, err = jwt.ParseRSAPrivateKeyFromPEM([]byte(x.PrivateKey))
	return privateKey, cert, err
}

// IdpEntityDescriptor
// SAML METADATA
type IdpEntityDescriptor struct {
	XMLName  xml.Name `xml:"EntityDescriptor"`
	DS       string   `xml:"xmlns:ds,attr"`
	XMLNS    string   `xml:"xmlns,attr"`
	MD       string   `xml:"xmlns:md,attr"`
	EntityId string   `xml:"entityID,attr"`

	IdpSSODescriptor IdpSSODescriptor `xml:"IDPSSODescriptor"`
}

type KeyInfo struct {
	XMLName  xml.Name `xml:"http://www.w3.org/2000/09/xmldsig# KeyInfo"`
	X509Data X509Data `xml:",innerxml"`
}

type X509Data struct {
	XMLName         xml.Name        `xml:"http://www.w3.org/2000/09/xmldsig# X509Data"`
	X509Certificate X509Certificate `xml:",innerxml"`
}

type X509Certificate struct {
	XMLName xml.Name `xml:"http://www.w3.org/2000/09/xmldsig# X509Certificate"`
	Cert    string   `xml:",innerxml"`
}

type KeyDescriptor struct {
	XMLName xml.Name `xml:"KeyDescriptor"`
	Use     string   `xml:"use,attr"`
	KeyInfo KeyInfo  `xml:"KeyInfo"`
}

type IdpSSODescriptor struct {
	XMLName                    xml.Name `xml:"urn:oasis:names:tc:SAML:2.0:metadata IDPSSODescriptor"`
	ProtocolSupportEnumeration string   `xml:"protocolSupportEnumeration,attr"`
	SigningKeyDescriptor       KeyDescriptor
	SingleLogoutServices       []SingleLogoutService `xml:"SingleLogoutService"`
	NameIDFormats              []NameIDFormat        `xml:"NameIDFormat"`
	SingleSignOnService        SingleSignOnService   `xml:"SingleSignOnService"`
	Attribute                  []Attribute           `xml:"Attribute"`
}

type NameIDFormat struct {
	// XMLName xml.Name
	Value string `xml:",innerxml"`
}

type SingleSignOnService struct {
	// XMLName  xml.Name
	Binding  string `xml:"Binding,attr"`
	Location string `xml:"Location,attr"`
}

type SingleLogoutService struct {
	Binding  string `xml:"Binding,attr"`
	Location string `xml:"Location,attr"`
}

type Attribute struct {
	// XMLName      xml.Name
	Xmlns        string   `xml:"xmlns,attr"`
	Name         string   `xml:"Name,attr"`
	NameFormat   string   `xml:"NameFormat,attr"`
	FriendlyName string   `xml:"FriendlyName,attr"`
	Values       []string `xml:"AttributeValue"`
}

func GetSamlMeta(application *Application, host string, enablePostBinding bool) (*IdpEntityDescriptor, error) {
	cert, err := getCertByApplication(application)
	if err != nil {
		return nil, err
	}

	if cert == nil {
		return nil, errors.New("please set a cert for the application first")
	}

	if cert.Certificate == "" {
		return nil, fmt.Errorf("the certificate field should not be empty for the cert: %v", cert)
	}

	block, _ := pem.Decode([]byte(cert.Certificate))
	certificate := base64.StdEncoding.EncodeToString(block.Bytes)

	originFrontend, originBackend := getOriginFromHost(host)

	idpLocation := ""
	idpBinding := ""
	if enablePostBinding {
		idpLocation = fmt.Sprintf("%s/api/saml/redirect/%s/%s", originBackend, application.Owner, application.Name)
		idpBinding = "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST"
	} else {
		idpLocation = fmt.Sprintf("%s/login/saml/authorize/%s/%s", originFrontend, application.Owner, application.Name)
		idpBinding = "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect"
	}

	sloLocation := getSamlSingleLogoutLocation(application, host)

	d := IdpEntityDescriptor{
		XMLName: xml.Name{
			Local: "md:EntityDescriptor",
		},
		DS:       "http://www.w3.org/2000/09/xmldsig#",
		XMLNS:    "urn:oasis:names:tc:SAML:2.0:metadata",
		MD:       "urn:oasis:names:tc:SAML:2.0:metadata",
		EntityId: originBackend,
		IdpSSODescriptor: IdpSSODescriptor{
			SigningKeyDescriptor: KeyDescriptor{
				Use: "signing",
				KeyInfo: KeyInfo{
					X509Data: X509Data{
						X509Certificate: X509Certificate{
							Cert: certificate,
						},
					},
				},
			},
			SingleLogoutServices: []SingleLogoutService{
				{Binding: samlRedirectBinding, Location: sloLocation},
				{Binding: samlPostBinding, Location: sloLocation},
			},
			NameIDFormats: []NameIDFormat{
				{Value: "urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress"},
				{Value: "urn:oasis:names:tc:SAML:2.0:nameid-format:persistent"},
				{Value: "urn:oasis:names:tc:SAML:2.0:nameid-format:transient"},
			},
			Attribute: []Attribute{
				{Xmlns: "urn:oasis:names:tc:SAML:2.0:assertion", Name: "Email", NameFormat: "urn:oasis:names:tc:SAML:2.0:attrname-format:basic", FriendlyName: "E-Mail"},
				{Xmlns: "urn:oasis:names:tc:SAML:2.0:assertion", Name: "DisplayName", NameFormat: "urn:oasis:names:tc:SAML:2.0:attrname-format:basic", FriendlyName: "displayName"},
				{Xmlns: "urn:oasis:names:tc:SAML:2.0:assertion", Name: "Name", NameFormat: "urn:oasis:names:tc:SAML:2.0:attrname-format:basic", FriendlyName: "Name"},
			},
			SingleSignOnService: SingleSignOnService{
				Binding:  idpBinding,
				Location: idpLocation,
			},
			ProtocolSupportEnumeration: "urn:oasis:names:tc:SAML:2.0:protocol",
		},
	}

	return &d, nil
}

// decodeSamlMessage decodes a base64 SAML message, which is also deflated when it comes over the HTTP-Redirect binding
func decodeSamlMessage(message string) ([]byte, error) {
	message = strings.ReplaceAll(message, " ", "+")
	defated, err := base64.StdEncoding.DecodeString(message)
	if err != nil {
		return nil, fmt.Errorf("err: Failed to decode SAML request, %s", err.Error())
	}

	if strings.Contains(string(defated), "xmlns:") {
		return defated, nil
	}

	var buffer bytes.Buffer
	rdr := flate.NewReader(bytes.NewReader(defated))
	for {
		_, err = io.CopyN(&buffer, rdr, 1024)
		if err != nil {
			if err == io.EOF {
				break
			}
			return nil, err
		}
	}

	return buffer.Bytes(), nil
}

// getAuthnRequest parses the AuthnRequest sent by the SP, parameter samlRequest is the SAML request in base64 format
func getAuthnRequest(application *Application, samlRequest string) (saml.AuthNRequest, error) {
	var authnRequest saml.AuthNRequest

	requestByte, err := decodeSamlMessage(samlRequest)
	if err != nil {
		return authnRequest, err
	}

	err = xml.Unmarshal(requestByte, &authnRequest)
	if err != nil {
		return authnRequest, fmt.Errorf("err: Failed to unmarshal AuthnRequest, please check the SAML request, %s", err.Error())
	}

	// verify samlRequest
	if isValid := application.IsRedirectUriValid(authnRequest.Issuer); !isValid {
		return authnRequest, fmt.Errorf("err: Issuer URI: %s doesn't exist in the allowed Redirect URI list", authnRequest.Issuer)
	}

	return authnRequest, nil
}

// isSamlAcsUrlValid checks the ACS URL of an AuthnRequest, which isn't signed: the signed
// assertion is posted there, so it must be a registered URL or on the host of one of them
func (application *Application) isSamlAcsUrlValid(acsUrl string) bool {
	if application.IsRedirectUriValid(acsUrl) {
		return true
	}

	acsUrlObj, err := url.Parse(acsUrl)
	if err != nil || acsUrlObj.Host == "" {
		return false
	}

	for _, redirectUri := range application.RedirectUris {
		redirectUriObj, err := url.Parse(redirectUri)
		if err == nil && redirectUriObj.Host != "" && redirectUriObj.Scheme == acsUrlObj.Scheme && redirectUriObj.Host == acsUrlObj.Host {
			return true
		}
	}
	return false
}

// getIdpInitiatedAuthnRequest builds the AuthnRequest for IdP-initiated SSO, where the SP doesn't send any AuthnRequest to Casdoor,
// so the ACS URL and the SP's entity ID are taken from the application's SAML config instead
func getIdpInitiatedAuthnRequest(application *Application) (saml.AuthNRequest, error) {
	var authnRequest saml.AuthNRequest

	if application.SamlReplyUrl == "" {
		return authnRequest, fmt.Errorf("err: the SAML reply URL should not be empty for IdP-initiated SSO")
	}

	entityId := ""
	for _, redirectUri := range application.RedirectUris {
		if redirectUri != "" {
			entityId = redirectUri
			break
		}
	}
	if entityId == "" {
		return authnRequest, fmt.Errorf("err: the Redirect URIs should contain the SP's entity ID for IdP-initiated SSO")
	}

	authnRequest.AssertionConsumerServiceURL = application.SamlReplyUrl
	authnRequest.Issuer = entityId
	authnRequest.ProtocolBinding = "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST"

	return authnRequest, nil
}

// GetSamlResponse generates a SAML2.0 response
// parameter samlRequest is saml request in base64 format, it is empty for IdP-initiated SSO
// parameter sessionId is the Casdoor session the SP signs in with, SAML Single Logout ends it again
func GetSamlResponse(application *Application, user *User, samlRequest string, host string, sessionId string) (string, string, string, error) {
	// request type
	method := "GET"

	var authnRequest saml.AuthNRequest
	var err error
	if samlRequest == "" {
		authnRequest, err = getIdpInitiatedAuthnRequest(application)
	} else {
		authnRequest, err = getAuthnRequest(application, samlRequest)
	}
	if err != nil {
		return "", "", "", err
	}

	// get certificate string
	cert, err := getCertByApplication(application)
	if err != nil {
		return "", "", "", err
	}

	if cert.Certificate == "" {
		return "", "", "", fmt.Errorf("the certificate field should not be empty for the cert: %v", cert)
	}

	block, _ := pem.Decode([]byte(cert.Certificate))
	certificate := base64.StdEncoding.EncodeToString(block.Bytes)

	// redirect Url (Assertion Consumer Url)
	if application.SamlReplyUrl != "" {
		method = "POST"
		authnRequest.AssertionConsumerServiceURL = application.SamlReplyUrl
	} else if authnRequest.AssertionConsumerServiceURL == "" {
		return "", "", "", fmt.Errorf("err: SAML request don't has attribute 'AssertionConsumerServiceURL' in <samlp:AuthnRequest>")
	} else if !application.isSamlAcsUrlValid(authnRequest.AssertionConsumerServiceURL) {
		return "", "", "", fmt.Errorf("err: AssertionConsumerServiceURL: %s doesn't match the SAML reply URL or the allowed Redirect URI list", authnRequest.AssertionConsumerServiceURL)
	}
	if authnRequest.ProtocolBinding == "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST" {
		method = "POST"
	}

	_, originBackend := getOriginFromHost(host)

	// build signedResponse
	sessionIndex := fmt.Sprintf("_%s", util.GenerateUUID())
	samlResponse, err := NewSamlResponse(application, user, originBackend, certificate, authnRequest.AssertionConsumerServiceURL, authnRequest.Issuer, authnRequest.ID, sessionIndex, application.RedirectUris)
	if err != nil {
		return "", "", "", fmt.Errorf("err: NewSamlResponse() error, %s", err.Error())
	}

	ctx := newSamlSigningContext(application, cert.PrivateKey, certificate)

	// signedXML, err := ctx.SignEnvelopedLimix(samlResponse)
	// if err != nil {
	//	return "", "", fmt.Errorf("err: %s", err.Error())
	// }

	// Sign the assertion (SAML 2.0 best practice)
	// Only sign if EnableSamlAssertionSignature is true
	if application.EnableSamlAssertionSignature {
		assertion := samlResponse.FindElement("./Assertion")
		if assertion != nil {
			assertionSig, err := constructSamlSignature(ctx, assertion)
			if err != nil {
				return "", "", "", fmt.Errorf("err: Failed to sign SAML assertion, %s", err.Error())
			}
			// Insert signature as the second child of assertion (after Issuer)
			assertion.InsertChildAt(1, assertionSig)
		}
	}

	// Sign the response
	sig, err := constructSamlSignature(ctx, samlResponse)
	if err != nil {
		return "", "", "", fmt.Errorf("err: Failed to serializes the SAML request into bytes, %s", err.Error())
	}

	samlResponse.InsertChildAt(1, sig)

	doc := etree.NewDocument()
	doc.SetRoot(samlResponse)

	// Write to bytes
	xmlBytes, err := doc.WriteToBytes()
	if err != nil {
		return "", "", "", fmt.Errorf("err: Failed to serializes the SAML request into bytes, %s", err.Error())
	}

	// compress
	if application.EnableSamlCompress {
		flated := bytes.NewBuffer(nil)
		writer, err := flate.NewWriter(flated, flate.DefaultCompression)
		if err != nil {
			return "", "", "", err
		}

		_, err = writer.Write(xmlBytes)
		if err != nil {
			return "", "", "", err
		}

		err = writer.Close()
		if err != nil {
			return "", "", "", err
		}

		xmlBytes = flated.Bytes()
	}
	nameIdValue, nameIdFormat := getSamlNameId(application, user)
	err = addSamlSession(&SamlSession{
		Owner:        user.Owner,
		Name:         user.Name,
		SessionIndex: sessionIndex,
		Application:  application.GetId(),
		SessionId:    sessionId,
		NameId:       nameIdValue,
		NameIdFormat: nameIdFormat,
		SpEntityId:   authnRequest.Issuer,
	})
	if err != nil {
		return "", "", "", err
	}

	// base64 encode
	res := base64.StdEncoding.EncodeToString(xmlBytes)
	return res, authnRequest.AssertionConsumerServiceURL, method, err
}

func newSamlSigningContext(application *Application, privateKey string, certificate string) *dsig.SigningContext {
	ctx := dsig.NewDefaultSigningContext(&X509Key{
		PrivateKey:      privateKey,
		X509Certificate: certificate,
	})
	if application.SamlHashAlgorithm == "" || application.SamlHashAlgorithm == "SHA1" {
		ctx.Hash = crypto.SHA1
	} else if application.SamlHashAlgorithm == "SHA256" {
		ctx.Hash = crypto.SHA256
	} else if application.SamlHashAlgorithm == "SHA512" {
		ctx.Hash = crypto.SHA512
	}

	if application.EnableSamlC14n10 {
		ctx.Canonicalizer = &samlC14n10Canonicalizer{prefixList: application.SamlC14nPrefix}
	}
	return ctx
}

// samlC14n10Canonicalizer canonicalizes a copy, as goxmldsig strips namespace declarations from the signed XML itself, and applies the prefix list to the reference only
type samlC14n10Canonicalizer struct {
	prefixList string
}

func (c *samlC14n10Canonicalizer) Canonicalize(el *etree.Element) ([]byte, error) {
	el = el.Copy()
	prefixList := c.prefixList
	if el.Tag == dsig.SignedInfoTag {
		addSamlInclusiveNamespaces(el, c.prefixList)
		prefixList = ""
	}
	return dsig.MakeC14N10ExclusiveCanonicalizerWithPrefixList(prefixList).Canonicalize(el)
}

func (c *samlC14n10Canonicalizer) Algorithm() dsig.AlgorithmID {
	return dsig.CanonicalXML10ExclusiveAlgorithmId
}

// addSamlInclusiveNamespaces writes the prefix list into the exclusive C14N transform, where the SP reads it from
func addSamlInclusiveNamespaces(signedInfo *etree.Element, prefixList string) {
	if signedInfo == nil || strings.TrimSpace(prefixList) == "" {
		return
	}

	for _, transform := range signedInfo.FindElements("./Reference/Transforms/Transform") {
		if transform.SelectAttrValue(dsig.AlgorithmAttr, "") == string(dsig.CanonicalXML10ExclusiveAlgorithmId) {
			inclusiveNamespaces := transform.CreateElement("ec:InclusiveNamespaces")
			inclusiveNamespaces.CreateAttr("xmlns:ec", string(dsig.CanonicalXML10ExclusiveAlgorithmId))
			inclusiveNamespaces.CreateAttr("PrefixList", prefixList)
		}
	}
}

func constructSamlSignature(ctx *dsig.SigningContext, el *etree.Element) (*etree.Element, error) {
	sig, err := ctx.ConstructSignature(el, true)
	if err != nil {
		return nil, err
	}

	if c, ok := ctx.Canonicalizer.(*samlC14n10Canonicalizer); ok {
		addSamlInclusiveNamespaces(sig.SelectElement(dsig.SignedInfoTag), c.prefixList)
	}
	return sig, nil
}

// NewSamlResponse11 return a saml1.1 response(not 2.0)
func NewSamlResponse11(application *Application, user *User, requestID string, host string) (*etree.Element, error) {
	samlResponse := &etree.Element{
		Space: "samlp",
		Tag:   "Response",
	}

	samlResponse.CreateAttr("xmlns:samlp", "urn:oasis:names:tc:SAML:1.0:protocol")
	samlResponse.CreateAttr("MajorVersion", "1")
	samlResponse.CreateAttr("MinorVersion", "1")

	responseID := util.GenerateUUID()
	samlResponse.CreateAttr("ResponseID", fmt.Sprintf("_%s", responseID))
	samlResponse.CreateAttr("InResponseTo", requestID)

	now := time.Now().UTC().Format(time.RFC3339)
	expireTime := time.Now().UTC().Add(time.Hour * 24).Format(time.RFC3339)

	samlResponse.CreateAttr("IssueInstant", now)

	samlResponse.CreateElement("samlp:Status").CreateElement("samlp:StatusCode").CreateAttr("Value", "samlp:Success")

	// create assertion which is inside the response
	assertion := samlResponse.CreateElement("saml:Assertion")
	assertion.CreateAttr("xmlns:saml", "urn:oasis:names:tc:SAML:1.0:assertion")
	assertion.CreateAttr("MajorVersion", "1")
	assertion.CreateAttr("MinorVersion", "1")
	assertion.CreateAttr("AssertionID", util.GenerateUUID())
	assertion.CreateAttr("Issuer", host)
	assertion.CreateAttr("IssueInstant", now)

	condition := assertion.CreateElement("saml:Conditions")
	condition.CreateAttr("NotBefore", now)
	condition.CreateAttr("NotOnOrAfter", expireTime)

	// AuthenticationStatement inside assertion
	authenticationStatement := assertion.CreateElement("saml:AuthenticationStatement")
	authenticationStatement.CreateAttr("AuthenticationMethod", "urn:oasis:names:tc:SAML:1.0:am:password")
	authenticationStatement.CreateAttr("AuthenticationInstant", now)

	// subject inside AuthenticationStatement
	subject := assertion.CreateElement("saml:Subject")
	// nameIdentifier inside subject
	nameIdentifier := subject.CreateElement("saml:NameIdentifier")
	// nameIdentifier.CreateAttr("Format", "urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress")
	nameIdValue, _ := getSamlNameId(application, user)
	nameIdentifier.SetText(nameIdValue)

	// subjectConfirmation inside subject
	subjectConfirmation := subject.CreateElement("saml:SubjectConfirmation")
	subjectConfirmation.CreateElement("saml:ConfirmationMethod").SetText("urn:oasis:names:tc:SAML:1.0:cm:artifact")

	attributeStatement := assertion.CreateElement("saml:AttributeStatement")
	subjectInAttribute := attributeStatement.CreateElement("saml:Subject")
	nameIdentifierInAttribute := subjectInAttribute.CreateElement("saml:NameIdentifier")
	nameIdentifierInAttribute.SetText(nameIdValue)

	subjectConfirmationInAttribute := subjectInAttribute.CreateElement("saml:SubjectConfirmation")
	subjectConfirmationInAttribute.CreateElement("saml:ConfirmationMethod").SetText("urn:oasis:names:tc:SAML:1.0:cm:artifact")

	data, err := json.Marshal(user)
	if err != nil {
		return nil, err
	}

	tmp := map[string]string{}
	err = json.Unmarshal(data, &tmp)
	if err != nil {
		return nil, err
	}

	for k, v := range tmp {
		if v != "" {
			attr := attributeStatement.CreateElement("saml:Attribute")
			attr.CreateAttr("saml:AttributeName", k)
			attr.CreateAttr("saml:AttributeNamespace", "http://www.ja-sig.org/products/cas/")
			attr.CreateElement("saml:AttributeValue").SetText(v)
		}
	}

	return samlResponse, nil
}

func GetSamlRedirectAddress(owner string, application string, relayState string, samlRequest string, host string, username string, loginHint string) string {
	originF, _ := getOriginFromHost(host)
	baseURL := fmt.Sprintf("%s/login/saml/authorize/%s/%s?relayState=%s&samlRequest=%s", originF, url.PathEscape(owner), url.PathEscape(application), relayState, url.QueryEscape(samlRequest))
	if username != "" {
		baseURL += fmt.Sprintf("&username=%s", url.QueryEscape(username))
	}
	if loginHint != "" {
		baseURL += fmt.Sprintf("&login_hint=%s", url.QueryEscape(loginHint))
	}
	return baseURL
}
