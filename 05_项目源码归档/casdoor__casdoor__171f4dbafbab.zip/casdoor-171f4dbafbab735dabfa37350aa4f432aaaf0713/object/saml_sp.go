// Copyright 2021 The Casdoor Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package object

import (
	"crypto/tls"
	"crypto/x509"
	"encoding/base64"
	"encoding/pem"
	"fmt"
	"net/url"
	"time"

	"github.com/casdoor/casdoor/i18n"
	"github.com/casdoor/casdoor/idp"
	"github.com/mitchellh/mapstructure"
	saml2 "github.com/russellhaering/gosaml2"
	dsig "github.com/russellhaering/goxmldsig"
)

// IsValidSamlRedirectURL checks that the redirect URL in the SAML RelayState
// points to the same origin as this Casdoor instance, preventing open redirect attacks.
func IsValidSamlRedirectURL(redirectURL, host string) bool {
	if redirectURL == "" {
		return false
	}
	parsed, err := url.Parse(redirectURL)
	if err != nil || parsed.Host == "" {
		return false
	}
	_, origin := getOriginFromHost(host)
	originParsed, err := url.Parse(origin)
	if err != nil {
		return false
	}
	return parsed.Host == originParsed.Host
}

// ParseSamlResponse validates the SAMLResponse of the provider and returns the user it
// asserts. requestId is the ID of the AuthnRequest this login started with, the
// response must answer it.
func ParseSamlResponse(samlResponse string, provider *Provider, host string, requestId string) (*idp.UserInfo, error) {
	samlResponse, _ = url.QueryUnescape(samlResponse)
	sp, err := buildSp(provider, samlResponse, host)
	if err != nil {
		return nil, err
	}

	assertionInfo, err := sp.RetrieveAssertionInfo(samlResponse)
	if err != nil {
		return nil, err
	}

	err = checkSamlAssertion(assertionInfo, requestId)
	if err != nil {
		return nil, err
	}

	userInfoMap := make(map[string]string)
	for spAttr, idpAttr := range provider.UserMapping {
		for _, attr := range assertionInfo.Values {
			if attr.Name == idpAttr {
				userInfoMap[spAttr] = attr.Values[0].Value
			}
		}
	}
	userInfoMap["id"] = assertionInfo.NameID

	customUserInfo := &idp.CustomUserInfo{}
	err = mapstructure.Decode(userInfoMap, customUserInfo)
	if err != nil {
		return nil, err
	}
	userInfo := &idp.UserInfo{
		Id:          customUserInfo.Id,
		Username:    customUserInfo.Username,
		DisplayName: customUserInfo.DisplayName,
		Email:       customUserInfo.Email,
		// asserted by the IdP's directory
		EmailVerified: customUserInfo.Email != "",
		AvatarUrl:     customUserInfo.AvatarUrl,
	}

	// Fallback: if Username is empty, use Email or NameID
	if userInfo.Username == "" {
		if userInfo.Email != "" {
			userInfo.Username = userInfo.Email
		} else if userInfo.Id != "" {
			userInfo.Username = userInfo.Id
		}
	}

	return userInfo, err
}

// checkSamlAssertion enforces what gosaml2 only reports in WarningInfo: the assertion
// must be within its validity window, be issued to this SP, answer the AuthnRequest
// this login started with, and not have been consumed before.
func checkSamlAssertion(assertionInfo *saml2.AssertionInfo, requestId string) error {
	warningInfo := assertionInfo.WarningInfo
	if warningInfo != nil {
		if warningInfo.InvalidTime {
			return fmt.Errorf("the SAML assertion is not within its validity period (NotBefore / NotOnOrAfter)")
		}
		if warningInfo.NotInAudience {
			return fmt.Errorf("the SAML assertion is not issued for this service provider (AudienceRestriction mismatch)")
		}
	}

	if len(assertionInfo.Assertions) == 0 {
		return fmt.Errorf("the SAML response contains no assertion")
	}
	assertion := assertionInfo.Assertions[0]

	inResponseTo := ""
	if assertion.Subject != nil && assertion.Subject.SubjectConfirmation != nil && assertion.Subject.SubjectConfirmation.SubjectConfirmationData != nil {
		inResponseTo = assertion.Subject.SubjectConfirmation.SubjectConfirmationData.InResponseTo
	}
	if requestId == "" || inResponseTo != requestId {
		return fmt.Errorf("the SAML assertion does not answer the AuthnRequest of this login (InResponseTo: %s)", inResponseTo)
	}

	if assertion.ID == "" {
		return fmt.Errorf("the SAML assertion has no ID")
	}
	ttl := time.Hour
	if assertion.Conditions != nil {
		notOnOrAfter, err := time.Parse(time.RFC3339, assertion.Conditions.NotOnOrAfter)
		if err == nil && notOnOrAfter.After(time.Now()) {
			ttl = time.Until(notOnOrAfter)
		}
	}
	isReplayed, err := SamlAssertionStore.MarkUsed(assertion.ID, ttl)
	if err != nil {
		return err
	}
	if isReplayed {
		return fmt.Errorf("the SAML assertion has already been used: %s", assertion.ID)
	}

	return nil
}

// GenerateSamlRequest builds the AuthnRequest for the provider and returns, with the
// URL or POST body carrying it, the request ID the response must answer.
func GenerateSamlRequest(id, relayState, host, lang string) (auth string, method string, requestId string, err error) {
	provider, err := GetProvider(id)
	if err != nil {
		return "", "", "", err
	}
	if provider.Category != "SAML" {
		return "", "", "", fmt.Errorf(i18n.Translate(lang, "saml_sp:provider %s's category is not SAML"), provider.Name)
	}

	sp, err := buildSp(provider, "", host)
	if err != nil {
		return "", "", "", err
	}

	doc, err := sp.BuildAuthRequestDocument()
	if err != nil {
		return "", "", "", err
	}
	requestId = doc.Root().SelectAttrValue("ID", "")

	if provider.EnableSignAuthnRequest {
		post, err := sp.BuildAuthBodyPostFromDocument(relayState, doc)
		if err != nil {
			return "", "", "", err
		}
		auth = string(post[:])
		method = "POST"
	} else {
		auth, err = sp.BuildAuthURLFromDocument(relayState, doc)
		if err != nil {
			return "", "", "", err
		}
		method = "GET"
	}
	return auth, method, requestId, nil
}

func buildSp(provider *Provider, samlResponse string, host string) (*saml2.SAMLServiceProvider, error) {
	_, origin := getOriginFromHost(host)

	certStore, err := buildSpCertificateStore(provider)
	if err != nil {
		return nil, err
	}

	sp := &saml2.SAMLServiceProvider{
		ServiceProviderIssuer:       fmt.Sprintf("%s/api/acs", origin),
		AssertionConsumerServiceURL: fmt.Sprintf("%s/api/acs", origin),
		AudienceURI:                 fmt.Sprintf("%s/api/acs", origin),
		SignAuthnRequests:           false,
		IDPCertificateStore:         &certStore,
		SPKeyStore:                  dsig.RandomKeyStoreForTest(),
	}

	if provider.Endpoint != "" {
		sp.IdentityProviderSSOURL = provider.Endpoint
		sp.IdentityProviderIssuer = provider.IssuerUrl
	}
	if provider.EnableSignAuthnRequest {
		sp.SignAuthnRequests = true
		sp.SPKeyStore, err = buildSpKeyStore()
		if err != nil {
			return nil, err
		}
	}

	return sp, nil
}

func buildSpKeyStore() (dsig.X509KeyStore, error) {
	cert, err := getCert("admin", "cert-built-in")
	if err != nil {
		return nil, err
	}
	if cert == nil || cert.Certificate == "" || cert.PrivateKey == "" {
		return nil, fmt.Errorf("the cert: admin/cert-built-in is not found")
	}

	keyPair, err := tls.X509KeyPair([]byte(cert.Certificate), []byte(cert.PrivateKey))
	if err != nil {
		return nil, err
	}
	return &dsig.TLSCertKeyStore{
		PrivateKey:  keyPair.PrivateKey,
		Certificate: keyPair.Certificate,
	}, nil
}

func buildSpCertificateStore(provider *Provider) (certStore dsig.MemoryX509CertificateStore, err error) {
	certEncodedData := provider.IdP
	if certEncodedData == "" {
		return dsig.MemoryX509CertificateStore{}, fmt.Errorf("the IdP certificate of provider: %s is empty", provider.Name)
	}

	var certData []byte
	block, _ := pem.Decode([]byte(certEncodedData))
	if block != nil {
		// this was a PEM file
		// block.Bytes are DER encoded so the following code block should happily accept it
		certData = block.Bytes
	} else {
		certData, err = base64.StdEncoding.DecodeString(certEncodedData)
		if err != nil {
			return dsig.MemoryX509CertificateStore{}, err
		}
	}

	idpCert, err := x509.ParseCertificate(certData)
	if err != nil {
		return dsig.MemoryX509CertificateStore{}, err
	}

	certStore = dsig.MemoryX509CertificateStore{
		Roots: []*x509.Certificate{idpCert},
	}
	return certStore, nil
}
