// Copyright 2026 The Casdoor Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package object

import (
	"fmt"
	"net/url"
	"strings"
	"time"

	"github.com/casdoor/casdoor/util"
)

// DynamicClientRegistrationRequest represents an RFC 7591 client registration request
type DynamicClientRegistrationRequest struct {
	ClientName              string   `json:"client_name,omitempty"`
	RedirectUris            []string `json:"redirect_uris,omitempty"`
	GrantTypes              []string `json:"grant_types,omitempty"`
	ResponseTypes           []string `json:"response_types,omitempty"`
	TokenEndpointAuthMethod string   `json:"token_endpoint_auth_method,omitempty"`
	ApplicationType         string   `json:"application_type,omitempty"`
	Contacts                []string `json:"contacts,omitempty"`
	LogoUri                 string   `json:"logo_uri,omitempty"`
	ClientUri               string   `json:"client_uri,omitempty"`
	PolicyUri               string   `json:"policy_uri,omitempty"`
	TosUri                  string   `json:"tos_uri,omitempty"`
	Scope                   string   `json:"scope,omitempty"`
}

// DynamicClientRegistrationResponse represents an RFC 7591/7592 client registration response
type DynamicClientRegistrationResponse struct {
	ClientId                string   `json:"client_id"`
	ClientSecret            string   `json:"client_secret,omitempty"`
	ClientIdIssuedAt        int64    `json:"client_id_issued_at,omitempty"`
	ClientSecretExpiresAt   int64    `json:"client_secret_expires_at"`
	ClientName              string   `json:"client_name,omitempty"`
	RedirectUris            []string `json:"redirect_uris,omitempty"`
	GrantTypes              []string `json:"grant_types,omitempty"`
	ResponseTypes           []string `json:"response_types,omitempty"`
	TokenEndpointAuthMethod string   `json:"token_endpoint_auth_method,omitempty"`
	ApplicationType         string   `json:"application_type,omitempty"`
	Contacts                []string `json:"contacts,omitempty"`
	LogoUri                 string   `json:"logo_uri,omitempty"`
	ClientUri               string   `json:"client_uri,omitempty"`
	PolicyUri               string   `json:"policy_uri,omitempty"`
	TosUri                  string   `json:"tos_uri,omitempty"`
	Scope                   string   `json:"scope,omitempty"`
	RegistrationClientUri   string   `json:"registration_client_uri,omitempty"`
	RegistrationAccessToken string   `json:"registration_access_token,omitempty"`
}

// DcrError represents an RFC 7591/7592 error response
type DcrError struct {
	Error            string `json:"error"`
	ErrorDescription string `json:"error_description,omitempty"`
}

// RegisterDynamicClient creates a new application based on DCR request (RFC 7591)
func RegisterDynamicClient(req *DynamicClientRegistrationRequest, organization string, registrationClientUri string, lang string) (*DynamicClientRegistrationResponse, *DcrError, error) {
	// Validate organization exists and has DCR enabled
	org, err := GetOrganization(util.GetId("admin", organization))
	if err != nil {
		return nil, nil, err
	}
	if org == nil {
		return nil, &DcrError{
			Error:            "invalid_client_metadata",
			ErrorDescription: "organization not found",
		}, nil
	}

	// Check if DCR is enabled for this organization
	if org.DcrPolicy == "" || org.DcrPolicy == "disabled" {
		return nil, &DcrError{
			Error:            "invalid_client_metadata",
			ErrorDescription: "dynamic client registration is disabled for this organization",
		}, nil
	}

	// Validate required fields
	if len(req.RedirectUris) == 0 {
		return nil, &DcrError{
			Error:            "invalid_redirect_uri",
			ErrorDescription: "redirect_uris is required and must contain at least one URI",
		}, nil
	}
	if dcrErr := checkDcrClientMetadata(req); dcrErr != nil {
		return nil, dcrErr, nil
	}

	// Set defaults
	if req.ClientName == "" {
		clientIdPrefix := util.GenerateClientId()
		if len(clientIdPrefix) > 8 {
			clientIdPrefix = clientIdPrefix[:8]
		}
		req.ClientName = fmt.Sprintf("DCR Client %s", clientIdPrefix)
	}
	if len(req.GrantTypes) == 0 {
		req.GrantTypes = []string{"authorization_code"}
	}
	if len(req.ResponseTypes) == 0 {
		req.ResponseTypes = []string{"code"}
	}
	if req.TokenEndpointAuthMethod == "" {
		req.TokenEndpointAuthMethod = "client_secret_basic"
	}
	if req.ApplicationType == "" {
		req.ApplicationType = "web"
	}

	registrationAccessToken := util.GenerateClientSecret()
	application := newDynamicClientApplication(req, org, "dcr")
	application.RegistrationAccessToken = registrationAccessToken
	clientId := application.ClientId
	clientSecret := application.ClientSecret

	// Add the application
	affected, err := AddApplication(application, lang)
	if err != nil {
		return nil, nil, err
	}
	if !affected {
		return nil, &DcrError{
			Error:            "invalid_client_metadata",
			ErrorDescription: "failed to create client application",
		}, nil
	}

	// Build response
	response := &DynamicClientRegistrationResponse{
		ClientId:                clientId,
		ClientSecret:            clientSecret,
		ClientIdIssuedAt:        time.Now().Unix(),
		ClientSecretExpiresAt:   0,
		ClientName:              req.ClientName,
		RedirectUris:            req.RedirectUris,
		GrantTypes:              req.GrantTypes,
		ResponseTypes:           req.ResponseTypes,
		TokenEndpointAuthMethod: req.TokenEndpointAuthMethod,
		ApplicationType:         req.ApplicationType,
		Contacts:                req.Contacts,
		LogoUri:                 req.LogoUri,
		ClientUri:               req.ClientUri,
		PolicyUri:               req.PolicyUri,
		TosUri:                  req.TosUri,
		Scope:                   req.Scope,
		RegistrationClientUri:   fmt.Sprintf("%s/%s", registrationClientUri, clientId),
		RegistrationAccessToken: registrationAccessToken,
	}

	return response, nil, nil
}

// newDynamicClientApplication builds an application for a client that registers itself, tagged with the way it registered
func newDynamicClientApplication(req *DynamicClientRegistrationRequest, org *Organization, tag string) *Application {
	appName := fmt.Sprintf("%s_%s", tag, util.GetRandomName())

	// Inherit providers, signin methods, and branding from the organization's default application
	// so that DCR-registered apps have a working sign-in method and correct branding out of the box.
	var inheritedProviders []*ProviderItem
	var inheritedSigninMethods []*SigninMethod
	var inheritedLogo, inheritedFooterHtml, inheritedFormCss string
	var inheritedThemeData *ThemeData
	var inheritedSigninItems []*SigninItem
	var inheritedEnableSigninSession, inheritedEnableWebAuthn bool
	defaultApp, err := GetDefaultApplication(util.GetId(org.Owner, org.Name))
	if err == nil && defaultApp != nil {
		inheritedProviders = defaultApp.Providers
		inheritedSigninMethods = defaultApp.SigninMethods
		inheritedLogo = defaultApp.Logo
		inheritedThemeData = defaultApp.ThemeData
		inheritedFooterHtml = defaultApp.FooterHtml
		inheritedFormCss = defaultApp.FormCss
		inheritedSigninItems = defaultApp.SigninItems
		inheritedEnableSigninSession = defaultApp.EnableSigninSession
		inheritedEnableWebAuthn = defaultApp.EnableWebAuthn
	}

	expireInHours, refreshExpireInHours, cookieExpireInHours := getDcrTokenLifetimes(defaultApp)

	// Create Application object
	// Note: DCR applications are created under "admin" owner by default
	// This can be made configurable in future versions
	return &Application{
		Owner:                "admin",
		Name:                 appName,
		Organization:         org.Name,
		CreatedTime:          util.GetCurrentTime(),
		DisplayName:          req.ClientName,
		Category:             "Agent",
		Type:                 "MCP",
		Scopes:               []*ScopeItem{},
		Logo:                 firstNonEmpty(req.LogoUri, inheritedLogo),
		ThemeData:            inheritedThemeData,
		FooterHtml:           inheritedFooterHtml,
		FormCss:              inheritedFormCss,
		SigninItems:          inheritedSigninItems,
		HomepageUrl:          req.ClientUri,
		ClientId:             util.GenerateClientId(),
		ClientSecret:         util.GenerateClientSecret(),
		RedirectUris:         req.RedirectUris,
		GrantTypes:           req.GrantTypes,
		EnablePassword:       true,
		EnableSignUp:         false,
		DisableSignin:        false,
		EnableSigninSession:  inheritedEnableSigninSession,
		EnableCodeSignin:     true,
		EnableAutoSignin:     false,
		EnableWebAuthn:       inheritedEnableWebAuthn,
		TokenFormat:          org.DefaultTokenFormat,
		TokenFields:          org.DefaultTokenFields,
		ExpireInHours:        expireInHours,
		RefreshExpireInHours: refreshExpireInHours,
		CookieExpireInHours:  cookieExpireInHours,
		FormOffset:           2,
		Tags:                 []string{tag},
		TermsOfUse:           req.TosUri,
		Providers:            inheritedProviders,
		SigninMethods:        inheritedSigninMethods,
	}
}

// GetDynamicClientByToken finds a DCR application by clientId and validates the registration access token
func GetDynamicClientByToken(clientId, bearerToken string) (*Application, *DcrError) {
	application, err := GetApplicationByClientId(clientId)
	if err != nil {
		return nil, &DcrError{Error: "server_error", ErrorDescription: err.Error()}
	}
	if application == nil {
		return nil, &DcrError{Error: "invalid_token", ErrorDescription: "client not found"}
	}
	if application.RegistrationAccessToken == "" || application.RegistrationAccessToken != bearerToken {
		return nil, &DcrError{Error: "invalid_token", ErrorDescription: "invalid registration access token"}
	}
	return application, nil
}

// GetDynamicClientRegistrationResponse builds a RFC 7592 read response from an application
func GetDynamicClientRegistrationResponse(app *Application, registrationClientUri string) *DynamicClientRegistrationResponse {
	return &DynamicClientRegistrationResponse{
		ClientId:                app.ClientId,
		ClientSecret:            app.ClientSecret,
		ClientIdIssuedAt:        0,
		ClientSecretExpiresAt:   0,
		ClientName:              app.DisplayName,
		RedirectUris:            app.RedirectUris,
		GrantTypes:              app.GrantTypes,
		TokenEndpointAuthMethod: "client_secret_basic",
		ApplicationType:         "web",
		LogoUri:                 app.Logo,
		ClientUri:               app.HomepageUrl,
		TosUri:                  app.TermsOfUse,
		RegistrationClientUri:   fmt.Sprintf("%s/%s", registrationClientUri, app.ClientId),
		RegistrationAccessToken: app.RegistrationAccessToken,
	}
}

// UpdateDynamicClient applies a RFC 7592 PUT update to a DCR application
func UpdateDynamicClient(app *Application, req *DynamicClientRegistrationRequest) (*DynamicClientRegistrationResponse, *DcrError, error) {
	if len(req.RedirectUris) == 0 {
		return nil, &DcrError{
			Error:            "invalid_redirect_uri",
			ErrorDescription: "redirect_uris is required and must contain at least one URI",
		}, nil
	}
	if dcrErr := checkDcrClientMetadata(req); dcrErr != nil {
		return nil, dcrErr, nil
	}

	app.DisplayName = firstNonEmpty(req.ClientName, app.DisplayName)
	app.RedirectUris = req.RedirectUris
	if len(req.GrantTypes) > 0 {
		app.GrantTypes = req.GrantTypes
	}
	if req.LogoUri != "" {
		app.Logo = req.LogoUri
	}
	if req.ClientUri != "" {
		app.HomepageUrl = req.ClientUri
	}
	if req.TosUri != "" {
		app.TermsOfUse = req.TosUri
	}

	_, err := UpdateApplication(util.GetId(app.Owner, app.Name), app, true, "", nil)
	if err != nil {
		return nil, nil, err
	}

	return GetDynamicClientRegistrationResponse(app, ""), nil, nil
}

// DeleteDynamicClient removes a DCR-registered application
func DeleteDynamicClient(app *Application) *DcrError {
	affected, err := DeleteApplication(app)
	if err != nil {
		return &DcrError{Error: "server_error", ErrorDescription: err.Error()}
	}
	if !affected {
		return &DcrError{Error: "server_error", ErrorDescription: "failed to delete client"}
	}
	return nil
}

func getDcrTokenLifetimes(defaultApp *Application) (float64, float64, int64) {
	expireInHours, refreshExpireInHours, cookieExpireInHours := 168.0, 720.0, int64(720)
	if defaultApp == nil {
		return expireInHours, refreshExpireInHours, cookieExpireInHours
	}

	if defaultApp.ExpireInHours > 0 {
		expireInHours = defaultApp.ExpireInHours
	}
	if defaultApp.RefreshExpireInHours > 0 {
		refreshExpireInHours = defaultApp.RefreshExpireInHours
	}
	if defaultApp.CookieExpireInHours > 0 {
		cookieExpireInHours = defaultApp.CookieExpireInHours
	}
	return expireInHours, refreshExpireInHours, cookieExpireInHours
}

var dcrGrantTypes = []string{"authorization_code", "refresh_token", "urn:ietf:params:oauth:grant-type:device_code"}

func checkDcrClientMetadata(req *DynamicClientRegistrationRequest) *DcrError {
	for _, redirectUri := range req.RedirectUris {
		if isScriptUrl(redirectUri) {
			return &DcrError{
				Error:            "invalid_redirect_uri",
				ErrorDescription: fmt.Sprintf("the redirect URI: %s is not allowed", redirectUri),
			}
		}
	}

	for _, uri := range []string{req.LogoUri, req.ClientUri, req.PolicyUri, req.TosUri} {
		if uri != "" && !isHttpUrl(uri) {
			return &DcrError{
				Error:            "invalid_client_metadata",
				ErrorDescription: fmt.Sprintf("the URI: %s must be an http or https URL", uri),
			}
		}
	}

	grantTypes := []string{}
	for _, grantType := range req.GrantTypes {
		if util.InSlice(dcrGrantTypes, grantType) {
			grantTypes = append(grantTypes, grantType)
		}
	}
	req.GrantTypes = grantTypes
	return nil
}

func isScriptUrl(rawUrl string) bool {
	u, err := url.Parse(strings.TrimSpace(rawUrl))
	if err != nil {
		return true
	}

	scheme := strings.ToLower(u.Scheme)
	return scheme == "javascript" || scheme == "data" || scheme == "vbscript"
}

func isHttpUrl(rawUrl string) bool {
	u, err := url.Parse(rawUrl)
	if err != nil {
		return false
	}

	return (u.Scheme == "http" || u.Scheme == "https") && u.Host != ""
}
