// Copyright 2024 The Casdoor Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package object

import (
	"fmt"
	"strings"
	"time"

	"github.com/casdoor/casdoor/idp"
	"github.com/casdoor/casdoor/util"
	"github.com/golang-jwt/jwt/v5"
)

func GetOAuthToken(grantType string, clientId string, clientSecret string, code string, verifier string, scope string, nonce string, username string, password string, countryCode string, host string, refreshToken string, tag string, avatar string, lang string, subjectToken string, subjectTokenType string, assertion string, clientAssertion string, clientAssertionType string, audience string, resource string, dpopProof string, clientIp string) (interface{}, error) {
	var (
		application *Application
		err         error
		ok          bool
	)

	if clientAssertionType == "urn:ietf:params:oauth:client-assertion-type:jwt-bearer" {
		ok, application, err = ValidateClientAssertion(clientAssertion, clientId, host)
		if err != nil {
			return nil, err
		}

		if !ok || application == nil {
			return &TokenError{
				Error:            InvalidClient,
				ErrorDescription: "client_assertion is invalid",
			}, nil
		}

		clientSecret = application.ClientSecret
		clientId = application.ClientId
	} else {
		application, err = GetApplicationByClientId(clientId)
		if err != nil {
			return nil, err
		}
	}

	if application == nil {
		return &TokenError{
			Error:            InvalidClient,
			ErrorDescription: "client_id is invalid",
		}, nil
	}

	// Handle WeChat Mini Program flow separately — it does not use standard OAuth grant types
	if tag == "wechat_miniprogram" {
		token, tokenError, err := GetWechatMiniProgramToken(application, code, host, username, avatar, lang)
		if err != nil {
			return nil, err
		}
		if tokenError != nil {
			return tokenError, nil
		}
		return token, nil
	}

	// Check if grantType is allowed in the current application
	if !IsGrantTypeValid(grantType, application.GrantTypes) {
		return &TokenError{
			Error:            UnsupportedGrantType,
			ErrorDescription: fmt.Sprintf("grant_type: %s is not supported in this application", grantType),
		}, nil
	}

	var token *Token
	var tokenError *TokenError
	switch grantType {
	case "authorization_code": // Authorization Code Grant
		token, tokenError, err = GetAuthorizationCodeToken(application, clientSecret, code, verifier, resource, lang)
	case "password": // Resource Owner Password Credentials Grant
		token, tokenError, err = GetPasswordToken(application, username, password, scope, host, clientIp, lang)
	case "client_credentials": // Client Credentials Grant
		token, tokenError, err = GetClientCredentialsToken(application, clientSecret, scope, host)
	case VerificationCodeGrantType:
		token, tokenError, err = GetVerificationCodeToken(application, username, countryCode, code, scope, host, clientIp, lang)
	case MobileOneClickGrantType:
		token, tokenError, err = GetMobileOneClickToken(application, code, scope, host, clientIp, lang)
	case "token", "id_token": // Implicit Grant
		token, tokenError, err = GetImplicitToken(application, username, password, scope, nonce, host, clientIp, lang)
	case "urn:ietf:params:oauth:grant-type:jwt-bearer":
		token, tokenError, err = GetJwtBearerToken(application, assertion, scope, nonce, host, clientIp, lang)
	case "urn:ietf:params:oauth:grant-type:device_code":
		// The user has already authenticated via browser in the device flow,
		// so we skip password verification and mint a token directly.
		token, tokenError, err = GetDeviceCodeToken(application, username, scope, nonce, host)
	case "urn:ietf:params:oauth:grant-type:token-exchange": // Token Exchange Grant (RFC 8693)
		token, tokenError, err = GetTokenExchangeToken(application, clientSecret, subjectToken, subjectTokenType, audience, scope, host)
	case "refresh_token":
		refreshToken2, err := RefreshToken(application, grantType, refreshToken, scope, clientId, clientSecret, resource, host, dpopProof, "/api/login/oauth/access_token")
		if err != nil {
			return nil, err
		}
		return refreshToken2, nil
	}

	if err != nil {
		return nil, err
	}

	if tokenError != nil {
		return tokenError, nil
	}

	// Apply DPoP binding (RFC 9449) if a DPoP proof was supplied by the client.
	if dpopProof != "" {
		dpopHtu := GetDPoPHtu(host, "/api/login/oauth/access_token")
		jkt, dpopErr := ValidateDPoPProof(dpopProof, "POST", dpopHtu, "")
		if dpopErr != nil {
			return &TokenError{
				Error:            "invalid_dpop_proof",
				ErrorDescription: dpopErr.Error(),
			}, nil
		}
		token.TokenType = "DPoP"
		token.DPoPJkt = jkt
		if err = updateTokenDPoP(token); err != nil {
			return nil, err
		}
	}

	token.CodeIsUsed = true

	_, err = updateUsedByCode(token)
	if err != nil {
		return nil, err
	}

	tokenWrapper := &TokenWrapper{
		AccessToken:  token.AccessToken,
		IdToken:      token.IdToken,
		RefreshToken: token.RefreshToken,
		TokenType:    token.TokenType,
		ExpiresIn:    token.ExpiresIn,
		Scope:        token.Scope,
	}

	return tokenWrapper, nil
}

// GetAuthorizationCodeToken handles the Authorization Code Grant flow.
func GetAuthorizationCodeToken(application *Application, clientSecret string, code string, verifier string, resource string, lang string) (*Token, *TokenError, error) {
	if code == "" {
		return nil, &TokenError{
			Error:            InvalidRequest,
			ErrorDescription: "authorization code should not be empty",
		}, nil
	}

	// Handle guest user creation
	if code == "guest-user" {
		if application.Organization == "built-in" {
			return nil, &TokenError{
				Error:            InvalidGrant,
				ErrorDescription: "guest signin is not allowed for built-in organization",
			}, nil
		}
		if !application.EnableGuestSignin {
			return nil, &TokenError{
				Error:            InvalidGrant,
				ErrorDescription: "guest signin is not enabled for this application",
			}, nil
		}
		if !application.EnableSignUp {
			return nil, &TokenError{
				Error:            InvalidGrant,
				ErrorDescription: "sign up is not enabled for this application",
			}, nil
		}
		return createGuestUserToken(application, clientSecret, verifier, lang)
	}

	token, err := getTokenByCode(code)
	if err != nil {
		return nil, nil, err
	}

	if token == nil {
		return nil, &TokenError{
			Error:            InvalidGrant,
			ErrorDescription: fmt.Sprintf("authorization code: [%s] is invalid", code),
		}, nil
	}

	if token.CodeIsUsed {
		// anti replay attacks
		return nil, &TokenError{
			Error:            InvalidGrant,
			ErrorDescription: fmt.Sprintf("authorization code has been used for token: [%s]", token.GetId()),
		}, nil
	}

	if token.CodeChallenge != "" {
		challengeAnswer := pkceChallenge(verifier)
		if challengeAnswer != token.CodeChallenge {
			return nil, &TokenError{
				Error:            InvalidGrant,
				ErrorDescription: fmt.Sprintf("verifier is invalid, challengeAnswer: [%s], token.CodeChallenge: [%s]", challengeAnswer, token.CodeChallenge),
			}, nil
		}
	}

	if application.ClientSecret != clientSecret {
		// when using PKCE, the Client Secret can be empty,
		// but if it is provided, it must be accurate.
		if token.CodeChallenge == "" {
			return nil, &TokenError{
				Error:            InvalidClient,
				ErrorDescription: fmt.Sprintf("client_secret is invalid for application: [%s], token.CodeChallenge: empty", application.GetId()),
			}, nil
		} else {
			if clientSecret != "" {
				return nil, &TokenError{
					Error:            InvalidClient,
					ErrorDescription: fmt.Sprintf("client_secret is invalid for application: [%s], token.CodeChallenge: [%s]", application.GetId(), token.CodeChallenge),
				}, nil
			}
		}
	}

	if application.Name != token.Application {
		return nil, &TokenError{
			Error:            InvalidGrant,
			ErrorDescription: fmt.Sprintf("the token is for wrong application (client_id), application.Name: [%s], token.Application: [%s]", application.Name, token.Application),
		}, nil
	}

	// RFC 8707: Validate resource parameter matches the one in the authorization request
	if resource != token.Resource {
		return nil, &TokenError{
			Error:            InvalidGrant,
			ErrorDescription: fmt.Sprintf("resource parameter does not match authorization request, expected: [%s], got: [%s]", token.Resource, resource),
		}, nil
	}

	nowUnix := time.Now().Unix()
	if nowUnix > token.CodeExpireIn {
		// code must be used within 5 minutes
		return nil, &TokenError{
			Error:            InvalidGrant,
			ErrorDescription: fmt.Sprintf("authorization code has expired, nowUnix: [%s], token.CodeExpireIn: [%s]", time.Unix(nowUnix, 0).Format(time.RFC3339), time.Unix(token.CodeExpireIn, 0).Format(time.RFC3339)),
		}, nil
	}

	claimed, err := claimAuthorizationCode(token.Code)
	if err != nil {
		return nil, nil, err
	}
	if !claimed {
		return nil, &TokenError{
			Error:            InvalidGrant,
			ErrorDescription: fmt.Sprintf("authorization code has been used for token: [%s]", token.GetId()),
		}, nil
	}

	if clientSecret != "" {
		token.GrantType = "authorization_code"
	}
	return token, nil, nil
}

// GetPasswordToken handles the Resource Owner Password Credentials Grant flow.
func GetPasswordToken(application *Application, username string, password string, scope string, host string, clientIp string, lang string) (*Token, *TokenError, error) {
	expandedScope, ok := IsScopeValidAndExpand(scope, application)
	if !ok {
		return nil, &TokenError{
			Error:            InvalidScope,
			ErrorDescription: "the requested scope is invalid or not defined in the application",
		}, nil
	}
	scope = expandedScope

	user, err := GetUserByFieldsForSharedApp(application, application.Organization, username)
	if err != nil {
		return nil, nil, err
	}
	if user == nil {
		return nil, &TokenError{
			Error:            InvalidGrant,
			ErrorDescription: "the user does not exist",
		}, nil
	}

	if user.Ldap != "" {
		err = CheckLdapUserPassword(user, password, lang)
	} else {
		// For OAuth users who don't have a password set, they cannot use password grant type
		if user.Password == "" {
			return nil, &TokenError{
				Error:            InvalidGrant,
				ErrorDescription: "OAuth users cannot use password grant type, please use authorization code flow",
			}, nil
		}
		err = CheckPassword(user, password, lang)
	}
	if err != nil {
		return nil, &TokenError{
			Error:            InvalidGrant,
			ErrorDescription: fmt.Sprintf("invalid username or password: %s", err.Error()),
		}, nil
	}

	if tokenError := getMfaUserTokenError(user); tokenError != nil {
		return nil, tokenError, nil
	}

	if tokenError := getSigninPolicyTokenError(user, lang); tokenError != nil {
		return nil, tokenError, nil
	}

	if tokenError := checkGrantUserSignin(application, user, clientIp, lang); tokenError != nil {
		return nil, tokenError, nil
	}

	return getUserGrantToken(application, user, scope, host)
}

// getUserGrantToken issues the token of a grant whose user has been authenticated by the grant itself
func getUserGrantToken(application *Application, user *User, scope string, host string) (*Token, *TokenError, error) {
	err := ExtendUserWithRolesAndPermissions(user)
	if err != nil {
		return nil, nil, err
	}

	accessToken, refreshToken, idToken, tokenName, err := generateJwtToken(application, user, "", "", "", scope, "", host)
	if err != nil {
		return nil, &TokenError{
			Error:            EndpointError,
			ErrorDescription: fmt.Sprintf("generate jwt token error: %s", err.Error()),
		}, nil
	}

	// Record the signin after the token is generated, so that the "lastSigninTime"
	// claim in the token means the previous signin instead of the current one.
	err = RecordUserSignin(user, "")
	if err != nil {
		return nil, nil, err
	}

	token := &Token{
		Owner:        application.Owner,
		Name:         tokenName,
		CreatedTime:  util.GetCurrentTime(),
		Application:  application.Name,
		Organization: user.Owner,
		User:         user.Name,
		Code:         util.GenerateAuthorizationCode(),
		AccessToken:  accessToken,
		RefreshToken: refreshToken,
		IdToken:      idToken,
		ExpiresIn:    int(application.ExpireInHours * float64(hourSeconds)),
		Scope:        scope,
		TokenType:    "Bearer",
		CodeIsUsed:   true,
	}
	_, err = AddToken(token)
	if err != nil {
		return nil, nil, err
	}

	return token, nil, nil
}

// GetClientCredentialsToken handles the Client Credentials Grant flow.
func GetClientCredentialsToken(application *Application, clientSecret string, scope string, host string) (*Token, *TokenError, error) {
	if application.ClientSecret != clientSecret {
		return nil, &TokenError{
			Error:            InvalidClient,
			ErrorDescription: "client_secret is invalid",
		}, nil
	}
	return getApplicationToken(application, scope, host, "client_credentials")
}

func getApplicationToken(application *Application, scope string, host string, grantType string) (*Token, *TokenError, error) {
	expandedScope, ok := IsScopeValidAndExpand(scope, application)
	if !ok {
		return nil, &TokenError{
			Error:            InvalidScope,
			ErrorDescription: "the requested scope is invalid or not defined in the application",
		}, nil
	}
	scope = expandedScope
	nullUser := &User{
		Owner: application.Owner,
		Id:    application.GetId(),
		Name:  application.Name,
		Type:  "application",
	}

	accessToken, _, _, tokenName, err := generateJwtToken(application, nullUser, "", "", "", scope, "", host)
	if err != nil {
		return nil, &TokenError{
			Error:            EndpointError,
			ErrorDescription: fmt.Sprintf("generate jwt token error: %s", err.Error()),
		}, nil
	}
	token := &Token{
		Owner:        application.Owner,
		Name:         tokenName,
		CreatedTime:  util.GetCurrentTime(),
		Application:  application.Name,
		Organization: application.Organization,
		User:         nullUser.Name,
		Code:         util.GenerateAuthorizationCode(),
		AccessToken:  accessToken,
		ExpiresIn:    int(application.ExpireInHours * float64(hourSeconds)),
		Scope:        scope,
		TokenType:    "Bearer",
		GrantType:    grantType,
		CodeIsUsed:   true,
	}
	_, err = AddToken(token)
	if err != nil {
		return nil, nil, err
	}

	return token, nil, nil
}

// GetImplicitToken handles the Implicit Grant flow (requires password verification).
func GetImplicitToken(application *Application, username string, password string, scope string, nonce string, host string, clientIp string, lang string) (*Token, *TokenError, error) {
	user, err := GetUserByFieldsForSharedApp(application, application.Organization, username)
	if err != nil {
		return nil, nil, err
	}
	if user == nil {
		return nil, &TokenError{
			Error:            InvalidGrant,
			ErrorDescription: "the user does not exist",
		}, nil
	}

	if user.Ldap != "" {
		err = CheckLdapUserPassword(user, password, lang)
	} else {
		if user.Password == "" {
			return nil, &TokenError{
				Error:            InvalidGrant,
				ErrorDescription: "OAuth users cannot use implicit grant type, please use authorization code flow",
			}, nil
		}
		err = CheckPassword(user, password, lang)
	}
	if err != nil {
		return nil, &TokenError{
			Error:            InvalidGrant,
			ErrorDescription: fmt.Sprintf("invalid username or password: %s", err.Error()),
		}, nil
	}

	if tokenError := getMfaUserTokenError(user); tokenError != nil {
		return nil, tokenError, nil
	}

	if tokenError := getSigninPolicyTokenError(user, lang); tokenError != nil {
		return nil, tokenError, nil
	}

	if tokenError := checkGrantUserSignin(application, user, clientIp, lang); tokenError != nil {
		return nil, tokenError, nil
	}

	return mintTokenForUser(application, user, scope, nonce, host)
}

func checkGrantUserSignin(application *Application, user *User, clientIp string, lang string) *TokenError {
	err := CheckApplicationSignin(application, user, clientIp, lang)
	if err != nil {
		return &TokenError{
			Error:            InvalidGrant,
			ErrorDescription: err.Error(),
		}
	}
	return nil
}

// getMfaUserTokenError refuses a password-only grant for an MFA-enabled user, the same as
// the password in the URL of AutoSigninFilter, or the password alone would skip the second factor
func getMfaUserTokenError(user *User) *TokenError {
	if !user.IsMfaEnabled() {
		return nil
	}

	return &TokenError{
		Error:            InvalidGrant,
		ErrorDescription: "the user has MFA enabled and cannot sign in with a password grant, please use the authorization code flow",
	}
}

func getSigninPolicyTokenError(user *User, lang string) *TokenError {
	err := CheckPasswordOnlySignin(user, "", lang)
	if err == nil {
		return nil
	}

	return &TokenError{
		Error:            InvalidGrant,
		ErrorDescription: err.Error(),
	}
}

func getInactiveUserTokenError(user *User) *TokenError {
	if !user.IsForbidden && !user.IsDeleted {
		return nil
	}

	return &TokenError{
		Error:            InvalidGrant,
		ErrorDescription: "the user is forbidden to sign in, please contact the administrator",
	}
}

// GetJwtBearerToken handles the JWT Bearer Grant flow (RFC 7523).
func GetJwtBearerToken(application *Application, assertion string, scope string, nonce string, host string, clientIp string, lang string) (*Token, *TokenError, error) {
	credential, federatedClaims, err := validateFederatedToken(application, assertion, host)
	if err != nil {
		return nil, &TokenError{
			Error:            InvalidGrant,
			ErrorDescription: err.Error(),
		}, nil
	}
	if credential != nil {
		user, tokenError, err := getFederatedUser(application, credential, federatedClaims)
		if err != nil || tokenError != nil {
			return nil, tokenError, err
		}
		if user == nil {
			return getApplicationToken(application, scope, host, "urn:ietf:params:oauth:grant-type:jwt-bearer")
		}
		if tokenError = checkGrantUserSignin(application, user, clientIp, lang); tokenError != nil {
			return nil, tokenError, nil
		}
		return mintTokenForUser(application, user, scope, nonce, host)
	}

	ok, claims, err := ValidateJwtAssertion(assertion, application, host)
	if err != nil || !ok {
		if err != nil {
			return nil, &TokenError{
				Error:            InvalidGrant,
				ErrorDescription: err.Error(),
			}, err
		}

		return nil, &TokenError{
			Error:            InvalidGrant,
			ErrorDescription: fmt.Sprintf("assertion (JWT) is invalid for application: [%s]", application.GetId()),
		}, nil
	}

	// JWT assertion has already been validated above; skip password re-verification
	return mintImplicitToken(application, claims.Subject, scope, nonce, host, clientIp, lang)
}

// GetTokenByUser mints a token for the given user (Implicit flow helper).
func GetTokenByUser(application *Application, user *User, scope string, nonce string, sessionId string, host string) (*Token, error) {
	return GetTokenByUserWithAuth(application, user, scope, nonce, sessionId, host, 0, false)
}

// GetTokenByUserWithAuth mints the tokens an implicit flow returns from the authorization endpoint:
// authTime is when the user entered credentials, withAtHash is set when the access token is
// returned together with the ID token
func GetTokenByUserWithAuth(application *Application, user *User, scope string, nonce string, sessionId string, host string, authTime int64, withAtHash bool) (*Token, error) {
	err := ExtendUserWithRolesAndPermissions(user)
	if err != nil {
		return nil, err
	}

	options := jwtTokenOptions{AuthTime: authTime, WithAtHash: withAtHash}
	accessToken, refreshToken, idToken, tokenName, err := generateJwtTokenWithOptions(application, user, "", "", nonce, scope, "", host, options)
	if err != nil {
		return nil, err
	}

	token := &Token{
		Owner:        application.Owner,
		Name:         tokenName,
		CreatedTime:  util.GetCurrentTime(),
		Application:  application.Name,
		Organization: user.Owner,
		User:         user.Name,
		Code:         util.GenerateAuthorizationCode(),
		AccessToken:  accessToken,
		RefreshToken: refreshToken,
		IdToken:      idToken,
		ExpiresIn:    int(application.ExpireInHours * float64(hourSeconds)),
		Scope:        scope,
		TokenType:    "Bearer",
		CodeIsUsed:   true,
		SessionId:    sessionId,
	}
	_, err = AddToken(token)
	if err != nil {
		return nil, err
	}

	return token, nil
}

// GetWechatMiniProgramToken handles the WeChat Mini Program flow.
func GetWechatMiniProgramToken(application *Application, code string, host string, username string, avatar string, lang string) (*Token, *TokenError, error) {
	mpProvider := GetWechatMiniProgramProvider(application)
	if mpProvider == nil {
		return nil, &TokenError{
			Error:            InvalidClient,
			ErrorDescription: "the application does not support wechat mini program",
		}, nil
	}
	provider, err := GetProvider(util.GetId("admin", mpProvider.Name))
	if err != nil {
		return nil, nil, err
	}

	mpIdp := idp.NewWeChatMiniProgramIdProvider(provider.ClientId, provider.ClientSecret)
	session, err := mpIdp.GetSessionByCode(code)
	if err != nil {
		return nil, &TokenError{
			Error:            InvalidGrant,
			ErrorDescription: fmt.Sprintf("get wechat mini program session error: %s", err.Error()),
		}, nil
	}

	openId, unionId := session.Openid, session.Unionid
	if openId == "" && unionId == "" {
		return nil, &TokenError{
			Error:            InvalidRequest,
			ErrorDescription: "the wechat mini program session is invalid",
		}, nil
	}
	user, err := getUserByWechatId(application.Organization, openId, unionId)
	if err != nil {
		return nil, nil, err
	}

	if user == nil {
		if !application.EnableSignUp || !application.IsSignupAllowedFor(application.Organization) {
			return nil, &TokenError{
				Error:            InvalidGrant,
				ErrorDescription: "the application does not allow to sign up new account",
			}, nil
		}
		// Add new user
		var name string
		if CheckUsername(username, lang) == "" {
			name = username
		} else {
			name = fmt.Sprintf("wechat-%s", openId)
		}

		// Generate a unique user ID within the confines of the application
		newUserId, idErr := GenerateIdForNewUser(application)
		if idErr != nil {
			// If we fail to generate a unique user ID, we can fallback to a random ID
			newUserId = util.GenerateId()
		}

		user = &User{
			Owner:             application.Organization,
			Id:                newUserId,
			Name:              name,
			Avatar:            avatar,
			SignupApplication: application.Name,
			WeChat:            openId,
			Type:              "normal-user",
			CreatedTime:       util.GetCurrentTime(),
			IsAdmin:           false,
			IsForbidden:       false,
			IsDeleted:         false,
			Properties: map[string]string{
				UserPropertiesWechatOpenId:  openId,
				UserPropertiesWechatUnionId: unionId,
			},
		}
		_, err = AddUser(user, lang)
		if err != nil {
			return nil, nil, err
		}
	}

	if tokenError := getInactiveUserTokenError(user); tokenError != nil {
		return nil, tokenError, nil
	}

	err = ExtendUserWithRolesAndPermissions(user)
	if err != nil {
		return nil, nil, err
	}

	accessToken, refreshToken, idToken, tokenName, err := generateJwtToken(application, user, "", "", "", "", "", host)
	if err != nil {
		return nil, &TokenError{
			Error:            EndpointError,
			ErrorDescription: fmt.Sprintf("generate jwt token error: %s", err.Error()),
		}, nil
	}

	token := &Token{
		Owner:        application.Owner,
		Name:         tokenName,
		CreatedTime:  util.GetCurrentTime(),
		Application:  application.Name,
		Organization: user.Owner,
		User:         user.Name,
		Code:         session.SessionKey, // a trick, because miniprogram does not use the code, so use the code field to save the session_key
		AccessToken:  accessToken,
		RefreshToken: refreshToken,
		IdToken:      idToken,
		ExpiresIn:    int(application.ExpireInHours * float64(hourSeconds)),
		Scope:        "",
		TokenType:    "Bearer",
		CodeIsUsed:   true,
	}
	_, err = AddToken(token)
	if err != nil {
		return nil, nil, err
	}
	return token, nil, nil
}

// GetTokenExchangeToken handles the Token Exchange Grant flow (RFC 8693).
// Exchanges a subject token for a new token with different audience or scope.
func GetTokenExchangeToken(application *Application, clientSecret string, subjectToken string, subjectTokenType string, audience string, scope string, host string) (*Token, *TokenError, error) {
	credential, federatedClaims, err := validateFederatedToken(application, subjectToken, host)
	if err != nil {
		return nil, &TokenError{
			Error:            InvalidGrant,
			ErrorDescription: fmt.Sprintf("invalid subject_token: %s", err.Error()),
		}, nil
	}
	if credential != nil {
		return getFederatedTokenExchangeToken(application, credential, federatedClaims, audience, scope, host)
	}

	if application.ClientSecret != clientSecret {
		return nil, &TokenError{
			Error:            InvalidClient,
			ErrorDescription: "client_secret is invalid",
		}, nil
	}

	if subjectToken == "" {
		return nil, &TokenError{
			Error:            InvalidRequest,
			ErrorDescription: "subject_token is required",
		}, nil
	}

	// RFC 8693 defines standard token type identifiers
	if subjectTokenType == "" {
		subjectTokenType = "urn:ietf:params:oauth:token-type:access_token" // Default to access_token
	}

	supportedTokenTypes := []string{
		"urn:ietf:params:oauth:token-type:access_token",
		"urn:ietf:params:oauth:token-type:jwt",
		"urn:ietf:params:oauth:token-type:id_token",
	}

	isValidTokenType := false
	for _, tokenType := range supportedTokenTypes {
		if subjectTokenType == tokenType {
			isValidTokenType = true
			break
		}
	}

	if !isValidTokenType {
		return nil, &TokenError{
			Error:            InvalidRequest,
			ErrorDescription: fmt.Sprintf("unsupported subject_token_type: %s", subjectTokenType),
		}, nil
	}

	subjectOwner, subjectName, subjectScope, tokenError, err := parseAndValidateSubjectToken(subjectToken, application.ClientId)
	if err != nil {
		return nil, nil, err
	}
	if tokenError != nil {
		return nil, tokenError, nil
	}

	// A valid signature is not enough: the subject token must still be active, the same
	// way the refresh_token grant checks it, or a revoked token can be exchanged forever.
	var subjectTokenRecord *Token
	if subjectTokenType == "urn:ietf:params:oauth:token-type:id_token" {
		subjectTokenRecord, err = GetTokenByIdToken(subjectToken)
	} else {
		subjectTokenRecord, err = GetTokenByAccessToken(subjectToken)
	}
	if err != nil {
		return nil, nil, err
	}
	if subjectTokenRecord == nil || subjectTokenRecord.ExpiresIn <= 0 {
		return nil, &TokenError{
			Error:            InvalidGrant,
			ErrorDescription: "subject_token is revoked or unknown",
		}, nil
	}

	user, err := getUser(subjectOwner, subjectName)
	if err != nil {
		return nil, nil, err
	}
	if user == nil {
		return nil, &TokenError{
			Error:            InvalidGrant,
			ErrorDescription: fmt.Sprintf("user from subject_token does not exist: %s", util.GetId(subjectOwner, subjectName)),
		}, nil
	}

	if user.IsForbidden {
		return nil, &TokenError{
			Error:            InvalidGrant,
			ErrorDescription: "the user is forbidden to sign in, please contact the administrator",
		}, nil
	}

	// the same as signing in: only a shared application serves the users of other organizations
	if user.Owner != application.Organization && !application.IsShared {
		return nil, &TokenError{
			Error:            InvalidGrant,
			ErrorDescription: fmt.Sprintf("user from subject_token: %s does not belong to the organization of the application: %s", user.GetId(), application.Organization),
		}, nil
	}

	// RFC 8693: "audience" is the target service the new token is for, by client ID or by application name
	targetAudience := ""
	if audience != "" {
		targetApplication, err := GetApplicationByClientId(audience)
		if err != nil {
			return nil, nil, err
		}
		if targetApplication == nil {
			targetApplication, err = getApplication(application.Owner, audience)
			if err != nil {
				return nil, nil, err
			}
		}
		if targetApplication == nil {
			return nil, &TokenError{
				Error:            InvalidTarget,
				ErrorDescription: fmt.Sprintf("the requested audience is not a known application: %s", audience),
			}, nil
		}
		if user.Owner != targetApplication.Organization && !targetApplication.IsShared {
			return nil, &TokenError{
				Error:            InvalidTarget,
				ErrorDescription: fmt.Sprintf("the requested audience: %s does not serve the organization of the user: %s", audience, user.GetId()),
			}, nil
		}
		targetAudience = targetApplication.ClientId
	}

	// If scope is not provided, use the scope from the subject token.
	// If scope is provided, it should be a subset of the subject token's scope (downscoping).
	if scope == "" {
		scope = subjectScope
	} else {
		if subjectScope != "" {
			subjectScopes := strings.Split(subjectScope, " ")
			requestedScopes := strings.Split(scope, " ")
			for _, requestedScope := range requestedScopes {
				if requestedScope == "" {
					continue
				}
				found := false
				for _, existingScope := range subjectScopes {
					if existingScope != "" && requestedScope == existingScope {
						found = true
						break
					}
				}
				if !found {
					return nil, &TokenError{
						Error:            InvalidScope,
						ErrorDescription: fmt.Sprintf("requested scope '%s' is not in subject token's scope", requestedScope),
					}, nil
				}
			}
		}
	}

	err = ExtendUserWithRolesAndPermissions(user)
	if err != nil {
		return nil, nil, err
	}

	accessToken, refreshToken, idToken, tokenName, err := generateJwtToken(application, user, "", "", "", scope, targetAudience, host)
	if err != nil {
		return nil, &TokenError{
			Error:            EndpointError,
			ErrorDescription: fmt.Sprintf("generate jwt token error: %s", err.Error()),
		}, nil
	}

	token := &Token{
		Owner:        application.Owner,
		Name:         tokenName,
		CreatedTime:  util.GetCurrentTime(),
		Application:  application.Name,
		Organization: user.Owner,
		User:         user.Name,
		Code:         util.GenerateAuthorizationCode(),
		AccessToken:  accessToken,
		RefreshToken: refreshToken,
		IdToken:      idToken,
		ExpiresIn:    int(application.ExpireInHours * float64(hourSeconds)),
		Scope:        scope,
		TokenType:    "Bearer",
		CodeIsUsed:   true,
		Resource:     targetAudience,
		GrantType:    "urn:ietf:params:oauth:grant-type:token-exchange",
	}

	_, err = AddToken(token)
	if err != nil {
		return nil, nil, err
	}

	return token, nil, nil
}

func GetAccessTokenByUser(user *User, host string) (string, error) {
	application, err := GetApplicationByUser(user)
	if err != nil {
		return "", err
	}
	if application == nil {
		return "", fmt.Errorf("the application for user %s is not found", user.Id)
	}

	token, err := GetTokenByUser(application, user, "profile", "", "", host)
	if err != nil {
		return "", err
	}

	return token.AccessToken, nil
}

// getFederatedTokenExchangeToken exchanges a token of an external issuer trusted by the application.
// The verified token is the credential, so no client secret is involved.
func getFederatedTokenExchangeToken(application *Application, credential *FederatedCredential, claims jwt.MapClaims, audience string, scope string, host string) (*Token, *TokenError, error) {
	user, tokenError, err := getFederatedUser(application, credential, claims)
	if err != nil || tokenError != nil {
		return nil, tokenError, err
	}

	expandedScope, ok := IsScopeValidAndExpand(scope, application)
	if !ok {
		return nil, &TokenError{
			Error:            InvalidScope,
			ErrorDescription: "the requested scope is invalid or not defined in the application",
		}, nil
	}
	scope = expandedScope

	organization := application.Organization
	isApplication := user == nil
	if isApplication {
		user = &User{
			Owner: application.Owner,
			Id:    application.GetId(),
			Name:  application.Name,
			Type:  "application",
		}
	} else {
		organization = user.Owner
		if user.IsForbidden {
			return nil, &TokenError{
				Error:            InvalidGrant,
				ErrorDescription: "the user is forbidden to sign in, please contact the administrator",
			}, nil
		}
	}

	targetAudience := ""
	if audience != "" {
		targetApplication, err := GetApplicationByClientId(audience)
		if err != nil {
			return nil, nil, err
		}
		if targetApplication == nil {
			targetApplication, err = getApplication(application.Owner, audience)
			if err != nil {
				return nil, nil, err
			}
		}
		if targetApplication == nil {
			return nil, &TokenError{
				Error:            InvalidTarget,
				ErrorDescription: fmt.Sprintf("the requested audience is not a known application: %s", audience),
			}, nil
		}
		if organization != targetApplication.Organization && !targetApplication.IsShared {
			return nil, &TokenError{
				Error:            InvalidTarget,
				ErrorDescription: fmt.Sprintf("the requested audience: %s does not serve the organization: %s", audience, organization),
			}, nil
		}
		targetAudience = targetApplication.ClientId
	}

	if !isApplication {
		err = ExtendUserWithRolesAndPermissions(user)
		if err != nil {
			return nil, nil, err
		}
	}

	accessToken, refreshToken, idToken, tokenName, err := generateJwtToken(application, user, "", "", "", scope, targetAudience, host)
	if err != nil {
		return nil, &TokenError{
			Error:            EndpointError,
			ErrorDescription: fmt.Sprintf("generate jwt token error: %s", err.Error()),
		}, nil
	}
	if isApplication {
		refreshToken = ""
		idToken = ""
	}

	token := &Token{
		Owner:        application.Owner,
		Name:         tokenName,
		CreatedTime:  util.GetCurrentTime(),
		Application:  application.Name,
		Organization: organization,
		User:         user.Name,
		Code:         util.GenerateAuthorizationCode(),
		AccessToken:  accessToken,
		RefreshToken: refreshToken,
		IdToken:      idToken,
		ExpiresIn:    int(application.ExpireInHours * float64(hourSeconds)),
		Scope:        scope,
		TokenType:    "Bearer",
		CodeIsUsed:   true,
		Resource:     targetAudience,
		GrantType:    "urn:ietf:params:oauth:grant-type:token-exchange",
	}

	_, err = AddToken(token)
	if err != nil {
		return nil, nil, err
	}

	return token, nil, nil
}
