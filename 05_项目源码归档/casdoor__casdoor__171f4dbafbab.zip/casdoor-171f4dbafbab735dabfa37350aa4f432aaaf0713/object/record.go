// Copyright 2021 The Casdoor Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package object

import (
	"encoding/json"
	"errors"
	"fmt"
	"regexp"
	"strings"

	"github.com/beego/beego/v2/server/web/context"
	"github.com/casdoor/casdoor/conf"
	"github.com/casdoor/casdoor/util"
)

var (
	logPostOnly          bool
	secretJsonRegex      *regexp.Regexp
	secretFormRegex      *regexp.Regexp
	secretMultipartRegex *regexp.Regexp
)

var secretRecordKeys = []string{
	"password", "oldPassword", "newPassword", "masterPassword", "defaultPassword", "passwordSalt", "passwordObfuscatorKey",
	"clientSecret", "client_secret", "clientSecret2", "accessSecret", "secret", "secretKey", "privateKey", "kerberosKeytab",
	"token", "accessToken", "access_token", "refreshToken", "refresh_token", "idToken", "id_token", "registrationAccessToken",
	"originalToken", "originalRefreshToken", "totpSecret", "masterVerificationCode",
	"code_verifier", "passcode", "recoveryCode", "recoveryCodes",
}

// secretRecordKeyPatterns match the per-provider OAuth tokens kept in a user's properties
var secretRecordKeyPatterns = []string{`oauth_[^"&=]*_(?:accessToken|refreshToken)`}

var secretRecordQueries = append([]string{"id_token_hint"}, secretRecordKeys...)

// alwaysLoggedActions lists the actions that are always recorded, even for GET
// requests when "logPostOnly" is enabled. These endpoints accept GET by design
// (OIDC RP-Initiated Logout navigates the browser to them), so filtering them
// out would silently drop security-relevant audit rows and their webhooks.
// Add an action here when losing its audit trail matters more than the noise.
var alwaysLoggedActions = map[string]bool{
	"logout":     true,
	"sso-logout": true,
}

func init() {
	logPostOnly = conf.GetConfigBool("logPostOnly")
	keys := strings.Join(append(append([]string{}, secretRecordKeys...), secretRecordKeyPatterns...), "|")
	jsonString := `"(?:[^"\\]|\\.)*"`
	secretJsonRegex = regexp.MustCompile(`(?i)"(` + keys + `)"\s*:\s*(?:` + jsonString + `|\[(?:` + jsonString + `|[^\]"])*\])`)
	secretFormRegex = regexp.MustCompile(`(?i)(^|&)(` + keys + `)=[^&]*`)
	secretMultipartRegex = regexp.MustCompile(`(?i)(name="(?:` + keys + `)"\r?\n\r?\n)[^\r\n]*`)
}

type Record struct {
	Id int `xorm:"int notnull pk autoincr" json:"id"`

	Owner       string `xorm:"varchar(100) index" json:"owner"`
	Name        string `xorm:"varchar(100) index" json:"name"`
	CreatedTime string `xorm:"varchar(100)" json:"createdTime"`

	Organization string `xorm:"varchar(100)" json:"organization"`
	ClientIp     string `xorm:"varchar(100)" json:"clientIp"`
	User         string `xorm:"varchar(100)" json:"user"`
	Method       string `xorm:"varchar(100)" json:"method"`
	RequestUri   string `xorm:"varchar(1000)" json:"requestUri"`
	Action       string `xorm:"varchar(1000)" json:"action"`
	Language     string `xorm:"varchar(100)" json:"language"`

	Object     string `xorm:"mediumtext" json:"object"`
	Response   string `xorm:"mediumtext" json:"response"`
	StatusCode int    `json:"statusCode"`

	Detail string `xorm:"varchar(100)" json:"detail"`

	IsTriggered bool `json:"isTriggered"`
}

type Response struct {
	Status string `json:"status"`
	Msg    string `json:"msg"`

	Data interface{} `json:"data"`
}

func maskSecrets(recordString string) string {
	recordString = secretJsonRegex.ReplaceAllString(recordString, `"$1":"***"`)
	recordString = secretFormRegex.ReplaceAllString(recordString, "${1}${2}=***")
	return secretMultipartRegex.ReplaceAllString(recordString, "${1}***")
}

func NewRecord(ctx *context.Context) (*Record, error) {
	clientIp := strings.Replace(util.GetClientIpFromRequest(ctx.Request), ": ", "", -1)
	action := strings.Replace(ctx.Request.URL.Path, "/api/", "", -1)
	if strings.HasPrefix(action, "notify-payment") {
		action = "notify-payment"
	}

	// "id_token_hint" carries a JWT, so it is dropped instead of being persisted in the audit row.
	requestUri := util.FilterQuery(ctx.Request.RequestURI, secretRecordQueries)
	if len(requestUri) > 1000 {
		requestUri = requestUri[0:1000]
	}

	object := ""
	if ctx.Input.RequestBody != nil && len(ctx.Input.RequestBody) != 0 {
		object = string(ctx.Input.RequestBody)
		object = maskSecrets(object)
	}

	respBytes, err := json.Marshal(ctx.Input.Data()["json"])
	if err != nil {
		return nil, err
	}

	var resp Response
	err = json.Unmarshal(respBytes, &resp)
	if err != nil {
		return nil, err
	}

	if action != "buy-product" && action != "notify-payment" {
		resp.Data = nil
	}

	dataResp := ""
	if resp.Data != nil {
		dataByte, err := json.Marshal(resp.Data)
		if err != nil {
			return nil, err
		}
		dataResp = fmt.Sprintf(", data:%s", string(dataByte))
	}

	languageCode := conf.GetAcceptLanguage(ctx.Request.Header.Get("Accept-Language"))

	record := Record{
		Name:        util.GenerateId(),
		CreatedTime: util.GetCurrentTime(),
		ClientIp:    clientIp,
		User:        "",
		Method:      ctx.Request.Method,
		RequestUri:  requestUri,
		Action:      action,
		Language:    languageCode,
		Object:      object,
		StatusCode:  200,
		Response:    fmt.Sprintf("{status:\"%s\", msg:\"%s\"%s}", resp.Status, resp.Msg, dataResp),
		IsTriggered: false,
	}
	return &record, nil
}

// SetUser sets the record's organization and user from the subject's user ID. An M2M
// credential ("app/<name>" or "app-dcr/<name>") is recorded in the application's organization,
// because the pseudo organizations "app" and "app-dcr" are shown by no organization's audit log.
func (record *Record) SetUser(userId string) error {
	if IsAppUser(userId) {
		_, name := util.GetOwnerAndNameFromIdNoCheck(userId)
		application, err := getAppUserApplication(name)
		if err != nil {
			return err
		}

		if application != nil {
			record.Organization, record.User = application.Organization, userId
			return nil
		}
	}

	owner, name, err := util.GetOwnerAndNameFromIdWithError(userId)
	if err != nil {
		return err
	}

	record.Organization, record.User = owner, name
	return nil
}

func addRecord(record *Record) (int64, error) {
	affected, err := ormer.Engine.Insert(record)
	return affected, err
}

func AddRecord(record *Record) bool {
	if logPostOnly {
		if record.Method == "GET" && !alwaysLoggedActions[record.Action] {
			return false
		}
	}

	// an empty owner matches no audit log query and no retention policy
	if record.Organization == "" {
		record.Organization = "built-in"
	}
	record.Owner = record.Organization
	record.Object = maskSecrets(record.Object)

	errWebhook := SendWebhooks(record)
	if errWebhook == nil {
		record.IsTriggered = true
	} else {
		fmt.Println(errWebhook)
	}

	affected, err := addRecord(record)
	if err != nil {
		panic(err)
	}

	sendAuditRecord(record)

	return affected != 0
}

func GetRecordCount(field, value string, filterRecord *Record) (int64, error) {
	session := GetSession("", -1, -1, field, value, "", "")
	return session.Count(filterRecord)
}

func GetRecords(organization string) ([]*Record, error) {
	records := []*Record{}
	err := ormer.Engine.Desc("id").Find(&records, &Record{Organization: organization})
	if err != nil {
		return records, err
	}

	return records, nil
}

func GetPaginationRecords(offset, limit int, field, value, sortField, sortOrder string, filterRecord *Record) ([]*Record, error) {
	records := []*Record{}

	if sortField == "" || sortOrder == "" {
		sortField = "id"
		sortOrder = "descend"
	}

	session := GetSession("", offset, limit, field, value, sortField, sortOrder)
	err := session.Find(&records, filterRecord)
	if err != nil {
		return records, err
	}

	return records, nil
}

func GetRecordsByField(record *Record) ([]*Record, error) {
	records := []*Record{}
	err := ormer.Engine.Find(&records, record)
	if err != nil {
		return records, err
	}

	return records, nil
}

func CopyRecord(record *Record) *Record {
	res := &Record{
		Owner:        record.Owner,
		Name:         record.Name,
		CreatedTime:  record.CreatedTime,
		Organization: record.Organization,
		ClientIp:     record.ClientIp,
		User:         record.User,
		Method:       record.Method,
		RequestUri:   record.RequestUri,
		Action:       record.Action,
		Language:     record.Language,
		Object:       record.Object,
		Response:     record.Response,
		Detail:       record.Detail,
		IsTriggered:  record.IsTriggered,
	}
	return res
}

func getFilteredWebhooks(webhooks []*Webhook, organization string, action string) []*Webhook {
	res := []*Webhook{}
	for _, webhook := range webhooks {
		if !webhook.IsEnabled {
			continue
		}

		if webhook.SingleOrgOnly {
			if webhook.Organization != organization {
				continue
			}
		}

		matched := false
		for _, event := range webhook.Events {
			if action == event {
				matched = true
				break
			}
		}

		if matched {
			res = append(res, webhook)
		}
	}
	return res
}

func addWebhookRecord(webhook *Webhook, record *Record, statusCode int, respBody string, sendError error) error {
	if statusCode == 200 {
		return nil
	}

	if len(respBody) > 300 {
		respBody = respBody[0:300]
	}

	webhookRecord := &Record{
		Owner:        record.Owner,
		Name:         util.GenerateId(),
		CreatedTime:  util.GetCurrentTime(),
		Organization: record.Organization,
		User:         record.User,

		Method:      webhook.Method,
		Action:      "send-webhook",
		RequestUri:  webhook.Url,
		StatusCode:  statusCode,
		Response:    respBody,
		Language:    record.Language,
		IsTriggered: false,
	}

	if sendError != nil {
		webhookRecord.Response = sendError.Error()
	}

	_, err := addRecord(webhookRecord)

	return err
}

func filterRecordObject(object string, objectFields []string) string {
	var rawObject map[string]interface{}
	_ = json.Unmarshal([]byte(object), &rawObject)

	if rawObject == nil {
		return object
	}

	filteredObject := make(map[string]interface{})

	for _, field := range objectFields {
		fieldValue, ok := rawObject[field]
		if !ok {
			continue
		}
		filteredObject[field] = fieldValue
	}

	return util.StructToJson(filteredObject)
}

func SendWebhooks(record *Record) error {
	webhooks, err := getWebhooksByOrganization("")
	if err != nil {
		return err
	}

	errs := []error{}
	webhooks = getFilteredWebhooks(webhooks, record.Organization, record.Action)

	for _, webhook := range webhooks {
		record2 := *record

		if len(webhook.ObjectFields) != 0 && webhook.ObjectFields[0] != "All" {
			record2.Object = filterRecordObject(record.Object, webhook.ObjectFields)
		}

		var user *User
		if webhook.IsUserExtended {
			user, err = getUser(record.Organization, record.User)
			if err != nil {
				errs = append(errs, fmt.Errorf("webhook %s: failed to get user: %w", webhook.GetId(), err))
				continue
			}

			user, err = GetMaskedUser(user, false, err)
			if err != nil {
				errs = append(errs, fmt.Errorf("webhook %s: failed to mask user: %w", webhook.GetId(), err))
				continue
			}
		}

		// Create webhook event for tracking and retry
		_, err = CreateWebhookEventFromRecord(webhook, &record2, user)
		if err != nil {
			errs = append(errs, fmt.Errorf("webhook %s: failed to create event: %w", webhook.GetId(), err))
			continue
		}

		// The webhook will be delivered by the background worker
		// This provides automatic retry and replay capability
	}

	if len(errs) > 0 {
		errStrings := []string{}
		for _, err := range errs {
			errStrings = append(errStrings, err.Error())
		}
		return errors.New(strings.Join(errStrings, " | "))
	}
	return nil
}
