// Copyright 2023 The Casdoor Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package object

import (
	"fmt"
	"strings"

	"github.com/casdoor/casdoor/xlsx"
)

func getRoleMap(roles []*Role) (map[string]*Role, error) {
	m := map[string]*Role{}

	owners := map[string]bool{}
	for _, role := range roles {
		if owners[role.Owner] {
			continue
		}
		owners[role.Owner] = true

		oldRoles, err := GetRoles(role.Owner)
		if err != nil {
			return nil, err
		}

		for _, oldRole := range oldRoles {
			m[oldRole.GetId()] = oldRole
		}
	}

	return m, nil
}

func UploadRoles(path string, organization string, lang string) (bool, error) {
	table, err := xlsx.ReadXlsxFile(path)
	if err != nil {
		return false, err
	}

	if len(table) == 0 {
		return false, fmt.Errorf("empty table")
	}

	for idx, row := range table[0] {
		splitRow := strings.Split(row, "#")
		if len(splitRow) > 1 {
			table[0][idx] = splitRow[1]
		}
	}

	uploadedRoles, err := StringArrayToStruct[Role](table)
	if err != nil {
		return false, err
	}

	for _, role := range uploadedRoles {
		err = checkUploadedOwner(&role.Owner, role.Name, organization, lang)
		if err != nil {
			return false, err
		}
	}

	oldRoleMap, err := getRoleMap(uploadedRoles)
	if err != nil {
		return false, err
	}

	newRoles := []*Role{}
	for _, role := range uploadedRoles {
		if _, ok := oldRoleMap[role.GetId()]; !ok {
			newRoles = append(newRoles, role)
		}
	}

	if len(newRoles) == 0 {
		return false, nil
	}

	return AddRolesInBatch(newRoles), nil
}
