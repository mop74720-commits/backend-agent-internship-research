// Copyright 2021 The Casdoor Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package object

import (
	"errors"
	"fmt"
	"sort"
	"strings"

	"github.com/casdoor/casdoor/conf"
	"github.com/casdoor/casdoor/i18n"
	"github.com/casdoor/casdoor/util"
	"github.com/xorm-io/core"
)

type Role struct {
	Owner       string `xorm:"varchar(100) notnull pk" json:"owner"`
	Name        string `xorm:"varchar(100) notnull pk" json:"name"`
	CreatedTime string `xorm:"varchar(100)" json:"createdTime"`
	DisplayName string `xorm:"varchar(100)" json:"displayName"`
	Description string `xorm:"mediumtext" json:"description"`

	Users     []string `xorm:"mediumtext" json:"users"`
	Groups    []string `xorm:"mediumtext" json:"groups"`
	Roles     []string `xorm:"mediumtext" json:"roles"`
	Domains   []string `xorm:"mediumtext" json:"domains"`
	IsEnabled bool     `json:"isEnabled"`

	// SourceGroups is only set when the role is resolved for a user, empty means it was assigned directly
	SourceGroups []string `xorm:"-" json:"sourceGroups,omitempty"`
}

func GetRoleCount(owner, field, value string) (int64, error) {
	session := GetSession(owner, -1, -1, field, value, "", "")
	return session.Count(&Role{})
}

func GetRoles(owner string) ([]*Role, error) {
	roles := []*Role{}
	err := ormer.Engine.Desc("created_time").Find(&roles, &Role{Owner: owner})
	if err != nil {
		return roles, err
	}

	return roles, nil
}

func GetPaginationRoles(owner string, offset, limit int, field, value, sortField, sortOrder string) ([]*Role, error) {
	roles := []*Role{}
	session := GetSession(owner, offset, limit, field, value, sortField, sortOrder)
	err := session.Find(&roles)
	if err != nil {
		return roles, err
	}

	return roles, nil
}

func getRole(owner string, name string) (*Role, error) {
	if owner == "" || name == "" {
		return nil, nil
	}

	role := Role{Owner: owner, Name: name}
	existed, err := ormer.Engine.Get(&role)
	if err != nil {
		return &role, err
	}

	if existed {
		return &role, nil
	} else {
		return nil, nil
	}
}

func GetRole(id string) (*Role, error) {
	owner, name := util.GetOwnerAndNameFromIdNoCheck(id)
	return getRole(owner, name)
}

func UpdateRole(id string, role *Role, isGlobalAdmin bool, lang string) (bool, error) {
	owner, name := util.GetOwnerAndNameFromIdNoCheck(id)
	oldRole, err := getRole(owner, name)
	if err != nil {
		return false, err
	}

	if oldRole == nil {
		return false, nil
	}

	if !isGlobalAdmin && oldRole.Owner != role.Owner {
		return false, errors.New(i18n.Translate(lang, "auth:Unauthorized operation"))
	}

	renameRole := name != role.Name
	oldPermissions := []*Permission{}
	if renameRole {
		oldPermissions, err = GetPermissionsByRole(id)
		if err != nil {
			return false, err
		}

		for _, permission := range oldPermissions {
			err = removePolicies(permission)
			if err != nil {
				return false, err
			}
		}
	}

	if renameRole {
		err := roleChangeTrigger(owner, name, role.Name)
		if err != nil {
			return false, err
		}
	}

	affected, err := ormer.Engine.ID(core.PK{owner, name}).AllCols().Update(role)
	if err != nil {
		return false, err
	}

	if renameRole && affected != 0 {
		permissions, err := GetPermissionsByRole(role.GetId())
		if err != nil {
			return false, err
		}

		for _, permission := range permissions {
			err = addPolicies(permission)
			if err != nil {
				return false, err
			}
		}
	}

	return affected != 0, nil
}

func AddRole(role *Role) (bool, error) {
	affected, err := ormer.Engine.Insert(role)
	if err != nil {
		return false, err
	}

	return affected != 0, nil
}

func AddRoles(roles []*Role) bool {
	if len(roles) == 0 {
		return false
	}
	affected, err := ormer.Engine.Insert(roles)
	if err != nil {
		if !strings.Contains(err.Error(), "Duplicate entry") {
			panic(err)
		}
	}
	return affected != 0
}

func AddRolesInBatch(roles []*Role) bool {
	batchSize := conf.GetConfigBatchSize()

	if len(roles) == 0 {
		return false
	}

	affected := false
	for i := 0; i < len(roles); i += batchSize {
		start := i
		end := i + batchSize
		if end > len(roles) {
			end = len(roles)
		}

		tmp := roles[start:end]
		fmt.Printf("The syncer adds roles: [%d - %d]\n", start, end)
		if AddRoles(tmp) {
			affected = true
		}
	}

	return affected
}

func deleteRole(role *Role) (bool, error) {
	affected, err := ormer.Engine.ID(core.PK{role.Owner, role.Name}).Delete(&Role{})
	if err != nil {
		return false, err
	}

	return affected != 0, nil
}

func DeleteRole(role *Role) (bool, error) {
	roleId := role.GetId()
	permissions, err := GetPermissionsByRole(roleId)
	if err != nil {
		return false, err
	}

	for _, permission := range permissions {
		permission.Roles = util.DeleteVal(permission.Roles, roleId)
		_, err := UpdatePermission(permission.GetId(), permission)
		if err != nil {
			return false, err
		}
	}

	return deleteRole(role)
}

func (role *Role) GetId() string {
	return fmt.Sprintf("%s/%s", role.Owner, role.Name)
}

func getRolesByUserInternal(userId string) ([]*Role, map[string][]string, error) {
	user, err := GetUser(userId)
	if err != nil {
		return nil, nil, err
	}
	if user == nil {
		return nil, nil, fmt.Errorf("The user: %s doesn't exist", userId)
	}

	query := ormer.Engine.Alias("r").Where("r.users like ?", fmt.Sprintf("%%%s%%", userId))
	for _, group := range user.Groups {
		query = query.Or("r.groups like ?", fmt.Sprintf("%%%s%%", group))
	}

	roles := []*Role{}
	err = query.Find(&roles)
	if err != nil {
		return nil, nil, err
	}

	res := []*Role{}
	// a source is the group that granted the role, "" means it was assigned directly
	sources := map[string][]string{}
	for _, role := range roles {
		roleSources := []string{}
		if util.InSlice(role.Users, userId) {
			roleSources = append(roleSources, "")
		}
		for _, group := range role.Groups {
			if util.InSlice(user.Groups, group) {
				roleSources = append(roleSources, group)
			}
		}

		if len(roleSources) != 0 {
			res = append(res, role)
			sources[role.GetId()] = roleSources
		}
	}
	return res, sources, nil
}

func fillSourceGroups(roles []*Role, sources map[string][]string) {
	resolved := map[string]map[string]bool{}
	for _, role := range roles {
		roleId := role.GetId()
		resolved[roleId] = map[string]bool{}
		for _, source := range sources[roleId] {
			resolved[roleId][source] = true
		}
	}

	for changed := true; changed; {
		changed = false
		for _, role := range roles {
			roleId := role.GetId()
			for _, subRoleId := range role.Roles {
				for source := range resolved[subRoleId] {
					if !resolved[roleId][source] {
						resolved[roleId][source] = true
						changed = true
					}
				}
			}
		}
	}

	for _, role := range roles {
		roleSources := resolved[role.GetId()]
		if roleSources[""] {
			role.SourceGroups = nil
			continue
		}

		sourceGroups := []string{}
		for source := range roleSources {
			sourceGroups = append(sourceGroups, source)
		}
		sort.Strings(sourceGroups)
		role.SourceGroups = sourceGroups
	}
}

func getRolesByUser(userId string) ([]*Role, error) {
	roles, sources, err := getRolesByUserInternal(userId)
	if err != nil {
		return nil, err
	}

	allRolesIds := []string{}
	for _, role := range roles {
		allRolesIds = append(allRolesIds, role.GetId())
	}

	allRoles, err := GetAncestorRoles(allRolesIds...)
	if err != nil {
		return nil, err
	}

	fillSourceGroups(allRoles, sources)

	for i := range allRoles {
		allRoles[i].Users = nil
	}

	return allRoles, nil
}

func roleChangeTrigger(owner string, oldName string, newName string) error {
	session := ormer.Engine.NewSession()
	defer session.Close()

	err := session.Begin()
	if err != nil {
		return err
	}

	var roles []*Role
	err = ormer.Engine.Find(&roles)
	if err != nil {
		return err
	}

	for _, role := range roles {
		changed := false
		for j, u := range role.Roles {
			if u == "*" {
				continue
			}

			subOwner, subName, err := util.GetOwnerAndNameFromIdWithError(u)
			if err != nil {
				return err
			}
			if subOwner == owner && subName == oldName {
				role.Roles[j] = util.GetId(subOwner, newName)
				changed = true
			}
		}
		if !changed {
			continue
		}
		_, err = session.Where("name=?", role.Name).And("owner=?", role.Owner).Update(role)
		if err != nil {
			return err
		}
	}

	var permissions []*Permission
	err = ormer.Engine.Find(&permissions)
	if err != nil {
		return err
	}

	for _, permission := range permissions {
		changed := false
		for j, u := range permission.Roles {
			// u = organization/rolename
			if u == "*" {
				continue
			}

			roleOwner, roleName, err := util.GetOwnerAndNameFromIdWithError(u)
			if err != nil {
				return err
			}
			if roleOwner == owner && roleName == oldName {
				permission.Roles[j] = util.GetId(roleOwner, newName)
				changed = true
			}
		}
		if !changed {
			continue
		}
		_, err = session.Where("name=?", permission.Name).And("owner=?", permission.Owner).Update(permission)
		if err != nil {
			return err
		}
	}

	return session.Commit()
}

func GetMaskedRoles(roles []*Role) []*Role {
	for _, role := range roles {
		role.Users = nil
	}

	return roles
}

// GetAncestorRoles returns a list of roles that contain the given roleIds
func GetAncestorRoles(roleIds ...string) ([]*Role, error) {
	if len(roleIds) == 0 {
		return []*Role{}, nil
	}

	visited := map[string]bool{}
	for _, roleId := range roleIds {
		visited[roleId] = true
	}

	owner, _ := util.GetOwnerAndNameFromIdNoCheck(roleIds[0])

	allRoles, err := GetRoles(owner)
	if err != nil {
		return nil, err
	}

	roleMap := map[string]*Role{}
	for _, r := range allRoles {
		roleMap[r.GetId()] = r
	}

	// find all the roles that contain father roles
	res := []*Role{}
	for _, r := range allRoles {
		isContain, ok := visited[r.GetId()]
		if isContain {
			res = append(res, r)
		} else if !ok {
			rId := r.GetId()
			visited[rId] = containsRole(r, roleMap, visited, roleIds...)
			if visited[rId] {
				res = append(res, r)
			}
		}
	}
	return res, nil
}

// containsRole is a helper function to check if a roles is related to any role in the given list roles
func containsRole(role *Role, roleMap map[string]*Role, visited map[string]bool, roleIds ...string) bool {
	roleId := role.GetId()
	if isContain, ok := visited[roleId]; ok {
		return isContain
	}

	visited[role.GetId()] = false

	for _, subRole := range role.Roles {
		if util.HasString(roleIds, subRole) {
			return true
		}

		r, ok := roleMap[subRole]
		if ok && containsRole(r, roleMap, visited, roleIds...) {
			return true
		}
	}

	return false
}
