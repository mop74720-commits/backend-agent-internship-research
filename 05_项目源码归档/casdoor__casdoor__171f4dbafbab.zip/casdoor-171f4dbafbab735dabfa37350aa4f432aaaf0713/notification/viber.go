// Copyright 2023 The Casdoor Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package notification

import (
	notify "github.com/casdoor/notify2"
	"github.com/casdoor/notify2/service/viber"
)

func NewViberProvider(senderName string, appKey string, webhookURL string, receiverId string) (notify.Notifier, error) {
	viberSrv := viber.New(appKey, senderName, "")

	err := viberSrv.SetWebhook(webhookURL)
	if err != nil {
		return nil, err
	}

	viberSrv.AddReceivers(receiverId)

	notifier := notify.New()
	notifier.UseServices(viberSrv)

	return notifier, nil
}
