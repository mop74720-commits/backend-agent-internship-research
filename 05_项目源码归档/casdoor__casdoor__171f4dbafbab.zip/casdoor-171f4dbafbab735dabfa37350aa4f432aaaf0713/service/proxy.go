// Copyright 2023 The casbin Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package service

import (
	"crypto/tls"
	"fmt"
	"net"
	"net/http"
	"net/http/httputil"
	"net/url"
	"path"
	"path/filepath"
	"strings"

	"github.com/beego/beego/v2/core/logs"
	"github.com/casdoor/casdoor/conf"
	"github.com/casdoor/casdoor/object"
	"github.com/casdoor/casdoor/rule"
	"github.com/casdoor/casdoor/util"
)

func forwardHandler(targetUrl string, writer http.ResponseWriter, request *http.Request) {
	target, err := url.Parse(targetUrl)

	if nil != err {
		panic(err)
	}

	proxy := httputil.NewSingleHostReverseProxy(target)
	proxy.Director = func(r *http.Request) {
		r.URL = target

		if clientIP, _, err := net.SplitHostPort(r.RemoteAddr); err == nil {
			if xff := r.Header.Get("X-Forwarded-For"); xff != "" && xff != clientIP {
				newXff := fmt.Sprintf("%s, %s", xff, clientIP)
				// r.Header.Set("X-Forwarded-For", newXff)
				r.Header.Set("X-Real-Ip", newXff)
			} else {
				// r.Header.Set("X-Forwarded-For", clientIP)
				r.Header.Set("X-Real-Ip", clientIP)
			}
		}
	}

	proxy.ModifyResponse = func(resp *http.Response) error {
		// Add Secure flag to all Set-Cookie headers in HTTPS responses
		if request.TLS != nil {
			// Add HSTS header for HTTPS responses if not already set by backend
			if resp.Header.Get("Strict-Transport-Security") == "" {
				resp.Header.Set("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
			}

			cookies := resp.Header["Set-Cookie"]
			if len(cookies) > 0 {
				// Clear existing Set-Cookie headers
				resp.Header.Del("Set-Cookie")
				// Add them back with Secure flag if not already present
				for _, cookie := range cookies {
					// Check if Secure attribute is already present (case-insensitive)
					cookieLower := strings.ToLower(cookie)
					hasSecure := strings.Contains(cookieLower, ";secure;") ||
						strings.Contains(cookieLower, "; secure;") ||
						strings.HasSuffix(cookieLower, ";secure") ||
						strings.HasSuffix(cookieLower, "; secure")
					if !hasSecure {
						cookie = cookie + "; Secure"
					}
					resp.Header.Add("Set-Cookie", cookie)
				}
			}
		}

		// Fix CORS issue: Remove CORS header combinations that allow credential theft from any origin
		allowOrigin := resp.Header.Get("Access-Control-Allow-Origin")
		allowCredentials := resp.Header.Get("Access-Control-Allow-Credentials")

		// Only "Allow-Credentials: true" together with a wildcard or "null" origin is
		// unsafe, since it would let any site read credentialed responses. A concrete
		// origin is the upstream's own allowlist decision (Casdoor validates it in
		// CorsFilter), so it must be preserved, otherwise every cross-origin login
		// through the proxy fails its preflight.
		if strings.EqualFold(allowCredentials, "true") && (allowOrigin == "*" || strings.EqualFold(allowOrigin, "null")) {
			// Remove CORS headers to prevent credential theft
			resp.Header.Del("Access-Control-Allow-Origin")
			resp.Header.Del("Access-Control-Allow-Credentials")
			resp.Header.Del("Access-Control-Allow-Methods")
			resp.Header.Del("Access-Control-Allow-Headers")
			resp.Header.Del("Access-Control-Expose-Headers")
			resp.Header.Del("Access-Control-Max-Age")
		}

		return nil
	}

	proxy.ServeHTTP(writer, request)
}

func getHostNonWww(host string) string {
	res := ""
	tokens := strings.Split(host, ".")
	if len(tokens) > 2 && tokens[0] == "www" {
		res = strings.Join(tokens[1:], ".")
	}
	return res
}

func logRequest(clientIp string, r *http.Request) {
	if !strings.Contains(r.UserAgent(), "Uptime-Kuma") {
		fmt.Printf("handleRequest: %s\t%s\t%s\t%s\t%s\t%s\n", clientIp, r.Method, r.Host, r.RequestURI, r.UserAgent(), r.RemoteAddr)
		record := object.Record{
			Owner:       "admin",
			CreatedTime: util.GetCurrentTime(),
			Method:      r.Method,
			RequestUri:  r.RequestURI,
			ClientIp:    clientIp,
		}
		object.AddRecord(&record)
	}
}

func redirectToHttps(w http.ResponseWriter, r *http.Request) {
	targetUrl := fmt.Sprintf("https://%s", joinPath(r.Host, r.RequestURI))
	http.Redirect(w, r, targetUrl, http.StatusMovedPermanently)
}

func redirectToHost(w http.ResponseWriter, r *http.Request, host string) {
	protocol := "https"
	if r.TLS == nil {
		protocol = "http"
	}

	targetUrl := fmt.Sprintf("%s://%s", protocol, joinPath(host, r.RequestURI))
	http.Redirect(w, r, targetUrl, http.StatusMovedPermanently)
}

func handleRequest(w http.ResponseWriter, r *http.Request) {
	clientIp := util.GetClientIp(r)
	logRequest(clientIp, r)

	site := getSiteByDomainWithWww(r.Host)
	if site == nil {
		if isHostIp(r.Host) {
			w.WriteHeader(http.StatusBadRequest)
			return
		}

		if strings.HasSuffix(r.Host, ".casdoor.com") && r.RequestURI == "/health-ping" {
			w.WriteHeader(http.StatusOK)
			_, err := fmt.Fprintf(w, "OK")
			if err != nil {
				panic(err)
			}
			return
		}

		responseError(w, "Casdoor site error: site not found for host: %s", r.Host)
		return
	}

	hostNonWww := getHostNonWww(r.Host)
	if hostNonWww != "" {
		redirectToHost(w, r, hostNonWww)
		return
	}

	if site.Domain != r.Host && site.NeedRedirect {
		redirectToHost(w, r, site.Domain)
		return
	}

	if strings.HasPrefix(r.RequestURI, "/.well-known/acme-challenge/") {
		challengeMap := site.GetChallengeMap()
		for token, keyAuth := range challengeMap {
			if r.RequestURI == fmt.Sprintf("/.well-known/acme-challenge/%s", token) {
				responseOk(w, "%s", keyAuth)
				return
			}
		}

		responseError(w, "Casdoor site error: ACME HTTP-01 challenge failed, requestUri cannot match with challengeMap, requestUri = %s, challengeMap = %v", r.RequestURI, challengeMap)
		return
	}

	if strings.HasPrefix(r.RequestURI, "/MP_verify_") {
		challengeMap := site.GetChallengeMap()
		for path, value := range challengeMap {
			if r.RequestURI == fmt.Sprintf("/%s", path) {
				responseOk(w, "%s", value)
				return
			}
		}
	}

	if site.SslMode == "HTTPS Only" {
		// This domain only supports https but receive http request, redirect to https
		if r.TLS == nil {
			redirectToHttps(w, r)
			return
		}
	}

	if !checkSiteRules(w, site, r) {
		return
	}

	// oAuth proxy
	if site.CasdoorApplication != "" {
		clearUserHeaders(r)

		if !isSitePublicPath(site, r.URL) {
			identity, result, msg := authenticateSiteRequest(site, r)
			switch result {
			case siteAuthNeedLogin:
				casdoorClient, err := getCasdoorClientFromSite(site)
				if err != nil {
					responseError(w, "Casdoor site error: getCasdoorClientFromSite() error: %s", err.Error())
					return
				}
				if _, err = r.Cookie("casdoor_access_token"); err == nil {
					clearAccessTokenCookie(w)
				}
				redirectToCasdoor(casdoorClient, w, r)
				return
			case siteAuthForbidden:
				responseForbidden(w, "Forbidden: %s", msg)
				return
			case siteAuthError:
				responseError(w, "Casdoor site error: %s", msg)
				return
			}

			setUserHeaders(r, identity)
		}
	}

	host := site.GetHost()
	if host == "" {
		responseError(w, "Casdoor site error: targetUrl should not be empty for host: %s, site = %v", r.Host, site)
		return
	}

	nextHandle(w, r)
}

// evaluateSiteRules returns whether the request is allowed by the rules of the site, if not, the status code and message to respond.
func evaluateSiteRules(site *object.Site, r *http.Request) (bool, int, string) {
	if len(site.Rules) == 0 {
		return true, 0, ""
	}

	result, err := rule.CheckRules(site.Rules, r)
	if err != nil {
		return false, http.StatusInternalServerError, fmt.Sprintf("Internal Server Error: %v", err)
	}

	reason := result.Reason
	if reason != "" && site.DisableVerbose {
		reason = "the rule has been hit"
	}

	switch result.Action {
	case "", "Allow":
		return true, 0, ""
	case "Block":
		return false, result.StatusCode, fmt.Sprintf("Blocked by Casdoor: %s", reason)
	case "Drop":
		return false, result.StatusCode, fmt.Sprintf("Dropped by Casdoor: %s", reason)
	default:
		return false, http.StatusInternalServerError, fmt.Sprintf("Casdoor site error: %s", reason)
	}
}

// checkSiteRules writes the response and returns false if the request is blocked by the rules of the site.
func checkSiteRules(w http.ResponseWriter, site *object.Site, r *http.Request) bool {
	isAllowed, statusCode, msg := evaluateSiteRules(site, r)
	if !isAllowed {
		w.WriteHeader(statusCode)
		responseErrorWithoutCode(w, "%s", msg)
	}
	return isAllowed
}

// isSitePublicPath reports whether the path is one of the site's public paths or under one of them,
// paths that aren't in the canonical form never count as public.
func isSitePublicPath(site *object.Site, u *url.URL) bool {
	if len(site.PublicPaths) == 0 {
		return false
	}

	urlPath := u.Path
	if !strings.HasPrefix(urlPath, "/") || u.RawPath != "" || strings.Contains(urlPath, "\\") {
		return false
	}
	if cleanPath := path.Clean(urlPath); cleanPath != urlPath && cleanPath+"/" != urlPath {
		return false
	}

	for _, publicPath := range site.PublicPaths {
		publicPath = strings.TrimSpace(publicPath)
		if !strings.HasPrefix(publicPath, "/") {
			continue
		}

		publicPath = strings.TrimSuffix(publicPath, "/")
		if publicPath == "" || urlPath == publicPath || strings.HasPrefix(urlPath, publicPath+"/") {
			return true
		}
	}
	return false
}

func nextHandle(w http.ResponseWriter, r *http.Request) {
	site := getSiteByDomainWithWww(r.Host)
	host := site.GetHost()
	if site.SslMode == "Static Folder" {
		http.ServeFile(w, r, getStaticFolderPath(host, r.URL.Path))
	} else {
		targetUrl := joinPath(site.GetHost(), r.RequestURI)
		forwardHandler(targetUrl, w, r)
	}
}

func getStaticFolderPath(folder string, urlPath string) string {
	if urlPath != "/" {
		return filepath.Join(folder, urlPath)
	}

	path := filepath.Join(folder, "/index.htm")
	if !util.FileExist(path) {
		path = filepath.Join(folder, "/index.html")
		if !util.FileExist(path) {
			path = filepath.Join(folder, urlPath)
		}
	}
	return path
}

func Start() {
	serverMux := http.NewServeMux()
	serverMux.HandleFunc("/", handleRequest)
	serverMux.HandleFunc("/caswaf-handler", handleAuthCallback)

	gatewayHttpPort, err := conf.GetConfigInt64("gatewayHttpPort")
	if err != nil {
		gatewayHttpPort = 80
	}

	gatewayHttpsPort, err := conf.GetConfigInt64("gatewayHttpsPort")
	if err != nil {
		gatewayHttpsPort = 443
	}

	go func() {
		fmt.Printf("Casdoor site proxy running on: http://127.0.0.1:%d\n", gatewayHttpPort)
		err := http.ListenAndServe(fmt.Sprintf(":%d", gatewayHttpPort), serverMux)
		if err != nil {
			logs.Error(err)
		}
	}()

	go func() {
		fmt.Printf("Casdoor site proxy running on: https://127.0.0.1:%d\n", gatewayHttpsPort)
		server := &http.Server{
			Handler: serverMux,
			Addr:    fmt.Sprintf(":%d", gatewayHttpsPort),
			TLSConfig: &tls.Config{
				// Minimum TLS version 1.2, TLS 1.3 is automatically supported
				MinVersion: tls.VersionTLS12,
				// Secure cipher suites for TLS 1.2 (excluding 3DES to prevent Sweet32 attack)
				// TLS 1.3 cipher suites are automatically configured by Go
				CipherSuites: []uint16{
					tls.TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,
					tls.TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,
					tls.TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256,
					tls.TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384,
					tls.TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305,
					tls.TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305,
				},
				// Prefer strong elliptic curves
				CurvePreferences: []tls.CurveID{
					tls.X25519,
					tls.CurveP256,
					tls.CurveP384,
				},
			},
		}

		// start https server and set how to get certificate
		server.TLSConfig.GetCertificate = func(info *tls.ClientHelloInfo) (*tls.Certificate, error) {
			domain := info.ServerName
			cert, err := getX509CertByDomain(domain)
			if err != nil {
				return nil, err
			}

			return cert, nil
		}

		err := server.ListenAndServeTLS("", "")
		if err != nil {
			logs.Error(err)
		}
	}()
}
