import asyncio
import logging
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from app.gateway.authz import (
    _AuthorizationUnavailable,
    _is_internal_caller,
    authorize_model_use,
    resolve_model_authorization,
)
from app.gateway.deps import get_config, get_optional_user_from_request
from app.gateway.internal_auth import get_trusted_internal_owner_user_id
from deerflow.config.app_config import AppConfig
from deerflow.config.model_config import ModelConfig
from deerflow.models.reasoning import reasoning_capabilities_payload, resolve_reasoning_contract
from deerflow.models.selection import ModelScope, resolve_model_control

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["models"])


async def _resolve_bound_owner_for_model_list(request: Request) -> object | None:
    """Resolve the trusted bound owner behind an internal channel call.

    Internal callers (IM channel workers, the scheduler) authenticate as a
    synthetic user whose role is popped to ``default_role`` when the
    authorization principal is built, so the filtered list reflects the
    default role — not the account the conversation actually belongs to.
    When the call carries a trusted ``X-DeerFlow-Owner-User-Id`` header, the
    channel acts on behalf of that owner (same identity run admission
    stamps), and the list must be filtered with the owner's role so commands
    like ``/model`` gate on the same principal the run would.
    """
    from app.gateway.services import resolve_trusted_internal_owner_for_attribution

    return await resolve_trusted_internal_owner_for_attribution(request, get_trusted_internal_owner_user_id(request))


class ReasoningEffortCapabilitiesResponse(BaseModel):
    """Effort values a model accepts, in display order."""

    values: list[str] = Field(..., description="Accepted effort values (provider vocabulary)")
    default: str | None = Field(default=None, description="Effort applied when the caller does not choose one")
    aliases: dict[str, str] = Field(default_factory=dict, description="Generic DeerFlow value -> provider value")


class ReasoningCapabilitiesResponse(BaseModel):
    """Normalized reasoning contract (issue #5073), derived for legacy profiles."""

    thinking: Literal["unsupported", "optional", "required"] = Field(..., description="Whether thinking can be toggled, is always on, or is unavailable")
    effort: ReasoningEffortCapabilitiesResponse | None = Field(default=None, description="Effort control; null when the model exposes none")
    history: Literal["preserve", "clear"] | None = Field(default=None, description="Reasoning-history requirement, when declared")
    source: Literal["legacy", "contract"] = Field(..., description="Whether the profile declared a contract or the booleans were projected")


class ModelResponse(BaseModel):
    """Response model for model information."""

    name: str = Field(..., description="Unique identifier for the model")
    model: str = Field(..., description="Actual provider model identifier")
    display_name: str | None = Field(None, description="Human-readable name")
    description: str | None = Field(None, description="Model description")
    supports_thinking: bool = Field(default=False, description="Whether model supports thinking mode (deprecated: derived from `reasoning`)")
    supports_reasoning_effort: bool = Field(default=False, description="Whether model supports reasoning effort (deprecated: derived from `reasoning`)")
    reasoning: ReasoningCapabilitiesResponse = Field(..., description="Normalized reasoning capability contract")


def _model_response(model: ModelConfig) -> ModelResponse:
    return ModelResponse(
        name=model.name,
        model=model.model,
        display_name=model.display_name,
        description=model.description,
        supports_thinking=model.supports_thinking,
        supports_reasoning_effort=model.supports_reasoning_effort,
        reasoning=ReasoningCapabilitiesResponse(**reasoning_capabilities_payload(resolve_reasoning_contract(model))),
    )


class TokenUsageResponse(BaseModel):
    """Token usage display configuration."""

    enabled: bool = Field(default=False, description="Whether token usage display is enabled")


class ModelsListResponse(BaseModel):
    """Response model for listing all models."""

    models: list[ModelResponse]
    token_usage: TokenUsageResponse


class ModelControlRequest(BaseModel):
    text: str = Field(max_length=4000)
    model_name: str | None = Field(default=None, max_length=200)
    scope: ModelScope | None = None


@router.post("/models/resolve", summary="Resolve a direct user model selection")
async def resolve_model_selection(body: ModelControlRequest, request: Request, config: AppConfig = Depends(get_config)) -> dict:
    """Read-only preview. Never starts a run or changes model defaults."""
    listing = await list_models(request, config)
    visible_names = {model.name for model in listing.models}
    visible_models = [model for model in config.models if model.name in visible_names]
    result = resolve_model_control(body.text, visible_models, model_name=body.model_name, scope=body.scope)
    if result["candidates"]:
        user = await get_optional_user_from_request(request)
        if user is not None:
            owner = await _resolve_bound_owner_for_model_list(request)
            internal = _is_internal_caller(request, user)
            if result["status"] == "resolved":
                await asyncio.to_thread(authorize_model_use, owner or user, result["model_name"], is_internal=internal, app_config=config)
            else:
                usable_names = set()
                for candidate in result["candidates"]:
                    try:
                        await asyncio.to_thread(authorize_model_use, owner or user, candidate["name"], is_internal=internal, app_config=config)
                    except HTTPException as exc:
                        if exc.status_code != 403:
                            raise
                    else:
                        usable_names.add(candidate["name"])
                if not usable_names:
                    # A recognized but denied choice must not become ordinary task text.
                    result.update(status="unavailable", model_name=None, candidates=[])
                else:
                    result = resolve_model_control(body.text, [model for model in visible_models if model.name in usable_names], model_name=body.model_name, scope=body.scope)
    return result


@router.get(
    "/models",
    response_model=ModelsListResponse,
    summary="List All Models",
    description="Retrieve a list of all available AI models configured in the system.",
)
async def list_models(
    request: Request,
    config: AppConfig = Depends(get_config),
) -> ModelsListResponse:
    """List all available models from configuration.

    Returns model information suitable for frontend display,
    excluding sensitive fields like API keys and internal configuration.

    When ``authorization.enabled`` is true, only models the caller's role may
    ``list`` are returned (filtered via ``provider.filter_resources``). A
    provider error yields an empty list (fail-closed) or all models (fail-open).

    Returns:
        A list of all configured models with their metadata and token usage display settings.

    Example Response:
        ```json
        {
            "models": [
                {
                    "name": "gpt-4",
                    "model": "gpt-4",
                    "display_name": "GPT-4",
                    "description": "OpenAI GPT-4 model",
                    "supports_thinking": false,
                    "supports_reasoning_effort": false,
                    "reasoning": {"thinking": "unsupported", "effort": null, "history": null, "source": "legacy"}
                },
                {
                    "name": "claude-3-opus",
                    "model": "claude-3-opus",
                    "display_name": "Claude 3 Opus",
                    "description": "Anthropic Claude 3 Opus model",
                    "supports_thinking": true,
                    "supports_reasoning_effort": false,
                    "reasoning": {"thinking": "optional", "effort": null, "history": null, "source": "legacy"}
                }
            ],
            "token_usage": {
                "enabled": true
            }
        }
        ```
    """
    visible_models = config.models
    fail_closed = config.authorization.fail_closed

    user = await get_optional_user_from_request(request)
    if user is not None:
        # Internal channel calls authenticate as a synthetic principal that
        # falls under default_role; when they carry a trusted bound owner,
        # filter with the owner's role so the list matches what run admission
        # would admit for that account.
        owner = await _resolve_bound_owner_for_model_list(request)
        principal_user = owner if owner is not None else user
        try:
            provider, principal = resolve_model_authorization(principal_user, is_internal=_is_internal_caller(request, user))
        except _AuthorizationUnavailable as exc:
            if exc.fail_closed:
                visible_models = []
        else:
            if provider is not None and principal is not None:
                try:
                    allowed_names = provider.filter_resources(principal, "model", [m.name for m in config.models])
                    if not isinstance(allowed_names, list) or any(not isinstance(n, str) for n in allowed_names):
                        raise TypeError("AuthorizationProvider.filter_resources must return list[str]")
                    allowed_set = set(allowed_names)
                    visible_models = [m for m in config.models if m.name in allowed_set]
                except Exception:
                    logger.warning("Authorization provider failed while filtering models", exc_info=True)
                    visible_models = [] if fail_closed else config.models

    models = [_model_response(model) for model in visible_models]
    return ModelsListResponse(
        models=models,
        token_usage=TokenUsageResponse(enabled=config.token_usage.enabled),
    )


@router.get(
    "/models/{model_name}",
    response_model=ModelResponse,
    summary="Get Model Details",
    description="Retrieve detailed information about a specific AI model by its name.",
)
async def get_model(
    model_name: str,
    request: Request,
    config: AppConfig = Depends(get_config),
) -> ModelResponse:
    """Get a specific model by name.

    Args:
        model_name: The unique name of the model to retrieve.

    Returns:
        Model information if found.

    Raises:
        HTTPException: 404 if model not found; 403 if the caller's role may not
        ``use`` the model (only when ``authorization.enabled`` is true). A
        provider resolution error yields 403 (fail-closed) or allows the request
        (fail-open), mirroring ``list_models``'s provider-error semantics.

    Example Response:
        ```json
        {
            "name": "gpt-4",
            "display_name": "GPT-4",
            "description": "OpenAI GPT-4 model",
            "supports_thinking": false
        }
        ```
    """
    model = config.get_model_config(model_name)
    if model is None:
        raise HTTPException(status_code=404, detail=f"Model '{model_name}' not found")

    # Phase 3: enforce model:use authorization (deny → 403, not 404, since the
    # model exists but the role lacks permission to use it).
    user = await get_optional_user_from_request(request)
    if user is not None:
        authorize_model_use(user, model_name, is_internal=_is_internal_caller(request, user), app_config=config)

    return _model_response(model)
