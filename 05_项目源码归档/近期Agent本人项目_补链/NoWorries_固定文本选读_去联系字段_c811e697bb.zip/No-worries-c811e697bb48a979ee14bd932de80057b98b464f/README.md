<p align="center">
  <a href="https://meetnoworries.com">
    <img src="noworries_app/docs/hero-banner.png" alt="无事 NoWorries - 何必亲劳？" width="600" />
  </a>
</p>

<p align="center">
  <strong>🌐 Language / 语言</strong>：
  <a href="README.md"><b>中文</b></a> | 
  <a href="README_EN.md">English</a>
</p>

<br />

<h1 align="center">无事 · NoWorries</h1>

<p align="center">
  <strong>开源免费的 AI 桌面助手</strong><br/>
  好用 · 安全 · 新手友好
</p>

<p align="center">
  <sub>Claude Code / Codex / MiniMax Agent / Qoder 的开源平替</sub>
</p>

<br />

<p align="center">
  <a href="https://meetnoworries.com">
    <img src="https://img.shields.io/badge/🌐_访问官网_下载安装包-meetnoworries.com-22c55e?style=for-the-badge&labelColor=1a1a1a" alt="Visit Website" />
  </a>
</p>

<p align="center">
  <sub>💡 不想折腾代码？<b>直接去官网下载安装包</b>，开箱即用</sub>
</p>

<br />

<p align="center">
  <a href="LICENSE"><img src="https://img.shields.io/badge/License-MIT-22c55e?style=flat-square" alt="MIT License" /></a>
  <a href="https://github.com/hlbbbbbbb/No-worries/stargazers"><img src="https://img.shields.io/github/stars/hlbbbbbbb/No-worries?style=flat-square&color=22c55e" alt="GitHub Stars" /></a>
</p>

<br />

---

## ✨ 为什么选 NoWorries

<br />

### 🧠 永久记忆 — 越用越懂你

**普通 AI 每次都是陌生人，NoWorries 会记住你。**

我们实现了完整的三层记忆系统：

| 记忆类型 | 作用 | 存储方式 |
|---------|------|---------|
| **即时记忆** | 当前对话的所有内容 | 实时保存 |
| **情景记忆** | 发生的事件：任务、文件、结果、你的反馈 | 按月归档 |
| **核心记忆** | 你的偏好、习惯、重要要求 | 向量嵌入 + 语义搜索 |

**技术实现：**
- **向量嵌入** — 对话和事件被转换为向量，存储在本地 SQLite
- **语义搜索** — 不需要记得原话，描述大概就能找到相关记忆
- **增量总结** — 对话过长时自动总结，保留重点，避免上下文溢出
- **情感标记** — 记录你的反馈（"做得好"/"不对"），用于改进

**效果示例：**
```
你：「上周老板说报告要改什么来着？」

NoWorries：搜索记忆中... 找到 3 条相关对话
           
           老板上周二说：
           1. 图表要用公司配色
           2. 数据要标注来源  
           3. 结论要加行动建议
           
           要我帮你改吗？
```

<br />

### 🛡️ 安全区 — 新手放心用

**担心 AI 把文件搞乱？我们设计了完整的安全保护机制。**

| 保护机制 | 说明 |
|---------|------|
| **工作区隔离** | AI 只能访问你授权的文件夹，不会乱动其他地方 |
| **自动备份** | 修改文件前自动创建副本，随时可恢复 |
| **命令验证** | 危险命令（`rm -rf` 等）会被拦截并提示 |
| **敏感路径保护** | 系统目录、配置文件等禁止访问 |
| **操作日志** | 每一步操作都有记录，完全可追溯 |
| **一键撤销** | 出问题可以快速恢复到之前状态 |

**对新手的承诺：**

> **最坏的情况也就是浪费几分钟。**
> 
> 误删了？有备份。改错了？改的是副本。崩溃了？重启就好，数据都在。
> 
> 你可以放心探索，不用担心把电脑搞坏。

<br />

### 🧩 Skills 技能系统 — 无限扩展

**让 AI 学会新技能，就像安装 App 一样简单。**

Skills 是 NoWorries 的技能插件系统，可以让 AI 学会处理特定领域的任务：

| 技能类型 | 说明 | 示例 |
|---------|------|------|
| **办公技能** | Excel、Word、PPT 专业处理 | 复杂透视表、批量生成文档 |
| **开发技能** | 代码审查、自动化测试 | Git 操作、CI/CD 配置 |
| **数据技能** | 数据分析、可视化 | 图表生成、报告撰写 |
| **自定义技能** | 你自己编写的技能 | 公司内部流程自动化 |

**技能特点：**
- **即插即用** — 下载技能文件，放入指定目录即可
- **社区共享** — 可以使用和分享社区创建的技能
- **自定义开发** — 按你的需求编写专属技能
- **版本管理** — 技能可以更新和回滚

```
你：「用公司模板生成本月销售报告」

NoWorries：检测到 [公司报告技能]
           读取销售数据...
           应用公司模板...
           生成图表和分析...
           ✓ 报告已生成：2026年1月销售报告.docx
```

<br />

---

## 💬 一句话，完成繁琐工作

> **不是聊天机器人，是真正帮你干活的桌面工具。**<br/>
> 文件在你电脑上，不上传云端。直接帮你改好，确认就行。

<br />

### 📊 Excel 表格处理

从简单的公式到复杂的数据分析，NoWorries 理解你的 Excel 文件结构，精准执行每一个操作。

**支持：** `公式自动填充` `数据透视表` `图表生成` `条件格式` `数据清洗` `批量处理`

| 你说 | NoWorries 做 |
|:-----|:-------------|
| 「把 A 列数据去重，最后加上求和公式」 | 去除重复项 → 识别数据范围 → 添加 SUM 公式 ✓ |
| 「按月份汇总销售额，做个数据透视表」 | 按月份分组 → 汇总销售额 → 生成透视表 ✓ |
| 「负数标红，正数标绿，加条件格式」 | 识别数值类型 → 负数标红 → 正数标绿 ✓ |
| 「做个柱状图对比各部门业绩」 | 选择数据源 → 创建柱状图 → 添加标签 ✓ |

<br />

### 📝 Word 文档处理

从报告生成到格式统一，从内容润色到模板填充。理解文档的结构和意图，帮你创作专业级文档。

**支持：** `报告生成` `格式统一` `内容润色` `批量邮件` `会议纪要` `模板填充`

| 你说 | NoWorries 做 |
|:-----|:-------------|
| 「根据销售数据生成月度分析报告」 | 读取数据源 → 生成图表 → 撰写分析 ✓ |
| 「标题用黑体，正文用宋体，统一格式」 | 识别标题 → 应用黑体 → 正文宋体 ✓ |
| 「写一份工作周报，重点是项目进度」 | 整理本周工作 → 总结进度 → 规划下周 ✓ |
| 「用模板批量生成 50 份邀请函」 | 读取 50 条数据 → 填充模板 → 批量生成 ✓ |

<br />

### 🔄 跨文件格式转换

打破文件类型边界，让 Excel、Word、PDF 之间自由流动。数据提取、格式转换、批量生成，一气呵成。

```
Excel  ──────►  Word    数据生成报告
PDF    ──────►  Excel   表格提取
Word   ──────►  PDF     批量转换
```

| 你说 | NoWorries 做 |
|:-----|:-------------|
| 「把 Excel 客户信息批量生成邀请函」 | 读取客户数据 → 填充模板 → 批量生成 ✓ |
| 「从 PDF 合同里提取表格到 Excel」 | 识别 PDF 表格 → 提取数据 → 导入 Excel ✓ |
| 「用财务数据生成季度报告带图表」 | 分析数据 → 生成图表 → 撰写报告 ✓ |
| 「Excel 工资表生成每人的工资条 PDF」 | 解析数据 → 生成条目 → 导出 PDF ✓ |

<br />

### 📁 文件整理自动化

告别混乱的文件夹。智能识别文件内容和属性，按你的规则自动分类、重命名、归档。

**支持：** `智能分类` `批量重命名` `查重清理` `自动归档` `照片整理` `定期清理`

| 你说 | NoWorries 做 |
|:-----|:-------------|
| 「把下载文件夹按类型分类整理」 | 扫描 128 个文件 → 识别类型 → 移动归档 ✓ |
| 「按拍摄日期重命名并分类照片」 | 读取 EXIF → 按日期重命名 → 分类归档 ✓ |
| 「找出文件夹里所有重复的文件」 | 计算哈希 → 发现重复 23 个 → 等待确认 ✓ |
| 「清理超过 30 天的临时文件」 | 扫描目录 → 筛选过期 → 释放 2.3GB ✓ |

<p align="center">
  <a href="https://meetnoworries.com">
    <strong>→ 访问官网查看更多使用场景</strong>
  </a>
</p>

<br />

---

## 🔌 支持国产 AI — 用你自己的密钥

| AI 提供商 | 说明 | 特点 |
|----------|------|------|
| **智谱 GLM-4** | 国产首选 | 能力强，支持好 |
| **通义千问** | 阿里云 | 稳定可靠 |
| **豆包** | 字节跳动 | 速度快 |
| **Kimi** | 月之暗面 | 长上下文能力强 |
| **DeepSeek** | 深度求索 | 性价比之王 |
| **Ollama** | 本地运行 | 完全离线，隐私最强 |

**没有订阅费，用多少算多少。** 你的 API 密钥加密存储在本地。

<br />

---

## ⚡ 和普通 AI 的区别

| 普通 AI 聊天 | NoWorries |
|:------------|:----------|
| ❌ 要把文件上传到云端 | ✅ 文件在你电脑上，不上传 |
| ❌ 只能给建议，还得自己动手 | ✅ 直接帮你改好，确认就行 |
| ❌ 看不懂复杂的 Excel 公式 | ✅ 深度理解文档结构，精准操作 |
| ❌ 大文件经常出错卡住 | ✅ 几百个文件也能批量处理 |
| ❌ 每次都要重新解释需求 | ✅ 有记忆，越用越懂你 |

<br />

---

## 🚀 下载安装

<p align="center">
  <a href="https://meetnoworries.com">
    <img src="https://img.shields.io/badge/🌐_官网下载安装包-meetnoworries.com-22c55e?style=for-the-badge&labelColor=1a1a1a" alt="Download from Website" />
  </a>
</p>

<p align="center">
  <strong>推荐直接去官网下载</strong>，有完整的安装引导和使用教程。
</p>

<br />

**安装步骤（2 分钟）：**

1. **下载** — 从官网下载安装包（Mac: `.dmg` / Windows: `.exe`）
2. **安装** — Mac: 拖入 Applications / Windows: 双击安装
3. **配置** — 输入你的 AI 密钥（智谱/千问/DeepSeek 等）
4. **授权** — 选择允许 AI 访问的文件夹
5. **开始** — 用大白话描述你想做什么

**系统要求：**

| 平台 | 要求 |
|------|------|
| **macOS** | 12.0+ (Apple Silicon / Intel) |
| **Windows** | Windows 10/11 (64-bit) |
| **磁盘空间** | 4GB |

<br />

---

## 📖 配置教程

安装完成后，3 分钟完成配置即可开始使用。

<br />

### Step 1：打开设置

点击左下角的 **⚙️ 设置图标**，进入配置页面。

<br />

### Step 2：配置 AI 模型

选择你喜欢的 AI 服务商，填入 API Key。

| 服务商 | 推荐度 | 说明 |
|--------|--------|------|
| **Kimi Code** | ⭐ 推荐 | 月之暗面专业编程模型，国内访问稳定 |
| **智谱 ZhiPu** | | GLM 系列模型 |
| **硅基流动** | 多模型 | Qwen、DeepSeek、GLM 等 |
| **OpenAI 兼容** | 通用 | 支持中转站、本地部署 |

<p align="center">
  <a href="https://www.kimi.com/code/zh">
    <img src="https://img.shields.io/badge/获取_Kimi_Code-www.kimi.com-10b981?style=for-the-badge" alt="Kimi Code" />
  </a>
</p>

<br />

### Step 3：配置记忆功能（Embedding）

启用 Embedding 让 AI 拥有**长期记忆**，能记住你之前的对话和偏好。

<p align="center">
  <strong>🎉 硅基流动的 Embedding 模型是免费的！</strong>
</p>

推荐使用 **硅基流动** —— 注册即送免费额度，Embedding 模型完全免费。

<p align="center">
  <a href="https://siliconflow.cn/">
    <img src="https://img.shields.io/badge/注册硅基流动（免费）-siliconflow.cn-8b5cf6?style=for-the-badge" alt="SiliconFlow" />
  </a>
</p>

<br />

### ✅ 配置完成！

现在你可以开始使用 NoWorries 了。用大白话描述你想做什么，AI 会帮你搞定。

<p align="center">
  <a href="https://meetnoworries.com/getting-started">
    <strong>→ 查看官网完整教程（带截图）</strong>
  </a>
</p>

<br />

---

## 🛠️ 开发者

如果你想参与开发或从源码运行：

```bash
git clone https://github.com/hlbbbbbbb/No-worries.git
cd No-worries/noworries_app
pnpm install
pnpm dev
```

<br />

---

## 💭 我们的理念

<p align="center">
  <strong>「技术的意义，不是让人更忙，是让人有资格『无事』。」</strong>
</p>

<br />

我们不是要让你做更多、卷得更快。

我们希望把繁琐的事交给 AI，让你省下时间去做真正重要的事——

陪家人、休息，或者什么都不做。

<p align="center">
  <strong>已无事。请得闲。</strong>
</p>

<br />

---

## 🙏 致谢

NoWorries 的诞生离不开这些优秀的开源项目：

- **[OpenClaw](https://openclaw.ai)** — Agent 架构启发
- **[Openwork](https://github.com/accomplish-ai/openwork)** — Electron 基础
- **[Pi Agent](https://github.com/mariozechner/pi-ai)** — Agent 框架

也感谢 Claude Code、OpenAI Codex、MiniMax Agent、阿里 Qoder 等产品，给了我们学习的方向。

<br />

---

<p align="center">
  <strong>⭐ 觉得有用？Star 一下支持我们！</strong>
</p>

<p align="center">
  <a href="https://meetnoworries.com"><strong>官网</strong></a> · 
  <a href="https://github.com/hlbbbbbbb/No-worries/issues">反馈问题</a> · 
  <a href="CONTRIBUTING.md">参与贡献</a>
</p>

<p align="center">
  <sub>MIT License · Made with ❤️</sub>
</p>
