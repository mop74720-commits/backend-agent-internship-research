/**
 * 安全沙盒模块入口
 * 
 * 导出所有沙盒相关功能
 */

import os from 'os';

// 工作区管理
export {
  getDefaultSafeWorkspacePath,
  getSafeWorkspacePath,
  initializeSafeWorkspace,
  isPathInSafeWorkspace,
  isSensitivePath,
  copyToSafeWorkspace,
  createInSafeWorkspace,
  listSafeWorkspaceFiles,
  cleanTempFiles,
  validatePath,
} from './workspace-manager';

// 命令验证
export {
  validateCommand,
  sanitizeCommandForDisplay,
  isReadOnlyCommand,
  type ValidationResult,
} from './command-validator';

// 系统级沙盒
export {
  executeMacOSSandbox,
  isMacOSSandboxAvailable,
  type SandboxExecutionResult as MacOSSandboxResult,
} from './macos-sandbox';

export {
  executeWindowsSandbox,
  executeWindowsCmdSandbox,
  isWindowsPowerShellAvailable,
  type SandboxExecutionResult as WindowsSandboxResult,
} from './windows-sandbox';

// 敏感信息追踪
export {
  sensitiveTracker,
  SensitiveInfoTracker,
  type FileAccessRecord,
  type TrackerStats,
} from './sensitive-tracker';

// 智能清除
export {
  smartCleaner,
  SmartCleaner,
  type SensitiveFinding,
  type ScanResult,
  type CleanResult,
  type CleanStats,
} from './smart-cleaner';

// 安全模式通知
export {
  generateEnableSafeModeMessage,
  generateDisableSafeModeMessage,
  generateSafeModeNotification,
  generateShortNotification,
  type SafeModeSystemMessage,
} from './safe-mode-notification';

/**
 * 统一的沙盒执行接口
 */
export interface SandboxExecutionResult {
  stdout: string;
  stderr: string;
  exitCode: number;
  sandboxed: boolean;
}

/**
 * 根据平台选择合适的沙盒执行器
 */
export async function executeSandboxed(
  command: string,
  options?: {
    workingDir?: string;
    timeout?: number;
    env?: Record<string, string>;
  }
): Promise<SandboxExecutionResult> {
  const platform = os.platform();
  
  if (platform === 'darwin') {
    const { executeMacOSSandbox } = await import('./macos-sandbox');
    return executeMacOSSandbox(command, options);
  } else if (platform === 'win32') {
    const { executeWindowsSandbox } = await import('./windows-sandbox');
    return executeWindowsSandbox(command, options);
  } else {
    // Linux - 暂时使用基本的环境变量隔离
    // 未来可以添加 bubblewrap 或 firejail 支持
    const { spawn } = await import('child_process');
    const { getSafeWorkspacePath } = await import('./workspace-manager');
    const path = await import('path');
    
    const workspacePath = getSafeWorkspacePath();
    const cwd = options?.workingDir || workspacePath;
    const timeout = options?.timeout || 30000;
    
    return new Promise((resolve) => {
      const env = {
        ...process.env,
        ...options?.env,
        HOME: workspacePath,
        TMPDIR: path.join(workspacePath, 'temp'),
      };
      
      const proc = spawn('bash', ['-c', command], {
        cwd,
        env,
        timeout,
      });
      
      let stdout = '';
      let stderr = '';
      
      proc.stdout.on('data', (data) => {
        stdout += data.toString();
      });
      
      proc.stderr.on('data', (data) => {
        stderr += data.toString();
      });
      
      proc.on('close', (code) => {
        resolve({
          stdout: stdout.slice(0, 50000),
          stderr: stderr.slice(0, 10000),
          exitCode: code ?? 0,
          sandboxed: true,
        });
      });
      
      proc.on('error', (err) => {
        resolve({
          stdout,
          stderr: `Linux execution error: ${err.message}`,
          exitCode: 1,
          sandboxed: false,
        });
      });
    });
  }
}
