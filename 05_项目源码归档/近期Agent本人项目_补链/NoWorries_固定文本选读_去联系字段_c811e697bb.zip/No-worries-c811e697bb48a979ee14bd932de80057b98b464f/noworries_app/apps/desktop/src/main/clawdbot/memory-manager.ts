/**
 * MemoryManager - 记忆存储管理器
 * 
 * 使用 SQLite 存储对话历史和向量嵌入，
 * 支持语义搜索和上下文检索。
 */

import { EventEmitter } from 'events';
import path from 'path';
import fs from 'fs';
import { app } from 'electron';

export interface MemoryEntry {
  id: string;
  sessionId: string;
  type: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
  metadata?: Record<string, unknown>;
  embedding?: number[];
}

export interface MemorySearchResult {
  entry: MemoryEntry;
  score: number;
}

export interface MemoryConfig {
  embeddings?: {
    provider: 'openai' | 'local';
    apiKey?: string;
  };
}

export class MemoryManager extends EventEmitter {
  private entries: Map<string, MemoryEntry> = new Map();
  private config: MemoryConfig;
  private dataDir: string;

  constructor(config: MemoryConfig = {}) {
    super();
    this.config = config;
    this.dataDir = path.join(app.getPath('userData'), 'clawdbot', 'memory');
    
    // 确保目录存在
    if (!fs.existsSync(this.dataDir)) {
      fs.mkdirSync(this.dataDir, { recursive: true });
    }
  }

  /**
   * 初始化记忆存储
   */
  async initialize(): Promise<void> {
    // 加载已保存的记忆
    await this.loadFromDisk();
    console.log(`[MemoryManager] Initialized with ${this.entries.size} entries`);
  }

  /**
   * 添加记忆条目
   */
  async add(entry: Omit<MemoryEntry, 'id'>): Promise<MemoryEntry> {
    const id = this.generateId();
    const fullEntry: MemoryEntry = {
      id,
      ...entry,
    };

    // 生成嵌入向量（如果配置了）
    if (this.config.embeddings) {
      try {
        fullEntry.embedding = await this.generateEmbedding(entry.content);
      } catch (err) {
        console.error('[MemoryManager] Embedding generation failed:', err);
      }
    }

    this.entries.set(id, fullEntry);
    
    // 保存到磁盘
    await this.saveToDisk();
    
    this.emit('memory:added', fullEntry);
    return fullEntry;
  }

  /**
   * 获取会话的所有记忆
   */
  getBySession(sessionId: string): MemoryEntry[] {
    return Array.from(this.entries.values())
      .filter(e => e.sessionId === sessionId)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  }

  /**
   * 搜索相关记忆
   */
  async search(query: string, limit = 5): Promise<MemorySearchResult[]> {
    if (!this.config.embeddings) {
      // 没有嵌入配置，使用简单的文本匹配
      return this.simpleSearch(query, limit);
    }

    try {
      const queryEmbedding = await this.generateEmbedding(query);
      return this.vectorSearch(queryEmbedding, limit);
    } catch (err) {
      console.error('[MemoryManager] Vector search failed, falling back to simple search:', err);
      return this.simpleSearch(query, limit);
    }
  }

  /**
   * 简单文本搜索
   */
  private simpleSearch(query: string, limit: number): MemorySearchResult[] {
    const queryLower = query.toLowerCase();
    const results: MemorySearchResult[] = [];

    for (const entry of this.entries.values()) {
      const contentLower = entry.content.toLowerCase();
      if (contentLower.includes(queryLower)) {
        // 计算简单的相关度分数
        const score = queryLower.length / contentLower.length;
        results.push({ entry, score });
      }
    }

    return results
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);
  }

  /**
   * 向量搜索
   */
  private vectorSearch(queryEmbedding: number[], limit: number): MemorySearchResult[] {
    const results: MemorySearchResult[] = [];

    for (const entry of this.entries.values()) {
      if (entry.embedding) {
        const score = this.cosineSimilarity(queryEmbedding, entry.embedding);
        results.push({ entry, score });
      }
    }

    return results
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);
  }

  /**
   * 生成嵌入向量
   */
  private async generateEmbedding(text: string): Promise<number[]> {
    if (this.config.embeddings?.provider === 'openai' && this.config.embeddings.apiKey) {
      return this.generateOpenAIEmbedding(text);
    }
    
    // 本地简单嵌入（仅用于演示）
    return this.generateLocalEmbedding(text);
  }

  /**
   * 使用 OpenAI 生成嵌入
   */
  private async generateOpenAIEmbedding(text: string): Promise<number[]> {
    const response = await fetch('https://api.openai.com/v1/embeddings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.config.embeddings!.apiKey}`,
      },
      body: JSON.stringify({
        model: 'text-embedding-3-small',
        input: text,
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const data = await response.json() as { data: Array<{ embedding: number[] }> };
    return data.data[0].embedding;
  }

  /**
   * 本地简单嵌入（基于字符频率）
   */
  private generateLocalEmbedding(text: string): number[] {
    const embedding = new Array(128).fill(0);
    const chars = text.toLowerCase();
    
    for (let i = 0; i < chars.length; i++) {
      const charCode = chars.charCodeAt(i);
      const index = charCode % 128;
      embedding[index] += 1;
    }
    
    // 归一化
    const magnitude = Math.sqrt(embedding.reduce((sum, val) => sum + val * val, 0));
    if (magnitude > 0) {
      for (let i = 0; i < embedding.length; i++) {
        embedding[i] /= magnitude;
      }
    }
    
    return embedding;
  }

  /**
   * 计算余弦相似度
   */
  private cosineSimilarity(a: number[], b: number[]): number {
    if (a.length !== b.length) return 0;
    
    let dotProduct = 0;
    let magnitudeA = 0;
    let magnitudeB = 0;
    
    for (let i = 0; i < a.length; i++) {
      dotProduct += a[i] * b[i];
      magnitudeA += a[i] * a[i];
      magnitudeB += b[i] * b[i];
    }
    
    const magnitude = Math.sqrt(magnitudeA) * Math.sqrt(magnitudeB);
    return magnitude > 0 ? dotProduct / magnitude : 0;
  }

  /**
   * 从磁盘加载
   */
  private async loadFromDisk(): Promise<void> {
    const filePath = path.join(this.dataDir, 'memory.json');
    
    if (fs.existsSync(filePath)) {
      try {
        const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
        for (const entry of data.entries || []) {
          entry.timestamp = new Date(entry.timestamp);
          this.entries.set(entry.id, entry);
        }
      } catch (err) {
        console.error('[MemoryManager] Load from disk failed:', err);
      }
    }
  }

  /**
   * 保存到磁盘
   */
  private async saveToDisk(): Promise<void> {
    const filePath = path.join(this.dataDir, 'memory.json');
    const data = {
      version: 1,
      entries: Array.from(this.entries.values()),
    };
    
    try {
      fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
    } catch (err) {
      console.error('[MemoryManager] Save to disk failed:', err);
    }
  }

  /**
   * 生成 ID
   */
  private generateId(): string {
    return `mem-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * 清空所有记忆
   */
  async clear(): Promise<void> {
    this.entries.clear();
    await this.saveToDisk();
    this.emit('memory:cleared');
  }

  /**
   * 获取统计信息
   */
  getStats(): { totalEntries: number; sessions: number } {
    const sessions = new Set(Array.from(this.entries.values()).map(e => e.sessionId));
    return {
      totalEntries: this.entries.size,
      sessions: sessions.size,
    };
  }
}
