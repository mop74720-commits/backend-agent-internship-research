/**
 * 情景记忆系统 (Episodic Memory)
 *
 * 存储具体事件，带有时间、地点、过程、情感
 * 与语义记忆（KeyFact）不同，情景记忆记录"发生了什么事"
 *
 * 存储路径: workspace/episodes/YYYY-MM.json
 *
 * 特性：
 * - 按月存储，避免单文件过大
 * - 支持分页加载，避免内存问题
 * - 失败队列机制，嵌入失败时自动重试
 * - 与 clawdbot 的 SQLite 嵌入系统集成
 */

import fsSync from "node:fs";
import path from "node:path";

import { createSubsystemLogger } from "../logging/subsystem.js";
import { ensureDir } from "./internal.js";

const log = createSubsystemLogger("episode-memory");

// ========== 类型定义 ==========

/**
 * 情景记忆数据结构
 */
export interface Episode {
  id: string;
  timestamp: number;
  event: string; // 事件描述，如 "用户要求美化 Excel 表格"
  actions: string[]; // 执行的操作，如 ["读取文件", "调整格式", "保存"]
  files: string[]; // 涉及的文件路径
  outcome: "success" | "partial" | "failed";
  userFeedback?: string; // 用户反馈，如 "做得不错" / "不是我想要的"
  emotionalContext?: string; // 用户情绪，如 "着急" / "开心"
  duration?: number; // 耗时（毫秒）
  toolsUsed?: string[]; // 使用的工具
  sessionId?: string; // 所属会话 ID
  agentId?: string; // 所属 Agent ID
}

/**
 * 月度 Episode 存储结构
 */
interface MonthlyEpisodeStore {
  month: string; // YYYY-MM
  episodes: Episode[];
  lastUpdated: number;
}

/**
 * 失败的嵌入任务
 */
interface FailedEmbedding {
  episode: Episode;
  attempts: number;
  lastAttempt: number;
  error: string;
}

// ========== 常量 ==========

const MAX_RETRY_ATTEMPTS = 3;
const RETRY_DELAY_MS = 5 * 60 * 1000; // 5 分钟后重试
const EPISODES_DIR = "episodes";

// ========== 失败队列 ==========

// 内存中的失败队列（按 agentId 分组）
const failedEmbeddingQueues = new Map<string, FailedEmbedding[]>();

function getFailedQueue(agentId: string): FailedEmbedding[] {
  let queue = failedEmbeddingQueues.get(agentId);
  if (!queue) {
    queue = [];
    failedEmbeddingQueues.set(agentId, queue);
  }
  return queue;
}

/**
 * 将失败的嵌入加入队列
 */
function queueFailedEmbedding(
  agentId: string,
  episode: Episode,
  error: string,
): void {
  const queue = getFailedQueue(agentId);
  const existing = queue.find((f) => f.episode.id === episode.id);

  if (existing) {
    existing.attempts += 1;
    existing.lastAttempt = Date.now();
    existing.error = error;

    // 超过最大重试次数，从队列移除
    if (existing.attempts >= MAX_RETRY_ATTEMPTS) {
      const index = queue.indexOf(existing);
      queue.splice(index, 1);
      log.warn(
        `Episode ${episode.id} exceeded max retries, removed from queue`,
      );
    }
  } else {
    queue.push({
      episode,
      attempts: 1,
      lastAttempt: Date.now(),
      error,
    });
  }

  log.debug(
    `Queued failed embedding: ${episode.id} (queue size: ${queue.length})`,
  );
}

// ========== 工具函数 ==========

/**
 * 获取 episodes 存储目录
 */
function getEpisodesPath(workspaceDir: string): string {
  const episodesPath = path.join(workspaceDir, EPISODES_DIR);
  ensureDir(episodesPath);
  return episodesPath;
}

/**
 * 获取当前月份字符串
 */
function getCurrentMonth(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}

/**
 * 获取指定月份的存储文件路径
 */
function getMonthFilePath(workspaceDir: string, month: string): string {
  return path.join(getEpisodesPath(workspaceDir), `${month}.json`);
}

/**
 * 读取月度 Episode 存储
 */
function readMonthlyStore(
  workspaceDir: string,
  month: string,
): MonthlyEpisodeStore {
  const filePath = getMonthFilePath(workspaceDir, month);

  if (fsSync.existsSync(filePath)) {
    try {
      const content = fsSync.readFileSync(filePath, "utf-8");
      return JSON.parse(content);
    } catch {
      log.warn(`Failed to read ${month} store, creating new one`);
    }
  }

  return {
    month,
    episodes: [],
    lastUpdated: Date.now(),
  };
}

/**
 * 保存月度 Episode 存储
 */
function saveMonthlyStore(
  workspaceDir: string,
  store: MonthlyEpisodeStore,
): void {
  const filePath = getMonthFilePath(workspaceDir, store.month);
  store.lastUpdated = Date.now();
  fsSync.writeFileSync(filePath, JSON.stringify(store, null, 2), "utf-8");
}

/**
 * 生成 Episode ID
 */
function generateEpisodeId(): string {
  const timestamp = Date.now().toString(36);
  const random = Math.random().toString(36).substr(2, 5);
  return `ep-${timestamp}-${random}`;
}

// ========== 核心功能 ==========

/**
 * 记录一个新的 Episode
 */
export function recordEpisode(
  workspaceDir: string,
  episode: Omit<Episode, "id" | "timestamp">,
): Episode {
  const month = getCurrentMonth();

  const newEpisode: Episode = {
    ...episode,
    id: generateEpisodeId(),
    timestamp: Date.now(),
  };

  // 读取当前月份的存储
  const store = readMonthlyStore(workspaceDir, month);

  // 添加新 Episode
  store.episodes.push(newEpisode);

  // 保存
  saveMonthlyStore(workspaceDir, store);

  log.info(`Recorded episode: ${newEpisode.event.slice(0, 50)}...`);

  return newEpisode;
}

/**
 * 将 Episode 格式化为可嵌入的文本
 */
export function formatEpisodeForEmbedding(episode: Episode): string {
  const lines: string[] = [];

  lines.push(`## 事件记录`);
  lines.push(`事件: ${episode.event}`);
  lines.push(`时间: ${new Date(episode.timestamp).toLocaleString("zh-CN")}`);
  lines.push(
    `结果: ${episode.outcome === "success" ? "成功" : episode.outcome === "partial" ? "部分完成" : "失败"}`,
  );

  if (episode.files.length > 0) {
    lines.push(`涉及文件: ${episode.files.join(", ")}`);
  }

  if (episode.actions.length > 0) {
    lines.push(`执行操作: ${episode.actions.join(" → ")}`);
  }

  if (episode.userFeedback) {
    lines.push(`用户反馈: ${episode.userFeedback}`);
  }

  if (episode.emotionalContext) {
    lines.push(`用户情绪: ${episode.emotionalContext}`);
  }

  if (episode.toolsUsed && episode.toolsUsed.length > 0) {
    lines.push(`使用工具: ${episode.toolsUsed.join(", ")}`);
  }

  return lines.join("\n");
}

/**
 * 根据 ID 获取 Episode
 * 优化：从 ID 中提取时间戳，只加载相关月份
 */
export function getEpisodeById(
  workspaceDir: string,
  episodeId: string,
): Episode | null {
  // Episode ID 格式: ep-{timestamp36}-{random}
  const match = episodeId.match(/^ep-([a-z0-9]+)-/);

  if (match) {
    try {
      const timestamp = parseInt(match[1], 36);
      const date = new Date(timestamp);
      const month = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;

      // 先在推测的月份中查找
      const store = readMonthlyStore(workspaceDir, month);
      const found = store.episodes.find((e) => e.id === episodeId);
      if (found) {
        return found;
      }

      // 如果没找到，检查前后月份（跨月边界情况）
      const prevMonth = new Date(date.getFullYear(), date.getMonth() - 1, 1);
      const nextMonth = new Date(date.getFullYear(), date.getMonth() + 1, 1);

      for (const d of [prevMonth, nextMonth]) {
        const m = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
        const s = readMonthlyStore(workspaceDir, m);
        const f = s.episodes.find((e) => e.id === episodeId);
        if (f) return f;
      }
    } catch {
      // 解析失败，降级到全量搜索
    }
  }

  // 降级：全量搜索
  const allEpisodes = getAllEpisodes(workspaceDir);
  return allEpisodes.find((e) => e.id === episodeId) || null;
}

/**
 * 获取所有 Episodes
 * 注意：此函数会加载所有数据到内存，数据量大时请使用 getEpisodesPaginated
 */
export function getAllEpisodes(workspaceDir: string): Episode[] {
  const episodesPath = getEpisodesPath(workspaceDir);

  if (!fsSync.existsSync(episodesPath)) {
    return [];
  }

  const files = fsSync
    .readdirSync(episodesPath)
    .filter((f) => f.endsWith(".json"))
    .sort()
    .reverse(); // 最新的月份在前

  const allEpisodes: Episode[] = [];

  for (const file of files) {
    const month = file.replace(".json", "");
    const store = readMonthlyStore(workspaceDir, month);
    allEpisodes.push(...store.episodes);
  }

  // 按时间戳降序排序
  allEpisodes.sort((a, b) => b.timestamp - a.timestamp);

  return allEpisodes;
}

/**
 * 分页获取 Episodes
 */
export function getEpisodesPaginated(
  workspaceDir: string,
  page: number = 0,
  pageSize: number = 50,
): {
  episodes: Episode[];
  total: number;
  hasMore: boolean;
  page: number;
  pageSize: number;
} {
  const episodesPath = getEpisodesPath(workspaceDir);

  if (!fsSync.existsSync(episodesPath)) {
    return { episodes: [], total: 0, hasMore: false, page, pageSize };
  }

  const files = fsSync
    .readdirSync(episodesPath)
    .filter((f) => f.endsWith(".json"))
    .sort()
    .reverse();

  // 计算总数
  let total = 0;
  const monthCounts: Array<{ month: string; count: number }> = [];

  for (const file of files) {
    const month = file.replace(".json", "");
    const store = readMonthlyStore(workspaceDir, month);
    const count = store.episodes.length;
    monthCounts.push({ month, count });
    total += count;
  }

  const startIndex = page * pageSize;
  const endIndex = startIndex + pageSize;

  if (startIndex >= total) {
    return { episodes: [], total, hasMore: false, page, pageSize };
  }

  // 找出需要读取的月份
  const episodes: Episode[] = [];
  let currentIndex = 0;

  for (const { month, count } of monthCounts) {
    const monthStart = currentIndex;
    const monthEnd = currentIndex + count;

    if (monthEnd > startIndex && monthStart < endIndex) {
      const store = readMonthlyStore(workspaceDir, month);
      const sortedEpisodes = store.episodes.sort(
        (a, b) => b.timestamp - a.timestamp,
      );

      for (let i = 0; i < sortedEpisodes.length; i++) {
        const globalIndex = monthStart + i;
        if (globalIndex >= startIndex && globalIndex < endIndex) {
          episodes.push(sortedEpisodes[i]);
        }
      }
    }

    currentIndex += count;

    if (episodes.length >= pageSize) {
      break;
    }
  }

  episodes.sort((a, b) => b.timestamp - a.timestamp);

  return {
    episodes: episodes.slice(0, pageSize),
    total,
    hasMore: endIndex < total,
    page,
    pageSize,
  };
}

/**
 * 获取 Episodes 总数
 */
export function getEpisodesCount(workspaceDir: string): number {
  const episodesPath = getEpisodesPath(workspaceDir);

  if (!fsSync.existsSync(episodesPath)) {
    return 0;
  }

  const files = fsSync
    .readdirSync(episodesPath)
    .filter((f) => f.endsWith(".json"));

  let total = 0;

  for (const file of files) {
    const month = file.replace(".json", "");
    const store = readMonthlyStore(workspaceDir, month);
    total += store.episodes.length;
  }

  return total;
}

/**
 * 获取最近 N 天的 Episodes
 */
export function getRecentEpisodes(
  workspaceDir: string,
  days: number = 7,
): Episode[] {
  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
  return getAllEpisodes(workspaceDir).filter((e) => e.timestamp >= cutoff);
}

/**
 * 获取涉及指定文件的 Episodes
 */
export function getEpisodesByFile(
  workspaceDir: string,
  filePath: string,
): Episode[] {
  const normalizedPath = filePath.toLowerCase();
  return getAllEpisodes(workspaceDir).filter((e) =>
    e.files.some((f) => f.toLowerCase().includes(normalizedPath)),
  );
}

/**
 * 获取指定结果类型的 Episodes
 */
export function getEpisodesByOutcome(
  workspaceDir: string,
  outcome: "success" | "partial" | "failed",
): Episode[] {
  return getAllEpisodes(workspaceDir).filter((e) => e.outcome === outcome);
}

/**
 * 关键词搜索 Episodes
 */
export function searchEpisodesByKeyword(
  workspaceDir: string,
  query: string,
  topK: number = 5,
): Array<{ episode: Episode; score: number }> {
  const allEpisodes = getAllEpisodes(workspaceDir);
  const queryLower = query.toLowerCase();
  const queryWords = queryLower.split(/\s+/);

  const scored: Array<{ episode: Episode; score: number }> = [];

  for (const episode of allEpisodes) {
    let score = 0;
    const searchText = [
      episode.event,
      ...episode.actions,
      ...episode.files,
      episode.userFeedback || "",
    ]
      .join(" ")
      .toLowerCase();

    for (const word of queryWords) {
      if (searchText.includes(word)) {
        score += 1;
      }
    }

    if (score > 0) {
      scored.push({ episode, score: score / queryWords.length });
    }
  }

  scored.sort((a, b) => b.score - a.score);

  return scored.slice(0, topK);
}

/**
 * 格式化 Episode 列表为可读文本（用于注入上下文）
 */
export function formatEpisodesForContext(episodes: Episode[]): string {
  if (episodes.length === 0) {
    return "";
  }

  const lines: string[] = ["## 相关历史事件"];

  for (const episode of episodes) {
    const date = new Date(episode.timestamp).toLocaleDateString("zh-CN");
    const outcome =
      episode.outcome === "success"
        ? "✓"
        : episode.outcome === "partial"
          ? "◐"
          : "✗";

    lines.push(`\n### ${date} ${outcome} ${episode.event}`);

    if (episode.files.length > 0) {
      lines.push(`文件: ${episode.files.join(", ")}`);
    }

    if (episode.actions.length > 0) {
      lines.push(`操作: ${episode.actions.join(" → ")}`);
    }

    if (episode.userFeedback) {
      lines.push(`反馈: ${episode.userFeedback}`);
    }
  }

  return lines.join("\n");
}

/**
 * 清理旧的 Episodes（保留最近 N 个月）
 */
export function cleanupOldEpisodes(
  workspaceDir: string,
  keepMonths: number = 6,
): number {
  const episodesPath = getEpisodesPath(workspaceDir);

  if (!fsSync.existsSync(episodesPath)) {
    return 0;
  }

  const files = fsSync
    .readdirSync(episodesPath)
    .filter((f) => f.endsWith(".json"))
    .sort();

  if (files.length <= keepMonths) {
    return 0;
  }

  const filesToDelete = files.slice(0, files.length - keepMonths);
  let deletedCount = 0;

  for (const file of filesToDelete) {
    const filePath = path.join(episodesPath, file);
    fsSync.unlinkSync(filePath);
    log.info(`Deleted old episode store: ${file}`);
    deletedCount++;
  }

  return deletedCount;
}

// ========== 失败队列管理 ==========

/**
 * 重试失败的 Episode 嵌入
 */
export async function retryFailedEpisodeEmbeddings(
  agentId: string,
  embedFn?: (episode: Episode) => Promise<void>,
): Promise<{ retried: number; success: number }> {
  const queue = getFailedQueue(agentId);
  const now = Date.now();
  const readyToRetry = queue.filter(
    (f) =>
      now - f.lastAttempt >= RETRY_DELAY_MS && f.attempts < MAX_RETRY_ATTEMPTS,
  );

  if (readyToRetry.length === 0) {
    return { retried: 0, success: 0 };
  }

  log.info(`Retrying ${readyToRetry.length} failed episode embeddings...`);

  let success = 0;

  for (const failed of readyToRetry) {
    try {
      if (embedFn) {
        await embedFn(failed.episode);
      }

      // 成功后从队列移除
      const index = queue.indexOf(failed);
      if (index !== -1) {
        queue.splice(index, 1);
      }

      success++;
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      queueFailedEmbedding(agentId, failed.episode, errorMsg);
    }

    // 避免过快重试
    await new Promise((resolve) => setTimeout(resolve, 200));
  }

  log.info(`Retry complete: ${success}/${readyToRetry.length} succeeded`);
  return { retried: readyToRetry.length, success };
}

/**
 * 获取失败队列状态
 */
export function getFailedEmbeddingQueueStatus(agentId: string): {
  count: number;
  episodes: string[];
} {
  const queue = getFailedQueue(agentId);
  return {
    count: queue.length,
    episodes: queue.map((f) => f.episode.id),
  };
}

/**
 * 添加嵌入失败到队列（供外部调用）
 */
export function addToFailedEmbeddingQueue(
  agentId: string,
  episode: Episode,
  error: string,
): void {
  queueFailedEmbedding(agentId, episode, error);
}

// ========== Episode 嵌入辅助 ==========

/**
 * 生成 Episode 的嵌入路径标识
 */
export function getEpisodeEmbeddingPath(episodeId: string): string {
  return `episode:${episodeId}`;
}

/**
 * 检查路径是否为 Episode 嵌入路径
 */
export function isEpisodeEmbeddingPath(pathStr: string): boolean {
  return pathStr.startsWith("episode:");
}

/**
 * 从嵌入路径提取 Episode ID
 */
export function extractEpisodeIdFromPath(pathStr: string): string | null {
  if (!isEpisodeEmbeddingPath(pathStr)) {
    return null;
  }
  return pathStr.replace("episode:", "");
}

// ========== 运行结果集成辅助 ==========

/**
 * 从运行结果创建 Episode 的参数
 */
export interface CreateEpisodeFromRunParams {
  workspaceDir: string;
  sessionId?: string;
  agentId?: string;
  /** 用户的原始请求/提示 */
  prompt: string;
  /** 运行是否成功 */
  success: boolean;
  /** 是否被中止 */
  aborted?: boolean;
  /** 是否超时 */
  timedOut?: boolean;
  /** 运行持续时间（毫秒） */
  durationMs?: number;
  /** 使用的工具列表 */
  toolsUsed?: Array<{ toolName: string; meta?: string }>;
  /** 涉及的文件路径 */
  filesInvolved?: string[];
  /** 错误信息 */
  errorMessage?: string;
  /** 用户反馈（可选） */
  userFeedback?: string;
}

/**
 * 从运行结果创建并记录 Episode
 *
 * 这是一个便捷函数，用于在 agent 运行完成后记录情景记忆
 */
export function createEpisodeFromRunResult(
  params: CreateEpisodeFromRunParams,
): Episode | null {
  try {
    // 确定结果类型
    let outcome: "success" | "partial" | "failed" = "success";
    if (!params.success) {
      outcome = params.aborted ? "partial" : "failed";
    }

    // 提取使用的工具名称
    const toolsUsed = params.toolsUsed?.map((t) => t.toolName) || [];

    // 从工具元数据提取涉及的文件
    const filesFromTools: string[] = [];
    if (params.toolsUsed) {
      for (const tool of params.toolsUsed) {
        if (tool.meta) {
          // 尝试从工具元数据中提取文件路径
          const pathMatches = tool.meta.match(/(?:path|file)[:\s]*["']?([^"'\s,]+)/gi);
          if (pathMatches) {
            for (const match of pathMatches) {
              const pathValue = match.replace(/^(?:path|file)[:\s]*["']?/i, "").replace(/["']$/, "");
              if (pathValue && !pathValue.startsWith("http")) {
                filesFromTools.push(pathValue);
              }
            }
          }
        }
      }
    }

    // 合并所有涉及的文件
    const allFiles = [
      ...(params.filesInvolved || []),
      ...filesFromTools,
    ].filter((f, i, arr) => arr.indexOf(f) === i); // 去重

    // 生成事件描述
    let event = params.prompt.slice(0, 200);
    if (params.prompt.length > 200) {
      event += "...";
    }

    // 生成操作描述
    const actions: string[] = [];
    if (toolsUsed.length > 0) {
      actions.push(`使用工具: ${toolsUsed.join(", ")}`);
    }
    if (params.aborted) {
      actions.push("任务被中止");
    }
    if (params.timedOut) {
      actions.push("任务超时");
    }
    if (params.errorMessage) {
      actions.push(`错误: ${params.errorMessage.slice(0, 100)}`);
    }

    // 记录 Episode
    return recordEpisode(params.workspaceDir, {
      event,
      actions,
      files: allFiles,
      outcome,
      duration: params.durationMs,
      toolsUsed,
      sessionId: params.sessionId,
      agentId: params.agentId,
      userFeedback: params.userFeedback,
      emotionalContext: params.aborted
        ? "任务中止"
        : params.timedOut
          ? "任务超时"
          : undefined,
    });
  } catch (error) {
    log.error(`Failed to create episode from run result: ${error}`);
    return null;
  }
}

/**
 * Episode 记录器配置
 */
export interface EpisodeRecorderConfig {
  workspaceDir: string;
  agentId?: string;
  sessionId?: string;
  enabled?: boolean;
}

/**
 * 创建一个 Episode 记录器
 *
 * 用于在运行开始时初始化，运行结束时调用 finish() 记录
 */
export function createEpisodeRecorder(config: EpisodeRecorderConfig) {
  const startTime = Date.now();
  const toolsUsed: Array<{ toolName: string; meta?: string }> = [];
  const filesInvolved: string[] = [];
  let prompt = "";

  return {
    /** 设置用户提示 */
    setPrompt(userPrompt: string) {
      prompt = userPrompt;
    },

    /** 记录使用的工具 */
    recordTool(toolName: string, meta?: string) {
      toolsUsed.push({ toolName, meta });
    },

    /** 记录涉及的文件 */
    recordFile(filePath: string) {
      if (!filesInvolved.includes(filePath)) {
        filesInvolved.push(filePath);
      }
    },

    /** 完成并记录 Episode */
    finish(result: {
      success: boolean;
      aborted?: boolean;
      timedOut?: boolean;
      errorMessage?: string;
      userFeedback?: string;
    }): Episode | null {
      if (config.enabled === false) {
        return null;
      }

      return createEpisodeFromRunResult({
        workspaceDir: config.workspaceDir,
        sessionId: config.sessionId,
        agentId: config.agentId,
        prompt,
        success: result.success,
        aborted: result.aborted,
        timedOut: result.timedOut,
        durationMs: Date.now() - startTime,
        toolsUsed,
        filesInvolved,
        errorMessage: result.errorMessage,
        userFeedback: result.userFeedback,
      });
    },
  };
}
