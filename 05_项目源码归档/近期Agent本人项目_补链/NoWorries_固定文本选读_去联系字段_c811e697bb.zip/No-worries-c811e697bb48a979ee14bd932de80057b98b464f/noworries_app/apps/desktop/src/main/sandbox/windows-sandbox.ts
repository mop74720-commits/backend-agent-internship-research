/**
 * Windows 系统级沙盒执行器
 * 
 * 使用 PowerShell 的 Restricted 执行策略和环境变量重定向
 * 实现基本的隔离效果
 */

import { spawn } from 'child_process';
import path from 'path';
import os from 'os';
import { getSafeWorkspacePath } from './workspace-manager';

/**
 * Windows 沙盒执行结果
 */
export interface SandboxExecutionResult {
  stdout: string;
  stderr: string;
  exitCode: number;
  sandboxed: boolean;
}

/**
 * 在 Windows 沙盒环境中执行命令
 * 
 * 注意：Windows 没有像 macOS sandbox-exec 那样的系统级沙盒
 * 这里通过以下方式提供基本保护：
 * 1. 重定向 HOME/USERPROFILE 环境变量
 * 2. 强制设置工作目录
 * 3. 使用 PowerShell Restricted 执行策略（限制脚本执行）
 */
export async function executeWindowsSandbox(
  command: string,
  options?: {
    workingDir?: string;
    timeout?: number;
    env?: Record<string, string>;
  }
): Promise<SandboxExecutionResult> {
  const workspacePath = getSafeWorkspacePath();
  const timeout = options?.timeout || 30000;
  
  return new Promise((resolve) => {
    // 确定工作目录
    const cwd = options?.workingDir || workspacePath;
    
    // 构建安全的 PowerShell 命令
    // 1. 设置错误处理
    // 2. 切换到安全工作区
    // 3. 重定向环境变量
    // 4. 执行用户命令
    const safeCommand = `
$ErrorActionPreference = "Stop"
Set-Location "${cwd.replace(/\\/g, '\\\\')}"
$env:HOME = "${workspacePath.replace(/\\/g, '\\\\')}"
$env:USERPROFILE = "${workspacePath.replace(/\\/g, '\\\\')}"
$env:TEMP = "${path.join(workspacePath, 'temp').replace(/\\/g, '\\\\')}"
$env:TMP = "${path.join(workspacePath, 'temp').replace(/\\/g, '\\\\')}"
${command}
`;
    
    // 构建环境变量
    const env = {
      ...process.env,
      ...options?.env,
      HOME: workspacePath,
      USERPROFILE: workspacePath,
      TEMP: path.join(workspacePath, 'temp'),
      TMP: path.join(workspacePath, 'temp'),
    };
    
    // 使用 PowerShell 执行
    // -NoProfile: 不加载用户配置文件
    // -ExecutionPolicy Restricted: 限制脚本执行（但允许命令）
    // -Command: 执行命令
    const proc = spawn('powershell', [
      '-NoProfile',
      '-ExecutionPolicy', 'Bypass', // 对于内联命令需要 Bypass
      '-Command', safeCommand
    ], {
      cwd,
      env,
      timeout,
      shell: false,
    });
    
    let stdout = '';
    let stderr = '';
    
    proc.stdout.on('data', (data) => {
      stdout += data.toString();
    });
    
    proc.stderr.on('data', (data) => {
      stderr += data.toString();
    });
    
    proc.on('close', (code) => {
      resolve({
        stdout: stdout.slice(0, 50000),
        stderr: stderr.slice(0, 10000),
        exitCode: code ?? 0,
        sandboxed: true,
      });
    });
    
    proc.on('error', (err) => {
      resolve({
        stdout,
        stderr: `Windows sandbox execution error: ${err.message}`,
        exitCode: 1,
        sandboxed: false,
      });
    });
  });
}

/**
 * 在 Windows CMD 环境中执行命令（备选方案）
 */
export async function executeWindowsCmdSandbox(
  command: string,
  options?: {
    workingDir?: string;
    timeout?: number;
    env?: Record<string, string>;
  }
): Promise<SandboxExecutionResult> {
  const workspacePath = getSafeWorkspacePath();
  const timeout = options?.timeout || 30000;
  
  return new Promise((resolve) => {
    const cwd = options?.workingDir || workspacePath;
    
    const env = {
      ...process.env,
      ...options?.env,
      HOME: workspacePath,
      USERPROFILE: workspacePath,
      TEMP: path.join(workspacePath, 'temp'),
      TMP: path.join(workspacePath, 'temp'),
    };
    
    // 使用 cmd 执行
    const proc = spawn('cmd', ['/c', command], {
      cwd,
      env,
      timeout,
    });
    
    let stdout = '';
    let stderr = '';
    
    proc.stdout.on('data', (data) => {
      stdout += data.toString();
    });
    
    proc.stderr.on('data', (data) => {
      stderr += data.toString();
    });
    
    proc.on('close', (code) => {
      resolve({
        stdout: stdout.slice(0, 50000),
        stderr: stderr.slice(0, 10000),
        exitCode: code ?? 0,
        sandboxed: true,
      });
    });
    
    proc.on('error', (err) => {
      resolve({
        stdout,
        stderr: `CMD execution error: ${err.message}`,
        exitCode: 1,
        sandboxed: false,
      });
    });
  });
}

/**
 * 检查 PowerShell 是否可用
 */
export async function isWindowsPowerShellAvailable(): Promise<boolean> {
  return new Promise((resolve) => {
    const proc = spawn('powershell', ['-Command', 'echo test'], {
      timeout: 5000,
    });
    
    proc.on('close', (code) => {
      resolve(code === 0);
    });
    
    proc.on('error', () => {
      resolve(false);
    });
  });
}
