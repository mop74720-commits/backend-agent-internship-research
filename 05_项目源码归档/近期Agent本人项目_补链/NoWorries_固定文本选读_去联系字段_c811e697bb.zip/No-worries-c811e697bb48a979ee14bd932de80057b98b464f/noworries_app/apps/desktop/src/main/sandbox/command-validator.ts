/**
 * 命令验证器
 * 
 * 负责：
 * 1. 命令白名单检查
 * 2. 危险模式检测
 * 3. 路径参数验证
 */

import path from 'path';
import { getSafeWorkspacePath, isPathInSafeWorkspace, isSensitivePath } from './workspace-manager';

/**
 * 允许的命令白名单
 */
const ALLOWED_COMMANDS = new Set([
  // 文件操作
  'ls', 'dir', 'cat', 'type', 'head', 'tail', 'grep', 'find', 'wc',
  'mkdir', 'cp', 'copy', 'mv', 'move', 'touch', 'rm', 'del', 'echo',
  'pwd', 'cd', 'tree',
  
  // 文本处理
  'sort', 'uniq', 'cut', 'tr', 'sed', 'awk',
  
  // 开发工具
  'python', 'python3', 'node', 'npm', 'npx', 'pip', 'pip3',
  'git', 'yarn', 'pnpm',
  
  // 办公工具
  'pandoc', 'libreoffice', 'soffice',
  
  // 网络工具（只读）
  'curl', 'wget',
  
  // 系统信息（只读）
  'date', 'cal', 'uptime', 'whoami', 'hostname',
  'which', 'where', 'env', 'printenv',
]);

/**
 * 危险命令/模式
 */
const DANGEROUS_PATTERNS: Array<{ pattern: RegExp; reason: string }> = [
  // 提权操作
  { pattern: /\bsudo\b/, reason: '禁止使用 sudo 提权' },
  { pattern: /\bsu\s/, reason: '禁止切换用户' },
  { pattern: /\bdoas\b/, reason: '禁止使用 doas 提权' },
  
  // 危险删除
  { pattern: /rm\s+(-[rf]+\s+)*[\/~]/, reason: '禁止删除根目录或用户主目录' },
  { pattern: /rm\s+-rf?\s+\*/, reason: '禁止使用通配符删除' },
  { pattern: /rmdir\s+[\/~]/, reason: '禁止删除根目录或用户主目录' },
  
  // 远程执行
  { pattern: /curl.*\|\s*(ba)?sh/, reason: '禁止通过 curl 执行远程脚本' },
  { pattern: /wget.*\|\s*(ba)?sh/, reason: '禁止通过 wget 执行远程脚本' },
  { pattern: /curl.*\|\s*python/, reason: '禁止通过 curl 执行远程 Python 脚本' },
  
  // 系统文件修改
  { pattern: />\s*\/etc/, reason: '禁止写入系统配置目录' },
  { pattern: />\s*\/usr/, reason: '禁止写入系统目录' },
  { pattern: />\s*\/bin/, reason: '禁止写入系统目录' },
  { pattern: />\s*\/sbin/, reason: '禁止写入系统目录' },
  
  // 危险磁盘操作
  { pattern: /\bmkfs\b/, reason: '禁止格式化磁盘' },
  { pattern: /\bdd\s+if=/, reason: '禁止使用 dd 进行磁盘操作' },
  { pattern: /\bfdisk\b/, reason: '禁止磁盘分区操作' },
  { pattern: /\bparted\b/, reason: '禁止磁盘分区操作' },
  
  // 进程操作
  { pattern: /\bkillall\b/, reason: '禁止批量终止进程' },
  { pattern: /\bpkill\b/, reason: '禁止按名称终止进程' },
  { pattern: /\bkill\s+-9\s+1\b/, reason: '禁止终止 init 进程' },
  
  // 网络危险操作
  { pattern: /\bnc\s+-l/, reason: '禁止启动网络监听' },
  { pattern: /\bnetcat\s+-l/, reason: '禁止启动网络监听' },
  
  // 权限修改
  { pattern: /chmod\s+[0-7]*777/, reason: '禁止设置全局可写权限' },
  { pattern: /chown\s+root/, reason: '禁止更改所有者为 root' },
  
  // 环境变量污染
  { pattern: /export\s+PATH=/, reason: '禁止修改 PATH 环境变量' },
  { pattern: /export\s+LD_/, reason: '禁止修改动态链接器变量' },
];

/**
 * 验证结果
 */
export interface ValidationResult {
  valid: boolean;
  reason?: string;
  blockedPattern?: string;
}

/**
 * 解析命令，获取基础命令名
 */
function getBaseCommand(command: string): string {
  // 去除前导空格和管道/重定向之前的部分
  const trimmed = command.trim();
  
  // 处理环境变量设置（VAR=value command）
  const envVarMatch = trimmed.match(/^(?:\w+=\S+\s+)*(.+)/);
  const commandPart = envVarMatch ? envVarMatch[1] : trimmed;
  
  // 获取第一个单词（命令名）
  const parts = commandPart.split(/\s+/);
  const firstPart = parts[0];
  
  // 如果是完整路径，提取文件名
  return path.basename(firstPart);
}

/**
 * 提取命令中的路径参数
 * 支持带空格的路径（引号包围或反斜杠转义）
 */
function extractPathArguments(command: string): string[] {
  const paths: string[] = [];
  
  // 1. 匹配双引号包围的路径
  const doubleQuotedPaths = command.match(/"(\/[^"]+)"/g);
  if (doubleQuotedPaths) {
    for (const match of doubleQuotedPaths) {
      // 去除引号
      paths.push(match.slice(1, -1));
    }
  }
  
  // 2. 匹配单引号包围的路径
  const singleQuotedPaths = command.match(/'(\/[^']+)'/g);
  if (singleQuotedPaths) {
    for (const match of singleQuotedPaths) {
      // 去除引号
      paths.push(match.slice(1, -1));
    }
  }
  
  // 3. 匹配带转义空格的路径 (如 /path\ with\ spaces/)
  const escapedSpacePaths = command.match(/(?:^|\s)(\/(?:[^\s\\]|\\.)+)/g);
  if (escapedSpacePaths) {
    for (const match of escapedSpacePaths) {
      // 去除前导空格，并将转义的空格还原
      const cleanPath = match.trim().replace(/\\ /g, ' ');
      if (cleanPath.includes(' ') || !paths.includes(cleanPath)) {
        paths.push(cleanPath);
      }
    }
  }
  
  // 4. 匹配普通路径（不含空格）
  const pathPatterns = [
    // Unix 绝对路径（不含空格和引号）
    /(?:^|\s)(\/[^\s;|&>"']+)/g,
    // Unix 相对路径
    /(?:^|\s)(\.\.?\/[^\s;|&>"']+)/g,
    // 用户主目录
    /(?:^|\s)(~\/[^\s;|&>"']+)/g,
    // Windows 路径
    /(?:^|\s)([A-Z]:\\[^\s;|&>"']+)/gi,
  ];
  
  for (const pattern of pathPatterns) {
    let match;
    while ((match = pattern.exec(command)) !== null) {
      const foundPath = match[1];
      // 避免重复添加
      if (!paths.includes(foundPath)) {
        paths.push(foundPath);
      }
    }
  }
  
  return paths;
}

/**
 * 验证命令是否安全
 */
export function validateCommand(
  command: string,
  isSafeModeEnabled: boolean
): ValidationResult {
  // 1. 检查危险模式
  for (const { pattern, reason } of DANGEROUS_PATTERNS) {
    if (pattern.test(command)) {
      return {
        valid: false,
        reason,
        blockedPattern: pattern.toString(),
      };
    }
  }
  
  // 2. 检查命令白名单（仅在安全模式下）
  if (isSafeModeEnabled) {
    const baseCommand = getBaseCommand(command);
    
    if (!ALLOWED_COMMANDS.has(baseCommand)) {
      return {
        valid: false,
        reason: `命令 "${baseCommand}" 不在安全模式允许列表中`,
      };
    }
    
    // 3. 检查路径参数
    const pathArgs = extractPathArguments(command);
    const workspacePath = getSafeWorkspacePath();
    
    for (const pathArg of pathArgs) {
      // 检查敏感路径
      if (isSensitivePath(pathArg)) {
        return {
          valid: false,
          reason: `路径 "${pathArg}" 包含敏感信息，禁止访问`,
        };
      }
      
      // 检查是否在工作区内
      // 注意：相对路径需要结合当前工作目录判断
      const isAbsolute = path.isAbsolute(pathArg) || pathArg.startsWith('~');
      
      if (isAbsolute && !isPathInSafeWorkspace(pathArg)) {
        return {
          valid: false,
          reason: `安全模式下禁止访问工作区外的路径: ${pathArg}`,
        };
      }
    }
  } else {
    // 非安全模式下只检查敏感路径
    const pathArgs = extractPathArguments(command);
    
    for (const pathArg of pathArgs) {
      if (isSensitivePath(pathArg)) {
        return {
          valid: false,
          reason: `路径 "${pathArg}" 包含敏感信息，禁止访问`,
        };
      }
    }
  }
  
  return { valid: true };
}

/**
 * 获取命令的安全版本（用于显示）
 * 隐藏敏感信息
 */
export function sanitizeCommandForDisplay(command: string): string {
  // 隐藏可能的 API keys
  let sanitized = command.replace(
    /([A-Za-z0-9_-]{20,})/g,
    (match) => match.slice(0, 6) + '***' + match.slice(-4)
  );
  
  // 隐藏密码参数
  sanitized = sanitized.replace(
    /(-p|--password|--secret|--token)[\s=]+\S+/gi,
    '$1=***'
  );
  
  return sanitized;
}

/**
 * 检查命令是否为只读操作
 */
export function isReadOnlyCommand(command: string): boolean {
  const readOnlyCommands = new Set([
    'ls', 'dir', 'cat', 'type', 'head', 'tail', 'grep', 'find', 'wc',
    'pwd', 'tree', 'which', 'where', 'env', 'printenv',
    'date', 'cal', 'uptime', 'whoami', 'hostname',
    'sort', 'uniq', 'cut',
  ]);
  
  const baseCommand = getBaseCommand(command);
  
  // 检查是否有写入重定向
  if (command.includes('>') && !command.includes('>>')) {
    return false;
  }
  
  return readOnlyCommands.has(baseCommand);
}
