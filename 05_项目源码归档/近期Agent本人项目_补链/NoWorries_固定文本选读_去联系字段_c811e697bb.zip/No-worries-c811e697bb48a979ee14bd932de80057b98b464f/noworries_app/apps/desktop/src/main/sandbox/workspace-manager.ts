/**
 * 安全工作区管理器
 * 
 * 负责：
 * 1. 初始化安全工作区文件夹
 * 2. 复制文件到安全工作区
 * 3. 路径验证
 */

import fs from 'fs';
import path from 'path';
import { app } from 'electron';
import { getSafeMode, setSafeModeWorkspacePath } from '../store/appSettings';

/**
 * 获取默认安全工作区路径
 */
export function getDefaultSafeWorkspacePath(): string {
  return path.join(app.getPath('userData'), 'SafeWorkspace');
}

/**
 * 获取当前安全工作区路径
 * 如果未设置，返回默认路径
 */
export function getSafeWorkspacePath(): string {
  const config = getSafeMode();
  return config.workspacePath || getDefaultSafeWorkspacePath();
}

/**
 * 初始化安全工作区
 * 创建文件夹并设置路径
 */
export async function initializeSafeWorkspace(): Promise<string> {
  const workspacePath = getSafeWorkspacePath();
  
  // 确保目录存在
  if (!fs.existsSync(workspacePath)) {
    fs.mkdirSync(workspacePath, { recursive: true });
    console.log('[SafeWorkspace] Created workspace directory:', workspacePath);
  }
  
  // 创建子目录
  const subDirs = ['imported', 'generated', 'temp'];
  for (const subDir of subDirs) {
    const subPath = path.join(workspacePath, subDir);
    if (!fs.existsSync(subPath)) {
      fs.mkdirSync(subPath, { recursive: true });
    }
  }
  
  // 更新配置
  const config = getSafeMode();
  if (!config.workspacePath) {
    setSafeModeWorkspacePath(workspacePath);
  }
  
  return workspacePath;
}

/**
 * 检查路径是否在安全工作区内
 */
export function isPathInSafeWorkspace(filePath: string): boolean {
  const workspacePath = getSafeWorkspacePath();
  
  // 规范化路径
  const normalizedFilePath = path.resolve(filePath).toLowerCase();
  const normalizedWorkspace = path.resolve(workspacePath).toLowerCase();
  
  // 检查是否是工作区的子路径
  return normalizedFilePath.startsWith(normalizedWorkspace);
}

/**
 * 检查路径是否为敏感目录
 */
export function isSensitivePath(filePath: string): boolean {
  const homeDir = process.env.HOME || process.env.USERPROFILE || '';
  const normalizedPath = path.resolve(filePath).toLowerCase();
  
  const sensitivePatterns = [
    // macOS / Linux
    path.join(homeDir, '.ssh').toLowerCase(),
    path.join(homeDir, '.gnupg').toLowerCase(),
    path.join(homeDir, '.aws').toLowerCase(),
    path.join(homeDir, '.config').toLowerCase(),
    path.join(homeDir, 'Library', 'Keychains').toLowerCase(),
    
    // Windows
    path.join(homeDir, 'AppData', 'Local', 'Microsoft', 'Credentials').toLowerCase(),
    
    // 通用敏感文件名模式
    '.env',
    'credentials',
    'password',
    'secret',
    'private_key',
    'id_rsa',
    'id_ed25519',
  ];
  
  // 检查路径是否包含敏感模式
  return sensitivePatterns.some(pattern => {
    if (pattern.includes(path.sep)) {
      // 完整路径匹配
      return normalizedPath.startsWith(pattern);
    } else {
      // 文件名模式匹配
      return normalizedPath.includes(pattern);
    }
  });
}

/**
 * 复制文件到安全工作区
 * 返回新文件的路径
 */
export async function copyToSafeWorkspace(
  sourcePath: string,
  options?: {
    subDir?: 'imported' | 'generated' | 'temp';
    newFileName?: string;
  }
): Promise<string> {
  const workspacePath = await initializeSafeWorkspace();
  const subDir = options?.subDir || 'imported';
  const targetDir = path.join(workspacePath, subDir);
  
  // 确保目标目录存在
  if (!fs.existsSync(targetDir)) {
    fs.mkdirSync(targetDir, { recursive: true });
  }
  
  // 确定目标文件名
  const sourceBasename = path.basename(sourcePath);
  let targetFileName = options?.newFileName || sourceBasename;
  
  // 检查文件是否已存在，如果存在则添加时间戳
  let targetPath = path.join(targetDir, targetFileName);
  if (fs.existsSync(targetPath)) {
    const ext = path.extname(targetFileName);
    const nameWithoutExt = path.basename(targetFileName, ext);
    const timestamp = Date.now();
    targetFileName = `${nameWithoutExt}_${timestamp}${ext}`;
    targetPath = path.join(targetDir, targetFileName);
  }
  
  // 复制文件
  await fs.promises.copyFile(sourcePath, targetPath);
  console.log('[SafeWorkspace] Copied file:', sourcePath, '->', targetPath);
  
  return targetPath;
}

/**
 * 在安全工作区创建文件
 */
export async function createInSafeWorkspace(
  fileName: string,
  content: string | Buffer,
  options?: {
    subDir?: 'imported' | 'generated' | 'temp';
  }
): Promise<string> {
  const workspacePath = await initializeSafeWorkspace();
  const subDir = options?.subDir || 'generated';
  const targetDir = path.join(workspacePath, subDir);
  
  // 确保目标目录存在
  if (!fs.existsSync(targetDir)) {
    fs.mkdirSync(targetDir, { recursive: true });
  }
  
  // 确定目标文件路径
  let targetPath = path.join(targetDir, fileName);
  
  // 检查文件是否已存在
  if (fs.existsSync(targetPath)) {
    const ext = path.extname(fileName);
    const nameWithoutExt = path.basename(fileName, ext);
    const timestamp = Date.now();
    const newFileName = `${nameWithoutExt}_${timestamp}${ext}`;
    targetPath = path.join(targetDir, newFileName);
  }
  
  // 写入文件
  await fs.promises.writeFile(targetPath, content);
  console.log('[SafeWorkspace] Created file:', targetPath);
  
  return targetPath;
}

/**
 * 列出安全工作区中的文件
 */
export async function listSafeWorkspaceFiles(
  subDir?: 'imported' | 'generated' | 'temp'
): Promise<Array<{
  name: string;
  path: string;
  size: number;
  modifiedAt: Date;
}>> {
  const workspacePath = getSafeWorkspacePath();
  const targetDir = subDir ? path.join(workspacePath, subDir) : workspacePath;
  
  if (!fs.existsSync(targetDir)) {
    return [];
  }
  
  const entries = await fs.promises.readdir(targetDir, { withFileTypes: true });
  const files: Array<{
    name: string;
    path: string;
    size: number;
    modifiedAt: Date;
  }> = [];
  
  for (const entry of entries) {
    if (entry.isFile()) {
      const filePath = path.join(targetDir, entry.name);
      const stats = await fs.promises.stat(filePath);
      files.push({
        name: entry.name,
        path: filePath,
        size: stats.size,
        modifiedAt: stats.mtime,
      });
    }
  }
  
  return files;
}

/**
 * 清空安全工作区的临时文件
 */
export async function cleanTempFiles(): Promise<void> {
  const workspacePath = getSafeWorkspacePath();
  const tempDir = path.join(workspacePath, 'temp');
  
  if (!fs.existsSync(tempDir)) {
    return;
  }
  
  const entries = await fs.promises.readdir(tempDir);
  for (const entry of entries) {
    const filePath = path.join(tempDir, entry);
    await fs.promises.unlink(filePath);
  }
  
  console.log('[SafeWorkspace] Cleaned temp directory');
}

/**
 * 验证并规范化路径
 * 如果路径在安全工作区外且安全模式开启，返回 null
 */
export function validatePath(
  filePath: string,
  isSafeModeEnabled: boolean
): { valid: boolean; normalizedPath: string | null; reason?: string } {
  const normalizedPath = path.resolve(filePath);
  
  // 检查敏感路径
  if (isSensitivePath(normalizedPath)) {
    return {
      valid: false,
      normalizedPath: null,
      reason: '该路径包含敏感信息，禁止访问',
    };
  }
  
  // 安全模式下检查是否在工作区内
  if (isSafeModeEnabled && !isPathInSafeWorkspace(normalizedPath)) {
    return {
      valid: false,
      normalizedPath: null,
      reason: '安全模式下只能访问安全工作区内的文件',
    };
  }
  
  return {
    valid: true,
    normalizedPath,
  };
}
