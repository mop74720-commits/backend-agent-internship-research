/**
 * 记忆巩固系统 (Memory Consolidation)
 *
 * 实现记忆的重要性评估、召回追踪和自动晋升
 * - 记录每个记忆项的召回次数和时间
 * - 计算有效重要性（考虑时间衰减）
 * - 自动将高频引用的记忆晋升到 MEMORY.md
 *
 * 存储路径: workspace/memory-index.json
 */

import fsSync from "node:fs";
import path from "node:path";

import { createSubsystemLogger } from "../logging/subsystem.js";
import { ensureDir } from "./internal.js";

const log = createSubsystemLogger("memory-consolidation");

// ========== 常量 ==========

const MEMORY_INDEX_FILE = "memory-index.json";
const MEMORY_FILE = "MEMORY.md";

// 晋升规则
const PROMOTION_RECALL_THRESHOLD = 3; // 召回次数阈值
const PROMOTION_DAYS_WINDOW = 7; // 统计窗口（天）
const DECAY_RATE = 0.1; // 每天衰减约 10%
const RECALL_BONUS_FACTOR = 0.5; // 召回加成系数

// ========== 类型定义 ==========

/**
 * 记忆项类型
 */
export type MemoryItemType =
  | "keyFact"
  | "episode"
  | "preference"
  | "lesson"
  | "file"
  | "credential";

/**
 * 记忆项数据结构
 */
export interface MemoryItem {
  id: string;
  content: string;
  type: MemoryItemType;
  importance: number; // 初始重要性 1-10
  recallCount: number; // 被检索/引用次数
  lastRecalled: number; // 最后检索时间戳
  createdAt: number; // 创建时间
  source: string; // 来源（session ID, part number 等）
  context?: string; // 上下文描述
  promoted?: boolean; // 是否已晋升到 MEMORY.md
  promotedAt?: number; // 晋升时间
  agentId?: string; // 所属 Agent ID
}

/**
 * 记忆索引存储结构
 */
export interface MemoryIndex {
  version: number;
  items: MemoryItem[];
  lastConsolidation: number; // 最后整理时间
}

// ========== 工具函数 ==========

/**
 * 获取记忆索引文件路径
 */
function getMemoryIndexPath(workspaceDir: string): string {
  return path.join(workspaceDir, MEMORY_INDEX_FILE);
}

/**
 * 获取 MEMORY.md 文件路径
 */
function getMemoryFilePath(workspaceDir: string): string {
  return path.join(workspaceDir, MEMORY_FILE);
}

/**
 * 生成记忆项 ID
 */
function generateMemoryId(): string {
  const timestamp = Date.now().toString(36);
  const random = Math.random().toString(36).substr(2, 5);
  return `mem-${timestamp}-${random}`;
}

// ========== 核心功能 ==========

/**
 * 加载记忆索引
 */
export function loadMemoryIndex(workspaceDir: string): MemoryIndex {
  const indexPath = getMemoryIndexPath(workspaceDir);

  if (fsSync.existsSync(indexPath)) {
    try {
      const content = fsSync.readFileSync(indexPath, "utf-8");
      return JSON.parse(content);
    } catch {
      log.warn("Failed to load memory index, creating new one");
    }
  }

  return {
    version: 1,
    items: [],
    lastConsolidation: 0,
  };
}

/**
 * 保存记忆索引
 */
export function saveMemoryIndex(
  workspaceDir: string,
  index: MemoryIndex,
): void {
  const indexPath = getMemoryIndexPath(workspaceDir);
  fsSync.writeFileSync(indexPath, JSON.stringify(index, null, 2), "utf-8");
}

/**
 * 计算有效重要性（考虑时间衰减和召回频率）
 *
 * 公式: effective = base * decay + recallBonus
 * - decay: 基于最后召回时间的指数衰减
 * - recallBonus: 基于召回次数的对数加成
 */
export function getEffectiveImportance(item: MemoryItem): number {
  const daysSinceRecall =
    (Date.now() - item.lastRecalled) / (24 * 60 * 60 * 1000);
  const decayFactor = Math.exp(-DECAY_RATE * daysSinceRecall);
  const recallBonus = Math.log(item.recallCount + 1) * RECALL_BONUS_FACTOR;

  return item.importance * decayFactor + recallBonus;
}

/**
 * 添加或更新记忆项
 */
export function addMemoryItem(
  workspaceDir: string,
  item: Omit<MemoryItem, "id" | "recallCount" | "lastRecalled" | "createdAt">,
): MemoryItem {
  const index = loadMemoryIndex(workspaceDir);

  // 检查是否已存在相同内容的记忆
  const existing = index.items.find(
    (i) => i.content === item.content && i.type === item.type,
  );

  if (existing) {
    // 更新现有记忆的重要性（取较大值）
    existing.importance = Math.max(existing.importance, item.importance);
    existing.lastRecalled = Date.now();
    existing.recallCount += 1;
    saveMemoryIndex(workspaceDir, index);
    log.debug(`Updated existing memory: ${existing.id}`);
    return existing;
  }

  // 创建新记忆
  const newItem: MemoryItem = {
    ...item,
    id: generateMemoryId(),
    recallCount: 0,
    lastRecalled: Date.now(),
    createdAt: Date.now(),
  };

  index.items.push(newItem);
  saveMemoryIndex(workspaceDir, index);

  log.debug(`Added new memory: ${newItem.id}`);
  return newItem;
}

/**
 * 记录记忆被召回（检索到时调用）
 */
export function onMemoryRecalled(workspaceDir: string, itemId: string): void {
  const index = loadMemoryIndex(workspaceDir);
  const item = index.items.find((i) => i.id === itemId);

  if (item) {
    item.recallCount += 1;
    item.lastRecalled = Date.now();
    saveMemoryIndex(workspaceDir, index);
    log.debug(`Memory recalled: ${itemId} (count: ${item.recallCount})`);
  }
}

/**
 * 批量记录记忆被召回
 */
export function onMemoriesRecalled(
  workspaceDir: string,
  itemIds: string[],
): void {
  if (itemIds.length === 0) return;

  const index = loadMemoryIndex(workspaceDir);
  const now = Date.now();

  for (const itemId of itemIds) {
    const item = index.items.find((i) => i.id === itemId);
    if (item) {
      item.recallCount += 1;
      item.lastRecalled = now;
    }
  }

  saveMemoryIndex(workspaceDir, index);
  log.debug(`Batch recalled ${itemIds.length} memories`);
}

/**
 * 搜索记忆项（关键词匹配）
 */
export function searchMemoryItems(
  workspaceDir: string,
  query: string,
  topK: number = 10,
): MemoryItem[] {
  const index = loadMemoryIndex(workspaceDir);
  const queryLower = query.toLowerCase();
  const queryWords = queryLower.split(/\s+/);

  // 计算每个记忆项的匹配分数
  const scored = index.items.map((item) => {
    const searchText = `${item.content} ${item.context || ""}`.toLowerCase();
    let matchScore = 0;

    for (const word of queryWords) {
      if (searchText.includes(word)) {
        matchScore += 1;
      }
    }

    // 综合匹配分数和有效重要性
    const effectiveImportance = getEffectiveImportance(item);
    const totalScore =
      (matchScore / queryWords.length) * 0.7 +
      (effectiveImportance / 10) * 0.3;

    return { item, score: totalScore };
  });

  // 过滤有匹配的，按分数排序
  return scored
    .filter((s) => s.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, topK)
    .map((s) => s.item);
}

/**
 * 获取晋升候选（N天内被引用M次以上）
 */
export function findPromotionCandidates(
  workspaceDir: string,
  recallThreshold: number = PROMOTION_RECALL_THRESHOLD,
  daysWindow: number = PROMOTION_DAYS_WINDOW,
): MemoryItem[] {
  const index = loadMemoryIndex(workspaceDir);
  const cutoff = Date.now() - daysWindow * 24 * 60 * 60 * 1000;

  return index.items.filter(
    (item) =>
      !item.promoted &&
      item.recallCount >= recallThreshold &&
      item.createdAt >= cutoff,
  );
}

/**
 * 读取 MEMORY.md 内容
 */
export function readMemoryFile(workspaceDir: string): string {
  const filePath = getMemoryFilePath(workspaceDir);
  if (fsSync.existsSync(filePath)) {
    return fsSync.readFileSync(filePath, "utf-8");
  }
  return "";
}

/**
 * 追加内容到 MEMORY.md
 */
export function appendToMemoryFile(
  workspaceDir: string,
  content: string,
): void {
  const filePath = getMemoryFilePath(workspaceDir);
  fsSync.appendFileSync(filePath, content, "utf-8");
}

/**
 * 晋升记忆到 MEMORY.md
 * 添加去重检查，避免重复写入
 */
export function promoteToLongTermMemory(
  workspaceDir: string,
  item: MemoryItem,
): boolean {
  // 读取当前 MEMORY.md
  const memoryContent = readMemoryFile(workspaceDir);

  // 去重检查：检查内容是否已存在
  const escaped = item.content.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const contentPattern = new RegExp(escaped, "i");

  if (contentPattern.test(memoryContent)) {
    log.debug(
      `Item already exists in MEMORY.md, skipping: ${item.content.slice(0, 50)}...`,
    );
    return false;
  }

  // 确定添加到哪个章节
  let section = "## 重要事件";
  if (item.type === "preference") {
    section = "## 用户偏好";
  } else if (item.type === "lesson") {
    section = "## 学到的教训";
  } else if (item.type === "file" || item.type === "credential") {
    section = "## 重要信息";
  }

  // 格式化记忆内容
  const date = new Date(item.createdAt).toLocaleDateString("zh-CN");
  const context = item.context ? ` (${item.context})` : "";
  const newEntry = `- [${date}] [${item.type}] ${item.content}${context}`;

  // 追加到 MEMORY.md
  const appendContent = `\n\n${section}\n\n${newEntry}`;
  appendToMemoryFile(workspaceDir, appendContent);

  log.info(
    `Promoted to MEMORY.md: ${item.content.slice(0, 50)}...`,
  );

  return true;
}

/**
 * 运行记忆整理（检查并执行晋升）
 */
export function runMemoryConsolidation(workspaceDir: string): {
  promoted: number;
  total: number;
} {
  log.info("Running consolidation...");

  const candidates = findPromotionCandidates(workspaceDir);
  let promotedCount = 0;

  for (const candidate of candidates) {
    try {
      const success = promoteToLongTermMemory(workspaceDir, candidate);

      if (success) {
        // 标记为已晋升
        const index = loadMemoryIndex(workspaceDir);
        const item = index.items.find((i) => i.id === candidate.id);
        if (item) {
          item.promoted = true;
          item.promotedAt = Date.now();
          saveMemoryIndex(workspaceDir, index);
        }

        promotedCount++;
      }
    } catch (error) {
      log.error(`Failed to promote ${candidate.id}: ${error}`);
    }
  }

  // 更新最后整理时间
  const index = loadMemoryIndex(workspaceDir);
  index.lastConsolidation = Date.now();
  saveMemoryIndex(workspaceDir, index);

  log.info(
    `Consolidation complete: ${promotedCount}/${candidates.length} promoted`,
  );

  return {
    promoted: promotedCount,
    total: candidates.length,
  };
}

/**
 * 检查是否需要运行记忆整理（每天最多一次）
 */
export function shouldRunConsolidation(workspaceDir: string): boolean {
  const index = loadMemoryIndex(workspaceDir);
  const oneDayAgo = Date.now() - 24 * 60 * 60 * 1000;

  return index.lastConsolidation < oneDayAgo;
}

/**
 * 从 KeyFact 导入记忆项
 */
export function importFromKeyFact(
  workspaceDir: string,
  fact: { type: string; value: string; context?: string },
  source: string,
): MemoryItem {
  // 根据 KeyFact 类型确定记忆项类型和重要性
  let memoryType: MemoryItemType = "keyFact";
  let importance = 5;

  switch (fact.type) {
    case "credential":
      memoryType = "credential";
      importance = 9; // 密码等凭证非常重要
      break;
    case "file":
      memoryType = "file";
      importance = 6;
      break;
    case "user_instruction":
      memoryType = "preference";
      importance = 8; // 用户明确指示很重要
      break;
    case "deadline":
      importance = 8;
      break;
    case "person":
    case "number":
      importance = 5;
      break;
  }

  return addMemoryItem(workspaceDir, {
    content: fact.value,
    type: memoryType,
    importance,
    source,
    context: fact.context,
  });
}

/**
 * 获取记忆统计信息
 */
export function getMemoryStats(workspaceDir: string): {
  total: number;
  promoted: number;
  byType: Record<string, number>;
  avgImportance: number;
} {
  const index = loadMemoryIndex(workspaceDir);

  const byType: Record<string, number> = {};
  let totalImportance = 0;

  for (const item of index.items) {
    byType[item.type] = (byType[item.type] || 0) + 1;
    totalImportance += getEffectiveImportance(item);
  }

  return {
    total: index.items.length,
    promoted: index.items.filter((i) => i.promoted).length,
    byType,
    avgImportance:
      index.items.length > 0 ? totalImportance / index.items.length : 0,
  };
}

/**
 * 清理低重要性的旧记忆
 */
export function cleanupLowImportanceMemories(
  workspaceDir: string,
  threshold: number = 1,
  maxAgeDays: number = 30,
): number {
  const index = loadMemoryIndex(workspaceDir);
  const cutoff = Date.now() - maxAgeDays * 24 * 60 * 60 * 1000;

  const before = index.items.length;

  index.items = index.items.filter((item) => {
    // 保留已晋升的
    if (item.promoted) return true;

    // 保留新创建的
    if (item.createdAt > cutoff) return true;

    // 保留高重要性的
    const effectiveImportance = getEffectiveImportance(item);
    return effectiveImportance >= threshold;
  });

  const removed = before - index.items.length;

  if (removed > 0) {
    saveMemoryIndex(workspaceDir, index);
    log.info(`Cleaned up ${removed} low-importance memories`);
  }

  return removed;
}

/**
 * 获取特定类型的记忆项
 */
export function getMemoryItemsByType(
  workspaceDir: string,
  type: MemoryItemType,
): MemoryItem[] {
  const index = loadMemoryIndex(workspaceDir);
  return index.items.filter((item) => item.type === type);
}

/**
 * 获取最近的记忆项
 */
export function getRecentMemoryItems(
  workspaceDir: string,
  days: number = 7,
  limit: number = 20,
): MemoryItem[] {
  const index = loadMemoryIndex(workspaceDir);
  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;

  return index.items
    .filter((item) => item.createdAt >= cutoff)
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, limit);
}

/**
 * 删除记忆项
 */
export function deleteMemoryItem(
  workspaceDir: string,
  itemId: string,
): boolean {
  const index = loadMemoryIndex(workspaceDir);
  const itemIndex = index.items.findIndex((i) => i.id === itemId);

  if (itemIndex === -1) {
    return false;
  }

  index.items.splice(itemIndex, 1);
  saveMemoryIndex(workspaceDir, index);
  log.debug(`Deleted memory item: ${itemId}`);

  return true;
}
