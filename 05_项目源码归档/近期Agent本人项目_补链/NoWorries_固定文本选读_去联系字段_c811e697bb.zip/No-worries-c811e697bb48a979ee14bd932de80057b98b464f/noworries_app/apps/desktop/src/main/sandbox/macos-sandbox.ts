/**
 * macOS 系统级沙盒执行器
 * 
 * 使用 sandbox-exec 命令实现系统级别的文件访问隔离
 */

import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';
import os from 'os';
import { getSafeWorkspacePath } from './workspace-manager';

/**
 * 转义 sandbox profile 中的路径
 * 处理空格和特殊字符
 */
function escapeSandboxPath(pathStr: string): string {
  // sandbox profile 使用 Scheme-like 语法，需要转义反斜杠
  return pathStr.replace(/\\/g, '\\\\');
}

/**
 * 生成 macOS sandbox profile
 */
function generateSandboxProfile(workspacePath: string): string {
  const homeDir = os.homedir();
  const escapedWorkspace = escapeSandboxPath(workspacePath);
  const escapedHome = escapeSandboxPath(homeDir);
  
  // 获取 Application Support 目录（包含 @noworries 目录）
  const appSupportPath = path.join(homeDir, 'Library', 'Application Support', '@noworries');
  const escapedAppSupport = escapeSandboxPath(appSupportPath);
  
  return `
(version 1)
(deny default)

;; 允许基本的系统访问
(allow process-fork)
(allow process-exec)
(allow signal)

;; 允许读取系统文件和可执行文件
(allow file-read*
  (subpath "/usr")
  (subpath "/bin")
  (subpath "/sbin")
  (subpath "/System")
  (subpath "/Library")
  (subpath "/private/var")
  (subpath "/private/etc")
  (subpath "/dev")
  (subpath "/Applications")
)

;; 允许读写整个 @noworries 应用数据目录（包含安全工作区）
(allow file-read* file-write*
  (subpath "${escapedAppSupport}")
)

;; 允许读写安全工作区（兼容直接指定的路径）
(allow file-read* file-write*
  (subpath "${escapedWorkspace}")
)

;; 允许读写临时目录
(allow file-read* file-write*
  (subpath "/private/tmp")
  (subpath "/var/folders")
)

;; 明确禁止敏感目录
(deny file-read* file-write*
  (subpath "${escapedHome}/.ssh")
  (subpath "${escapedHome}/.gnupg")
  (subpath "${escapedHome}/.aws")
  (subpath "${escapedHome}/Library/Keychains")
  (subpath "${escapedHome}/Library/Cookies")
  (subpath "${escapedHome}/Library/Messages")
  (subpath "${escapedHome}/Library/Mail")
)

;; 允许网络访问（用于下载等操作）
(allow network*)

;; 允许 sysctl 读取
(allow sysctl-read)

;; 允许 mach 服务（关键：需要这个来运行大多数程序）
(allow mach-lookup)

;; 允许 I/O Kit 访问
(allow iokit-open)

;; 允许进程相关操作
(allow process-info*)

;; 允许伪终端操作（关键：需要这个来捕获 stdout/stderr）
(allow file-read* file-write* file-ioctl
  (literal "/dev/tty")
  (regex #"^/dev/ttys[0-9]+$")
  (regex #"^/dev/pty[pqrs][0-9a-f]+$")
)

;; 允许管道和文件描述符操作
(allow file-read* file-write*
  (literal "/dev/null")
  (literal "/dev/zero")
  (literal "/dev/random")
  (literal "/dev/urandom")
)

;; 允许读取用户 shell 配置（但不包括敏感目录）
(allow file-read*
  (literal "${escapedHome}/.bashrc")
  (literal "${escapedHome}/.bash_profile")
  (literal "${escapedHome}/.profile")
  (literal "${escapedHome}/.zshrc")
  (literal "${escapedHome}/.zprofile")
)
`;
}

/**
 * macOS 沙盒执行结果
 */
export interface SandboxExecutionResult {
  stdout: string;
  stderr: string;
  exitCode: number;
  sandboxed: boolean;
}

/**
 * 在 macOS 沙盒中执行命令
 * 注意：新版 macOS (10.15+) 对 sandbox-exec 有更多限制
 * 如果 sandbox-exec 失败，会回退到环境变量隔离模式
 */
export async function executeMacOSSandbox(
  command: string,
  options?: {
    workingDir?: string;
    timeout?: number;
    env?: Record<string, string>;
  }
): Promise<SandboxExecutionResult> {
  const workspacePath = getSafeWorkspacePath();
  const timeout = options?.timeout || 30000;
  
  // 确定工作目录
  const cwd = options?.workingDir || workspacePath;
  
  // 构建安全的环境变量
  const safeEnv = {
    ...process.env,
    ...options?.env,
    HOME: workspacePath,
    TMPDIR: path.join(workspacePath, 'temp'),
    // 限制 PATH 只包含必要的目录
    PATH: '/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:/Applications/NoWorries.app/Contents/Resources/python/arm64/python/bin',
  };
  
  // 首先尝试使用 sandbox-exec
  const sandboxResult = await tryExecuteWithSandbox(command, cwd, timeout, safeEnv, workspacePath);
  
  // 如果 sandbox-exec 成功且有输出，直接返回
  if (sandboxResult.sandboxed && (sandboxResult.stdout || sandboxResult.stderr || sandboxResult.exitCode !== 0)) {
    return sandboxResult;
  }
  
  // 如果 sandbox-exec 返回空输出，可能是 macOS 限制导致
  // 回退到环境变量隔离模式
  console.log('[macOS-sandbox] sandbox-exec returned empty output, falling back to env isolation');
  
  return executeWithEnvIsolation(command, cwd, timeout, safeEnv);
}

/**
 * 尝试使用 sandbox-exec 执行
 */
async function tryExecuteWithSandbox(
  command: string,
  cwd: string,
  timeout: number,
  env: Record<string, string | undefined>,
  workspacePath: string
): Promise<SandboxExecutionResult> {
  // 生成沙盒 profile
  const profile = generateSandboxProfile(workspacePath);
  
  // 创建临时 profile 文件
  const profilePath = path.join(os.tmpdir(), `noworries-sandbox-${Date.now()}.sb`);
  
  try {
    fs.writeFileSync(profilePath, profile);
    
    return new Promise((resolve) => {
      // 使用 sandbox-exec 执行命令
      const proc = spawn('sandbox-exec', ['-f', profilePath, 'bash', '-c', command], {
        cwd,
        env: env as NodeJS.ProcessEnv,
        timeout,
      });
      
      let stdout = '';
      let stderr = '';
      
      proc.stdout.on('data', (data) => {
        stdout += data.toString();
      });
      
      proc.stderr.on('data', (data) => {
        stderr += data.toString();
      });
      
      proc.on('close', (code) => {
        // 清理临时 profile 文件
        try {
          fs.unlinkSync(profilePath);
        } catch {
          // 忽略清理错误
        }
        
        resolve({
          stdout: stdout.slice(0, 50000),
          stderr: stderr.slice(0, 10000),
          exitCode: code ?? 0,
          sandboxed: true,
        });
      });
      
      proc.on('error', (err) => {
        // 清理临时 profile 文件
        try {
          fs.unlinkSync(profilePath);
        } catch {
          // 忽略清理错误
        }
        
        resolve({
          stdout,
          stderr: `Sandbox execution error: ${err.message}`,
          exitCode: 1,
          sandboxed: false,
        });
      });
    });
  } catch (error) {
    // 清理临时 profile 文件
    try {
      fs.unlinkSync(profilePath);
    } catch {
      // 忽略清理错误
    }
    
    return {
      stdout: '',
      stderr: `Failed to create sandbox profile: ${error}`,
      exitCode: 1,
      sandboxed: false,
    };
  }
}

/**
 * 使用环境变量隔离执行命令
 * 当 sandbox-exec 不可用时的回退方案
 */
async function executeWithEnvIsolation(
  command: string,
  cwd: string,
  timeout: number,
  env: Record<string, string | undefined>
): Promise<SandboxExecutionResult> {
  return new Promise((resolve) => {
    const proc = spawn('bash', ['-c', command], {
      cwd,
      env: env as NodeJS.ProcessEnv,
      timeout,
    });
    
    let stdout = '';
    let stderr = '';
    
    proc.stdout.on('data', (data) => {
      stdout += data.toString();
    });
    
    proc.stderr.on('data', (data) => {
      stderr += data.toString();
    });
    
    proc.on('close', (code) => {
      resolve({
        stdout: stdout.slice(0, 50000),
        stderr: stderr.slice(0, 10000),
        exitCode: code ?? 0,
        sandboxed: false, // 标记为非沙盒模式
      });
    });
    
    proc.on('error', (err) => {
      resolve({
        stdout,
        stderr: `Execution error: ${err.message}`,
        exitCode: 1,
        sandboxed: false,
      });
    });
  });
}

/**
 * 检查 macOS sandbox-exec 是否可用
 */
export async function isMacOSSandboxAvailable(): Promise<boolean> {
  return new Promise((resolve) => {
    const proc = spawn('which', ['sandbox-exec']);
    
    proc.on('close', (code) => {
      resolve(code === 0);
    });
    
    proc.on('error', () => {
      resolve(false);
    });
  });
}
