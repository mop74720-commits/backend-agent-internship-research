# 简历与候选人案例：目录导览与直达索引

> **快速看真实简历**：为方便在资源管理器中直接打开脱敏 PDF、PNG 与网页版简历，已将 11 份视觉简历按 **`序号_编号_方向_标签`** 统一汇总至 [`argon_精选简历直达/`](argon_精选简历直达) 文件夹，同时你也可以打开可视化网页 [`argon_候选人与简历图册.html`](argon_候选人与简历图册.html) 按赛道筛选与对比。

## 一、11 份含真实视觉附件的简历直达表

| 编号 | 候选人方向与背景 | 可读直达文件（点击直接打开） | 图册锚点 |
| :---: | :--- | :--- | :---: |
| **CV30** | Andrew Wang：字节后端与Agent实习完整专业履历 | [`argon_01_CV30_Agent与后端_字节CreatorAssistant实习简历.pdf`](argon_精选简历直达/argon_01_CV30_Agent与后端_字节CreatorAssistant实习简历.pdf) | [图册卡片](argon_候选人与简历图册.html#CV30) |
| **CV31** | 黄一航：中科曙光Agent实习完整履历与本人项目 | [`argon_02_CV31_Agent工程_中科曙光实习与开源项目简历.pdf`](argon_精选简历直达/argon_02_CV31_Agent工程_中科曙光实习与开源项目简历.pdf) | [图册卡片](argon_候选人与简历图册.html#CV31) |
| **CV28** | DavidHLP：近期后端实习完整履历与本人开源项目直接关联 | [`argon_03_CV28_后端开发_DavidHLP完整网页履历.html`](argon_精选简历直达/argon_03_CV28_后端开发_DavidHLP完整网页履历.html) | [图册卡片](argon_候选人与简历图册.html#CV28) |
| **CV23** | 张恒华 / Henghua Zhang：近期实习完整公开履历脱敏副本 | [`argon_04_CV23_后端开发_zhh2001完整网页履历.html`](argon_精选简历直达/argon_04_CV23_后端开发_zhh2001完整网页履历.html) | [图册卡片](argon_候选人与简历图册.html#CV23) |
| **CV24** | 林祥庆 / Huoma LXQ：近期实习完整公开履历脱敏副本 | [`argon_05_CV24_Agent工程_huomalxq双段实习完整简历.pdf`](argon_精选简历直达/argon_05_CV24_Agent工程_huomalxq双段实习完整简历.pdf) | [图册卡片](argon_候选人与简历图册.html#CV24) |
| **CV01** | 后端秋招24场100%胜率的SSP，真的只是靠卷技术吗？ | [`argon_06_CV01_后端SSP_字节实习通知服务简历片段.png`](argon_精选简历直达/argon_06_CV01_后端SSP_字节实习通知服务简历片段.png) | [图册卡片](argon_候选人与简历图册.html#CV01) |
| **CV06** | 双非一本获腾讯IEG、百度、字节等offer：wasabi的实习与开源简历片段 | [`argon_07_CV06_后端开发_实习与开源经历简历片段.png`](argon_精选简历直达/argon_07_CV06_后端开发_实习与开源经历简历片段.png) | [图册卡片](argon_候选人与简历图册.html#CV06) |
| **OBS11** | 后端开发收藏内容分享 附完整脱敏简历 | [`argon_08_OBS11_后端对照_一页式网盘与RPC简历图.png`](argon_精选简历直达/argon_08_OBS11_后端对照_一页式网盘与RPC简历图.png) | [图册卡片](argon_候选人与简历图册.html#OBS11) |
| **OBS05** | 郭天宇 / Tianyu Guo：研究/AI Infra完整履历脱敏对照 | [`argon_09_OBS05_算法对照_大模型训练研究简历.pdf`](argon_精选简历直达/argon_09_OBS05_算法对照_大模型训练研究简历.pdf) | [图册卡片](argon_候选人与简历图册.html#OBS05) |
| **OBS06** | 李忠智 / Zhongzhi Li：研究/AI Infra完整履历脱敏对照 | [`argon_10_OBS06_算法对照_强化学习与多模态简历.pdf`](argon_精选简历直达/argon_10_OBS06_算法对照_强化学习与多模态简历.pdf) | [图册卡片](argon_候选人与简历图册.html#OBS06) |
| **OBS07** | Hanrong Zhang：研究/AI Infra完整履历脱敏对照 | [`argon_11_OBS07_AI_Infra对照_推理加速与系统简历.pdf`](argon_精选简历直达/argon_11_OBS07_AI_Infra对照_推理加速与系统简历.pdf) | [图册卡片](argon_候选人与简历图册.html#OBS07) |

## 二、本目录文件结构说明

- [`argon_候选人与简历图册.html`](argon_候选人与简历图册.html)：**【首选入口】** 含 6 大简历改写模板 + 34 位核心候选人 + 4 份视觉对照交互图册。
- [`argon_34位候选人案例合集.md`](argon_34位候选人案例合集.md)：将 `逐条分析底稿/` 下的 34 份零散 TXT 整合为单文件可读合集。
- `argon_精选简历直达/`：按中文可读文件名整理好的 11 份 PDF / PNG / HTML 简历副本。
- `核心Agent履历_脱敏副本/`、`核心后端履历_脱敏副本/`、`履历对照_脱敏副本/`、`简历视觉材料/`、`简历预览/`：底层原始归档路径（供图册与校验脚本引用）。
