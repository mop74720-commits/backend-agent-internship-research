# Agent实习阅读顺序

严格近期先看；缺年份但明确实习者保留高相关选读并提示时间。历史SSP用于具体模块与贡献表达，不能当当前门槛。

CV31近期中科曙光Agent实习有完整CV和本人源码直链；框架继承、模块风险、本人面经及SSP缺口另列。CV30为互联网大厂内部Agent履历，无公开内部源码。

## 履历与面经

- [CV31 黄一航：中科曙光Agent实习完整履历与本人项目](https://imyihang.com/)：实习／近期确认

- [CV30 Andrew Wang：字节后端与Agent实习完整专业履历](https://andrewtheterp.com/)：实习／近期确认

- [CV07 等闲king：2025后端实习offer与本人Agent项目深挖](https://www.nowcoder.com/feed/main/detail/a3e209dc72154cb586a65a2d60fc5c3d)：实习／近期确认

- [CV24 林祥庆 / Huoma LXQ：近期实习完整公开履历脱敏副本](https://huomalxq.github.io/resume/)：实习／近期确认

- [CV25 2026暑期：蚂蚁AlipayPlus智能体应用offer、TikTok后端OC及本人面经](https://ac.nowcoder.com/discuss/1610772)：实习／近期确认

- [CV26 金蝶/讯飞Agent实习经历、360实习offer与多家公司项目深挖](https://www.nowcoder.com/feed/main/detail/202664206f23428ebea5d513ea261c9d?sourceSSR=subject)：实习／年份未知

- [CV08 商汤大模型算法应用实习面经（已offer）](https://www.nowcoder.com/feed/main/detail/2762070c2c52472da06bf9ee59518d79)：实习／年份未知

- [CV09 27双非本：腾讯IEG游戏安全后台实习面经](https://www.nowcoder.com/feed/main/detail/9ecd5997a7d74f3fa885695032f32065?sourceSSR=dynamic&weFlow=true)：实习／近期确认

- [INT42 26.4百度大模型生态集成实习，新鲜面经~](https://www.nowcoder.com/feed/main/detail/62d4ca9866d84d63bf6eafbb0a947bb8?sourceSSR=search)：实习／近期确认

- [INT47 小红书大模型平台 Agentic 全栈研发练习生 一面凉经](https://www.nowcoder.com/feed/main/detail/e5e9311a623940eead6ec98c65e7f9e8?sourceSSR=search)：实习／近期确认

- [INT74 MINISO名创优品Agent开发实习一面](https://www.nowcoder.com/feed/main/detail/f844a4ac20be44bc9b3f756bd0ebb84c?sourceSSR=subject)：实习／年份未知

- [INT72 深信服Agent开发实习生一面二面](https://www.nowcoder.com/feed/main/detail/14b2c379ae434062a009aefea9fc5df9?sourceSSR=subject)：实习／年份未知

- [INT73 九号公司Agent开发实习一面，1h30m](https://www.nowcoder.com/feed/main/detail/c0b53fdd38e041d2bc779753d04ee2ce?sourceSSR=subject)：实习／年份未知

- [INT75 小红书Agent开发实习生一面凉经，附百度Agent凉经](https://www.nowcoder.com/feed/main/detail/e319aadc79a9479397a6661a7f5ca088?sourceSSR=subject)：实习／年份未知

- [INT76 科大讯飞（AI相关岗）一面](https://www.nowcoder.com/feed/main/detail/1c425483516d4af1813d2dcdf98f4781?sourceSSR=users)：实习／年份未知

- [INT01 字节跳动-Agent开发实习生 一面（45分钟）](https://www.nowcoder.com/feed/main/detail/931a8a935a5e4b4f8d0b71cd4e818604)：实习／年份未知

- [INT02 4.21 字节agent开发实习一面分享](https://www.nowcoder.com/feed/main/detail/e0d5745e28b64db79ba1832f958b758c)：实习／年份未知

- [INT40 智能体与大模型应用工程实习 一面](https://www.nowcoder.com/discuss/894720138258173952?sourceSSR=post)：实习／年份未知

- [INT41 腾讯实习 ai应用开发后端面经分享](https://www.nowcoder.com/feed/main/detail/144c6ae334b24c0aa643ed43ccfebaac?sourceSSR=dynamic)：实习／年份未知

- [INT54 字节数据中台Agent全栈面经](https://www.nowcoder.com/feed/main/detail/fe77496948f74b4091ab4bb6e8156c8b?sourceSSR=dynamic)：实习／年份未知

- [INT55 字节Agent开发后端 日常实习一面凉面](https://www.nowcoder.com/discuss/932295617999622144)：实习／年份未知

- [INT84 9.7百度agent开发日常实习面经](https://www.nowcoder.com/feed/main/detail/bb8c28105f364770b57ff5eb5649cc60)：实习／年份未知

- [INT67 阿里云Agent一面：项目取舍、RPC与AI Coding热更新](https://www.nowcoder.com/discuss/872120976190816256)：未知／年份未知

- [INT82 字节- AML大模型后端开发-一二面](https://www.nowcoder.com/feed/main/detail/25df6c4042a742dbbe420db58c3abf0c)：未知／年份未知

- [INT83 百度一面面经](https://www.nowcoder.com/feed/main/detail/fa3706d7d465417f83d550b7f471941b)：未知／年份未知

## 项目指定模块

- [PRO04 Ragent：Java Agent与RAG全链路参考](https://github.com/nageoffer/ragent)｜精读：Java方向重点比较Workflow/Agent、状态与拒绝处理，先确认边界再看功能。
  模块：agent/src/main/java/com/nageoffer/ai/ragent/agent/confirm/AgentConfirmDenialMiddleware.java；agent/src/main/java/com/nageoffer/ai/ragent/agent/dao/mapper/AgentStateMapper.java；agent/src/main/java/com/nageoffer/ai/ragent/agent/config/AgentEngineConfiguration.java
  边界：固定源码可审，权限局部边界明确；未核业务评测和成功候选人链。

- [PRO05 DeerFlow：长任务运行与隔离参考](https://github.com/bytedance/deer-flow)｜选读：先读检查点恢复契约和鉴权，再按需要读运行系统；平台范围较大。
  模块：backend/app/gateway/auth_middleware.py；backend/app/gateway/checkpoint_retention.py；backend/docs/checkpoint-retention-contract.md；backend/tests/test_checkpoint_retention_contract.py
  边界：源码和契约测试可审，DRAFT边界保留；无业务评测实测和候选人归属。

- [PRO06 Open Deep Research：研究编排与评测参考](https://github.com/langchain-ai/open_deep_research)｜精读：优先看评测器与基线配置，再沿研究循环回看质量来源；适合补评测短板。
  模块：src/open_deep_research/deep_researcher.py；tests/evaluators.py；tests/run_evaluate.py；tests/pairwise_evaluation.py
  边界：源码与评测脚本可审；运行、裁判校准、实际成本和录用链均未验证。

- [PRO07 RAGFlow：文档解析与检索工程参考](https://github.com/infiniflow/ragflow)｜精读：RAG方向先读召回诊断与SDK，分清检索质量、生成质量、HTTP性能三者。
  模块：docs/guides/dataset/retrieval_testing.md；example/sdk/retrieval_example.py；test/benchmark/README.md；test/README.md
  边界：固定源码和检索/测试材料可审；全Agent循环、权限及准确率未核。

- [PRO10 Casdoor：从候选人开源条目拆读身份与权限工程](https://github.com/casdoor/casdoor)｜选读：仅作工具背后业务授权的配套材料，不列为已核Agent求职项目。
  模块：object/permission_enforcer.go；object/permission_enforcer_test.go；object/token_jwt_key.go；object/token_jwt_key_test.go
  边界：有实际简历片段和平台源码；贡献归属/具体PR缺失，完整协议验证未做。

- [PRO11 AgentScope：工具权限、状态与中断测试的工程参考](https://github.com/agentscope-ai/agentscope)｜精读：优先读权限引擎和中断测试，学会把机制保证与业务授权/任务成功分开。
  模块：src/agentscope/permission/_engine.py；src/agentscope/agent/_agent.py；src/agentscope/state/_state.py；tests/permission_engine_test.py
  边界：固定源码与机制测试可审；无业务任务基准实测或成功者归属。

- [PRO12 OpenManus：紧凑 Agent循环、工具调用与沙箱边界对照](https://github.com/FoundationAgents/OpenManus)｜精读：范围较紧凑，先读完整工具循环，再对照AgentScope的权限/中断与评测缺口。
  模块：app/agent/base.py；app/agent/toolcall.py；app/sandbox/core/sandbox.py；tests/sandbox/test_sandbox.py
  边界：固定源码与边界可审；沙箱测试未运行，任务成功率及权限整体未验证。

- [PRO13 Hello-Agents：评测方法与教材代码参考，整库不归档](https://github.com/datawhalechina/hello-agents)｜选读：先补第十二章评价方法，分清示例、预期输出和实际基准；按缺口读章节。
  模块：LICENSE.txt；code/chapter12/README.md；code/chapter12/03_bfcl_custom_evaluation.py；code/chapter12/04_run_bfcl_evaluation.py
  边界：指定固定源码/许可已读，无整仓ZIP；章节依赖和许可混合，不提供统一运行认证。

- [PRO18 Crony：Go分布式定时任务工程参考，未证作者SSP](https://github.com/tmnhs/Crony/tree/00df3df90306811332d0aff66a259cf90ad6954f)｜选读：仅作为Agent长任务调度/重试的后端参照；本身不是Agent或SSP成功者项目。
  模块：README.md；go.mod；common/pkg/etcdclient/registry.go；admin/internal/service/node.go
  边界：本人归属、关键源码与MIT已核；公司名称/录用档位未知，未归档整仓配置。

- [PRO20 UltiCode：完整履历直接点名的本人判题平台](https://github.com/DavidHLP/UltiCode/tree/d53b582e2fae32ef644642651086df0e5ed3163d)｜选读：可补异步任务可靠性与服务基础；不作为Agent项目证明。
  模块：services/submission/src/main/java/com/ulticode/modules/queue/outbox/dispatcher/JudgeOutboxDispatcher.java
  边界：本人履历→点名源码直接；面经仅主题对应，公司/事件年/结果未知；现版晚于实习。

- [PRO21 ResiCache：完整履历直接点名的本人缓存扩展](https://github.com/DavidHLP/ResiCache/tree/1ed3be36af0795a363d624d38de676c0d00b4cf7)｜选读：可补异步任务可靠性与服务基础；不作为Agent项目证明。
  模块：src/main/java/io/github/davidhlp/spring/cache/redis/cache/SyncSupport.java
  边界：本人履历→点名源码直接；面经仅主题对应，公司/事件年/结果未知；现版晚于实习。

- [PRO24 Sprout：任务树编排、预算与文本打分边界](https://github.com/hlbbbbbbb/sprout/tree/3ecd36e5a4eac42ae90be854e415857fd0f3cf7c)｜选读：研究机制与失败路径；未验证为成熟可直接复用的成品。
  模块：sprout/task_tree.py；sprout/worker.py；sprout/llm.py；examples/benchmark.py；tests/test_task_tree.py
  边界：近期Agent实习完整CV→本人主页/项目直接链接已建立；本人面经、SSP及运行验证仍缺。

- [PRO25 NoWorries：桌面记忆与跨平台隔离风险选读](https://github.com/hlbbbbbbb/No-worries/tree/c811e697bb48a979ee14bd932de80057b98b464f)｜选读：研究机制与失败路径；未验证为成熟可直接复用的成品。
  模块：noworries_app/apps/desktop/src/main/sandbox/macos-sandbox.ts；noworries_app/apps/desktop/src/main/sandbox/windows-sandbox.ts；noworries_app/apps/desktop/src/main/sandbox/workspace-manager.ts；noworries_app/apps/desktop/src/main/clawdbot/memory/episode-memory.ts；noworries_app/apps/desktop/src/main/clawdbot/memory/memory-consolidation.ts
  边界：近期Agent实习完整CV→本人主页/项目直接链接已建立；本人面经、SSP及运行验证仍缺。

- [PRO23 QuantHarbor：多Agent状态与执行隔离风险对照](https://github.com/shufengc/QuantHarbor/tree/f0d6380e9846f84f10be5f284fec40d42cfb34f9)｜待核：适合研究状态/工具与权限边界的反例；不作为成熟成品推荐。
  模块：src/agents/base_agent.py；src/utils/code_executor_async.py；src_rag/core/report_pipeline.py
  边界：腾讯实习者主页→本人项目直链成立；课程复用、当前版本和个人比例另核，面经/SSP缺。

个人项目设计继续暂缓。
