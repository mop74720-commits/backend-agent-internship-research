整理日期：2026-10-23

这是作者完整公开HTML履历的整理者脱敏转录，保留原文件已有的全部专业模块；删除邮箱、电话、站点前置结构化联系元数据。不是企业核验结果，也不是求职时投递版本证明。莉莉丝Golang后端和简文投资全栈经历属于近期实习；网易2026年岗位是游戏客户端。原稿仅列项目名称、角色、主体与时间，缺少具体职责、技术难点及开源源码，不能补写。

原页：https://zhh2001.github.io/resume

固定版本：https://raw.githubusercontent.com/zhh2001/zhh2001.github.io/bdd665acc8d73c80aefc7260fdeeef598fabf48f/docs/resume.md

---

# 张恒华

**研究方向**：软件定义网络、可编程数据平面、带内网络遥测

**GitHub**：<https://github.com/zhh2001>

## 教育背景

2024.09-2027.06 上海工程技术大学 （硕士）\
电子电气工程学院 | 电子信息

2018.09-2022.06 湖南工商大学 （本科）\
理学院 | 数据科学与大数据技术

## 科研成果

1. **Henghua Zhang**, Jue Chen, Yuhang Wu, Yujie Xiong. [TT-INT: A time-threshold-based lightweight in-band network telemetry scheme for P4-enabled programmable networks](https://doi.org/10.1109/tnsm.2026.3688086). *IEEE Transactions on Network and Service Management*, 2026. （中科院二区） （CCF推荐期刊）
2. **Henghua Zhang**, Jue Chen, Haidong Peng, Junru Chen. [MAT4PM: Machine learning-guided adaptive threshold control for P4-based monitoring in SDNs](https://doi.org/10.1109/tnsm.2026.3677416). *IEEE Transactions on Network and Service Management*, 2026. （中科院二区） （CCF推荐期刊）
3. **Henghua Zhang**, Jue Chen. [A measurement methodology for BMv2-based P4 emulation: Fidelity and operating regimes on a single WSL2 host](https://doi.org/10.1016/j.comcom.2026.108708). *Computer Communications*, 2026. （中科院三区） （CCF推荐期刊）
4. Jue Chen, Haidong Peng, **Henghua Zhang**, Junru Chen, Xihe Qiu. [SCV-IDS: CNN-ViT cross-attention on serialized traffic images for spatiotemporal intrusion detection](https://doi.org/10.1109/jiot.2026.3695912). *IEEE Internet of Things Journal*, 2026. （中科院一区TOP） （CCF推荐期刊）
5. Junru Chen, Jue Chen, **Henghua Zhang**, Haidong Peng. [ATHGID: Two-stage graph intrusion detection via attention-fused network-host feature and producer-consumer parallelization](https://doi.org/10.1016/j.comnet.2026.112418). *Computer Networks*, 2026. （中科院三区） （CCF-B类期刊）

另有多篇一作在投

## 学术服务

期刊审稿人：

- *Future Generation Computer Systems* (FGCS)

会议审稿人：

- ACM Symposium on Cloud Computing (SoCC)

## 实习经历

2026.09-至今 网易游戏\
杭州 | 奇点事业部 | 游戏客户端

2026.03-2026.06 莉莉丝游戏\
上海 | 发行中心 | Golang后端

2025.09-2026.03 上海简文私募基金管理有限公司\
上海 | 投研部 | Golang全栈

2024.01-2024.08 华为上海研究所\
上海 | 海思半导体与器件业务部 | 软件开发

2022.07-2023.03 多益网络\
广州 | 技术平台 | 软件后端

2021.07-2021.09 湖南广播电视台\
长沙 | 数据互动事业部 | Web前端

## 获奖情况

- 2026 年硕士研究生**国家奖学金**
- 2026 年上海工程技术大学优秀学生
- 2026 年上海工程技术大学研究生学业奖学金一等奖
- 2025 年上海工程技术大学研究生学业奖学金三等奖
- 第六届上海市研究生智慧城市创意设计大赛三等奖
- 2025 年上海工程技术大学产教融合优秀学生
- 2024 年上海工程技术大学研究生新生学业奖学金

## 技能证书

- 计算机技术与软件专业技术资格证书（中级 | 软件设计师）
- 计算机技术与软件专业技术资格证书（初级 | 程序员）
- 全国计算机等级考试（二级 | MySQL数据库程序设计）
- 全国计算机等级考试（二级 | Python语言程序设计）
- 全国计算机等级考试（二级 | C++语言程序设计）
- 全国计算机等级考试（二级 | C语言程序设计）
- 全国计算机等级考试（二级 | Web程序设计）

## 项目经历

2026.09-至今 萤火突击\
项目主体：网易游戏\
角色：游戏客户端工程师

2026.03-2026.06 LiLAC本地化平台\
项目主体：莉莉丝游戏\
角色：Golang后端工程师

2025.09-2026.03 LC-Event交易平台\
项目主体：简文投资\
角色：Golang全栈工程师

2025.09-2026.03 LC-SBL海外借券\
项目主体：简文投资\
角色：Python后端工程师

2025.09-2025.10 涨停原因分析工具\
项目主体：简文投资\
角色：Python全栈工程师

2024.11-2025.02 懂经营\
项目主体：红砥智能\

2024.01-2024.08 凤凰山\
项目主体：华为上研\
角色：Python工程师

2022.12-2023.03 内容审核平台\
项目主体：多益网络\
角色：Python后端工程师

2022.09-2023.03 随手扫描\
项目主体：多益网络\
角色：Python后端工程师

2022.07-2022.09 员工客服中心\
项目主体：多益网络\
角色：Python后端工程师

2021.07-2021.09 铁粉电台后台管理系统\
项目主体：湖南广电\
角色：Web前端工程师

<Comments />