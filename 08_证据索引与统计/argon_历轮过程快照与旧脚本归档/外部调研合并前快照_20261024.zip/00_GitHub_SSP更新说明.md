# GitHub SSP专项更新

新增4份候选人分析，补强CV02；新增4份项目分析及源码包、3份面经资料、1份对照案例。

- [专项报告](01_调研报告/GitHub_SSP项目与面经专项.html)
- [专项PDF](01_调研报告/GitHub_SSP项目与面经专项.pdf)
- [阅读导航](01_调研报告/GitHub_SSP阅读导航.md)
- [完整搜索目录](01_调研报告/index.html)
- [统计与分组](08_证据索引与统计/GitHub_SSP专项统计.json)
- [本轮源码归档清单](05_项目源码归档/GITHUB_SSP_SOURCE_MANIFEST.json)

近期Agent SSP成熟项目强关联仍未找到；完整CV仍为0；所有录用均作者自述；项目未运行。个人项目设计暂缓。
